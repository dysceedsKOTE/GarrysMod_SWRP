if SERVER then return end
local function HIDEHud (hud)
	for k, v in pairs{ "CHudHealth", "CHudBattery", "CHudAmmo" } do
		if hud == v then return false end
	end
end

net.Receive("defchudsendserverblack_cl", function()
local pluker = net.ReadEntity()	
local plukertrue = net.ReadString()
chat.AddText( Color( 0,0,0 ), "[Чёрный код] ("..plukertrue..") - обьявил чёрный код!")
surface.PlaySound( "xsignal/black.wav" )
end)

net.Receive("defchudsendserverviolet_cl", function()
local pluker = net.ReadEntity()	
local plukertrue = net.ReadString()
chat.AddText( Color( 200,100,200 ), "[Фиолетовый код] ("..plukertrue..") - обьявил фиолетовый код!")
surface.PlaySound( "xsignal/violet.wav" )
end)

net.Receive("defchudsendserverred_cl", function()
local pluker = net.ReadEntity()	
local plukertrue = net.ReadString()
chat.AddText( Color( 255,0,0 ), "[Красный код] ("..plukertrue..") - обьявил красный код!")
surface.PlaySound( "xsignal/red.wav" )
end)

net.Receive("defchudsendserveryellow_cl", function()
local pluker = net.ReadEntity()	
local plukertrue = net.ReadString()
chat.AddText( Color( 255,255,0 ), "[Жёлтый код] ("..plukertrue..") - обьявил жёлтый код!")
surface.PlaySound( "xsignal/yellow.wav" )
end)

net.Receive("defchudsendservergreen_cl", function()
local pluker = net.ReadEntity()	
local plukertrue = net.ReadString()
chat.AddText( Color(0,230,0), "[Зелёный код] ("..plukertrue..") - обьявил зелёный код!")
surface.PlaySound( "xsignal/green.wav" )
end)

net.Receive("f1menu_to_hud_clientprikazupdate", function()
local player = net.ReadEntity()
local prikaz = net.ReadString()
if prikaz == "null" then if IsValid(zadanietextusx) then zadanietextusx:Remove() end end
if IsValid(zadanietextusx) then
zadanietextusx:Remove()
zadanietextusx = vgui.Create("RichText")
zadanietextusx:SetPos(ScrW()*0.802, ScrH()*0.075)
zadanietextusx:SetSize(ScrW()*0.2, ScrH()*0.15)
zadanietextusx:SetText(prikaz)
zadanietextusx.Paint = function( self, w, h )
draw.RoundedBox( 0, 0, 0, w, h, Color( 30,30,30, 170 ) )
end
zadanietextusx:SetMouseInputEnabled( false )
end
end)

hook.Add("HUDShouldDraw","Hide", HIDEHud)

timer.Create( "hudtimerupdate", 1, 0, function()
local function sendservhud()
net.Start('HUDmyservg')   
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
sendservhud()
end)

----

surface.CreateFont( "InfoHP", {
	font = "Exo 2 Semi Bold",
	extended = true,
	size = 18,
	weight = 500,
	antialias = true,
	underline = false,
	shadow = true,
} )

surface.CreateFont( "NewInfoHP", {
	font = "Exo 2 Semi Bold",
	extended = true,
	size = 75,
	weight = 500,
	antialias = true,
	underline = false,
	shadow = true,
} )

surface.CreateFont( "littleInfoHP", {
	font = "Exo 2 Semi Bold",
	extended = true,
	size = 16,
	weight = 700,
	antialias = true,
	underline = false,
	shadow = false,
} )

surface.CreateFont( "littleInfoHP22", {
	font = "Exo 2 Semi Bold",
	extended = true,
	size = 20,
	weight = 700,
	antialias = true,
	underline = false,
	shadow = false,
} )


--[[net.Receive("HUDmyinfog", function()
local name = net.ReadString()
local number = net.ReadString()
local legion = net.ReadString()
local rank = net.ReadString()
local spec = net.ReadString()
local admindpl = net.ReadString()
local count = net.ReadString()
local radio = net.ReadString()
local defc = net.ReadString()
local prikaz = net.ReadString()
local cloak = net.ReadString()
local interdist = net.ReadString()
local intercom = net.ReadString()
local frozen = net.ReadString()
local statminaboost = net.ReadString()
hook.Add( "HUDPaint", "HUDPaint_DrawABox", function()
local hpmah = math.ceil((LocalPlayer():Health() / LocalPlayer():GetMaxHealth()) * 100)
local armah = math.ceil((LocalPlayer():Armor() / LocalPlayer():GetMaxArmor()) * 100)
local stmah = math.ceil((LocalPlayer():GetNWInt( LocalPlayer():SteamID64().."dysceedsststminaworks" ) / (100 * statminaboost)) * 100)
local camerapos = LocalPlayer():GetEyeTrace().StartPos
local cameraangle = EyeAngles()
-- HP
if LocalPlayer():Health() > 1 then
draw.RoundedBox(0, ScrW()*0.01, ScrH()*0.96, hpmah * 3, ScrH()*0.01, Color(255,155,155))
surface.SetDrawColor( Color( 200, 100, 100, 255 ) )
surface.DrawOutlinedRect( ScrW()*0.01, ScrH()*0.96, 100 * 3, ScrH()*0.01 )
draw.SimpleText( LocalPlayer():Health(), "InfoHP", 100 * 3 + 25, ScrH()*0.9555, Color(255,255,255) )
end
--
-- Armor
if LocalPlayer():Health() > 1 then
if LocalPlayer():Armor() > 1 then
draw.RoundedBox(0, ScrW()*0.01, ScrH()*0.935, armah * 3, ScrH()*0.01, Color(155,155,255))
surface.SetDrawColor( Color( 100, 100, 200, 255 ) )
surface.DrawOutlinedRect( ScrW()*0.01, ScrH()*0.935, 100 * 3, ScrH()*0.01 )
draw.SimpleText( LocalPlayer():Armor(), "InfoHP", 100 * 3 + 25, ScrH()*0.9305, Color(255,255,255) )
end
end
-- stamina
if LocalPlayer():Health() > 1 then
draw.RoundedBox(0, ScrW()*0.01, ScrH()*0.985, stmah * 3, ScrH()*0.01, Color(255,150,0))
surface.SetDrawColor( Color( 200, 100, 0, 255 ) )
surface.DrawOutlinedRect( ScrW()*0.01, ScrH()*0.985, 100 * 3, ScrH()*0.01 )
draw.DrawText(LocalPlayer():GetNWInt( LocalPlayer():SteamID64().."dysceedsststminaworks" ), "InfoHP", 100 * 3 + 25, ScrH()*0.9805, Color(255,255,255))
end
--
if not IsValid(zadanietextusx) then
if prikaz == "null" then
else
zadanietextusx = vgui.Create("RichText")
zadanietextusx:SetPos(ScrW()*0.802, ScrH()*0.075)
zadanietextusx:SetSize(ScrW()*0.2, ScrH()*0.15)
zadanietextusx:SetText(prikaz)
zadanietextusx.Paint = function( self, w, h )
draw.RoundedBox( 0, 0, 0, w, h, Color( 30,30,30, 170 ) )
end
zadanietextusx:SetMouseInputEnabled( false )
end
end
if IsValid(zadanietextusx) then
if prikaz == "null" then
zadanietextusx:Remove()
end
end
--
--
draw.RoundedBox(0, ScrW()*0, ScrH()*0, 380, 40, Color(100,100,200))
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( ScrW()*0, ScrH()*0, 380, 40 )
draw.SimpleText( legion.." | "..name.." | "..number.." | "..rank.." | "..spec, "littleInfoHP", ScrW()*0.005, ScrH()*0.01, Color(255,255,255) )
--
draw.RoundedBox(0, ScrW()*0.8025, ScrH()*0, 380, 40, Color(100,100,200))
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( ScrW()*0.802, ScrH()*0, 380, 40 )
--surface.DrawOutlinedRect( ScrW()*0.98, ScrH()*0, 38, 40 )
--surface.DrawOutlinedRect( ScrW()*0.9605, ScrH()*0, 38, 40 )
--surface.DrawOutlinedRect( ScrW()*0.9415, ScrH()*0, 38, 40 )
--surface.DrawOutlinedRect( ScrW()*0.9220, ScrH()*0, 38, 40 )
local green = Color(255,255,255)
local yellow = Color(255,255,255)
local red = Color(255,255,255)
local violet = Color(255,255,255)
local black = Color(255,255,255)
draw.SimpleText( "Коды безопасности", "littleInfoHP", ScrW()*0.81, ScrH()*0.01, Color(255,255,255) )
if defc == "G" then
green = Color(0,230,0)
elseif defc == "Y" then
yellow = Color(255,255,0)
elseif defc == "R" then
red = Color(255,0,0)	
elseif defc == "V" then
violet = Color(200,100,200)
elseif defc == "B" then
black = Color(0,0,0)
end
draw.SimpleText( "З", "littleInfoHP22", ScrW()*0.911, ScrH()*0.009, green )
draw.SimpleText( "Ж", "littleInfoHP22", ScrW()*0.931, ScrH()*0.009, yellow )
draw.SimpleText( "К", "littleInfoHP22", ScrW()*0.952, ScrH()*0.009, red )
draw.SimpleText( "Ф", "littleInfoHP22", ScrW()*0.969, ScrH()*0.009, violet )
draw.SimpleText( "Ч", "littleInfoHP22", ScrW()*0.9855, ScrH()*0.009, black )
--
if LocalPlayer():Health() > 1 then
if (frozen == "true") then
draw.SimpleText( "Вас заморозили", "InfoHP", ScrW()*0.01, ScrH()*0.83, Color(255,255,255) )
end
if ((admindpl == "admin") or (admindpl == "highadmin") or (admindpl == "owner")) then
draw.SimpleText( count.." | репорты", "InfoHP", ScrW()*0.01, ScrH()*0.85, Color(255,255,255) )
local keka = "?"
if cloak == "true" then
keka = "вкл"
else
keka = "выкл"
end
draw.SimpleText( "Слежка: "..keka, "InfoHP", ScrW()*0.01, ScrH()*0.87, Color(255,255,255) )
end
if ((admindpl == "admin") or (admindpl == "highadmin") or (admindpl == "owner") or (admindpl == "commander")) then
if intercom == "true" then
draw.SimpleText( "Интерком включен, множитель: "..interdist, "InfoHP", ScrW()*0.01, ScrH()*0.89, Color(255,255,255) )
else
draw.SimpleText( "Интерком выключен", "InfoHP", ScrW()*0.01, ScrH()*0.89, Color(255,255,255) )
end
end
if (radio != "null") then
draw.SimpleText( "Канал рации: "..radio, "InfoHP", ScrW()*0.01, ScrH()*0.91, Color(255,255,255) )
else
draw.SimpleText( "Канал рации: отсутствует", "InfoHP", ScrW()*0.01, ScrH()*0.91, Color(255,255,255) )
end
end
--
end )
end )]]
local lerparmor = 100
local lerphp = 100
local lerstamina = 100

Dynamic3DHud_DefaultTheme = Dynamic3DHud_DefaultTheme or {}

--------------------= Default values =--------------------

  Dynamic3DHud_DefaultTheme.Enabled = true
  Dynamic3DHud_DefaultTheme.TransitionSpeed = 0.075
  Dynamic3DHud_DefaultTheme.Rotation = 0.2
  Dynamic3DHud_DefaultTheme.Bend = true

  Dynamic3DHud_DefaultTheme.ScaleX = 1
  Dynamic3DHud_DefaultTheme.ScaleY = 1
  Dynamic3DHud_DefaultTheme.ScaleSize = 1

  Dynamic3DHud_DefaultTheme.Color = {
    Back = Color(0,0,0, 100),
    Text = Color(255,236,12, 150),
    Deny = Color(225,0,0, 150)
  }

----------------------------------------------------------

Dynamic3DHud_DefaultTheme.ScreenRadio = ScrH() / ScrW()
Dynamic3DHud_DefaultTheme.LastHealth = nil
Dynamic3DHud_DefaultTheme.LastWeapon = nil
Dynamic3DHud_DefaultTheme.LastAmmo = nil
Dynamic3DHud_DefaultTheme.LastArmor = nil
Dynamic3DHud_DefaultTheme.Angle = nil

Dynamic3DHud_DefaultTheme.Health = {
  BackColor = Dynamic3DHud_DefaultTheme.Color.Back,
  TextColor = Dynamic3DHud_DefaultTheme.Color.Text
}
Dynamic3DHud_DefaultTheme.Armor = {
  Transparency = 0,
  BackColor = Dynamic3DHud_DefaultTheme.Color.Back,
  TextColor = Dynamic3DHud_DefaultTheme.Color.Text
}
Dynamic3DHud_DefaultTheme.Ammo = {
  Transparency = 0,
  SizeTransition = 0,
  PositionTransition = 0,
  BackColor = Dynamic3DHud_DefaultTheme.Color.Back,
  TextColor = Dynamic3DHud_DefaultTheme.Color.Text
}

surface.CreateFont("Dynamic3DHud_DefaultTheme_FontSmall", {
  font = "Helvetica",
  size = 75,
  weight = 750
})
surface.CreateFont("Dynamic3DHud_DefaultTheme_Font", {
  font = "HalfLife2",
  size = 250
})
surface.CreateFont("Dynamic3DHud_DefaultTheme_FontNormalSmall", {
  font = "HalfLife2",
  size = 125
})

local hide = {"CHudHealth", "CHudBattery", "CHudAmmo", "CHudSecondaryAmmo"}
hook.Add("HUDShouldDraw", "Dynamic3DHud_DefaultTheme_HideHud", function(name)
	if Dynamic3DHud_DefaultTheme.Enabled && table.HasValue(hide, name) then return false end
end)

net.Receive("HUDmyinfog", function()
local name = net.ReadString()
local number = net.ReadString()
local legion = net.ReadString()
local rank = net.ReadString()
local spec = net.ReadString()
local admindpl = net.ReadString()
local count = net.ReadString()
local radio = net.ReadString()
local radioon = net.ReadString()
local defc = net.ReadString()
local prikaz = net.ReadString()
local cloak = net.ReadString()
local interdist = net.ReadString()
local intercom = net.ReadString()
local frozen = net.ReadString()
local statminaboost = net.ReadString()
hook.Add("HUDPaint", "Dynamic3DHud_DefaultTheme_HUD", function()
  Dynamic3DHud_DefaultTheme.UpdateValues()
  if Dynamic3DHud_DefaultTheme.Enabled && LocalPlayer():Alive() then
    surface.DisableClipping(true)
      local fov = 92
      if Dynamic3DHud_DefaultTheme.ScreenRadio >= 0.75 then fov = 75
      elseif Dynamic3DHud_DefaultTheme.ScreenRadio >= 0.625 then fov = 84 end
      cam.Start3D(EyeVector()*0, EyeAngles(), fov)
      Dynamic3DHud_DefaultTheme.DrawHealth()
      Dynamic3DHud_DefaultTheme.DrawAmmo()
    cam.End3D()
    surface.DisableClipping(false)
  end
end)

Dynamic3DHud_DefaultTheme.UpdateValues = function()
  local delta = math.Clamp((1/FrameTime() / 60) ^ -1, 1, 20)
  local weapon = LocalPlayer():GetActiveWeapon()
  if !Dynamic3DHud_DefaultTheme.Angle then Dynamic3DHud_DefaultTheme.Angle = EyeAngles() end
  Dynamic3DHud_DefaultTheme.Angle = LerpAngle(math.Clamp(Dynamic3DHud_DefaultTheme.TransitionSpeed * delta, 0, 1), Dynamic3DHud_DefaultTheme.Angle, EyeAngles())
  Dynamic3DHud_DefaultTheme.ScreenRadio = ScrH() / ScrW()
  
  Dynamic3DHud_DefaultTheme.Armor.Transparency = Lerp(0.1 * delta, Dynamic3DHud_DefaultTheme.Armor.Transparency, LocalPlayer():Armor() > 0 and 1 or 0)
  Dynamic3DHud_DefaultTheme.Health.BackColor = Dynamic3DHud_DefaultTheme.LerpColor(0.025 * delta, Dynamic3DHud_DefaultTheme.Health.BackColor, Dynamic3DHud_DefaultTheme.Color.Back)
  Dynamic3DHud_DefaultTheme.Armor.BackColor = Dynamic3DHud_DefaultTheme.LerpColor(0.025 * delta, Dynamic3DHud_DefaultTheme.Armor.BackColor, Dynamic3DHud_DefaultTheme.Color.Back)
  Dynamic3DHud_DefaultTheme.Health.TextColor = Dynamic3DHud_DefaultTheme.LerpColor(0.02 * delta, Dynamic3DHud_DefaultTheme.Health.TextColor, LocalPlayer():Health() < LocalPlayer():GetMaxHealth()*0.20 and ColorAlpha(Dynamic3DHud_DefaultTheme.Color.Deny, Dynamic3DHud_DefaultTheme.Color.Text.a) or Dynamic3DHud_DefaultTheme.Color.Text)
  Dynamic3DHud_DefaultTheme.Armor.TextColor = Dynamic3DHud_DefaultTheme.LerpColor(0.025 * delta, Dynamic3DHud_DefaultTheme.Armor.TextColor, Dynamic3DHud_DefaultTheme.Color.Text)

  if LocalPlayer():Health() != Dynamic3DHud_DefaultTheme.LastHealth then
    if LocalPlayer():Health() >= LocalPlayer():GetMaxHealth()*0.20 then
      Dynamic3DHud_DefaultTheme.Health.BackColor = ColorAlpha(Dynamic3DHud_DefaultTheme.Color.Text, Dynamic3DHud_DefaultTheme.Health.BackColor.a*0.5)
    else
      Dynamic3DHud_DefaultTheme.Health.BackColor = ColorAlpha(Dynamic3DHud_DefaultTheme.Color.Deny, Dynamic3DHud_DefaultTheme.Health.BackColor.a*1.25)
    end
    Dynamic3DHud_DefaultTheme.Health.TextColor = Dynamic3DHud_DefaultTheme.Color.Text
    Dynamic3DHud_DefaultTheme.LastHealth = LocalPlayer():Health()
  end
    Dynamic3DHud_DefaultTheme.Ammo.BackColor = ColorAlpha(Dynamic3DHud_DefaultTheme.Color.Text, 25)
    Dynamic3DHud_DefaultTheme.Ammo.TextColor = ColorAlpha(Dynamic3DHud_DefaultTheme.Color.Text)
    Dynamic3DHud_DefaultTheme.LastWeapon = "LocalPlayer():GetActiveWeapon()"
    Dynamic3DHud_DefaultTheme.Ammo.BackColor = ColorAlpha(Dynamic3DHud_DefaultTheme.Color.Text, 25)
  if LocalPlayer():Armor() != Dynamic3DHud_DefaultTheme.LastArmor then
    Dynamic3DHud_DefaultTheme.Armor.BackColor = ColorAlpha(Dynamic3DHud_DefaultTheme.Color.Text, 25)
    Dynamic3DHud_DefaultTheme.LastArmor = LocalPlayer():Armor()
  end
    Dynamic3DHud_DefaultTheme.Ammo.Transparency = Lerp(0.1 * delta, Dynamic3DHud_DefaultTheme.Ammo.Transparency, ((true || true) and 1 or 0))
    Dynamic3DHud_DefaultTheme.Ammo.BackColor = Dynamic3DHud_DefaultTheme.LerpColor(0.025 * delta, Dynamic3DHud_DefaultTheme.Ammo.BackColor, Dynamic3DHud_DefaultTheme.Color.Back)
    Dynamic3DHud_DefaultTheme.Ammo.TextColor = Dynamic3DHud_DefaultTheme.LerpColor(0.05 * delta, Dynamic3DHud_DefaultTheme.Ammo.TextColor, (true || (true && true)) and Dynamic3DHud_DefaultTheme.Color.Text or Dynamic3DHud_DefaultTheme.Color.Deny)
    
      Dynamic3DHud_DefaultTheme.Ammo.SizeTransition = Lerp(0.1 * delta, Dynamic3DHud_DefaultTheme.Ammo.SizeTransition, (true && true) and 0 or 1)
    Dynamic3DHud_DefaultTheme.Ammo.PositionTransition = Lerp(0.1 * delta, Dynamic3DHud_DefaultTheme.Ammo.PositionTransition, true and 1 or 0)
end

Dynamic3DHud_DefaultTheme.DrawHealth = function()
  local pos = Vector(10,8.5,-5)
  if Dynamic3DHud_DefaultTheme.ScreenRadio >= 0.75 then pos = Vector(10,6,-5)
  elseif Dynamic3DHud_DefaultTheme.ScreenRadio >= 0.625 then pos = Vector(10,7.25,-5) end
  pos = pos * Vector(1,Dynamic3DHud_DefaultTheme.ScaleX,Dynamic3DHud_DefaultTheme.ScaleY)
  pos:Rotate(Dynamic3DHud_DefaultTheme.Angle)
  
  local angleOffset = Vector(15*(Dynamic3DHud_DefaultTheme.Rotation^-1),0,0)
  angleOffset:Rotate(Angle(Dynamic3DHud_DefaultTheme.Angle.pitch*0.75, Dynamic3DHud_DefaultTheme.Angle.yaw, Dynamic3DHud_DefaultTheme.Angle.pitch))
  local angle = (pos + angleOffset):Angle()
  angle = Angle(angle.roll, angle.yaw - 90, -angle.pitch + 90 - Dynamic3DHud_DefaultTheme.Angle.pitch*0.25)
  
  local width = 850
  local height = 275
  cam.Start3D2D(pos, angle, 0.003 * Dynamic3DHud_DefaultTheme.ScaleSize)
-------------------------------------------------------------
local hpmah = math.ceil((LocalPlayer():Health() / LocalPlayer():GetMaxHealth()) * 100)
local armah = math.ceil((LocalPlayer():Armor() / LocalPlayer():GetMaxArmor()) * 100)
local stmah = math.ceil((LocalPlayer():GetNWInt( LocalPlayer():SteamID64().."dysceedsststminaworks" ) / (100 * statminaboost)) * 100)
--АРМОР
lerparmor = Lerp(0.01, lerparmor, armah)
if LocalPlayer():Health() > 1 then
if LocalPlayer():Armor() > 1 then
draw.RoundedBox(0, -width/2, -height/1.5, lerparmor * 15, ScrH()*0.05, Color(155,155,255))
surface.SetDrawColor( Color( 100, 100, 200, 255 ) )
surface.DrawOutlinedRect( -width/2, -height/1.5, 100 * 15, ScrH()*0.05 )
draw.SimpleText( LocalPlayer():Armor(), "NewInfoHP", -width/2 + 1550, height*-0.725, Color(255,255,255) )
end
end

----ХП
lerphp = Lerp(0.01, lerphp, hpmah)
if LocalPlayer():Health() > 1 then
draw.RoundedBox(0, -width/2, -height/3, lerphp * 15, ScrH()*0.05, Color(255,155,155))
surface.SetDrawColor( Color( 200, 100, 100, 255 ) )
surface.DrawOutlinedRect( -width/2, -height/3, 100 * 15, ScrH()*0.05 )
draw.SimpleText( LocalPlayer():Health(), "NewInfoHP", -width/2 + 1550, height*-0.4, Color(255,255,255) )
end

--СТАМИНА
lerstamina = Lerp(0.01, lerstamina, stmah)
if LocalPlayer():Health() > 1 then
draw.RoundedBox(0, -width/2, -height*-0.01, lerstamina * 15, ScrH()*0.05, Color(255,150,0))
surface.SetDrawColor( Color( 200, 100, 0, 255 ) )
surface.DrawOutlinedRect( -width/2, -height*-0.01, 100 * 15, ScrH()*0.05 )
draw.DrawText(LocalPlayer():GetNWInt( LocalPlayer():SteamID64().."dysceedsststminaworks" ), "NewInfoHP", -width/2 + 1550, height*-0.05, Color(255,255,255))
end

--БАР СО СТАТАМИ
draw.RoundedBox(0, -width/2, -height*13, 1800, 100, Color(100,100,200))
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( -width/2, -height*13, 1800, 100 )
draw.SimpleText( legion.." | "..name.." | "..number.." | "..rank.." | "..spec, "NewInfoHP", -width/2.1, height*-12.975, Color(255,255,255) )

--ДОПЫ ТЕКСТОВЫЕ
if LocalPlayer():Health() > 1 then
if (frozen == "true") then
draw.SimpleText( "Вас заморозили", "NewInfoHP", -width/2, height*-1.75, Color(255,255,255) )
end
if ((admindpl == "admin") or (admindpl == "highadmin") or (admindpl == "owner")) then
draw.SimpleText( count.." | репорты", "NewInfoHP", -width/2, height*-1.5, Color(255,255,255) )
local keka = "?"
if cloak == "true" then
keka = "вкл"
else
keka = "выкл"
end
draw.SimpleText( "Слежка: "..keka, "NewInfoHP", -width/2, height*-1.25, Color(255,255,255) )
end
if ((admindpl == "admin") or (admindpl == "highadmin") or (admindpl == "owner") or (admindpl == "commander")) then
if intercom == "true" then
draw.SimpleText( "Интерком включен, множитель: "..interdist, "NewInfoHP", -width/2, height*-1, Color(255,255,255) )
else
draw.SimpleText( "Интерком выключен", "NewInfoHP", -width/2, height*-1, Color(255,255,255) )
end
end
if (radio != "null") then
draw.SimpleText( "Канал рации: "..radio, "NewInfoHP", -width/2, height*-12.4, Color(255,255,255) )
else
draw.SimpleText( "Канал рации: отсутствует", "NewInfoHP", -width/2, height*-12.4, Color(255,255,255) )
end
if (radioon != "null") then
draw.SimpleText( "Отправлять голос: да ("..input.LookupBinding( "+speed" ).." + "..input.LookupBinding( "+use" )..")", "NewInfoHP", -width/2, height*-12.65, Color(255,255,255) )
else
draw.SimpleText( "Отправлять голос: нет ("..input.LookupBinding( "+speed" ).." + "..input.LookupBinding( "+use" )..")", "NewInfoHP", -width/2, height*-12.65, Color(255,255,255) )
end
end
-------------------------------------------------------------  
  cam.End3D2D()
end

Dynamic3DHud_DefaultTheme.DrawAmmo = function()
  local pos = Vector(10,-8,-5)
  if Dynamic3DHud_DefaultTheme.ScreenRadio >= 0.75 then pos = Vector(10,-5.5,-5)
  elseif Dynamic3DHud_DefaultTheme.ScreenRadio >= 0.625 then pos = Vector(10,-6.75,-5) end
  pos = pos * Vector(1,Dynamic3DHud_DefaultTheme.ScaleX,Dynamic3DHud_DefaultTheme.ScaleY)
  pos:Rotate(Dynamic3DHud_DefaultTheme.Angle)

  local angleOffset = Vector(15*(Dynamic3DHud_DefaultTheme.Rotation^-1),0,0)
  angleOffset:Rotate(Angle(Dynamic3DHud_DefaultTheme.Angle.pitch*0.75, Dynamic3DHud_DefaultTheme.Angle.yaw, Dynamic3DHud_DefaultTheme.Angle.pitch))
  local angle = (pos + angleOffset):Angle()
  angle = Angle(angle.roll, angle.yaw - 90, -angle.pitch + 90 - Dynamic3DHud_DefaultTheme.Angle.pitch*0.25)
  
  local width = 1100 - 250*Dynamic3DHud_DefaultTheme.Ammo.SizeTransition
  local height = 275
  
  local x = -550*Dynamic3DHud_DefaultTheme.Ammo.PositionTransition
  surface.SetAlphaMultiplier(Dynamic3DHud_DefaultTheme.Ammo.Transparency)
  cam.Start3D2D(pos, angle, 0.003 * Dynamic3DHud_DefaultTheme.ScaleSize)
  ------------------------------------------------------
  --ДЕФКОНЫ
draw.RoundedBox(0, -width/0.85, -height*13, 1800, 100, Color(100,100,200))
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( -width/0.85, -height*13, 1800, 100 )
--surface.DrawOutlinedRect( ScrW()*0.98, ScrH()*0, 38, 40 )
--surface.DrawOutlinedRect( ScrW()*0.9605, ScrH()*0, 38, 40 )
--surface.DrawOutlinedRect( ScrW()*0.9415, ScrH()*0, 38, 40 )
--surface.DrawOutlinedRect( ScrW()*0.9220, ScrH()*0, 38, 40 )
local green = Color(255,255,255)
local yellow = Color(255,255,255)
local red = Color(255,255,255)
local violet = Color(255,255,255)
local black = Color(255,255,255)
draw.SimpleText( "Коды безопасности", "NewInfoHP", -width/0.87, -height*12.975, Color(255,255,255) )
if defc == "G" then
green = Color(0,230,0)
elseif defc == "Y" then
yellow = Color(255,255,0)
elseif defc == "R" then
red = Color(255,0,0)	
elseif defc == "V" then
violet = Color(200,100,200)
elseif defc == "B" then
black = Color(0,0,0)
end
draw.SimpleText( "З", "NewInfoHP", -width*0.4, -height*12.975, green )
draw.SimpleText( "Ж", "NewInfoHP", -width*0.3, -height*12.975, yellow )
draw.SimpleText( "К", "NewInfoHP", -width*0.2, -height*12.975, red )
draw.SimpleText( "Ф", "NewInfoHP", -width*0.1, -height*12.975, violet )
draw.SimpleText( "Ч", "NewInfoHP", -width*0, -height*12.975, black )

--ПРИКАЗЫ
if not IsValid(zadanietextusx) then
if prikaz == "null" then
else
zadanietextusx = vgui.Create("RichText")
zadanietextusx:SetPos(ScrW()*0.802, ScrH()*0.09)
zadanietextusx:SetSize(ScrW()*0.2, ScrH()*0.15)
zadanietextusx:SetText(prikaz)
zadanietextusx.Paint = function( self, w, h )
draw.RoundedBox( 0, 0, 0, w, h, Color( 30,30,30, 170 ) )
end
zadanietextusx:SetMouseInputEnabled( false )
end
end
if IsValid(zadanietextusx) then
if prikaz == "null" then
zadanietextusx:Remove()
end
end
 --------------------------------------------------- 
  cam.End3D2D()
  surface.SetAlphaMultiplier(1)
end

Dynamic3DHud_DefaultTheme.LerpColor = function(t, from, to)
  return Color(
    Lerp(t, from.r, to.r),
    Lerp(t, from.g, to.g),
    Lerp(t, from.b, to.b),
    Lerp(t, from.a, to.a)
  )
end
Dynamic3DHud_DefaultTheme.ResetConvar = function(name)
  local convar = GetConVar(name)
  if convar then convar:SetString(convar:GetDefault()) end
end
Dynamic3DHud_DefaultTheme.BooleanToNumber = function(value)
  if value == true then return 1
  else return 0 end
end

Dynamic3DHud_DefaultTheme.Enabled = CreateClientConVar("dynamic3dhud_enabled", Dynamic3DHud_DefaultTheme.Enabled and "1" or "0"):GetBool()
Dynamic3DHud_DefaultTheme.TransitionSpeed = math.Clamp(CreateClientConVar("dynamic3dhud_transition", Dynamic3DHud_DefaultTheme.TransitionSpeed):GetFloat(), 0, 1)
Dynamic3DHud_DefaultTheme.Rotation = math.Clamp(CreateClientConVar("dynamic3dhud_rotation", Dynamic3DHud_DefaultTheme.Rotation):GetFloat(), 0.0001, 1)
Dynamic3DHud_DefaultTheme.Bend = CreateClientConVar("dynamic3dhud_bend", Dynamic3DHud_DefaultTheme.Bend and "1" or "0"):GetBool()

Dynamic3DHud_DefaultTheme.ScaleX = CreateClientConVar("dynamic3dhud_scale_x", Dynamic3DHud_DefaultTheme.ScaleX):GetFloat()
Dynamic3DHud_DefaultTheme.ScaleY = CreateClientConVar("dynamic3dhud_scale_y", Dynamic3DHud_DefaultTheme.ScaleY):GetFloat()
Dynamic3DHud_DefaultTheme.ScaleSize = CreateClientConVar("dynamic3dhud_scale_size", Dynamic3DHud_DefaultTheme.ScaleSize):GetFloat()

Dynamic3DHud_DefaultTheme.Color.Back.r = CreateClientConVar("dynamic3dhud_backcolor_r", Dynamic3DHud_DefaultTheme.Color.Back.r):GetFloat()
Dynamic3DHud_DefaultTheme.Color.Back.g = CreateClientConVar("dynamic3dhud_backcolor_g", Dynamic3DHud_DefaultTheme.Color.Back.g):GetFloat()
Dynamic3DHud_DefaultTheme.Color.Back.b = CreateClientConVar("dynamic3dhud_backcolor_b", Dynamic3DHud_DefaultTheme.Color.Back.b):GetFloat()
Dynamic3DHud_DefaultTheme.Color.Back.a = CreateClientConVar("dynamic3dhud_backcolor_a", Dynamic3DHud_DefaultTheme.Color.Back.a):GetFloat()

Dynamic3DHud_DefaultTheme.Color.Text.r = CreateClientConVar("dynamic3dhud_textcolor_r", Dynamic3DHud_DefaultTheme.Color.Text.r):GetFloat()
Dynamic3DHud_DefaultTheme.Color.Text.g = CreateClientConVar("dynamic3dhud_textcolor_g", Dynamic3DHud_DefaultTheme.Color.Text.g):GetFloat()
Dynamic3DHud_DefaultTheme.Color.Text.b = CreateClientConVar("dynamic3dhud_textcolor_b", Dynamic3DHud_DefaultTheme.Color.Text.b):GetFloat()
Dynamic3DHud_DefaultTheme.Color.Text.a = CreateClientConVar("dynamic3dhud_textcolor_a", Dynamic3DHud_DefaultTheme.Color.Text.a):GetFloat()

Dynamic3DHud_DefaultTheme.Color.Deny.r = CreateClientConVar("dynamic3dhud_denycolor_r", Dynamic3DHud_DefaultTheme.Color.Deny.r):GetFloat()
Dynamic3DHud_DefaultTheme.Color.Deny.g = CreateClientConVar("dynamic3dhud_denycolor_g", Dynamic3DHud_DefaultTheme.Color.Deny.g):GetFloat()
Dynamic3DHud_DefaultTheme.Color.Deny.b = CreateClientConVar("dynamic3dhud_denycolor_b", Dynamic3DHud_DefaultTheme.Color.Deny.b):GetFloat()
Dynamic3DHud_DefaultTheme.Color.Deny.a = CreateClientConVar("dynamic3dhud_denycolor_a", Dynamic3DHud_DefaultTheme.Color.Deny.a):GetFloat()

cvars.AddChangeCallback("dynamic3dhud_enabled", function(convar, oldValue, newValue)
  Dynamic3DHud_DefaultTheme.Enabled = tobool(newValue)
end)
cvars.AddChangeCallback("dynamic3dhud_transition", function(convar, oldValue, newValue)
  Dynamic3DHud_DefaultTheme.TransitionSpeed = math.Clamp(tonumber(newValue), 0, 1)
end)
cvars.AddChangeCallback("dynamic3dhud_rotation", function(convar, oldValue, newValue)
  Dynamic3DHud_DefaultTheme.Rotation =  math.Clamp(tonumber(newValue), 0.0001, 1)
end)
cvars.AddChangeCallback("dynamic3dhud_bend", function(convar, oldValue, newValue)
  Dynamic3DHud_DefaultTheme.Bend = tobool(newValue)
end)

cvars.AddChangeCallback("dynamic3dhud_scale_x", function(convar, oldValue, newValue)
  Dynamic3DHud_DefaultTheme.ScaleX = tonumber(newValue)
end)
cvars.AddChangeCallback("dynamic3dhud_scale_y", function(convar, oldValue, newValue)
  Dynamic3DHud_DefaultTheme.ScaleY = tonumber(newValue)
end)
cvars.AddChangeCallback("dynamic3dhud_scale_size", function(convar, oldValue, newValue)
  Dynamic3DHud_DefaultTheme.ScaleSize = tonumber(newValue)
end)

cvars.AddChangeCallback("dynamic3dhud_backcolor_r", function(convar, oldValue, newValue)
  Dynamic3DHud_DefaultTheme.Color.Back.r = tonumber(newValue)
end)
cvars.AddChangeCallback("dynamic3dhud_backcolor_g", function(convar, oldValue, newValue)
  Dynamic3DHud_DefaultTheme.Color.Back.g = tonumber(newValue)
end)
cvars.AddChangeCallback("dynamic3dhud_backcolor_b", function(convar, oldValue, newValue)
  Dynamic3DHud_DefaultTheme.Color.Back.b = tonumber(newValue)
end)
cvars.AddChangeCallback("dynamic3dhud_backcolor_a", function(convar, oldValue, newValue)
  Dynamic3DHud_DefaultTheme.Color.Back.a = tonumber(newValue)
end)

cvars.AddChangeCallback("dynamic3dhud_textcolor_r", function(convar, oldValue, newValue)
  Dynamic3DHud_DefaultTheme.Color.Text.r = tonumber(newValue)
end)
cvars.AddChangeCallback("dynamic3dhud_textcolor_g", function(convar, oldValue, newValue)
  Dynamic3DHud_DefaultTheme.Color.Text.g = tonumber(newValue)
end)
cvars.AddChangeCallback("dynamic3dhud_textcolor_b", function(convar, oldValue, newValue)
  Dynamic3DHud_DefaultTheme.Color.Text.b = tonumber(newValue)
end)
cvars.AddChangeCallback("dynamic3dhud_textcolor_a", function(convar, oldValue, newValue)
  Dynamic3DHud_DefaultTheme.Color.Text.a = tonumber(newValue)
end)

cvars.AddChangeCallback("dynamic3dhud_denycolor_r", function(convar, oldValue, newValue)
  Dynamic3DHud_DefaultTheme.Color.Deny.r = tonumber(newValue)
end)
cvars.AddChangeCallback("dynamic3dhud_denycolor_g", function(convar, oldValue, newValue)
  Dynamic3DHud_DefaultTheme.Color.Deny.g = tonumber(newValue)
end)
cvars.AddChangeCallback("dynamic3dhud_denycolor_b", function(convar, oldValue, newValue)
  Dynamic3DHud_DefaultTheme.Color.Deny.b = tonumber(newValue)
end)
cvars.AddChangeCallback("dynamic3dhud_denycolor_a", function(convar, oldValue, newValue)
  Dynamic3DHud_DefaultTheme.Color.Deny.a = tonumber(newValue)
end)

concommand.Add("dynamic3dhud_reset", function()
  Dynamic3DHud_DefaultTheme.ResetConvar("dynamic3dhud_enabled")
  Dynamic3DHud_DefaultTheme.ResetConvar("dynamic3dhud_transition")
  Dynamic3DHud_DefaultTheme.ResetConvar("dynamic3dhud_rotation")
  Dynamic3DHud_DefaultTheme.ResetConvar("dynamic3dhud_bend")
  
  Dynamic3DHud_DefaultTheme.ResetConvar("dynamic3dhud_scale_x")
  Dynamic3DHud_DefaultTheme.ResetConvar("dynamic3dhud_scale_y")
  Dynamic3DHud_DefaultTheme.ResetConvar("dynamic3dhud_scale_size")
  
  Dynamic3DHud_DefaultTheme.ResetConvar("dynamic3dhud_backcolor_r")
  Dynamic3DHud_DefaultTheme.ResetConvar("dynamic3dhud_backcolor_g")
  Dynamic3DHud_DefaultTheme.ResetConvar("dynamic3dhud_backcolor_b")
  Dynamic3DHud_DefaultTheme.ResetConvar("dynamic3dhud_backcolor_a")
  
  Dynamic3DHud_DefaultTheme.ResetConvar("dynamic3dhud_textcolor_r")
  Dynamic3DHud_DefaultTheme.ResetConvar("dynamic3dhud_textcolor_g")
  Dynamic3DHud_DefaultTheme.ResetConvar("dynamic3dhud_textcolor_b")
  Dynamic3DHud_DefaultTheme.ResetConvar("dynamic3dhud_textcolor_a")
  
  Dynamic3DHud_DefaultTheme.ResetConvar("dynamic3dhud_denycolor_r")
  Dynamic3DHud_DefaultTheme.ResetConvar("dynamic3dhud_denycolor_g")
  Dynamic3DHud_DefaultTheme.ResetConvar("dynamic3dhud_denycolor_b")
  Dynamic3DHud_DefaultTheme.ResetConvar("dynamic3dhud_denycolor_a")
end)

hook.Add("PopulateToolMenu", "Dynamic3DHud_Settings", function()
	spawnmenu.AddToolMenuOption("Utilities", "User", "Dynamic3DHud_DefaultTheme", "Dynamic 3D Hud", "", "", function(panel)
		panel:ClearControls()
    panel:Help("These variables only affect the current player.")
		panel:NumSlider("Transition Delay:", "dynamic3dhud_transition", 0, 1)
		panel:NumSlider("Rotation Scale:", "dynamic3dhud_rotation", 0, 1)
    panel:CheckBox("Enabled", "dynamic3dhud_enabled")
    panel:CheckBox("Bend", "dynamic3dhud_bend")
    panel:Button("Reset to Default", "dynamic3dhud_reset", false)
    
    local ColorSettings = vgui.Create("DForm")
    ColorSettings:SetLabel("Color Settings")
    ColorSettings:SetExpanded(0)
    ColorSettings:DockMargin(-10,0,-10,0)
    ColorSettings:DockPadding(0,0,0,5)
    
    local BackColorLabel = vgui.Create("DLabel")
    BackColorLabel:SetColor(Color(0,0,0))
    BackColorLabel:SetText("Background Color:")
    ColorSettings:AddItem(BackColorLabel)
    
    local BackColor = vgui.Create("DColorMixer")
    BackColor:SetConVarR("dynamic3dhud_backcolor_r")
    BackColor:SetConVarG("dynamic3dhud_backcolor_g")
    BackColor:SetConVarB("dynamic3dhud_backcolor_b")
    BackColor:SetConVarA("dynamic3dhud_backcolor_a")
    ColorSettings:AddItem(BackColor)
    
    local TextColorLabel = vgui.Create("DLabel")
    TextColorLabel:SetColor(Color(0,0,0))
    TextColorLabel:SetText("Text Color:")
    ColorSettings:AddItem(TextColorLabel)
    
    local TextColor = vgui.Create("DColorMixer")
    TextColor:SetConVarR("dynamic3dhud_textcolor_r")
    TextColor:SetConVarG("dynamic3dhud_textcolor_g")
    TextColor:SetConVarB("dynamic3dhud_textcolor_b")
    TextColor:SetConVarA("dynamic3dhud_textcolor_a")
    ColorSettings:AddItem(TextColor)
    
    local DenyColorLabel = vgui.Create("DLabel")
    DenyColorLabel:SetColor(Color(0,0,0))
    DenyColorLabel:SetText("Dying / No Ammo Color:")
    ColorSettings:AddItem(DenyColorLabel)
    
    local DenyColor = vgui.Create("DColorMixer")
    DenyColor:SetConVarR("dynamic3dhud_denycolor_r")
    DenyColor:SetConVarG("dynamic3dhud_denycolor_g")
    DenyColor:SetConVarB("dynamic3dhud_denycolor_b")
    DenyColor:SetConVarA("dynamic3dhud_denycolor_a")
    ColorSettings:AddItem(DenyColor)
    
    panel:AddItem(ColorSettings)
    
    local ScaleSettings = vgui.Create("DForm")
    ScaleSettings:SetLabel("Scale Settings")
    ScaleSettings:SetExpanded(0)
    ScaleSettings:DockMargin(-10,-5,-10,0)
    ScaleSettings:DockPadding(0,0,0,10)
    
    ScaleSettings:Help("Adjust these values in case of a different resolution.")
		ScaleSettings:NumSlider("X Scale:", "dynamic3dhud_scale_x", 0, 5)
		ScaleSettings:NumSlider("Y Scale:", "dynamic3dhud_scale_y", -5, 5)
		ScaleSettings:NumSlider("Size Scale:", "dynamic3dhud_scale_size", 0, 5)
    
    panel:AddItem(ScaleSettings)
	end)
end)
end)

hook.Add( "KeyPress", "Radioselectionbindos234", function( ply, key )
if ( IsFirstTimePredicted() ) then
if ply:KeyDown( IN_USE ) and ply:KeyDown( IN_SPEED ) then
chat.PlaySound()
local function radionactive()
net.Start("changeradiovoiceactivestate263")
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
radionactive()
end
end
end)