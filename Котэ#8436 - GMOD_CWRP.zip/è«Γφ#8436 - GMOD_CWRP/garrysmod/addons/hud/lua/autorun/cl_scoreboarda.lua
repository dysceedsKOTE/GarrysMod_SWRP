local HeightLine = 26


local mat_wrench = Material('icons/wrench.png', 'noclamp smooth')
local mat_star = Material('icons/star.png', 'noclamp smooth')
local mat_key = Material('icons/key.png', 'noclamp smooth')
local mat_case = Material('icons/case.png', 'noclamp smooth')
local mat_hammer = Material('icons/hammer.png', 'noclamp smooth')
local mat_lines = Material('icons/lines.png', 'noclamp smooth')

surface.CreateFont( "KOsdfvHSBsd", {
	font = "Exo 2 Semi Bold",
	extended = true,
	size = 20,
	weight = 700,
	antialias = true,
	underline = false,
	shadow = false,
} )

team.SetColor( 0, Color(131,138,142) )
team.SetColor( 1001, Color(131,138,142) )

local MainPanel, Main
local alpha, alpha_lerp = 0, 0
function ScoreboardOpen()
	if not IsValid(Main) then
        alpha = 160

		LocalPlayer().Scoreboard = true
		Main = vgui.Create("DFrame")
		Main:SetSize(ScrW(),ScrH())
		Main:SetPos((ScrW()-Main:GetWide())/2,(ScrH()-Main:GetTall())/2)
		Main:SetTitle('')

		-- Main:Center()
		Main:SetDraggable(false)
		Main:ShowCloseButton(false)
		Main.Paint = function( self, w, h )
			alpha_lerp = Lerp(FrameTime()*6,alpha_lerp or 0,alpha or 0) or 0

            local x, y = self:GetPos()
            -- print(alpha_lerp)

            draw.RoundedBox(0,0,0,w,h,Color(52, 73, 94, alpha_lerp))
		end

        MainPanel = vgui.Create('DScrollPanel', Main)
        MainPanel:SetSize(Main:GetWide()/1.4,Main:GetTall()/1.2)
        MainPanel:SetPos(Main:GetWide()*.5 - MainPanel:GetWide()*.5, Main:GetTall()*.5 - MainPanel:GetTall()*.5)

        local line_front = markup.Parse(string.format('<font=KOsdfvHSBsd><colour=255, 255, 255, 255>Сейчас играет <colour=175, 175, 175, 255>%s</colour> из <colour=175, 175, 175, 255>%s</colour> игроков. Текущая карта <colour=175, 175, 175, 255>%s</colour></colour></font>',
            #player.GetAll(),
            game.MaxPlayers(),
            game.GetMap()
        ))
        MainPanel.Paint = function( self, w, h )
            line_front:Draw( 0, 0, 0, 0 )
            -- draw.SimpleText('Сейчас играет '..#player.GetAll()..' из '..game.MaxPlayers()..' игроков. Текущая карта '..game.GetMap(), "KOsdfvHSBsd", 0, 0, color_white, 0, 0)
        end

        MainPanel.VBar:SetWide(0)

        local layout = vgui.Create( "DListLayout", MainPanel )
        layout:SetSize( MainPanel:GetWide(), MainPanel:GetTall() )
        layout:SetPos( 0, 30 )
        -- layout:SetSpace( 2 )

        --Draw a background so we can see what it's doing
        -- layout:SetPaintBackground( true )
        -- layout:SetBackgroundColor( Color( 0, 100, 100 ) )

        -- layout:MakeDroppable( "unique_name" ) -- Allows us to rearrange children

        local players = player.GetAll()
        table.sort(players, function(a, b)
			return a:Team() < b:Team()
		end)

for i, pl in pairs(players) do
local function ranksendserv()
net.Start('scrankserv')   
net.WriteString(pl:SteamID64())
net.WriteEntity(pl)
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
ranksendserv()
end

net.Receive("scrank", function()
local rank = net.ReadString() 
local specialis = net.ReadString()
local legions = net.ReadString()
local names = net.ReadString()
local numbers = net.ReadString()
local lpladmin = net.ReadString()
local pladmin = net.ReadString()
local pl = net.ReadEntity()
local lpl = net.ReadEntity()

           if not MainPanel or not IsValid(MainPanel) then
           return
           end
            local PlayerPanel = vgui.Create('DButton')
            PlayerPanel:SetTall(30)
            PlayerPanel:SetWide(MainPanel:GetWide())
            PlayerPanel:SetText('')
            PlayerPanel.Paint = function( self, w, h )
                if not pl or not IsValid(pl) then
                    return
                end

                local carcolordec = Color(155,155,255,250)
                if (pl:Team() == 1) then
                carcolordec = Color(155,155,255,250)
                elseif (pl:Team() == 2) then
                carcolordec = Color(100,100,200,250)
                elseif (pl:Team() == 3) then
                carcolordec = Color(255,90,0,250)
                elseif (pl:Team() == 4) then
                carcolordec = Color(0,150,45,250)
                elseif (pl:Team() == 5) then
                carcolordec = Color(255,0,0,250)
                elseif (pl:Team() == 6) then
                carcolordec = Color(100,100,100,250)
                elseif (pl:Team() == 7) then
                carcolordec = Color(0,190,230,250)
                elseif (pl:Team() == 8) then
                carcolordec = Color(0,190,230,250)
                end
                local pcol = team.GetColor(pl:Team())
                h = 28
                if pl and pcol then
                    draw.RoundedBox(0,0,0,w,h,carcolordec)

                    surface.SetFont('KOsdfvHSBsd')

                    surface.SetFont('KOsdfvHSBsd')
                    local wgr = 0

                    -- if tblIconsGroups[pl:GetUserGroup()] then
                    --     local group_data = tblIconsGroups[pl:GetUserGroup()]
                    --     -- PrintTable(group_data)
                    --     surface.SetFont('font_base_24')
                    --     wgr, _ = surface.GetTextSize(group_data.symbol..' ')

                    --     draw.SimpleText(group_data.symbol, "font_base_24", wrt+34+1, h/2+1, Color( 0, 0, 0, 60 ), 0, 1)
                    --     draw.SimpleText(group_data.symbol, "font_base_24", wrt+34, h/2, group_data.col, 0, 1)
                    -- end

                    draw.SimpleText(legions.." | "..names.." | "..numbers, "KOsdfvHSBsd", 34+wgr+1, h/2+1, Color( 0, 0, 0, 60 ), 0, 1)
                    draw.SimpleText(legions.." | "..names.." | "..numbers, "KOsdfvHSBsd", 34+wgr, h/2, Color( 255, 255, 255, 250 ), 0, 1)


                    -- surface.SetFont('KOsdfvHSBsd')
                    -- local wt, _ = surface.GetTextSize(name)
                    draw.SimpleText(rank, "KOsdfvHSBsd", w/3 +1, h/2+1, Color( 0, 0, 0, 60 ), 1, 1)
                    draw.SimpleText(rank, "KOsdfvHSBsd", w/3 , h/2, Color( 255, 255, 255, 255 ), 1, 1)

                    draw.SimpleText(specialis, "KOsdfvHSBsd", w/2 +1, h/2+1, Color( 0, 0, 0, 60 ), 1, 1)
                    draw.SimpleText(specialis, "KOsdfvHSBsd", w/2 , h/2, Color( 255, 255, 255, 255 ), 1, 1)
                    
                    if (pladmin == "owner" or pladmin == "highadmin" or pladmin == "admin" or pladmin == "commander") then
                    if pladmin == "owner" then 
                    local pladmin = "УПРАВЛЯЮЩИЙ"
                    draw.SimpleText(pladmin, "KOsdfvHSBsd", w/1.25 +1, h/2+1, Color( 0, 0, 0, 60 ), 1, 1)
                    draw.SimpleText(pladmin, "KOsdfvHSBsd", w/1.25 , h/2, Color( 255, 255, 255, 255 ), 1, 1)
                    elseif pladmin == "highadmin" then
                    local pladmin = "СТАРШИЙ АДМИН"
                    draw.SimpleText(pladmin, "KOsdfvHSBsd", w/1.25 +1, h/2+1, Color( 0, 0, 0, 60 ), 1, 1)
                    draw.SimpleText(pladmin, "KOsdfvHSBsd", w/1.25 , h/2, Color( 255, 255, 255, 255 ), 1, 1)
                    elseif pladmin == "admin" then
                    local pladmin = "АДМИН"
                    draw.SimpleText(pladmin, "KOsdfvHSBsd", w/1.25 +1, h/2+1, Color( 0, 0, 0, 60 ), 1, 1)
                    draw.SimpleText(pladmin, "KOsdfvHSBsd", w/1.25 , h/2, Color( 255, 255, 255, 255 ), 1, 1)
                    elseif pladmin == "commander" then
                    local pladmin = "КОМАНДУЮЩИЙ"
                    draw.SimpleText(pladmin, "KOsdfvHSBsd", w/1.25 +1, h/2+1, Color( 0, 0, 0, 60 ), 1, 1)
                    draw.SimpleText(pladmin, "KOsdfvHSBsd", w/1.25 , h/2, Color( 255, 255, 255, 255 ), 1, 1)                    
                    end
                    end

                    if self:IsHovered() then
                        -- local oldname = pl:OldName()
                        -- draw.SimpleText(oldname, "KOsdfvHSBsd", w/1.3 +1, h/2+1, Color( 0, 0, 0, 60 ), 1, 1)
                        -- draw.SimpleText(oldname, "KOsdfvHSBsd", w/1.3, h/2, Color( 195, 195, 195, 255 ), 1, 1)


                        draw.RoundedBox(0,0,0,w,h,Color(230, 230, 230, 4))
                    end
                end

                draw.RoundedBox(0, w-10+1, 4+1, 6, 20, Color(0,0,0,60))
                draw.RoundedBox(0, w-17+1, 9+1, 6, 15, Color(0,0,0,60))
                draw.RoundedBox(0, w-24+1, 14+1, 6, 10, Color(0,0,0,60))

                local pg = pl:Ping()
                local pgcol = pl:Ping() < 100 and Color(119,184,0) or pg < 200 and Color(255,165,0) or Color(214,45,32)
                draw.RoundedBox(0, w-10, 4, 6, 20, pgcol)
                draw.RoundedBox(0, w-17, 9, 6, 15, pgcol)
                draw.RoundedBox(0, w-24, 14, 6, 10, pgcol)

                draw.SimpleText(pg, "KOsdfvHSBsd", w - 30 +1, h/2+1, Color( 0, 0, 0, 60 ), 2, 1)
                draw.SimpleText(pg, "KOsdfvHSBsd", w - 30 , h/2, Color( 255, 255, 255, 255 ), 2, 1)
            end

            PlayerPanel.DoClick = function( self )
 				if not IsValid(pl) then return end

				local bNoAccess = true
				local menu = DermaMenu(Main);
				menu:SetSkin("serverguard");
				menu:AddOption("Открыть профиль Steam", function()
					pl:ShowProfile()
				end):SetIcon("icon16/group_link.png");
				menu:AddSpacer()
				menu:AddOption(pl:SteamID(), function()
					SetClipboardText(pl:SteamID());
				end):SetIcon("icon16/page_copy.png");
				menu:AddOption(pl:SteamID64(), function()
					SetClipboardText(pl:SteamID64());
				end):SetIcon("icon16/page_copy.png");
				menu:AddOption(pl:Name(), function()
					SetClipboardText(pl:Name());
				end):SetIcon("icon16/page_copy.png");

                menu:AddSpacer()
                if (lpladmin == "owner" or lpladmin == "highadmin" or lpladmin == "admin" or lpladmin == "commander") then

                local sub_commands2 = menu:AddSubMenu("Вайтлист")
                local sub_commands21 = sub_commands2:AddSubMenu("Солдатский корпус")

sub_commands21:AddOption("Клон солдат", function()
local function tpplysssssdddd()
    net.Start('Clone_CT_S')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

sub_commands21:AddOption("Клон офицер", function()
local function tpplysssssdddd()
    net.Start('Clone_CT_O')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

sub_commands21:AddOption("Клон старший офицер", function()
local function tpplysssssdddd()
    net.Start('Clone_CT_HO')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

sub_commands21:AddOption("Клон командир", function()
local function tpplysssssdddd()
    net.Start('Clone_CT_CC')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

                local sub_commands22 = sub_commands2:AddSubMenu("501-ый легион")

sub_commands22:AddOption("Клон солдат", function()
local function tpplysssssdddd()
    net.Start('Clone_501_S')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

sub_commands22:AddOption("Клон офицер", function()
local function tpplysssssdddd()
    net.Start('Clone_501_O')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

sub_commands22:AddOption("Клон старший офицер", function()
local function tpplysssssdddd()
    net.Start('Clone_501_HO')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

sub_commands22:AddOption("Клон командир", function()
local function tpplysssssdddd()
    net.Start('Clone_501_CC')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

                local sub_commands23 = sub_commands2:AddSubMenu("574-ый корпус")

sub_commands23:AddOption("Клон солдат", function()
local function tpplysssssdddd()
    net.Start('Clone_104_S')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

sub_commands23:AddOption("Клон офицер", function()
local function tpplysssssdddd()
    net.Start('Clone_104_O')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

sub_commands23:AddOption("Клон старший офицер", function()
local function tpplysssssdddd()
    net.Start('Clone_104_HO')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

sub_commands23:AddOption("Клон командир", function()
local function tpplysssssdddd()
    net.Start('Clone_104_CC')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

                local sub_commands24 = sub_commands2:AddSubMenu("41-ый корпус")

sub_commands24:AddOption("Клон солдат", function()
local function tpplysssssdddd()
    net.Start('Clone_91_S')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

sub_commands24:AddOption("Клон офицер", function()
local function tpplysssssdddd()
    net.Start('Clone_91_O')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

sub_commands24:AddOption("Клон старший офицер", function()
local function tpplysssssdddd()
    net.Start('Clone_91_HO')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

sub_commands24:AddOption("Клон командир", function()
local function tpplysssssdddd()
    net.Start('Clone_91_CC')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)                

                local sub_commands25 = sub_commands2:AddSubMenu("Гвардейский корпус")

sub_commands25:AddOption("Клон солдат", function()
local function tpplysssssdddd()
    net.Start('Clone_GUARD_S')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

sub_commands25:AddOption("Клон офицер", function()
local function tpplysssssdddd()
    net.Start('Clone_GUARD_O')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

sub_commands25:AddOption("Клон старший офицер", function()
local function tpplysssssdddd()
    net.Start('Clone_GUARD_HO')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

sub_commands25:AddOption("Клон командир", function()
local function tpplysssssdddd()
    net.Start('Clone_GUARD_CC')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

                local sub_commands26 = sub_commands2:AddSubMenu("Флот")

sub_commands26:AddOption("Матрос", function()
local function tpplysssssdddd()
    net.Start('Clone_FLEET_S')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

sub_commands26:AddOption("Офицер", function()
local function tpplysssssdddd()
    net.Start('Clone_FLEET_O')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

sub_commands26:AddOption("Старший офицер", function()
local function tpplysssssdddd()
    net.Start('Clone_FLEET_HO')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

sub_commands26:AddOption("Командир", function()
local function tpplysssssdddd()
    net.Start('Clone_FLEET_XO')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

sub_commands26:AddOption("Адмирал", function()
local function tpplysssssdddd()
    net.Start('Clone_FLEET_CC')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

                local sub_commands27 = sub_commands2:AddSubMenu("ЭРК")

sub_commands27:AddOption("Клон ARC", function()
local function tpplysssssdddd()
    net.Start('Clone_ARC_S')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

sub_commands27:AddOption("Клон комадир ARC", function()
local function tpplysssssdddd()
    net.Start('Clone_ARC_CC')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

sub_commands27:AddOption("ARC Alpha 77", function()
local function tpplysssssdddd()
    net.Start('Clone_ARC_A77')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

sub_commands27:AddOption("ARC Муунилинст-10", function()
local function tpplysssssdddd()
    net.Start('Clone_ARC_A77L')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

                local sub_commands28 = sub_commands2:AddSubMenu("Донат")

sub_commands28:AddOption("Республиканский коммандос", function()
local function tpplysssssdddd()
    net.Start('Clone_RC_STANDART')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

--------+++++++++++++++++++

sub_commands2:AddOption("Сбросить всё", function()
local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Сброс персонажа "..pl:Name().." ("..pl:SteamID64()..")")
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите причину и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function wlreloadallc()
    net.Start('wlreloadchars')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    wlreloadallc()
end
end)

--------+++++++++++++++++++ конец обычного вайтлиста но не проверки на админа

local sub_commands3 = menu:AddSubMenu("Тонкий вайтлист")
local sub_commands31 = sub_commands3:AddSubMenu("Ранги и положения")

sub_commands31:AddOption("Установить позывной WL", function()
local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Позывной "..pl:Name().." ("..pl:SteamID64()..")")
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите позывной и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function tonkiywl()
    net.Start('wlistpoziv')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    tonkiywl()
end
end)

sub_commands31:AddOption("Установить IDN WL", function()
local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("IDN "..pl:Name().." ("..pl:SteamID64()..")")
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите IDN и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function tonkiywl()
    net.Start('wlistnum')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    tonkiywl()
end
end)

sub_commands31:AddOption("Установить легион WL", function()
local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Легион "..pl:Name().." ("..pl:SteamID64()..")")
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите легион и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function tonkiywl()
    net.Start('wlistlegion')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    tonkiywl()
end
end)

sub_commands31:AddOption("Установить звание WL", function()
local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Звание "..pl:Name().." ("..pl:SteamID64()..")")
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите звание и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function tonkiywl()
    net.Start('wlrank')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    tonkiywl()
end
end)

sub_commands31:AddOption("Установить специализацию WL", function()
local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Специализация "..pl:Name().." ("..pl:SteamID64()..")")
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите специализацию и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function tonkiywl()
    net.Start('wlspec')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    tonkiywl()
end
end)


local sub_commands32 = sub_commands3:AddSubMenu("Внешний вид") 

sub_commands32:AddOption("Установить модель WL", function()
local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Модель "..pl:Name().." ("..pl:SteamID64()..")")
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите путь к модели и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function tonkiywl()
    net.Start('wlistmodel')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    tonkiywl()
end
end)

sub_commands32:AddOption("Установить БГ WL", function()
local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Бодигруппы "..pl:Name().." ("..pl:SteamID64()..")")
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите (000000) и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function tonkiywl()
    net.Start('wlistbodygroups')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    tonkiywl()
end
end)

sub_commands32:AddOption("Установить скин WL", function()
local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Скин "..pl:Name().." ("..pl:SteamID64()..")")
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите (0) и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function tonkiywl()
    net.Start('wlistskinsesd')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    tonkiywl()
end
end)

sub_commands32:AddOption("Установить размер WL", function()
local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Размер "..pl:Name().." ("..pl:SteamID64()..")")
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите множитель и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function tonkiywl()
    net.Start('wlistsize')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    tonkiywl()
end
end)


local sub_commands33 = sub_commands3:AddSubMenu("Вооружение")

sub_commands33:AddOption("Основное оружие WL", function()
local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Основное оружие "..pl:Name().." ("..pl:SteamID64()..")")
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите класс оружия и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function tonkiywl()
    net.Start('wlfirweap')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    tonkiywl()
end
end)

sub_commands33:AddOption("Вторичное оружие WL", function()
local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Вторичное оружие "..pl:Name().." ("..pl:SteamID64()..")")
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите класс оружия и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function tonkiywl()
    net.Start('wlsecweap')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    tonkiywl()
end
end)

sub_commands33:AddOption("Основная граната WL", function()
local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Основная граната "..pl:Name().." ("..pl:SteamID64()..")")
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите класс гранаты и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function tonkiywl()
    net.Start('wlfirgren')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    tonkiywl()
end
end)

sub_commands33:AddOption("Вторичная граната WL", function()
local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Вторичная граната "..pl:Name().." ("..pl:SteamID64()..")")
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите класс гранаты и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function tonkiywl()
    net.Start('wlsecgren')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    tonkiywl()
end
end)

sub_commands33:AddOption("Холодное оружие WL", function()
local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Холодное оружие "..pl:Name().." ("..pl:SteamID64()..")")
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите класс оружия и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function tonkiywl()
    net.Start('wlknife')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    tonkiywl()
end
end)

sub_commands33:AddOption("Запасной слот WL", function()
local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Запасной слот "..pl:Name().." ("..pl:SteamID64()..")")
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите класс оружия и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function tonkiywl()
    net.Start('wlutil')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    tonkiywl()
end
end)

sub_commands33:AddOption("Запасной слот №2 WL", function()
local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Запасной слот №2 "..pl:Name().." ("..pl:SteamID64()..")")
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите класс оружия и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function tonkiywl()
    net.Start('wlutil2')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    tonkiywl()
end
end)

sub_commands33:AddOption("Энтити WL", function()
local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Энтити "..pl:Name().." ("..pl:SteamID64()..")")
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите класс энтити и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function tonkiywl()
    net.Start('wlent')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    tonkiywl()
end
end)


local sub_commands34 = sub_commands3:AddSubMenu("Другие параметры")

sub_commands34:AddOption("Здоровье WL", function()
local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Здоровье "..pl:Name().." ("..pl:SteamID64()..")")
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите кол-во и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function tonkiywl()
    net.Start('wlhealths')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    tonkiywl()
end
end)

sub_commands34:AddOption("Броня WL", function()
local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Броня "..pl:Name().." ("..pl:SteamID64()..")")
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите кол-во и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function tonkiywl()
    net.Start('wlarmorhs')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    tonkiywl()
end
end)

sub_commands34:AddOption("Скорость WL", function()
local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Скорость "..pl:Name().." ("..pl:SteamID64()..")")
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите множитель и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function tonkiywl()
    net.Start('wlspeed')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    tonkiywl()
end
end)

sub_commands34:AddOption("Гравитация WL", function()
local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Гравитация "..pl:Name().." ("..pl:SteamID64()..")")
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите множитель и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function tonkiywl()
    net.Start('wlgrav')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    tonkiywl()
end
end)

end -- Конец

                if (lpladmin == "owner" or lpladmin == "highadmin" or lpladmin == "admin") then
				local sub_commands = menu:AddSubMenu("Администрирование")
                ---
sub_commands:AddOption("К игроку", function()
local function tpplysssssdddd()
net.Start('teleporttoplay')  
net.WriteString(LocalPlayer():SteamID64())
net.WriteEntity(pl)
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
tpplysssssdddd()
end)

sub_commands:AddOption("К себе", function()
   local function bringusply()
    net.Start('bringplay')  
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.WriteEntity(LocalPlayer())
    net.SendToServer()
    end
    bringusply()
end)

sub_commands:AddOption("Убрать оружия", function()
   local function strippiaponsgog()
    net.Start('strippiaponsgog')  
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.WriteEntity(LocalPlayer())
    net.SendToServer()
    end
    strippiaponsgog()
end)

sub_commands:AddOption("Кикнуть", function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Кикнуть игрока "..pl:Name())
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Ввидите причину и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function sendservamen()
    net.Start('sendtoserveramenu')  
    net.WriteString(self:GetValue())
    net.WriteString(pl:SteamID())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteString(pl:SteamID64())
    net.SendToServer()
    end
    sendservamen()
    end
end)

if (lpladmin == "owner" or lpladmin == "highadmin") then
sub_commands:AddOption("Пермабан", function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Забанить игрока "..pl:Name())
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Ввидите причину и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function sendservamenban()
    net.Start('sendtoserveramenuban')   
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteString(LocalPlayer():Name())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    sendservamenban()
    end
end)
end

sub_commands:AddOption("Выговоры", function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Выговоры "..pl:Name())
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Выдать выговор по причине (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function warncipkasend()
    net.Start('warncipka')
    net.WriteString(pl:SteamID64()) 
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteString(LocalPlayer():Name())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    warncipkasend()
end
    local TextEntryPH2 = vgui.Create( "DTextEntry", Krame )
    TextEntryPH2:Dock( TOP )
    TextEntryPH2:DockMargin( 0, 5, 0, 0 )
    TextEntryPH2:SetPlaceholderText( "Снять выговор по причине (ENTER)" )
    TextEntryPH2.OnEnter = function( self )
    local function warncipkaremove()
    net.Start('warncipkar')
    net.WriteString(pl:SteamID64()) 
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.SendToServer()
    end
    warncipkaremove()
    end
end)

sub_commands:AddOption("Размер модели", function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Размер модели "..pl:Name())
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите размер и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function sendservamenmodel()
    net.Start('sendtoserveramenmodel')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    sendservamenmodel()
    end
end)

sub_commands:AddOption("Выдать армора", function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Броник для "..pl:Name())
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите кол-во и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function sendservamenarmor()
    net.Start('sendtoserveramenarmoer')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    sendservamenarmor()
    end
end)

sub_commands:AddOption("Выдать хэлсов", function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Броник для "..pl:Name())
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите кол-во и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function sendservamenheals()
    net.Start('sendtoserveramenheels')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    sendservamenheals()
    end
end)

sub_commands:AddOption("Выдать скорость", function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Скорость "..pl:Name())
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "(1-стандарт) Введите и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function sendservamenspee()
    net.Start('sendtoserveramenspeed')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    sendservamenspee()
    end
end)

sub_commands:AddOption("Установить гравитацию", function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Гравитация "..pl:Name())
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "(1-стандарт) Введите и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function sendservamengra()
    net.Start('sendtoserveramengrav')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    sendservamengra()
    end
end)

sub_commands:AddOption("Установить модель", function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Модель "..pl:Name())
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите путь к модели и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function sendservamenmodel()
    net.Start('sendtoserveramenmodl')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    sendservamenmodel()
    end
end)

sub_commands:AddOption("Заморозить/Разморозить", function()
   local function sendservamenfre()
    net.Start('sendtoserveramenfreez')  
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    sendservamenfre()
end)

sub_commands:AddOption("Слежка", function()
   local function sendservamenspec()
    net.Start('spectateplyersd')  
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.WriteEntity(LocalPlayer())
    net.SendToServer()
    end
    sendservamenspec()
end)

sub_commands:AddOption("Бан на время", function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Бан на время "..pl:Name())
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите причину" )
    local TextEntryPH2 = vgui.Create( "DTextEntry", Krame )
    TextEntryPH2:Dock( TOP )
    TextEntryPH2:DockMargin( 0, 5, 0, 0 )
    TextEntryPH2:SetPlaceholderText( "Введите время в минутах" )
    local DermaButton = vgui.Create( "DButton", Krame ) 
    DermaButton:SetText( "Выдать наказание" )                   
    DermaButton:SetPos( 67, 100 )                   
    DermaButton:SetSize( 250, 30 )  
    DermaButton.DoClick = function()    
    local function sendservamentimerba()
    net.Start('sendtoserveramentimerban')
    net.WriteString(pl:SteamID64()) 
    net.WriteString(TextEntryPH:GetValue())
    net.WriteString(TextEntryPH2:GetInt())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteString(LocalPlayer():Name())
    net.WriteEntity(pl)
    net.SendToServer()
    end
   sendservamentimerba()
end
end)

if (lpladmin == "owner" or lpladmin == "highadmin") then
local sub_commandsik234 = menu:AddSubMenu("Выдача рангов")

sub_commandsik234:AddOption("Ранг (игрок)", function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Ранг (игрок) "..pl:Name())
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите причину" )
    local DermaButton = vgui.Create( "DButton", Krame ) 
    DermaButton:SetText( "Выдать ранг" )                   
    DermaButton:SetPos( 67, 100 )                   
    DermaButton:SetSize( 250, 30 )  
    DermaButton.DoClick = function()    
    local function sendservamentimerba()
    net.Start('sendtoserveramenuser')
    net.WriteString(TextEntryPH:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
   sendservamentimerba()
end
end)

sub_commandsik234:AddOption("Ранг (командир)", function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Ранг (командир) "..pl:Name())
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите причину" )
    local DermaButton = vgui.Create( "DButton", Krame ) 
    DermaButton:SetText( "Выдать ранг" )                   
    DermaButton:SetPos( 67, 100 )                   
    DermaButton:SetSize( 250, 30 )  
    DermaButton.DoClick = function()    
    local function sendservamentimerba()
    net.Start('sendtoserveramencmd')
    net.WriteString(TextEntryPH:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
   sendservamentimerba()
end
end)

sub_commandsik234:AddOption("Ранг (админ)", function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Ранг (админ) "..pl:Name())
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите причину" )
    local DermaButton = vgui.Create( "DButton", Krame ) 
    DermaButton:SetText( "Выдать ранг" )                   
    DermaButton:SetPos( 67, 100 )                   
    DermaButton:SetSize( 250, 30 )  
    DermaButton.DoClick = function()    
    local function sendservamentimerba()
    net.Start('sendtoserveramenadmin')
    net.WriteString(TextEntryPH:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
   sendservamentimerba()
end
end)

if (lpladmin == "owner") then
sub_commandsik234:AddOption("Ранг (старший админ)", function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Ранг (старший админ) "..pl:Name())
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите причину" )
    local DermaButton = vgui.Create( "DButton", Krame ) 
    DermaButton:SetText( "Выдать ранг" )                   
    DermaButton:SetPos( 67, 100 )                   
    DermaButton:SetSize( 250, 30 )  
    DermaButton.DoClick = function()    
    local function sendservamentimerba()
    net.Start('sendtoserveramenhighadmin')
    net.WriteString(TextEntryPH:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
   sendservamentimerba()
end
end)
end

end
                ---
                end
				menu:Open();
            end

            local Avatar = vgui.Create( "AvatarImage", PlayerPanel )
            Avatar:SetSize( 28, 28 )
            Avatar:SetPos( 0, 0 )
            Avatar:SetPlayer( pl, 64 )

            -- local DermaCheckbox = vgui.Create( "DCheckBox", PlayerPanel )
            -- DermaCheckbox:SetPos( PlayerPanel:GetWide()-DermaCheckbox:GetWide()-2, 2 )
            -- DermaCheckbox:SetValue( 0 )
            -- DermaCheckbox.Paint = function( self, w, h )
            --     draw.RoundedBox(4,0,0,w,h,color_white)
            --     if DermaCheckbox:GetChecked() then
            --         draw.RoundedBox(4,2,2,w-4,w-4,Color(119,184,0))
            --     end
            -- end


            layout:Add( PlayerPanel )
        end)
	end
end

function ScoreboardClose()
	if IsValid(Main) then
		Main:Close()
		LocalPlayer().Scoreboard = false
        gui.EnableScreenClicker(false)
	end
end

function ScoreboardShowon()
	ScoreboardOpen()

	if IsValid(Main) then
		Main:Show()
		-- Main:MakePopup()
        gui.EnableScreenClicker(true)
		Main:SetKeyboardInputEnabled(true)
	end
end
hook.Add("ScoreboardShow", "Open scoreboard.", ScoreboardShowon)

function ScoreboardHideoff()
    if MainPanel and IsValid(MainPanel) then
        MainPanel:Remove()
    end
	if IsValid(Main) then
        Main:SetKeyboardInputEnabled(false)
        LocalPlayer().Scoreboard = false

        alpha = 0
        timer.Simple(FrameTime()*6*8, function()
		    ScoreboardClose()
        end)
        gui.EnableScreenClicker(false)
	end
end
hook.Add("ScoreboardHide", "Close scoreboard.", ScoreboardHideoff)

hook.Add('OnReloaded','CloseScoreboard_OnReloaded',function()
    if MainPanel and IsValid(MainPanel) then
        MainPanel:Remove()
    end
    if Main and IsValid(Main) then
        Main:Remove()
    end
    ScoreboardClose()
end)
