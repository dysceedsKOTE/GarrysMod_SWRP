surface.CreateFont( "3d2dtext", {
	font = "Arial",
	extended = true,
	size = 40,
	weight = 500,
	antialias = true,
	underline = false,
	shadow = false,
} )

surface.CreateFont( "3d2drank", {
	font = "Arial",
	extended = true,
	size = 30,
	weight = 500,
	antialias = true,
	underline = false,
	shadow = false,
} )