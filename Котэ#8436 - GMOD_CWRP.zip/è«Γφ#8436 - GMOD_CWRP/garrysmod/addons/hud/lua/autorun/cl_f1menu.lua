if SERVER then return end
surface.CreateFont( 'menubutfontf1', {
	font = 'Exo 2 Semi Bold',
	extended = true,
	size = 30,
	weight = 500,
	antialias = true,
	underline = false,
	shadow = true,
} )

surface.CreateFont( 'menubutfontf1li', {
	font = 'Exo 2 Semi Bold',
	extended = true,
	size = 14,
	weight = 500,
	antialias = true,
	underline = false,
	shadow = true,
} )

surface.CreateFont( 'threbuchetkos2', {
	font = 'Trebuchet24',
	extended = true,
	size = 24,
	weight = 500,
	antialias = true,
	underline = false,
	shadow = true,
} )
local secbutc = Color( 100, 100, 200, 255 )
local homebutc = Color( 100, 100, 200, 255 )
local tributc = Color( 100, 100, 200, 255 )
local forbutc = Color( 100, 100, 200, 255 )
local fivebutc = Color( 100, 100, 200, 255 )
local pointbutc = Color( 100, 100, 200, 255 )
local sixbutc = Color( 100, 100, 200, 255 )
local sevenbutc = Color( 100, 100, 200, 255 )

hook.Add( "PlayerBindPress", "PlayerBindPressExample", function( ply, bind, pressed, bcode )
if (bcode == 92) then
return true
end
if (bcode == 95) then
return true
end
end)

hook.Add( "PlayerButtonDown", "pLAYER_F1menu", function( ply, button )
----
if ( IsFirstTimePredicted() ) then
--++
if button == 92 then

f1menu = vgui.Create( "DFrame" ) 	
f1menu:SetPos(ScrW()*0.2, ScrH()*0.1)			
f1menu:SetSize(ScrW()*0.6, ScrH()*0.6) 				
f1menu:SetTitle( "" )
f1menu:SetAlpha(0)
f1menu:AlphaTo(255,0.25)
f1menu:MoveTo(ScrW()*0.2, ScrH()*0.2, 0.2) 		
f1menu:MakePopup() 
function f1menu:Paint( w, h )
draw.RoundedBox( 0, w*0.2, 0, w*0.8, h, Color( 100, 100, 200, 220 ) )
draw.RoundedBox( 0, 0, 0, w*0.2, h, Color( 155,155,255, 170 ) )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( w*0.2, 0, w*0.8, h )
surface.DrawOutlinedRect( 0, 0, w*0.2, h )
end

local textfadepanel = vgui.Create( "DPanel", f1menu ) 	
textfadepanel:SetPos(0, 0)			
textfadepanel:SetSize(ScrW(), ScrH()) 				
textfadepanel:SetAlpha(0)
textfadepanel:SetMouseInputEnabled( false )	
function textfadepanel:Paint( w, h )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
end

local homebut = vgui.Create( 'DButton', f1menu ) 
homebut:SetText( '' )				
homebut:SetPos( ScrW()*-0.1, 0 )			
homebut:SetSize( ScrW()*0.12, ScrH()*0.05 )	
homebut:SetAlpha(0)		
function homebut:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, homebutc )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText('Основное','menubutfontf1',w*0.05,h*0.2,Color(230,230,230), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
end
homebut.OnCursorEntered = function()
homebutc = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
homebut.OnCursorExited = function()
if IsValid( character3 ) then return end;
homebutc = Color( 100, 100, 200, 255 )
end 
homebut.DoClick = function()

if IsValid( TextEntryKEK23 ) then
TextEntryKEK23:Remove()
end
if IsValid( DComboBoxkeksik2283 ) then
DComboBoxkeksik2283:Remove()
end
if IsValid( DermaButtonka ) then
DermaButtonka:Remove()
textfadepanel:SetAlpha(0)
end
if IsValid( DermaButtonkad ) then
DermaButtonkad:Remove()
textfadepanel:SetAlpha(0)
end
if IsValid( richtextusjaloba ) then
richtextusjaloba:Remove()
textfadepanel:SetAlpha(0)
end
if IsValid( Dcombohtlbox ) then 
Dcombohtlbox:Remove()
end
if IsValid( htmldocs ) then 
htmldocs:Remove()
end
if IsValid( radioconnectionsframe ) then 
radioconnectionsframe:Remove()
end
if IsValid( Radiochannelinsert ) then 
Radiochannelinsert:Remove()
end
if IsValid( radioconnections ) then 
radioconnections:Remove()
end
if IsValid( radioconnectbut ) then 
radioconnectbut:Remove()
end
if IsValid( radiodisconnectbut ) then 
radiodisconnectbut:Remove()
end
if IsValid( textfadepanel5 ) then 
textfadepanel5:Remove()
end
if IsValid( textfadepanel6 ) then 
textfadepanel6:Remove()
end
if IsValid( textfadepanel7 ) then 
textfadepanel7:Remove()
end
if IsValid(batonkafordefc) then
batonkafordefc:Remove()
batonkafordefc2:Remove()
batonkafordefc3:Remove()
batonkafordefc4:Remove()
batonkafordefc5:Remove()
Textprikazzadan:Remove()
butforsendprikaz:Remove()
butforsendprikazcl:Remove()
end
if IsValid(textintercomdist) then
textintercomdist:Remove()
butonforinterdist:Remove()
inercomonbut:Remove()
inercomonbut2:Remove()
end
if IsValid(textfadepanel8) then
textfadepanel8:Remove()
textfadepanel9:Remove()
hpbut:Remove()
hpbut2:Remove()
armorbut:Remove()
armorbut2:Remove()
staminbut:Remove()
staminbut2:Remove()
runbut:Remove()
runbut2:Remove()
ammobut:Remove()
ammobut2:Remove()
rpgbut:Remove()
rpgbut2:Remove()
pointssend:Remove()
end
if IsValid(moneysend) then
moneysend:Remove()
weaponmodeldc17:Remove()
weaponmodeldc15a:Remove()
weaponmodeldc15s:Remove()
end
tributc = Color(100,100,200, 255)
secbutc = Color(100,100,200, 255)
forbutc = Color(100,100,200, 255)
fivebutc = Color(100,100,200, 255)
sixbutc = Color(100,100,200, 255)
sevenbutc = Color(100,100,200, 255)
pointbutc = Color(100,100,200, 255)
--++-------------------------------------------------------------------------------------------------------------------------------------------------
if IsValid( character3 ) then return end;
local function ranksendserv()
net.Start('homebutt_f1menu_server')
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
ranksendserv()

textfadepanel:AlphaTo(255,0.5)

net.Receive('homebutt_f1menu', function()
local name = net.ReadString()
local number = net.ReadString()
local legion = net.ReadString()
local rank = net.ReadString()
local spec = net.ReadString()
local admin = net.ReadString()
local model = net.ReadString()
local skin = net.ReadString()
local bodygroups = net.ReadString()
local warns = net.ReadString()
if util.IsValidModel( model ) == false then
model = "models/breen.mdl"
end
character3 = vgui.Create( 'DModelPanel', f1menu )
character3:SetSize( ScrW()*0.4, ScrH()*0.73 )
character3:SetPos(ScrW()*0.5,ScrH()*-0.131)
character3:MoveTo(ScrW()*0.2,ScrH()*-0.131, 0.5)
character3:SetModel(model) 
character3:GetEntity():SetSkin(skin)
character3:GetEntity():SetBodyGroups(bodygroups)
character3:SetMouseInputEnabled( false )
function character3:LayoutEntity( Entity ) 
return 
end
local eyepos = character3.Entity:GetBonePosition( character3.Entity:LookupBone( 'ValveBiped.Bip01_Head1' ) )
eyepos:Add( Vector( 0, 0, -5 ) )
character3:SetLookAt( eyepos )
character3:SetCamPos( eyepos-Vector( -40, 0, 0 ) )	
character3.Entity:SetEyeTarget( eyepos-Vector( -100, 0, 0 ) )

if IsValid(textfadepanel) then
function textfadepanel:Paint( w, h )
if IsValid( character3 ) then
local podrazdel = legion
if (legion == "СК") then
podrazdel = "Солдатский корпус"
elseif (legion == "501-Л") then
podrazdel = "501-ый легион"
elseif (legion == "104-Б") then
podrazdel = "104-ый батальон"
elseif (legion == "91-К") then
podrazdel = "91-ый корпус"
elseif (legion == "ГК") then
podrazdel = "Гвардейский корпус"
end
draw.SimpleText('Подразделение: '..podrazdel,'menubutfontf1',w*0.125,h*0.025,Color(230,230,230), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
draw.SimpleText('Позывной: '..name,'menubutfontf1',w*0.125,h*0.055,Color(230,230,230), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
draw.SimpleText('Номер: '..number,'menubutfontf1',w*0.125,h*0.085,Color(230,230,230), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
draw.SimpleText('Звание: '..rank,'menubutfontf1',w*0.125,h*0.115,Color(230,230,230), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
draw.SimpleText('Спец: '..spec,'menubutfontf1',w*0.125,h*0.145,Color(230,230,230), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
draw.SimpleText('Выговоры: '..warns.."/6",'menubutfontf1',w*0.125,h*0.52,Color(230,230,230), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
local adminkat = "Игрок"
if (admin == "owner") then
adminkat = "Управляющий"
elseif (admin == "highadmin") then
adminkat = "Старший администратор"
elseif (admin == "admin") then
adminkat = "Администратор"
elseif (admin == "commander") then
adminkat = "Командир"
end
draw.SimpleText('Доступ: '..adminkat,'menubutfontf1',w*0.125,h*0.55,Color(230,230,230), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
end
end
end

end)
--++----------------------------------------------------------------------------------------------------------------
end

homebut.DoClick()
homebutc = Color(155,155,255, 255)






local secbut = vgui.Create( 'DButton', f1menu ) 
secbut:SetText( '' )				
secbut:SetPos( ScrW()*-0.1, ScrH()*0.05 )			
secbut:SetSize( ScrW()*0.12, ScrH()*0.05 )	
secbut:SetAlpha(0)		
function secbut:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, secbutc )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText('Жалобы','menubutfontf1',w*0.05,h*0.2,Color(230,230,230), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
end
secbut.OnCursorEntered = function()
secbutc = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
secbut.OnCursorExited = function()
if IsValid( TextEntryKEK23 ) then return end;
if IsValid( richtextusjaloba ) then return end;
secbutc = Color( 100, 100, 200, 255 )
end
secbut.DoClick = function()
if IsValid( TextEntryKEK23 ) then
TextEntryKEK23:Remove()
end
if IsValid( DComboBoxkeksik2283 ) then
DComboBoxkeksik2283:Remove()
end
if IsValid( DermaButtonka ) then
DermaButtonka:Remove()
textfadepanel:SetAlpha(0)
end
if IsValid( DermaButtonkad ) then
DermaButtonkad:Remove()
textfadepanel:SetAlpha(0)
end
if IsValid( richtextusjaloba ) then
richtextusjaloba:Remove()
textfadepanel:SetAlpha(0)
end
if IsValid( character3 ) then
character3:Remove()
textfadepanel:SetAlpha(0)
end
if IsValid( Dcombohtlbox ) then 
Dcombohtlbox:Remove()
end
if IsValid( htmldocs ) then 
htmldocs:Remove()
end
if IsValid( radioconnectionsframe ) then 
radioconnectionsframe:Remove()
end
if IsValid( Radiochannelinsert ) then 
Radiochannelinsert:Remove()
end
if IsValid( radioconnections ) then 
radioconnections:Remove()
end
if IsValid( radioconnectbut ) then 
radioconnectbut:Remove()
end
if IsValid( radiodisconnectbut ) then 
radiodisconnectbut:Remove()
end
if IsValid( textfadepanel5 ) then 
textfadepanel5:Remove()
end
if IsValid( textfadepanel6 ) then 
textfadepanel6:Remove()
end
if IsValid( textfadepanel7 ) then 
textfadepanel7:Remove()
end
if IsValid(batonkafordefc) then
batonkafordefc:Remove()
batonkafordefc2:Remove()
batonkafordefc3:Remove()
batonkafordefc4:Remove()
batonkafordefc5:Remove()
Textprikazzadan:Remove()
butforsendprikaz:Remove()
butforsendprikazcl:Remove()
end
if IsValid(textintercomdist) then
textintercomdist:Remove()
butonforinterdist:Remove()
inercomonbut:Remove()
inercomonbut2:Remove()
end
if IsValid(textfadepanel8) then
textfadepanel8:Remove()
textfadepanel9:Remove()
hpbut:Remove()
hpbut2:Remove()
armorbut:Remove()
armorbut2:Remove()
staminbut:Remove()
staminbut2:Remove()
runbut:Remove()
runbut2:Remove()
ammobut:Remove()
ammobut2:Remove()
rpgbut:Remove()
rpgbut2:Remove()
pointssend:Remove()
end
if IsValid(moneysend) then
moneysend:Remove()
weaponmodeldc17:Remove()
weaponmodeldc15a:Remove()
weaponmodeldc15s:Remove()
end
homebutc = Color( 100, 100, 200, 255 )
tributc = Color(100,100,200, 255)
forbutc = Color(100,100,200, 255)
fivebutc = Color(100,100,200, 255)
sixbutc = Color(100,100,200, 255)
sevenbutc = Color(100,100,200, 255)
pointbutc = Color(100,100,200, 255)
--++------------------------------------------------------------------------------------------------------------------------
if IsValid( TextEntryKEK23 ) then return end;
if IsValid( richtextusjaloba ) then return end;

if IsValid( textfadepanel2 ) then 
textfadepanel2:Remove()
end

local function servzaprosinfirep()
net.Start('reportclzaprosadmin')
net.WriteEntity(ply)
net.SendToServer()
end
servzaprosinfirep()
net.Receive( "reportadminsends", function()
local reportinfo = net.ReadTable()

textfadepanel2 = vgui.Create( "DPanel", f1menu ) 	
textfadepanel2:SetPos(0, 0)			
textfadepanel2:SetSize(ScrW(), ScrH()) 				
textfadepanel2:SetAlpha(0)
textfadepanel2:SetMouseInputEnabled( false )	
function textfadepanel2:Paint( w, h )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
end
textfadepanel2:AlphaTo(255,0.5)

TextEntryKEK23 = vgui.Create( "DTextEntry", f1menu )
TextEntryKEK23:SetPos( ScrW()*0.25,ScrH()*0.2 )					
TextEntryKEK23:SetSize( ScrW()*0.2,ScrH()*0.15 )
TextEntryKEK23:SetAlpha(0)
TextEntryKEK23:AlphaTo(255,0.5)
TextEntryKEK23:SetMultiline( true )
TextEntryKEK23:SetEnterAllowed( false )
TextEntryKEK23:SetPlaceholderText( "Комментарий" )
function TextEntryKEK23:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, Color(100,100,200,255) )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
TextEntryKEK23:DrawTextEntryText(Color(255, 255, 255), Color(30, 130, 255), Color(255, 255, 255))
end
TextEntryKEK23.OnEnter = function( self )
end

DComboBoxkeksik2283 = vgui.Create( "DComboBox", f1menu )
DComboBoxkeksik2283:SetPos( ScrW()*0.25,ScrH()*0.175 )					
DComboBoxkeksik2283:SetSize( ScrW()*0.2,ScrH()*0.02 )
DComboBoxkeksik2283:SetAlpha(0)
DComboBoxkeksik2283:AlphaTo(255,0.25)
DComboBoxkeksik2283:SetValue( "Причина" )
DComboBoxkeksik2283:AddChoice( "Вопрос" )
DComboBoxkeksik2283:AddChoice( "Застрял" )
DComboBoxkeksik2283:AddChoice( "Жалоба на игрока" )
DComboBoxkeksik2283:AddChoice( "Админ уже рассматривает" )
DComboBoxkeksik2283:AddChoice( "Выдать форму" )
DComboBoxkeksik2283:AddChoice( "Обустроить казарму" )
DComboBoxkeksik2283:AddChoice( "Другое" )
DComboBoxkeksik2283.OnSelect = function( self, index, value )
end

local kakabat = Color(100,100,200,255)
DermaButtonka = vgui.Create( "DButton", f1menu ) 
DermaButtonka:SetText( " " )					
DermaButtonka:SetPos( ScrW()*0.25,ScrH()*0.355 )					
DermaButtonka:SetSize( ScrW()*0.2,ScrH()*0.04 )
DermaButtonka:SetAlpha(0)
DermaButtonka:AlphaTo(255,0.75)
function DermaButtonka:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, kakabat )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText('ОТПРАВИТЬ ЖАЛОБУ','menubutfontf1',w*0.49,h*0.125,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end
DermaButtonka.OnCursorEntered = function()
kakabat = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
DermaButtonka.OnCursorExited = function()
kakabat = Color( 100, 100, 200, 255 )
end
DermaButtonka.DoClick = function()
local textstring = TextEntryKEK23:GetValue()
local yesstring = string.gsub(textstring, "%s+", "")
if (string.len(yesstring) < 256) then
if IsValid(DermaButtonka) then
DermaButtonka:Remove()
end			
if IsValid(DComboBoxkeksik2283) then
DComboBoxkeksik2283:Remove()
end		
if IsValid(TextEntryKEK23) then
TextEntryKEK23:Remove()
end		
local function reportclsendrep2()
net.Start('reportclsendrep')
net.WriteEntity(ply)
net.WriteString(TextEntryKEK23:GetValue())
net.WriteString(DComboBoxkeksik2283:GetValue())
net.SendToServer()
end
reportclsendrep2()
secbut.DoClick()
else
LocalPlayer():ChatPrint( "[Жалобы] максимум символов 256!" )
end
end

for i, v in ipairs( reportinfo ) do
if (v[4] == LocalPlayer():SteamID64()) then
TextEntryKEK23:Remove()
DComboBoxkeksik2283:Remove()
DermaButtonka:Remove()

if (v[7] != "true") then
local kakabat2 = Color(100,100,200,255)
DermaButtonkad = vgui.Create( "DButton", f1menu ) 
DermaButtonkad:SetText( " " )					
DermaButtonkad:SetPos( ScrW()*0.25,ScrH()*0.45 )					
DermaButtonkad:SetSize( ScrW()*0.2,ScrH()*0.04 )
DermaButtonkad:SetAlpha(0)
DermaButtonkad:AlphaTo(255,0.75)
function DermaButtonkad:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, kakabat2 )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText('ЗАКРЫТЬ ЖАЛОБУ','menubutfontf1',w*0.49,h*0.125,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end
DermaButtonkad.OnCursorEntered = function()
kakabat2 = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
DermaButtonkad.OnCursorExited = function()
kakabat2 = Color( 100, 100, 200, 255 )
end
DermaButtonkad.DoClick = function()
if IsValid(f1menu) then
f1menu:Remove()
end				
local function adminalclosenrep()
net.Start('admincloserepoetalone')
net.WriteString(LocalPlayer():SteamID64())
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
adminalclosenrep()
end
end

function textfadepanel2:Paint( w, h )
if IsValid(richtextusjaloba) then
if (v[7] != "true") then
draw.SimpleText('Проблема: '..v[5].." | ".."не принята",'menubutfontf1',w*0.2,h*0.067,Color(230,230,230), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
draw.SimpleText('Cоздано секунд назад: '..math.ceil(CurTime() - v[7]),'menubutfontf1',w*0.2,h*0.3545,Color(230,230,230), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
else
draw.SimpleText('Проблема: '..v[5].." | ".."принята",'menubutfontf1',w*0.2,h*0.067,Color(230,230,230), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
draw.SimpleText('Принято секунд назад: '..math.ceil(CurTime() - v[9]),'menubutfontf1',w*0.2,h*0.4,Color(230,230,230), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
for i, adminushka in ipairs(player.GetAll()) do
if (adminushka:SteamID64() == v[8]) then
draw.SimpleText('Принял: '..v[8].." | "..adminushka:Name(),'menubutfontf1',w*0.2,h*0.3545,Color(230,230,230), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
end
end
end
end
end

richtextusjaloba = vgui.Create("RichText", f1menu)
richtextusjaloba:SetPos(ScrW()*0.2, ScrH()*0.1)
richtextusjaloba:SetSize(ScrW()*0.3, ScrH()*0.25)
richtextusjaloba:SetText(v[6])
richtextusjaloba:SetAlpha(0)
richtextusjaloba:AlphaTo(255,0.25)
richtextusjaloba.Paint = function( self, w, h )
draw.RoundedBox( 0, 0, 0, w, h, Color( 30,30,30, 170 ) )
end
end
end

end)
--++------------------------------------------------------------------------------------------------------------------------------------------------
end





local tribut = vgui.Create( 'DButton', f1menu ) 
tribut:SetText( '' )				
tribut:SetPos( ScrW()*-0.1, ScrH()*0.1 )			
tribut:SetSize( ScrW()*0.12, ScrH()*0.05 )	
tribut:SetAlpha(0)		
function tribut:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, tributc )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText('Ссылки','menubutfontf1',w*0.05,h*0.2,Color(230,230,230), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
end
tribut.OnCursorEntered = function()
tributc = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
tribut.OnCursorExited = function()
if IsValid( Dcombohtlbox ) then return end;
tributc = Color( 100, 100, 200, 255 )
end 
tribut.DoClick = function()
if IsValid( TextEntryKEK23 ) then
TextEntryKEK23:Remove()
end
if IsValid( DComboBoxkeksik2283 ) then
DComboBoxkeksik2283:Remove()
end
if IsValid( DermaButtonka ) then
DermaButtonka:Remove()
textfadepanel:SetAlpha(0)
end
if IsValid( DermaButtonkad ) then
DermaButtonkad:Remove()
textfadepanel:SetAlpha(0)
end
if IsValid( richtextusjaloba ) then
richtextusjaloba:Remove()
textfadepanel:SetAlpha(0)
end
if IsValid( character3 ) then
character3:Remove()
textfadepanel:SetAlpha(0)
end
if IsValid( radioconnectionsframe ) then 
radioconnectionsframe:Remove()
end
if IsValid( Radiochannelinsert ) then 
Radiochannelinsert:Remove()
end
if IsValid( radioconnections ) then 
radioconnections:Remove()
end
if IsValid( radioconnectbut ) then 
radioconnectbut:Remove()
end
if IsValid( radiodisconnectbut ) then 
radiodisconnectbut:Remove()
end
if IsValid( textfadepanel5 ) then 
textfadepanel5:Remove()
end
if IsValid( textfadepanel6 ) then 
textfadepanel6:Remove()
end
if IsValid( textfadepanel7 ) then 
textfadepanel7:Remove()
end
if IsValid(batonkafordefc) then
batonkafordefc:Remove()
batonkafordefc2:Remove()
batonkafordefc3:Remove()
batonkafordefc4:Remove()
batonkafordefc5:Remove()
Textprikazzadan:Remove()
butforsendprikaz:Remove()
butforsendprikazcl:Remove()
end
if IsValid(textintercomdist) then
textintercomdist:Remove()
butonforinterdist:Remove()
inercomonbut:Remove()
inercomonbut2:Remove()
end
if IsValid(textfadepanel8) then
textfadepanel8:Remove()
textfadepanel9:Remove()
hpbut:Remove()
hpbut2:Remove()
armorbut:Remove()
armorbut2:Remove()
staminbut:Remove()
staminbut2:Remove()
runbut:Remove()
runbut2:Remove()
ammobut:Remove()
ammobut2:Remove()
rpgbut:Remove()
rpgbut2:Remove()
pointssend:Remove()
end
if IsValid(moneysend) then
moneysend:Remove()
weaponmodeldc17:Remove()
weaponmodeldc15a:Remove()
weaponmodeldc15s:Remove()
end
homebutc = Color( 100, 100, 200, 255 )
secbutc = Color(100,100,200, 255)
forbutc = Color(100,100,200, 255)
fivebutc = Color(100,100,200, 255)
sixbutc = Color(100,100,200, 255)
sevenbutc = Color(100,100,200, 255)
pointbutc = Color(100,100,200, 255)
----------------------------------------------------------------------------------------------------------------++++
if IsValid( Dcombohtlbox ) then return end;

textfadepanel3 = vgui.Create( "DPanel", f1menu ) 	
textfadepanel3:SetPos(0, 0)			
textfadepanel3:SetSize(ScrW(), ScrH()) 				
textfadepanel3:SetAlpha(0)
textfadepanel3:SetMouseInputEnabled( false )	
function textfadepanel3:Paint( w, h )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
end

Dcombohtlbox = vgui.Create( "DComboBox", f1menu )
Dcombohtlbox:SetPos( ScrW()*0.255,ScrH()*-0.1 )					
Dcombohtlbox:SetSize( ScrW()*0.2,ScrH()*0.02 )
Dcombohtlbox:MoveTo(ScrW()*0.255,ScrH()*0.1, 0.5)
Dcombohtlbox:SetAlpha(0)
Dcombohtlbox:AlphaTo(255,0.25)
Dcombohtlbox:SetValue( "Выберите ссылку (нужно подождать)" )
Dcombohtlbox:AddChoice( "Правила" )
Dcombohtlbox:AddChoice( "Устав" )
Dcombohtlbox:AddChoice( "Дискорд" )
Dcombohtlbox.OnSelect = function( self, index, value )
if (value == "Правила") then
if IsValid(htmldocs) then
htmldocs:Remove()
end
htmldocs = vgui.Create("DHTML", f1menu)
htmldocs:SetPos( ScrW()*0.15,ScrH()*0.8 )					
htmldocs:SetSize( ScrW()*0.42,ScrH()*0.4 )
htmldocs:MoveTo(ScrW()*0.15,ScrH()*0.15, 0.75)
htmldocs:OpenURL("https://docs.google.com/document/d/1OCDV61qhzAo5yGflbRLkscs1AJurzjlrhv-96jR5iis")
textfadepanel3:AlphaTo(255,0.5)
elseif (value == "Устав") then
if IsValid(htmldocs) then
htmldocs:Remove()
end
htmldocs = vgui.Create("DHTML", f1menu)
htmldocs:SetPos( ScrW()*0.15,ScrH()*0.8 )					
htmldocs:SetSize( ScrW()*0.42,ScrH()*0.4 )
htmldocs:MoveTo(ScrW()*0.15,ScrH()*0.15, 0.75)
htmldocs:OpenURL("https://sites.google.com/view/xrpinfo/оглавление?authuser=0")
textfadepanel3:AlphaTo(255,0.5)
elseif (value == "Дискорд") then
if IsValid(htmldocs) then
htmldocs:Remove()
end
htmldocs = vgui.Create("DHTML", f1menu)
htmldocs:SetPos( ScrW()*0.15,ScrH()*0.8 )					
htmldocs:SetSize( ScrW()*0.42,ScrH()*0.4 )
htmldocs:MoveTo(ScrW()*0.15,ScrH()*0.15, 0.75)
htmldocs:OpenURL("https://discord.gg/hYydpfw")
textfadepanel3:AlphaTo(255,0.5)
end
end

function textfadepanel3:Paint( w, h )
if IsValid(htmldocs) then
draw.SimpleText('Ожидайте...','menubutfontf1',w*0.35,h*0.25,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end
end
----------------------------------------------------------------------------------------------------------------++++
end





local forbut = vgui.Create( 'DButton', f1menu ) 
forbut:SetText( '' )				
forbut:SetPos( ScrW()*-0.1, ScrH()*0.15 )			
forbut:SetSize( ScrW()*0.12, ScrH()*0.05 )	
forbut:SetAlpha(0)		
function forbut:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, forbutc )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText('Рация','menubutfontf1',w*0.05,h*0.2,Color(230,230,230), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
end
forbut.OnCursorEntered = function()
forbutc = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
forbut.OnCursorExited = function()
if IsValid(radioconnectionsframe) then return end;
forbutc = Color( 100, 100, 200, 255 )
end
forbut.DoClick = function()
if IsValid( TextEntryKEK23 ) then
TextEntryKEK23:Remove()
end
if IsValid( DComboBoxkeksik2283 ) then
DComboBoxkeksik2283:Remove()
end
if IsValid( DermaButtonka ) then
DermaButtonka:Remove()
textfadepanel:SetAlpha(0)
end
if IsValid( DermaButtonkad ) then
DermaButtonkad:Remove()
textfadepanel:SetAlpha(0)
end
if IsValid( richtextusjaloba ) then
richtextusjaloba:Remove()
textfadepanel:SetAlpha(0)
end
if IsValid( character3 ) then
character3:Remove()
textfadepanel:SetAlpha(0)
end
if IsValid( Dcombohtlbox ) then
Dcombohtlbox:Remove()
end
if IsValid( htmldocs ) then
htmldocs:Remove()
end
if IsValid( textfadepanel5 ) then 
textfadepanel5:Remove()
end
if IsValid( textfadepanel6 ) then 
textfadepanel6:Remove()
end
if IsValid( textfadepanel7 ) then 
textfadepanel7:Remove()
end
if IsValid(batonkafordefc) then
batonkafordefc:Remove()
batonkafordefc2:Remove()
batonkafordefc3:Remove()
batonkafordefc4:Remove()
batonkafordefc5:Remove()
Textprikazzadan:Remove()
butforsendprikaz:Remove()
butforsendprikazcl:Remove()
end
if IsValid(textintercomdist) then
textintercomdist:Remove()
butonforinterdist:Remove()
inercomonbut:Remove()
inercomonbut2:Remove()
end
if IsValid(textfadepanel8) then
textfadepanel8:Remove()
textfadepanel9:Remove()
hpbut:Remove()
hpbut2:Remove()
armorbut:Remove()
armorbut2:Remove()
staminbut:Remove()
staminbut2:Remove()
runbut:Remove()
runbut2:Remove()
ammobut:Remove()
ammobut2:Remove()
rpgbut:Remove()
rpgbut2:Remove()
pointssend:Remove()
end
if IsValid( radioconnectionsframe ) then 
radioconnectionsframe:Remove()
end
if IsValid( Radiochannelinsert ) then 
Radiochannelinsert:Remove()
end
if IsValid( radioconnections ) then 
radioconnections:Remove()
end
if IsValid( radioconnectbut ) then 
radioconnectbut:Remove()
end
if IsValid( radiodisconnectbut ) then 
radiodisconnectbut:Remove()
end
if IsValid(moneysend) then
moneysend:Remove()
weaponmodeldc17:Remove()
weaponmodeldc15a:Remove()
weaponmodeldc15s:Remove()
end
homebutc = Color( 100, 100, 200, 255 )
secbutc = Color(100,100,200, 255)
tributc = Color(100,100,200, 255)
fivebutc = Color(100,100,200, 255)
sixbutc = Color(100,100,200, 255)
sevenbutc = Color(100,100,200, 255)
pointbutc = Color(100,100,200, 255)
------------------------------------------------------------------------------------------------------------------+++
if IsValid( radioconnectionsframe ) then return end;

local function sendserverrados()
net.Start('radiosendtoserv')	
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
sendserverrados()

for i, v in ipairs( player.GetAll() ) do
local function sendservhud2()
local playadm = LocalPlayer():SteamID64()
net.Start('HUDmyservradio')
net.WriteString(playadm)
net.WriteEntity(LocalPlayer())
net.WriteEntity(v)
net.SendToServer()
end
sendservhud2()
end

if IsValid( textfadepanel4 ) then 
textfadepanel4:Remove()
end
textfadepanel4 = vgui.Create( "DPanel", f1menu ) 	
textfadepanel4:SetPos(0, 0)			
textfadepanel4:SetSize(ScrW(), ScrH()) 				
textfadepanel4:SetAlpha(0)
textfadepanel4:SetMouseInputEnabled( false )	
function textfadepanel4:Paint( w, h )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
end

textfadepanel4:AlphaTo(255,0.5)

Radiochannelinsert = vgui.Create( "DTextEntry", f1menu )
Radiochannelinsert:SetPos( ScrW()*0.255,ScrH()*0.1 )					
Radiochannelinsert:SetSize( ScrW()*0.2,ScrH()*0.02 )
Radiochannelinsert:SetAlpha(0)
Radiochannelinsert:AlphaTo(255,0.25)
Radiochannelinsert:SetPlaceholderText( "Канал рации (1-6 чисел)" )
Radiochannelinsert.OnEnter = function( self )
end

radioconnectionsframe = vgui.Create("DFrame", f1menu)
radioconnectionsframe:SetPos( ScrW()*0.255,ScrH()*0.125 )					
radioconnectionsframe:SetSize( ScrW()*0.2,ScrH()*0.27 )
radioconnectionsframe:SetAlpha(0)
radioconnectionsframe:AlphaTo(255,0.5)
radioconnectionsframe:SetTitle("Подключения")
radioconnectionsframe:SetDraggable( false )
radioconnectionsframe:ShowCloseButton( false )
radioconnectionsframe.Paint = function( self, w, h ) -- 'function Frame:Paint( w, h )' works too
	draw.RoundedBox( 0, 0, 0, w, h, Color( 100, 100, 200, 150 ) ) -- Draw a red box instead of the frame
	surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
    surface.DrawOutlinedRect( 0, 0, w, h )
end

radioconnections = vgui.Create("DListLayout", radioconnectionsframe)					
radioconnections:Dock( FILL )	
radioconnections:SetPaintBackground(false)
radioconnections:MakeDroppable( "unique_name" )
radioconnections.Paint = function( self, w, h ) -- 'function Frame:Paint( w, h )' works too
draw.RoundedBox( 0, 0, 0, w, h, Color( 100, 100, 200, 150 ) ) -- Draw a red box instead of the frame
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
end
net.Receive("HUDmyinforadio", function()
local radiome = net.ReadString()
local radionotme = net.ReadString()
local namenotme = net.ReadString()
local numbernotme = net.ReadString()
local legionnotme = net.ReadString()
if radiome == "null" then 
elseif radiome == radionotme then
radioconnections:Add( Label( " "..legionnotme.." | "..namenotme.." | "..numbernotme ) )
end
end)

radiobuttonkas = Color( 100, 100, 200, 255 )
radioconnectbut = vgui.Create( "DButton", f1menu ) 
radioconnectbut:SetText( " " )					
radioconnectbut:SetPos( ScrW()*0.255,ScrH()*0.4 )					
radioconnectbut:SetSize( ScrW()*0.2,ScrH()*0.04 )
radioconnectbut:SetAlpha(0)
radioconnectbut:AlphaTo(255,0.5)
function radioconnectbut:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, radiobuttonkas )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText('ПОДКЛЮЧИТЬСЯ','menubutfontf1',w*0.49,h*0.125,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end
radioconnectbut.OnCursorEntered = function()
radiobuttonkas = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
radioconnectbut.OnCursorExited = function()
radiobuttonkas = Color( 100, 100, 200, 255 )
end				
radioconnectbut.DoClick = function()
chat.AddText(Color( 28, 144, 202 ), "[Рация] Попытка установить соединение: "..Radiochannelinsert:GetValue())
local function sendserverrado()
net.Start('radiochatreciver')	
net.WriteString(LocalPlayer():SteamID64())
net.WriteString(Radiochannelinsert:GetValue())
net.SendToServer()
end
sendserverrado()
if IsValid( radioconnectionsframe ) then 
radioconnectionsframe:Remove()
end
if IsValid( Radiochannelinsert ) then 
Radiochannelinsert:Remove()
end
if IsValid( radioconnections ) then 
radioconnections:Remove()
end
if IsValid( radioconnectbut ) then 
radioconnectbut:Remove()
end
if IsValid( radiodisconnectbut ) then 
radiodisconnectbut:Remove()
end
forbut.DoClick()			
end

radiobuttonkas2 = Color( 100, 100, 200, 255 )
radiodisconnectbut = vgui.Create( "DButton", f1menu ) 
radiodisconnectbut:SetText( " " )					
radiodisconnectbut:SetPos( ScrW()*0.255,ScrH()*0.445 )					
radiodisconnectbut:SetSize( ScrW()*0.2,ScrH()*0.04 )
radiodisconnectbut:SetAlpha(0)
radiodisconnectbut:AlphaTo(255,0.5)
function radiodisconnectbut:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, radiobuttonkas2 )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText('ОТКЛЮЧИТЬСЯ','menubutfontf1',w*0.49,h*0.125,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end
radiodisconnectbut.OnCursorEntered = function()
radiobuttonkas2 = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
radiodisconnectbut.OnCursorExited = function()
radiobuttonkas2 = Color( 100, 100, 200, 255 )
end					
radiodisconnectbut.DoClick = function()	
chat.AddText(Color( 28, 144, 202 ), "[Рация] Соединение успешно разорвано!")
local function sendserverrad2o()
net.Start('radiochatreciver')	
net.WriteString(LocalPlayer():SteamID64())
net.WriteString("null")
net.SendToServer()
end
sendserverrad2o()
if IsValid( radioconnectionsframe ) then 
radioconnectionsframe:Remove()
end
if IsValid( Radiochannelinsert ) then 
Radiochannelinsert:Remove()
end
if IsValid( radioconnections ) then 
radioconnections:Remove()
end
if IsValid( radioconnectbut ) then 
radioconnectbut:Remove()
end
if IsValid( radiodisconnectbut ) then 
radiodisconnectbut:Remove()
end
forbut.DoClick()			
end

net.Receive("radiochannelclient", function()
radiochannel = net.ReadString()
function textfadepanel4:Paint( w, h )
if IsValid( Radiochannelinsert ) then
if (radiochannel != "null") then
draw.SimpleText('Канал: '..radiochannel,'menubutfontf1',w*0.255,h*0.065,Color(230,230,230), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
else
draw.SimpleText('Канал: '.."отсутствует",'menubutfontf1',w*0.255,h*0.065,Color(230,230,230), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
end
end
end
end)
------------------------------------------------------------------------------------------------------------------+++
end





local fivebut = vgui.Create( 'DButton', f1menu ) 
fivebut:SetText( '' )				
fivebut:SetPos( ScrW()*-0.1, ScrH()*0.2 )			
fivebut:SetSize( ScrW()*0.12, ScrH()*0.05 )	
fivebut:SetAlpha(0)		
function fivebut:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, fivebutc )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText('Управление','menubutfontf1',w*0.05,h*0.2,Color(230,230,230), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
end
fivebut.OnCursorEntered = function()
fivebutc = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
fivebut.OnCursorExited = function()
if IsValid(textfadepanel5) then return end;
fivebutc = Color( 100, 100, 200, 255 )
end
fivebut.DoClick = function()
if IsValid( TextEntryKEK23 ) then
TextEntryKEK23:Remove()
end
if IsValid( DComboBoxkeksik2283 ) then
DComboBoxkeksik2283:Remove()
end
if IsValid( DermaButtonka ) then
DermaButtonka:Remove()
textfadepanel:SetAlpha(0)
end
if IsValid( DermaButtonkad ) then
DermaButtonkad:Remove()
textfadepanel:SetAlpha(0)
end
if IsValid( richtextusjaloba ) then
richtextusjaloba:Remove()
textfadepanel:SetAlpha(0)
end
if IsValid( character3 ) then
character3:Remove()
textfadepanel:SetAlpha(0)
end
if IsValid( Dcombohtlbox ) then
Dcombohtlbox:Remove()
end
if IsValid( htmldocs ) then
htmldocs:Remove()
end
if IsValid( radioconnectionsframe ) then 
radioconnectionsframe:Remove()
end
if IsValid( Radiochannelinsert ) then 
Radiochannelinsert:Remove()
end
if IsValid( radioconnections ) then 
radioconnections:Remove()
end
if IsValid( radioconnectbut ) then 
radioconnectbut:Remove()
end
if IsValid( radiodisconnectbut ) then 
radiodisconnectbut:Remove()
end
if IsValid( textfadepanel6 ) then 
textfadepanel6:Remove()
end
if IsValid( textfadepanel7 ) then 
textfadepanel7:Remove()
end
if IsValid(batonkafordefc) then
batonkafordefc:Remove()
batonkafordefc2:Remove()
batonkafordefc3:Remove()
batonkafordefc4:Remove()
batonkafordefc5:Remove()
Textprikazzadan:Remove()
butforsendprikaz:Remove()
butforsendprikazcl:Remove()
end
if IsValid(textintercomdist) then
textintercomdist:Remove()
butonforinterdist:Remove()
inercomonbut:Remove()
inercomonbut2:Remove()
end
if IsValid(textfadepanel8) then
textfadepanel8:Remove()
textfadepanel9:Remove()
hpbut:Remove()
hpbut2:Remove()
armorbut:Remove()
armorbut2:Remove()
staminbut:Remove()
staminbut2:Remove()
runbut:Remove()
runbut2:Remove()
ammobut:Remove()
ammobut2:Remove()
rpgbut:Remove()
rpgbut2:Remove()
pointssend:Remove()
end
if IsValid(moneysend) then
moneysend:Remove()
weaponmodeldc17:Remove()
weaponmodeldc15a:Remove()
weaponmodeldc15s:Remove()
end
homebutc = Color( 100, 100, 200, 255 )
secbutc = Color(100,100,200, 255)
tributc = Color(100,100,200, 255)
forbutc = Color(100,100,200, 255)
sixbutc = Color(100,100,200, 255)
sevenbutc = Color(100,100,200, 255)
pointbutc = Color(100,100,200, 255)
------------------------------------------------------------------------------------------------------------------+++

if IsValid( textfadepanel5 ) then 
textfadepanel5:Remove()
end
textfadepanel5 = vgui.Create( "DPanel", f1menu ) 	
textfadepanel5:SetPos(0, 0)			
textfadepanel5:SetSize(ScrW(), ScrH()) 				
textfadepanel5:SetAlpha(0)
textfadepanel5:SetMouseInputEnabled( false )	
function textfadepanel5:Paint( w, h )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
--draw.SimpleText('Тут ещё не всё готово (ОБТ)','menubutfontf1',w*0.35,h*0.25,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
--draw.SimpleText("Тут можно будет управлять приказами",'menubutfontf1',w*0.35,h*0.3,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
--draw.SimpleText("(Раздел будет только у КМД)",'menubutfontf1',w*0.35,h*0.325,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end

textfadepanel5:AlphaTo(255,0.5)


local batonkafordefcc = Color(100,100,200,255)
batonkafordefc = vgui.Create( "DButton", f1menu ) 
batonkafordefc:SetText( " " )					
batonkafordefc:SetPos( ScrW()*0.125,ScrH()*0.55 )					
batonkafordefc:SetSize( ScrW()*0.025,ScrH()*0.04 )
batonkafordefc:SetAlpha(0)
batonkafordefc:AlphaTo(255,0.75)
function batonkafordefc:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, batonkafordefcc )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText('З','menubutfontf1',w*0.5,h*0.125,Color(0,230,0), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end
batonkafordefc.OnCursorEntered = function()
batonkafordefcc = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
batonkafordefc.OnCursorExited = function()
batonkafordefcc = Color( 100, 100, 200, 255 )
end
batonkafordefc.DoClick = function()
local function reportclsendrep22()
net.Start('defchudsendservergreen')
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
reportclsendrep22()
end

local batonkafordefcc2 = Color(100,100,200,255)
batonkafordefc2 = vgui.Create( "DButton", f1menu ) 
batonkafordefc2:SetText( " " )					
batonkafordefc2:SetPos( ScrW()*0.125,ScrH()*0.5 )					
batonkafordefc2:SetSize( ScrW()*0.025,ScrH()*0.04 )
batonkafordefc2:SetAlpha(0)
batonkafordefc2:AlphaTo(255,0.75)
function batonkafordefc2:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, batonkafordefcc2 )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText('Ж','menubutfontf1',w*0.5,h*0.125,Color(255,255,0), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end
batonkafordefc2.OnCursorEntered = function()
batonkafordefcc2 = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
batonkafordefc2.OnCursorExited = function()
batonkafordefcc2 = Color( 100, 100, 200, 255 )
end
batonkafordefc2.DoClick = function()
local function reportclsendrep22()
net.Start('defchudsendserveryellow')
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
reportclsendrep22()
end

local batonkafordefcc3 = Color(100,100,200,255)
batonkafordefc3 = vgui.Create( "DButton", f1menu ) 
batonkafordefc3:SetText( " " )					
batonkafordefc3:SetPos( ScrW()*0.125,ScrH()*0.45 )					
batonkafordefc3:SetSize( ScrW()*0.025,ScrH()*0.04 )
batonkafordefc3:SetAlpha(0)
batonkafordefc3:AlphaTo(255,0.75)
function batonkafordefc3:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, batonkafordefcc3 )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText('К','menubutfontf1',w*0.5,h*0.125,Color(255,0,0), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end
batonkafordefc3.OnCursorEntered = function()
batonkafordefcc3 = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
batonkafordefc3.OnCursorExited = function()
batonkafordefcc3 = Color( 100, 100, 200, 255 )
end
batonkafordefc3.DoClick = function()
local function reportclsendrep22()
net.Start('defchudsendserverred')
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
reportclsendrep22()
end

local batonkafordefcc4 = Color(100,100,200,255)
batonkafordefc4 = vgui.Create( "DButton", f1menu ) 
batonkafordefc4:SetText( " " )					
batonkafordefc4:SetPos( ScrW()*0.125,ScrH()*0.4 )					
batonkafordefc4:SetSize( ScrW()*0.025,ScrH()*0.04 )
batonkafordefc4:SetAlpha(0)
batonkafordefc4:AlphaTo(255,0.75)
function batonkafordefc4:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, batonkafordefcc4 )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText('Ф','menubutfontf1',w*0.5,h*0.125,Color(200,100,200), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end
batonkafordefc4.OnCursorEntered = function()
batonkafordefcc4 = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
batonkafordefc4.OnCursorExited = function()
batonkafordefcc4 = Color( 100, 100, 200, 255 )
end
batonkafordefc4.DoClick = function()
local function reportclsendrep22()
net.Start('defchudsendserverviolet')
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
reportclsendrep22()
end

local batonkafordefcc5 = Color(100,100,200,255)
batonkafordefc5 = vgui.Create( "DButton", f1menu ) 
batonkafordefc5:SetText( " " )					
batonkafordefc5:SetPos( ScrW()*0.125,ScrH()*0.35 )					
batonkafordefc5:SetSize( ScrW()*0.025,ScrH()*0.04 )
batonkafordefc5:SetAlpha(0)
batonkafordefc5:AlphaTo(255,0.75)
function batonkafordefc5:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, batonkafordefcc5 )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText('Ч','menubutfontf1',w*0.5,h*0.125,Color(0,0,0), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end
batonkafordefc5.OnCursorEntered = function()
batonkafordefcc5 = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
batonkafordefc5.OnCursorExited = function()
batonkafordefcc5 = Color( 100, 100, 200, 255 )
end
batonkafordefc5.DoClick = function()
local function reportclsendrep22()
net.Start('defchudsendserverblack')
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
reportclsendrep22()
end

Textprikazzadan = vgui.Create( "DTextEntry", f1menu )
Textprikazzadan:SetPos(ScrW()*0.25,ScrH()*0.4)					
Textprikazzadan:SetSize( ScrW()*0.2,ScrH()*0.15 )
Textprikazzadan:SetAlpha(0)
Textprikazzadan:AlphaTo(255,0.5)
Textprikazzadan:SetMultiline( true )
Textprikazzadan:SetEnterAllowed( false )
Textprikazzadan:SetPlaceholderText( "Комментарий" )
function Textprikazzadan:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, Color(100,100,200,255) )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
Textprikazzadan:DrawTextEntryText(Color(255, 255, 255), Color(30, 130, 255), Color(255, 255, 255))
end
Textprikazzadan.OnEnter = function( self )
end

local butforsendprikazc = Color(100,100,200,255)
butforsendprikaz = vgui.Create( "DButton", f1menu ) 
butforsendprikaz:SetText( " " )					
butforsendprikaz:SetPos( ScrW()*0.25,ScrH()*0.55 )					
butforsendprikaz:SetSize( ScrW()*0.2,ScrH()*0.04 )
butforsendprikaz:SetAlpha(0)
butforsendprikaz:AlphaTo(255,0.75)
function butforsendprikaz:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, butforsendprikazc )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText('ОТПРАВИТЬ ПРИКАЗ','menubutfontf1',w*0.49,h*0.125,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end
butforsendprikaz.OnCursorEntered = function()
butforsendprikazc = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
butforsendprikaz.OnCursorExited = function()
butforsendprikazc = Color( 100, 100, 200, 255 )
end
butforsendprikaz.DoClick = function()
local textstring = Textprikazzadan:GetValue()
local yesstring = string.gsub(textstring, "%s+", "")
if (string.len(yesstring) < 1001) then
local function reportclsendrep2()
net.Start('f1menu_to_hud_serverprikaz')
net.WriteEntity(LocalPlayer())
net.WriteString(Textprikazzadan:GetValue())
net.SendToServer()
end
reportclsendrep2()
else
LocalPlayer():ChatPrint( "[Приказ] Максимум символов 1000!" )
end
end

local butforsendprikazc2 = Color(100,100,200,255)
butforsendprikazcl = vgui.Create( "DButton", f1menu ) 
butforsendprikazcl:SetText( " " )					
butforsendprikazcl:SetPos( ScrW()*0.25,ScrH()*0.361 )					
butforsendprikazcl:SetSize( ScrW()*0.2,ScrH()*0.04 )
butforsendprikazcl:SetAlpha(0)
butforsendprikazcl:AlphaTo(255,0.75)
function butforsendprikazcl:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, butforsendprikazc2 )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText('УБРАТЬ ПРИКАЗ','menubutfontf1',w*0.49,h*0.125,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end
butforsendprikazcl.OnCursorEntered = function()
butforsendprikazc2 = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
butforsendprikazcl.OnCursorExited = function()
butforsendprikazc2 = Color( 100, 100, 200, 255 )
end
butforsendprikazcl.DoClick = function()
local function reportclsendrep2()
net.Start('f1menu_to_hud_serverprikaz')
net.WriteEntity(LocalPlayer())
net.WriteString("null")
net.SendToServer()
end
reportclsendrep2()
end

textintercomdist = vgui.Create( "DNumberWang", f1menu )
textintercomdist:SetPos(ScrW()*0.25,ScrH()*0.3)					
textintercomdist:SetSize( ScrW()*0.1,ScrH()*0.05 )
textintercomdist:SetMin(0)
textintercomdist:SetMax(100)
textintercomdist:SetAlpha(0)
textintercomdist:AlphaTo(255,0.5)
textintercomdist:SetMultiline( true )
textintercomdist:SetEnterAllowed( false )
textintercomdist:SetPlaceholderText( "Комментарий" )
function textintercomdist:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, Color(100,100,200,255) )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
textintercomdist:DrawTextEntryText(Color(255, 255, 255), Color(30, 130, 255), Color(255, 255, 255))
end
textintercomdist.OnEnter = function( self )
end

local butonforinterdistc = Color(100,100,200,255)
butonforinterdist = vgui.Create( "DButton", f1menu ) 
butonforinterdist:SetText( " " )					
butonforinterdist:SetPos( ScrW()*0.35,ScrH()*0.3 )					
butonforinterdist:SetSize( ScrW()*0.1,ScrH()*0.05 )
butonforinterdist:SetAlpha(0)
butonforinterdist:AlphaTo(255,0.75)
function butonforinterdist:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, butonforinterdistc )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText('УСТАНОВИТЬ','menubutfontf1',w*0.49,h*0.15,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end
butonforinterdist.OnCursorEntered = function()
butonforinterdistc = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
butonforinterdist.OnCursorExited = function()
butonforinterdistc = Color( 100, 100, 200, 255 )
end
butonforinterdist.DoClick = function()
local function reportclsendrep2()
net.Start('f1menu_to_hud_intercomdist')
net.WriteEntity(LocalPlayer())
net.WriteString(textintercomdist:GetValue())
net.SendToServer()
end
reportclsendrep2()
end

local inercomonbutc = Color(100,100,200,255)
inercomonbut = vgui.Create( "DButton", f1menu ) 
inercomonbut:SetText( " " )					
inercomonbut:SetPos( ScrW()*0.25,ScrH()*0.261 )					
inercomonbut:SetSize( ScrW()*0.2,ScrH()*0.04 )
inercomonbut:SetAlpha(0)
inercomonbut:AlphaTo(255,0.75)
function inercomonbut:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, inercomonbutc )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText('ВКЛЮЧИТЬ ИНТЕРКОМ','menubutfontf1',w*0.49,h*0.125,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end
inercomonbut.OnCursorEntered = function()
inercomonbutc = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
inercomonbut.OnCursorExited = function()
inercomonbutc = Color( 100, 100, 200, 255 )
end
inercomonbut.DoClick = function()
local function reportclsendrep2()
net.Start('f1menu_to_hud_intercomon')
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
reportclsendrep2()
end

local inercomonbutc2 = Color(100,100,200,255)
inercomonbut2 = vgui.Create( "DButton", f1menu ) 
inercomonbut2:SetText( " " )					
inercomonbut2:SetPos( ScrW()*0.25,ScrH()*0.221 )					
inercomonbut2:SetSize( ScrW()*0.2,ScrH()*0.04 )
inercomonbut2:SetAlpha(0)
inercomonbut2:AlphaTo(255,0.75)
function inercomonbut2:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, inercomonbutc2 )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText('ВЫКЛЮЧИТЬ ИНТЕРКОМ','menubutfontf1',w*0.49,h*0.125,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end
inercomonbut2.OnCursorEntered = function()
inercomonbutc2 = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
inercomonbut2.OnCursorExited = function()
inercomonbutc2 = Color( 100, 100, 200, 255 )
end
inercomonbut2.DoClick = function()
local function reportclsendrep2()
net.Start('f1menu_to_hud_intercomoff')
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
reportclsendrep2()
end
------------------------------------------------------------------------------------------------------------------+++
end

local function sendservhud()
net.Start('f1menu_cmdbutserver')   
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
sendservhud()

net.Receive("f1menu_cmdbutclient", function()
local playergrishka = net.ReadEntity()
if IsValid(fivebut) then
fivebut:Remove()
end
end)





local pointbut = vgui.Create( 'DButton', f1menu ) 
pointbut:SetText( '' )				
pointbut:SetPos( ScrW()*-0.1, ScrH()*0.45 )			
pointbut:SetSize( ScrW()*0.12, ScrH()*0.05 )	
pointbut:SetAlpha(0)		
function pointbut:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, pointbutc )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText('Персонаж','menubutfontf1',w*0.05,h*0.2,Color(230,230,230), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
end
pointbut.OnCursorEntered = function()
pointbutc = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
pointbut.OnCursorExited = function()
if IsValid( textfadepanel8 ) then return end
pointbutc = Color( 100, 100, 200, 255 )
end
pointbut.DoClick = function()
if IsValid( TextEntryKEK23 ) then
TextEntryKEK23:Remove()
end
if IsValid( DComboBoxkeksik2283 ) then
DComboBoxkeksik2283:Remove()
end
if IsValid( DermaButtonka ) then
DermaButtonka:Remove()
textfadepanel:SetAlpha(0)
end
if IsValid( DermaButtonkad ) then
DermaButtonkad:Remove()
textfadepanel:SetAlpha(0)
end
if IsValid( richtextusjaloba ) then
richtextusjaloba:Remove()
textfadepanel:SetAlpha(0)
end
if IsValid( character3 ) then
character3:Remove()
textfadepanel:SetAlpha(0)
end
if IsValid( Dcombohtlbox ) then
Dcombohtlbox:Remove()
end
if IsValid( htmldocs ) then
htmldocs:Remove()
end
if IsValid( radioconnectionsframe ) then 
radioconnectionsframe:Remove()
end
if IsValid( Radiochannelinsert ) then 
Radiochannelinsert:Remove()
end
if IsValid( radioconnections ) then 
radioconnections:Remove()
end
if IsValid( radioconnectbut ) then 
radioconnectbut:Remove()
end
if IsValid( radiodisconnectbut ) then 
radiodisconnectbut:Remove()
end
if IsValid( textfadepanel5 ) then 
textfadepanel5:Remove()
end
if IsValid( textfadepanel7 ) then 
textfadepanel7:Remove()
end
if IsValid(batonkafordefc) then
batonkafordefc:Remove()
batonkafordefc2:Remove()
batonkafordefc3:Remove()
batonkafordefc4:Remove()
batonkafordefc5:Remove()
Textprikazzadan:Remove()
butforsendprikaz:Remove()
butforsendprikazcl:Remove()
end
if IsValid(textintercomdist) then
textintercomdist:Remove()
butonforinterdist:Remove()
inercomonbut:Remove()
inercomonbut2:Remove()
end
if IsValid( textfadepanel6 ) then 
textfadepanel6:Remove()
end
if IsValid(textfadepanel8) then
hpbut:Remove()
hpbut2:Remove()
armorbut:Remove()
armorbut2:Remove()
staminbut:Remove()
staminbut2:Remove()
runbut:Remove()
runbut2:Remove()
ammobut:Remove()
ammobut2:Remove()
rpgbut:Remove()
rpgbut2:Remove()
pointssend:Remove()
end
if IsValid(moneysend) then
moneysend:Remove()
weaponmodeldc17:Remove()
weaponmodeldc15a:Remove()
weaponmodeldc15s:Remove()
end
homebutc = Color( 100, 100, 200, 255 )
secbutc = Color(100,100,200, 255)
tributc = Color(100,100,200, 255)
forbutc = Color(100,100,200, 255)
fivebutc = Color(100,100,200, 255)
sixbutc = Color(100,100,200, 255)
sevenbutc = Color(100,100,200, 255)
------------------------------------------------------------------------------------------------------------------+++
local function pointsget()
net.Start("f1menu_to_hud_srvpoints")
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
pointsget()
net.Receive("f1menu_to_hud_clientpoints", function()
local plpoints = net.ReadString()
local plxp = net.ReadString()
local pllevel = net.ReadString()
local hpboost = net.ReadString()
local armorboost = net.ReadString()
local statminaboost = net.ReadString()
local speedboost = net.ReadString()
local ammoboost = net.ReadString()
local rpgboost = net.ReadString()
local hpup = "0"
local armorup = "0"
local staminaup = "0"
local speedup = "0"
local ammoup = "0"
local rpgup = "0"
local hpup1 = "null"
local armorup1 = "null"
local staminaup1 = "null"
local speedup1 = "null"
local ammoup1 = "null"
local rpgup1 = "null"
local siniy = Color(100,100,255,255)
local green = Color(0,255,0,255)
local beliy = Color(0,255,0,255)
local palochka1 = Color(255,255,255,255)
local palochka12 = Color(255,255,255,255)
local palochka13 = Color(255,255,255,255)
local palochka14 = Color(255,255,255,255)
local palochka15 = Color(255,255,255,255)
local palochka16 = Color(255,255,255,255)
local palochka17 = Color(255,255,255,255)
local palochka18 = Color(255,255,255,255)
local palochka19 = Color(255,255,255,255)
local palochka110 = Color(255,255,255,255)
if hpboost == "1.5" then
palochka1 = green
palochka12 = green
palochka13 = green
palochka14 = green
palochka15 = green
palochka16 = green
palochka17 = green
palochka18 = green
palochka19 = green
palochka110 = green
elseif hpboost == "1.45" then
palochka1 = green
palochka12 = green
palochka13 = green
palochka14 = green
palochka15 = green
palochka16 = green
palochka17 = green
palochka18 = green
palochka19 = green
elseif hpboost == "1.4" then
palochka1 = green
palochka12 = green
palochka13 = green
palochka14 = green
palochka15 = green
palochka16 = green
palochka17 = green
palochka18 = green
elseif hpboost == "1.35" then
palochka1 = green
palochka12 = green
palochka13 = green
palochka14 = green
palochka15 = green
palochka16 = green
palochka17 = green
elseif hpboost == "1.3" then
palochka1 = green
palochka12 = green
palochka13 = green
palochka14 = green
palochka15 = green
palochka16 = green
elseif hpboost == "1.25" then
palochka1 = green
palochka12 = green
palochka13 = green
palochka14 = green
palochka15 = green
elseif hpboost == "1.2" then
palochka1 = green
palochka12 = green
palochka13 = green
palochka14 = green
elseif hpboost == "1.15" then
palochka1 = green
palochka12 = green
palochka13 = green
elseif hpboost == "1.1" then
palochka1 = green
palochka12 = green
elseif hpboost == "1.05" then
palochka1 = green
end

local hpbutcol = Color(100,100,200,255)
hpbut = vgui.Create( "DButton", f1menu ) 
hpbut:SetText( " " )					
hpbut:SetPos( ScrW()*0.2565,ScrH()*0.05 )					
hpbut:SetSize( ScrW()*0.02,ScrH()*0.025 )
hpbut:SetAlpha(0)
hpbut:AlphaTo(255,0.75)
function hpbut:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, hpbutcol )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText('>','threbuchetkos2',w*0.5,h*0,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end
hpbut.OnCursorEntered = function()
hpbutcol = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
hpbut.OnCursorExited = function()
hpbutcol = Color( 100, 100, 200, 255 )
end
hpbut.DoClick = function()
if palochka1 == Color(255,255,255,255) then
    palochka1 = siniy
    hpup = hpup + 1
    hpup1 = "hpup1"
elseif palochka12 == Color(255,255,255,255) then
	palochka12 = siniy
	hpup = hpup + 1
	hpup1 = "hpup2"
elseif palochka13 == Color(255,255,255,255) then
	palochka13 = siniy
	hpup = hpup + 2
	hpup1 = "hpup3"
elseif palochka14 == Color(255,255,255,255) then
	palochka14 = siniy
	hpup = hpup + 2
	hpup1 = "hpup4"
elseif palochka15 == Color(255,255,255,255) then
	palochka15 = siniy
	hpup = hpup + 3
	hpup1 = "hpup5"
elseif palochka16 == Color(255,255,255,255) then
	palochka16 = siniy
	hpup = hpup + 3
	hpup1 = "hpup6"
elseif palochka17 == Color(255,255,255,255) then
	palochka17 = siniy
	hpup = hpup + 4
	hpup1 = "hpup7"
elseif palochka18 == Color(255,255,255,255) then
	palochka18 = siniy
	hpup = hpup + 4
	hpup1 = "hpup8"
elseif palochka19 == Color(255,255,255,255) then
	palochka19 = siniy
	hpup = hpup + 5
	hpup1 = "hpup9"
elseif palochka110 == Color(255,255,255,255) then
	palochka110 = siniy
	hpup = hpup + 5
	hpup1 = "hpup10"
end
end

local hpbutcol2 = Color(100,100,200,255)
hpbut2 = vgui.Create( "DButton", f1menu ) 
hpbut2:SetText( " " )					
hpbut2:SetPos( ScrW()*0.125,ScrH()*0.05 )					
hpbut2:SetSize( ScrW()*0.02,ScrH()*0.025 )
hpbut2:SetAlpha(0)
hpbut2:AlphaTo(255,0.75)
function hpbut2:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, hpbutcol2 )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText('<','threbuchetkos2',w*0.5,h*0,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end
hpbut2.OnCursorEntered = function()
hpbutcol2 = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
hpbut2.OnCursorExited = function()
hpbutcol2 = Color( 100, 100, 200, 255 )
end
hpbut2.DoClick = function()
if palochka110 == siniy then
    palochka110 = Color(255,255,255,255)
    hpup = hpup - 5
    hpup1 = "hpup9"
elseif palochka19 == siniy then
	palochka19 = Color(255,255,255,255)
	hpup = hpup - 5
	hpup1 = "hpup8"
elseif palochka18 == siniy then
	palochka18 = Color(255,255,255,255)
	hpup = hpup - 4
	hpup1 = "hpup7"
elseif palochka17 == siniy then
	palochka17 = Color(255,255,255,255)
	hpup = hpup - 4
	hpup1 = "hpup6"
elseif palochka16 == siniy then
	palochka16 = Color(255,255,255,255)
	hpup = hpup - 3
	hpup1 = "hpup5"
elseif palochka15 == siniy then
	palochka15 = Color(255,255,255,255)
	hpup = hpup - 3
	hpup1 = "hpup4"
elseif palochka14 == siniy then
	palochka14 = Color(255,255,255,255)
	hpup = hpup - 2
	hpup1 = "hpup3"
elseif palochka13 == siniy then
	palochka13 = Color(255,255,255,255)
	hpup = hpup - 2
	hpup1 = "hpup2"
elseif palochka12 == siniy then
	palochka12 = Color(255,255,255,255)
	hpup = hpup - 1
	hpup1 = "hpup1"
elseif palochka1 == siniy then
	palochka1 = Color(255,255,255,255)
	hpup = hpup - 1
	hpup1 = "null"
end
end

local palochka2 = Color(255,255,255,255)
local palochka22 = Color(255,255,255,255)
local palochka23 = Color(255,255,255,255)
local palochka24 = Color(255,255,255,255)
local palochka25 = Color(255,255,255,255)
local palochka26 = Color(255,255,255,255)
local palochka27 = Color(255,255,255,255)
local palochka28 = Color(255,255,255,255)
local palochka29 = Color(255,255,255,255)
local palochka210 = Color(255,255,255,255)
if armorboost == "1.5" then
palochka2 = green
palochka22 = green
palochka23 = green
palochka24 = green
palochka25 = green
palochka26 = green
palochka27 = green
palochka28 = green
palochka29 = green
palochka210 = green
elseif armorboost == "1.45" then
palochka2 = green
palochka22 = green
palochka23 = green
palochka24 = green
palochka25 = green
palochka26 = green
palochka27 = green
palochka28 = green
palochka29 = green
elseif armorboost == "1.4" then
palochka2 = green
palochka22 = green
palochka23 = green
palochka24 = green
palochka25 = green
palochka26 = green
palochka27 = green
palochka28 = green
elseif armorboost == "1.35" then
palochka2 = green
palochka22 = green
palochka23 = green
palochka24 = green
palochka25 = green
palochka26 = green
palochka27 = green
elseif armorboost == "1.3" then
palochka2 = green
palochka22 = green
palochka23 = green
palochka24 = green
palochka25 = green
palochka26 = green
elseif armorboost == "1.25" then
palochka2 = green
palochka22 = green
palochka23 = green
palochka24 = green
palochka25 = green
elseif armorboost == "1.2" then
palochka2 = green
palochka22 = green
palochka23 = green
palochka24 = green
elseif armorboost == "1.15" then
palochka2 = green
palochka22 = green
palochka23 = green
elseif armorboost == "1.1" then
palochka2 = green
palochka22 = green
elseif armorboost == "1.05" then
palochka2 = green
end

local armorbutcol = Color(100,100,200,255)
armorbut = vgui.Create( "DButton", f1menu ) 
armorbut:SetText( " " )					
armorbut:SetPos( ScrW()*0.2565,ScrH()*0.08 )					
armorbut:SetSize( ScrW()*0.02,ScrH()*0.025 )
armorbut:SetAlpha(0)
armorbut:AlphaTo(255,0.75)
function armorbut:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, armorbutcol )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText('>','threbuchetkos2',w*0.5,h*0,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end
armorbut.OnCursorEntered = function()
armorbutcol = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
armorbut.OnCursorExited = function()
armorbutcol = Color( 100, 100, 200, 255 )
end
armorbut.DoClick = function()
if palochka2 == Color(255,255,255,255) then
    palochka2 = siniy
    armorup = armorup + 1
    armorup1 = "armorup1"
elseif palochka22 == Color(255,255,255,255) then
	palochka22 = siniy
	armorup = armorup + 1
	armorup1 = "armorup2"
elseif palochka23 == Color(255,255,255,255) then
	palochka23 = siniy
	armorup = armorup + 2
	armorup1 = "armorup3"
elseif palochka24 == Color(255,255,255,255) then
	palochka24 = siniy
	armorup = armorup + 2
	armorup1 = "armorup4"
elseif palochka25 == Color(255,255,255,255) then
	palochka25 = siniy
	armorup = armorup + 3
	armorup1 = "armorup5"
elseif palochka26 == Color(255,255,255,255) then
	palochka26 = siniy
	armorup = armorup + 3
	armorup1 = "armorup6"
elseif palochka27 == Color(255,255,255,255) then
	palochka27 = siniy
	armorup = armorup + 4
	armorup1 = "armorup7"
elseif palochka28 == Color(255,255,255,255) then
	palochka28 = siniy
	armorup = armorup + 4
	armorup1 = "armorup8"
elseif palochka29 == Color(255,255,255,255) then
	palochka29 = siniy
	armorup = armorup + 5
	armorup1 = "armorup9"
elseif palochka210 == Color(255,255,255,255) then
	palochka210 = siniy
	armorup = armorup + 5
	armorup1 = "armorup10"
end
end

local armorbutcol2 = Color(100,100,200,255)
armorbut2 = vgui.Create( "DButton", f1menu ) 
armorbut2:SetText( " " )					
armorbut2:SetPos( ScrW()*0.125,ScrH()*0.08 )					
armorbut2:SetSize( ScrW()*0.02,ScrH()*0.025 )
armorbut2:SetAlpha(0)
armorbut2:AlphaTo(255,0.75)
function armorbut2:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, armorbutcol2 )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText('<','threbuchetkos2',w*0.5,h*0,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end
armorbut2.OnCursorEntered = function()
armorbutcol2 = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
armorbut2.OnCursorExited = function()
armorbutcol2 = Color( 100, 100, 200, 255 )
end
armorbut2.DoClick = function()
if palochka210 == siniy then
    palochka210 = Color(255,255,255,255)
    armorup = armorup - 5
    armorup1 = "armorup9"
elseif palochka29 == siniy then
	palochka29 = Color(255,255,255,255)
	armorup = armorup - 5
	armorup1 = "armorup8"
elseif palochka28 == siniy then
	palochka28 = Color(255,255,255,255)
	armorup = armorup - 4
	armorup1 = "armorup7"
elseif palochka27 == siniy then
	palochka27 = Color(255,255,255,255)
	armorup = armorup - 4
	armorup1 = "armorup6"
elseif palochka26 == siniy then
	palochka26 = Color(255,255,255,255)
	armorup = armorup - 3
	armorup1 = "armorup5"
elseif palochka25 == siniy then
	palochka25 = Color(255,255,255,255)
	armorup = armorup - 3
	armorup1 = "armorup4"
elseif palochka24 == siniy then
	palochka24 = Color(255,255,255,255)
	armorup = armorup - 2
	armorup1 = "armorup3"
elseif palochka23 == siniy then
	palochka23 = Color(255,255,255,255)
	armorup = armorup - 2
	armorup1 = "armorup2"
elseif palochka22 == siniy then
	palochka22 = Color(255,255,255,255)
	armorup = armorup - 1
	armorup1 = "armorup1"
elseif palochka2 == siniy then
	palochka2 = Color(255,255,255,255)
	armorup = armorup - 1
	armorup1 = "null"
end
end

local palochka3 = Color(255,255,255,255)
local palochka32 = Color(255,255,255,255)
local palochka33 = Color(255,255,255,255)
local palochka34 = Color(255,255,255,255)
local palochka35 = Color(255,255,255,255)
local palochka36 = Color(255,255,255,255)
local palochka37 = Color(255,255,255,255)
local palochka38 = Color(255,255,255,255)
local palochka39 = Color(255,255,255,255)
local palochka310 = Color(255,255,255,255)
if statminaboost == "1.5" then
palochka3 = green
palochka32 = green
palochka33 = green
palochka34 = green
palochka35 = green
palochka36 = green
palochka37 = green
palochka38 = green
palochka39 = green
palochka310 = green
elseif statminaboost == "1.45" then
palochka3 = green
palochka32 = green
palochka33 = green
palochka34 = green
palochka35 = green
palochka36 = green
palochka37 = green
palochka38 = green
palochka39 = green
elseif statminaboost == "1.4" then
palochka3 = green
palochka32 = green
palochka33 = green
palochka34 = green
palochka35 = green
palochka36 = green
palochka37 = green
palochka38 = green
elseif statminaboost == "1.35" then
palochka3 = green
palochka32 = green
palochka33 = green
palochka34 = green
palochka35 = green
palochka36 = green
palochka37 = green
elseif statminaboost == "1.3" then
palochka3 = green
palochka32 = green
palochka33 = green
palochka34 = green
palochka35 = green
palochka36 = green
elseif statminaboost == "1.25" then
palochka3 = green
palochka32 = green
palochka33 = green
palochka34 = green
palochka35 = green
elseif statminaboost == "1.2" then
palochka3 = green
palochka32 = green
palochka33 = green
palochka34 = green
elseif statminaboost == "1.15" then
palochka3 = green
palochka32 = green
palochka33 = green
elseif statminaboost == "1.1" then
palochka3 = green
palochka32 = green
elseif statminaboost == "1.05" then
palochka3 = green
end

local staminbutcol = Color(100,100,200,255)
staminbut = vgui.Create( "DButton", f1menu ) 
staminbut:SetText( " " )					
staminbut:SetPos( ScrW()*0.2565,ScrH()*0.11 )					
staminbut:SetSize( ScrW()*0.02,ScrH()*0.025 )
staminbut:SetAlpha(0)
staminbut:AlphaTo(255,0.75)
function staminbut:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, staminbutcol )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText('>','threbuchetkos2',w*0.5,h*0,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end
staminbut.OnCursorEntered = function()
staminbutcol = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
staminbut.OnCursorExited = function()
staminbutcol = Color( 100, 100, 200, 255 )
end
staminbut.DoClick = function()
if palochka3 == Color(255,255,255,255) then
    palochka3 = siniy
    staminaup = staminaup + 1
    staminaup1 = "staminaup1"
elseif palochka32 == Color(255,255,255,255) then
	palochka32 = siniy
	staminaup = staminaup + 1
	staminaup1 = "staminaup2"
elseif palochka33 == Color(255,255,255,255) then
	palochka33 = siniy
	staminaup = staminaup + 2
	staminaup1 = "staminaup3"
elseif palochka34 == Color(255,255,255,255) then
	palochka34 = siniy
	staminaup = staminaup + 2
	staminaup1 = "staminaup4"
elseif palochka35 == Color(255,255,255,255) then
	palochka35 = siniy
	staminaup = staminaup + 3
	staminaup1 = "staminaup5"
elseif palochka36 == Color(255,255,255,255) then
	palochka36 = siniy
	staminaup = staminaup + 3
	staminaup1 = "staminaup6"
elseif palochka37 == Color(255,255,255,255) then
	palochka37 = siniy
	staminaup = staminaup + 4
	staminaup1 = "staminaup7"
elseif palochka38 == Color(255,255,255,255) then
	palochka38 = siniy
	staminaup = staminaup + 4
	staminaup1 = "staminaup8"
elseif palochka39 == Color(255,255,255,255) then
	palochka39 = siniy
	staminaup = staminaup + 5
	staminaup1 = "staminaup9"
elseif palochka310 == Color(255,255,255,255) then
	palochka310 = siniy
	staminaup = staminaup + 5
	staminaup1 = "staminaup10"
end
end

local staminbutcol2 = Color(100,100,200,255)
staminbut2 = vgui.Create( "DButton", f1menu ) 
staminbut2:SetText( " " )					
staminbut2:SetPos( ScrW()*0.125,ScrH()*0.11 )					
staminbut2:SetSize( ScrW()*0.02,ScrH()*0.025 )
staminbut2:SetAlpha(0)
staminbut2:AlphaTo(255,0.75)
function staminbut2:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, staminbutcol2 )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText('<','threbuchetkos2',w*0.5,h*0,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end
staminbut2.OnCursorEntered = function()
staminbutcol2 = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
staminbut2.OnCursorExited = function()
staminbutcol2 = Color( 100, 100, 200, 255 )
end
staminbut2.DoClick = function()
if palochka310 == siniy then
    palochka310 = Color(255,255,255,255)
    staminaup = staminaup - 5
    staminaup1 = "staminaup9"
elseif palochka39 == siniy then
	palochka39 = Color(255,255,255,255)
	staminaup = staminaup - 5
	staminaup1 = "staminaup8"
elseif palochka38 == siniy then
	palochka38 = Color(255,255,255,255)
	staminaup = staminaup - 4
	staminaup1 = "staminaup7"
elseif palochka37 == siniy then
	palochka37 = Color(255,255,255,255)
	staminaup = staminaup - 4
	staminaup1 = "staminaup6"
elseif palochka36 == siniy then
	palochka36 = Color(255,255,255,255)
	staminaup = staminaup - 3
	staminaup1 = "staminaup5"
elseif palochka35 == siniy then
	palochka35 = Color(255,255,255,255)
	staminaup = staminaup - 3
	staminaup1 = "staminaup4"
elseif palochka34 == siniy then
	palochka34 = Color(255,255,255,255)
	staminaup = staminaup - 2
	staminaup1 = "staminaup3"
elseif palochka33 == siniy then
	palochka33 = Color(255,255,255,255)
	staminaup = staminaup - 2
	staminaup1 = "staminaup2"
elseif palochka32 == siniy then
	palochka32 = Color(255,255,255,255)
	staminaup = staminaup - 1
	staminaup1 = "staminaup1"
elseif palochka3 == siniy then
	palochka3 = Color(255,255,255,255)
	staminaup = staminaup - 1
	staminaup1 = "null"
end
end

local palochka4 = Color(255,255,255,255)
local palochka42 = Color(255,255,255,255)
local palochka43 = Color(255,255,255,255)
local palochka44 = Color(255,255,255,255)
local palochka45 = Color(255,255,255,255)
local palochka46 = Color(255,255,255,255)
local palochka47 = Color(255,255,255,255)
local palochka48 = Color(255,255,255,255)
if speedboost == "1.2" then
palochka4 = green
palochka42 = green
palochka43 = green
palochka44 = green
palochka45 = green
palochka46 = green
palochka47 = green
palochka48 = green
elseif speedboost == "1.175" then
palochka4 = green
palochka42 = green
palochka43 = green
palochka44 = green
palochka45 = green
palochka46 = green
palochka47 = green
elseif speedboost == "1.15" then
palochka4 = green
palochka42 = green
palochka43 = green
palochka44 = green
palochka45 = green
palochka46 = green
elseif speedboost == "1.125" then
palochka4 = green
palochka42 = green
palochka43 = green
palochka44 = green
palochka45 = green
elseif speedboost == "1.1" then
palochka4 = green
palochka42 = green
palochka43 = green
palochka44 = green
elseif speedboost == "1.075" then
palochka4 = green
palochka42 = green
palochka43 = green
elseif speedboost == "1.05" then
palochka4 = green
palochka42 = green
elseif speedboost == "1.025" then
palochka4 = green
end

local runbutcol = Color(100,100,200,255)
runbut = vgui.Create( "DButton", f1menu ) 
runbut:SetText( " " )					
runbut:SetPos( ScrW()*0.2565,ScrH()*0.14 )					
runbut:SetSize( ScrW()*0.02,ScrH()*0.025 )
runbut:SetAlpha(0)
runbut:AlphaTo(255,0.75)
function runbut:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, runbutcol )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText('>','threbuchetkos2',w*0.5,h*0,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end
runbut.OnCursorEntered = function()
runbutcol = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
runbut.OnCursorExited = function()
runbutcol = Color( 100, 100, 200, 255 )
end
runbut.DoClick = function()
if palochka4 == Color(255,255,255,255) then
    palochka4 = siniy
    speedup = speedup + 1
    speedup1 = "speedup1"
elseif palochka42 == Color(255,255,255,255) then
	palochka42 = siniy
	speedup = speedup + 1
	speedup1 = "speedup2"
elseif palochka43 == Color(255,255,255,255) then
	palochka43 = siniy
	speedup = speedup + 2
	speedup1 = "speedup3"
elseif palochka44 == Color(255,255,255,255) then
	palochka44 = siniy
	speedup = speedup + 2
	speedup1 = "speedup4"
elseif palochka45 == Color(255,255,255,255) then
	palochka45 = siniy
	speedup = speedup + 3
	speedup1 = "speedup5"
elseif palochka46 == Color(255,255,255,255) then
	palochka46 = siniy
	speedup = speedup + 3
	speedup1 = "speedup6"
elseif palochka47 == Color(255,255,255,255) then
	palochka47 = siniy
	speedup = speedup + 4
	speedup1 = "speedup7"
elseif palochka48 == Color(255,255,255,255) then
	palochka48 = siniy
	speedup = speedup + 4
	speedup1 = "speedup8"
end
end

local runbutcol2 = Color(100,100,200,255)
runbut2 = vgui.Create( "DButton", f1menu ) 
runbut2:SetText( " " )					
runbut2:SetPos( ScrW()*0.125,ScrH()*0.14 )					
runbut2:SetSize( ScrW()*0.02,ScrH()*0.025 )
runbut2:SetAlpha(0)
runbut2:AlphaTo(255,0.75)
function runbut2:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, runbutcol2 )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText('<','threbuchetkos2',w*0.5,h*0,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end
runbut2.OnCursorEntered = function()
runbutcol2 = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
runbut2.OnCursorExited = function()
runbutcol2 = Color( 100, 100, 200, 255 )
end
runbut2.DoClick = function()
if palochka48 == siniy then
	palochka48 = Color(255,255,255,255)
	speedup = speedup - 4
	speedup1 = "speedup7"
elseif palochka47 == siniy then
	palochka47 = Color(255,255,255,255)
	speedup = speedup - 4
	speedup1 = "speedup6"
elseif palochka46 == siniy then
	palochka46 = Color(255,255,255,255)
	speedup = speedup - 3
	speedup1 = "speedup5"
elseif palochka45 == siniy then
	palochka45 = Color(255,255,255,255)
	speedup = speedup - 3
	speedup1 = "speedup4"
elseif palochka44 == siniy then
	palochka44 = Color(255,255,255,255)
	speedup = speedup - 2
	speedup1 = "speedup3"
elseif palochka43 == siniy then
	palochka43 = Color(255,255,255,255)
	speedup = speedup - 2
	speedup1 = "speedup2"
elseif palochka42 == siniy then
	palochka42 = Color(255,255,255,255)
	speedup = speedup - 1
	speedup1 = "speedup1"
elseif palochka4 == siniy then
	palochka4 = Color(255,255,255,255)
	speedup = speedup - 1
	speedup1 = "null"
end
end

local palochka5 = Color(255,255,255,255)
local palochka52 = Color(255,255,255,255)
local palochka53 = Color(255,255,255,255)
local palochka54 = Color(255,255,255,255)
local palochka55 = Color(255,255,255,255)
local palochka56 = Color(255,255,255,255)
local palochka57 = Color(255,255,255,255)
local palochka58 = Color(255,255,255,255)
local palochka59 = Color(255,255,255,255)
local palochka510 = Color(255,255,255,255)
if ammoboost == "1.5" then
palochka5 = green
palochka52 = green
palochka53 = green
palochka54 = green
palochka55 = green
palochka56 = green
palochka57 = green
palochka58 = green
palochka59 = green
palochka510 = green
elseif ammoboost == "1.45" then
palochka5 = green
palochka52 = green
palochka53 = green
palochka54 = green
palochka55 = green
palochka56 = green
palochka57 = green
palochka58 = green
palochka59 = green
elseif ammoboost == "1.4" then
palochka5 = green
palochka52 = green
palochka53 = green
palochka54 = green
palochka55 = green
palochka56 = green
palochka57 = green
palochka58 = green
elseif ammoboost == "1.35" then
palochka5 = green
palochka52 = green
palochka53 = green
palochka54 = green
palochka55 = green
palochka56 = green
palochka57 = green
elseif ammoboost == "1.3" then
palochka5 = green
palochka52 = green
palochka53 = green
palochka54 = green
palochka55 = green
palochka56 = green
elseif ammoboost == "1.25" then
palochka5 = green
palochka52 = green
palochka53 = green
palochka54 = green
palochka55 = green
elseif ammoboost == "1.2" then
palochka5 = green
palochka52 = green
palochka53 = green
palochka54 = green
elseif ammoboost == "1.15" then
palochka5 = green
palochka52 = green
palochka53 = green
elseif ammoboost == "1.1" then
palochka5 = green
palochka52 = green
elseif ammoboost == "1.05" then
palochka5 = green
end

local ammobutcol = Color(100,100,200,255)
ammobut = vgui.Create( "DButton", f1menu ) 
ammobut:SetText( " " )					
ammobut:SetPos( ScrW()*0.2565,ScrH()*0.17 )					
ammobut:SetSize( ScrW()*0.02,ScrH()*0.025 )
ammobut:SetAlpha(0)
ammobut:AlphaTo(255,0.75)
function ammobut:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, ammobutcol )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText('>','threbuchetkos2',w*0.5,h*0,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end
ammobut.OnCursorEntered = function()
ammobutcol = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
ammobut.OnCursorExited = function()
ammobutcol = Color( 100, 100, 200, 255 )
end
ammobut.DoClick = function()
if palochka5 == Color(255,255,255,255) then
    palochka5 = siniy
    ammoup = ammoup + 1
    ammoup1 = "ammoup1"
elseif palochka52 == Color(255,255,255,255) then
	palochka52 = siniy
	ammoup = ammoup + 1
	ammoup1 = "ammoup2"
elseif palochka53 == Color(255,255,255,255) then
	palochka53 = siniy
	ammoup = ammoup + 2
	ammoup1 = "ammoup3"
elseif palochka54 == Color(255,255,255,255) then
	palochka54 = siniy
	ammoup = ammoup + 2
	ammoup1 = "ammoup4"
elseif palochka55 == Color(255,255,255,255) then
	palochka55 = siniy
	ammoup = ammoup + 3
	ammoup1 = "ammoup5"
elseif palochka56 == Color(255,255,255,255) then
	palochka56 = siniy
	ammoup = ammoup + 3
	ammoup1 = "ammoup6"
elseif palochka57 == Color(255,255,255,255) then
	palochka57 = siniy
	ammoup = ammoup + 4
	ammoup1 = "ammoup7"
elseif palochka58 == Color(255,255,255,255) then
	palochka58 = siniy
	ammoup = ammoup + 4
	ammoup1 = "ammoup8"
elseif palochka59 == Color(255,255,255,255) then
	palochka59 = siniy
	ammoup = ammoup + 5
	ammoup1 = "ammoup9"
elseif palochka510 == Color(255,255,255,255) then
	palochka510 = siniy
	ammoup = ammoup + 5
	ammoup1 = "ammoup10"
end
end

local ammobutcol2 = Color(100,100,200,255)
ammobut2 = vgui.Create( "DButton", f1menu ) 
ammobut2:SetText( " " )					
ammobut2:SetPos( ScrW()*0.125,ScrH()*0.17 )					
ammobut2:SetSize( ScrW()*0.02,ScrH()*0.025 )
ammobut2:SetAlpha(0)
ammobut2:AlphaTo(255,0.75)
function ammobut2:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, ammobutcol2 )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText('<','threbuchetkos2',w*0.5,h*0,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end
ammobut2.OnCursorEntered = function()
ammobutcol2 = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
ammobut2.OnCursorExited = function()
ammobutcol2 = Color( 100, 100, 200, 255 )
end
ammobut2.DoClick = function()
if palochka510 == siniy then
    palochka510 = Color(255,255,255,255)
    ammoup = ammoup - 5
    ammoup1 = "ammoup9"
elseif palochka59 == siniy then
	palochka59 = Color(255,255,255,255)
	ammoup = ammoup - 5
	ammoup1 = "ammoup8"
elseif palochka58 == siniy then
	palochka58 = Color(255,255,255,255)
	ammoup = ammoup - 4
	ammoup1 = "ammoup7"
elseif palochka57 == siniy then
	palochka57 = Color(255,255,255,255)
	ammoup = ammoup - 4
	ammoup1 = "ammoup6"
elseif palochka56 == siniy then
	palochka56 = Color(255,255,255,255)
	ammoup = ammoup - 3
	ammoup1 = "ammoup5"
elseif palochka55 == siniy then
	palochka55 = Color(255,255,255,255)
	ammoup = ammoup - 3
	ammoup1 = "ammoup4"
elseif palochka54 == siniy then
	palochka54 = Color(255,255,255,255)
	ammoup = ammoup - 2
	ammoup1 = "ammoup3"
elseif palochka53 == siniy then
	palochka53 = Color(255,255,255,255)
	ammoup = ammoup - 2
	ammoup1 = "ammoup2"
elseif palochka52 == siniy then
	palochka52 = Color(255,255,255,255)
	ammoup = ammoup - 1
	ammoup1 = "ammoup1"
elseif palochka5 == siniy then
	palochka5 = Color(255,255,255,255)
	ammoup = ammoup - 1
	ammoup1 = "null"
end
end

local palochka6 = Color(255,255,255,255)
local palochka62 = Color(255,255,255,255)
local palochka63 = Color(255,255,255,255)
if rpgboost == "3" then
palochka63 = green
palochka62 = green
palochka6 = green
elseif rpgboost == "2" then
palochka62 = green
palochka6 = green
elseif rpgboost == "1" then
palochka6 = green
end

local rpgbutcol = Color(100,100,200,255)
rpgbut = vgui.Create( "DButton", f1menu ) 
rpgbut:SetText( " " )					
rpgbut:SetPos( ScrW()*0.2565,ScrH()*0.2 )					
rpgbut:SetSize( ScrW()*0.02,ScrH()*0.025 )
rpgbut:SetAlpha(0)
rpgbut:AlphaTo(255,0.75)
function rpgbut:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, rpgbutcol )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText('>','threbuchetkos2',w*0.5,h*0,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end
rpgbut.OnCursorEntered = function()
rpgbutcol = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
rpgbut.OnCursorExited = function()
rpgbutcol = Color( 100, 100, 200, 255 )
end
rpgbut.DoClick = function()
if palochka6 == Color(255,255,255,255) then
    palochka6 = siniy
    rpgup = rpgup + 1
    rpgup1 = "rpgup1"
elseif palochka62 == Color(255,255,255,255) then
	palochka62 = siniy
	rpgup = rpgup + 3
	rpgup1 = "rpgup2"
elseif palochka63 == Color(255,255,255,255) then
	palochka63 = siniy
	rpgup = rpgup + 5
	rpgup1 = "rpgup3"
end
end

local rpgbutcol2 = Color(100,100,200,255)
rpgbut2 = vgui.Create( "DButton", f1menu ) 
rpgbut2:SetText( " " )					
rpgbut2:SetPos( ScrW()*0.125,ScrH()*0.2 )					
rpgbut2:SetSize( ScrW()*0.02,ScrH()*0.025 )
rpgbut2:SetAlpha(0)
rpgbut2:AlphaTo(255,0.75)
function rpgbut2:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, rpgbutcol2 )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText('<','threbuchetkos2',w*0.5,h*0,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end
rpgbut2.OnCursorEntered = function()
rpgbutcol2 = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
rpgbut2.OnCursorExited = function()
rpgbutcol2 = Color( 100, 100, 200, 255 )
end
rpgbut2.DoClick = function()
if palochka63 == siniy then
    palochka63 = Color(255,255,255,255)
    rpgup = rpgup - 5
    rpgup1 = "rpgup2"
elseif palochka62 == siniy then
	palochka62 = Color(255,255,255,255)
	rpgup = rpgup - 3
	rpgup1 = "rpgup1"
elseif palochka6 == siniy then
	palochka6 = Color(255,255,255,255)
	rpgup = rpgup - 1
	rpgup1 = "null"
end
end

local xpmax = math.ceil((plxp / 1000) * 100)
local xpneed = "1000"
if pllevel == "0" then
xpmax = math.ceil((plxp / 120) * 100)
xpneed = "120"
elseif pllevel == "1" then
xpmax = math.ceil((plxp / 150) * 100)
xpneed = "150"
elseif pllevel == "2" then
xpmax = math.ceil((plxp / 190) * 100)
xpneed = "190"
elseif pllevel == "3" then
xpmax = math.ceil((plxp / 240) * 100)
xpneed = "240"
elseif pllevel == "4" then
xpmax = math.ceil((plxp / 300) * 100)
xpneed = "300"
elseif pllevel == "5" then
xpmax = math.ceil((plxp / 400) * 100)
xpneed = "400"
elseif pllevel == "6" then
xpmax = math.ceil((plxp / 500) * 100)
xpneed = "500"
elseif pllevel == "7" then
xpmax = math.ceil((plxp / 600) * 100)
xpneed = "600"
elseif pllevel == "8" then
xpmax = math.ceil((plxp / 700) * 100)
xpneed = "700"
elseif pllevel == "9" then
xpmax = math.ceil((plxp / 800) * 100)
xpneed = "800"
elseif pllevel == "10" then
xpmax = math.ceil((plxp / 1000) * 100)
xpneed = "1000"
end

if IsValid( textfadepanel8 ) then 
textfadepanel8:Remove()
end
textfadepanel8 = vgui.Create( "DPanel", f1menu ) 	
textfadepanel8:SetPos(0, 0)			
textfadepanel8:SetSize(ScrW(), ScrH()) 				
textfadepanel8:SetAlpha(0)
textfadepanel8:SetMouseInputEnabled( false )	
function textfadepanel8:Paint( w, h )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
---1
draw.RoundedBox( 1, w*0.15, h*0.05, w*0.1015, h*0.025, Color(55,55,55,220) )
draw.RoundedBox( 1, w*0.15125, h*0.0525, w*0.005, h*0.02, palochka1 )
draw.RoundedBox( 1, w*0.16125, h*0.0525, w*0.005, h*0.02, palochka12 )
draw.RoundedBox( 1, w*0.17175, h*0.0525, w*0.005, h*0.02, palochka13 )
draw.RoundedBox( 1, w*0.18225, h*0.0525, w*0.005, h*0.02, palochka14 )
draw.RoundedBox( 1, w*0.19275, h*0.0525, w*0.005, h*0.02, palochka15 )
draw.RoundedBox( 1, w*0.20325, h*0.0525, w*0.005, h*0.02, palochka16 )
draw.RoundedBox( 1, w*0.21375, h*0.0525, w*0.005, h*0.02, palochka17 )
draw.RoundedBox( 1, w*0.22425, h*0.0525, w*0.005, h*0.02, palochka18 )
draw.RoundedBox( 1, w*0.23475, h*0.0525, w*0.005, h*0.02, palochka19 )
draw.RoundedBox( 1, w*0.24525, h*0.0525, w*0.005, h*0.02, palochka110 )
---2
draw.RoundedBox( 1, w*0.15, h*0.08, w*0.1015, h*0.025, Color(55,55,55,220) )
draw.RoundedBox( 1, w*0.15125, h*0.0825, w*0.005, h*0.02, palochka2 )
draw.RoundedBox( 1, w*0.16125, h*0.0825, w*0.005, h*0.02, palochka22 )
draw.RoundedBox( 1, w*0.17175, h*0.0825, w*0.005, h*0.02, palochka23 )
draw.RoundedBox( 1, w*0.18225, h*0.0825, w*0.005, h*0.02, palochka24 )
draw.RoundedBox( 1, w*0.19275, h*0.0825, w*0.005, h*0.02, palochka25 )
draw.RoundedBox( 1, w*0.20325, h*0.0825, w*0.005, h*0.02, palochka26 )
draw.RoundedBox( 1, w*0.21375, h*0.0825, w*0.005, h*0.02, palochka27 )
draw.RoundedBox( 1, w*0.22425, h*0.0825, w*0.005, h*0.02, palochka28 )
draw.RoundedBox( 1, w*0.23475, h*0.0825, w*0.005, h*0.02, palochka29 )
draw.RoundedBox( 1, w*0.24525, h*0.0825, w*0.005, h*0.02, palochka210 )
---3
draw.RoundedBox( 1, w*0.15, h*0.11, w*0.1015, h*0.025, Color(55,55,55,220) )
draw.RoundedBox( 1, w*0.15125, h*0.1125, w*0.005, h*0.02, palochka3 )
draw.RoundedBox( 1, w*0.16125, h*0.1125, w*0.005, h*0.02, palochka32 )
draw.RoundedBox( 1, w*0.17175, h*0.1125, w*0.005, h*0.02, palochka33 )
draw.RoundedBox( 1, w*0.18225, h*0.1125, w*0.005, h*0.02, palochka34 )
draw.RoundedBox( 1, w*0.19275, h*0.1125, w*0.005, h*0.02, palochka35 )
draw.RoundedBox( 1, w*0.20325, h*0.1125, w*0.005, h*0.02, palochka36 )
draw.RoundedBox( 1, w*0.21375, h*0.1125, w*0.005, h*0.02, palochka37 )
draw.RoundedBox( 1, w*0.22425, h*0.1125, w*0.005, h*0.02, palochka38 )
draw.RoundedBox( 1, w*0.23475, h*0.1125, w*0.005, h*0.02, palochka39 )
draw.RoundedBox( 1, w*0.24525, h*0.1125, w*0.005, h*0.02, palochka310 )
---4
draw.RoundedBox( 1, w*0.15, h*0.14, w*0.1015, h*0.025, Color(55,55,55,220) )
draw.RoundedBox( 1, w*0.15125, h*0.1425, w*0.005, h*0.02, palochka4 )
draw.RoundedBox( 1, w*0.16125, h*0.1425, w*0.005, h*0.02, palochka42 )
draw.RoundedBox( 1, w*0.17175, h*0.1425, w*0.005, h*0.02, palochka43 )
draw.RoundedBox( 1, w*0.18225, h*0.1425, w*0.005, h*0.02, palochka44 )
draw.RoundedBox( 1, w*0.19275, h*0.1425, w*0.005, h*0.02, palochka45 )
draw.RoundedBox( 1, w*0.20325, h*0.1425, w*0.005, h*0.02, palochka46 )
draw.RoundedBox( 1, w*0.21375, h*0.1425, w*0.005, h*0.02, palochka47 )
draw.RoundedBox( 1, w*0.22425, h*0.1425, w*0.005, h*0.02, palochka48 )
---5
draw.RoundedBox( 1, w*0.15, h*0.17, w*0.1015, h*0.025, Color(55,55,55,220) )
draw.RoundedBox( 1, w*0.15125, h*0.173, w*0.005, h*0.02, palochka5 )
draw.RoundedBox( 1, w*0.16125, h*0.173, w*0.005, h*0.02, palochka52 )
draw.RoundedBox( 1, w*0.17175, h*0.173, w*0.005, h*0.02, palochka53 )
draw.RoundedBox( 1, w*0.18225, h*0.173, w*0.005, h*0.02, palochka54 )
draw.RoundedBox( 1, w*0.19275, h*0.173, w*0.005, h*0.02, palochka55 )
draw.RoundedBox( 1, w*0.20325, h*0.173, w*0.005, h*0.02, palochka56 )
draw.RoundedBox( 1, w*0.21375, h*0.173, w*0.005, h*0.02, palochka57 )
draw.RoundedBox( 1, w*0.22425, h*0.173, w*0.005, h*0.02, palochka58 )
draw.RoundedBox( 1, w*0.23475, h*0.173, w*0.005, h*0.02, palochka59 )
draw.RoundedBox( 1, w*0.24525, h*0.173, w*0.005, h*0.02, palochka510 )
---6
draw.RoundedBox( 1, w*0.15, h*0.2, w*0.1015, h*0.025, Color(55,55,55,220) )
draw.RoundedBox( 1, w*0.15125, h*0.203, w*0.005, h*0.02, palochka6 )
draw.RoundedBox( 1, w*0.16125, h*0.203, w*0.005, h*0.02, palochka62 )
draw.RoundedBox( 1, w*0.17175, h*0.203, w*0.005, h*0.02, palochka63 )
---
draw.RoundedBox( 1, w*0.15, h*0.55, xpmax * (w*0.00157), h*0.014, Color(55,55,55,220) )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( w*0.15, h*0.55, 100 * (w*0.00157), h*0.014 )
end

--local hptext = plpoints.."/"..hpup.." здоровье (5%)"
--local armortext = plpoints.."/"..armorup.." броня (5%)"
--local staminatext = plpoints.."/"..staminaup.." стамина (5%)"
--local speedtext = plpoints.."/"..speedup.." скорость (2,5%)"
--local ammotext = plpoints.."/"..ammoup.." патроны (5%)"
--local rpgtext = plpoints.."/"..rpgup.." взрывчатка (1ед)"

--if palochka110 == green then
--hptext = "MAX здоровье"
--end
--if palochka210 == green then
--armortext = "MAX броня"
--end
--if palochka310 == green then
--staminatext = "MAX стамина"
--end
--if palochka48 == green then
--speedtext = "MAX скорость"
--end
--if palochka510 == green then
--ammotext = "MAX патроны"
--end
--if palochka63 == green then
--rpgtext = "MAX взрывчатка"
--end

if IsValid( textfadepanel9 ) then 
textfadepanel9:Remove()
end
textfadepanel9 = vgui.Create( "DPanel", f1menu ) 	
textfadepanel9:SetPos(0, 0)			
textfadepanel9:SetSize(ScrW(), ScrH()) 				
textfadepanel9:SetAlpha(0)
textfadepanel9:SetMouseInputEnabled( false )	
function textfadepanel9:Paint( w, h )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
draw.SimpleText(plpoints.."/"..hpup.." здоровье (5%)",'menubutfontf1',w*0.3,h*0.05,Color(230,230,230), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
draw.SimpleText(plpoints.."/"..armorup.." броня (5%)",'menubutfontf1',w*0.3,h*0.08,Color(230,230,230), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
draw.SimpleText(plpoints.."/"..staminaup.." стамина (5%)",'menubutfontf1',w*0.3,h*0.11,Color(230,230,230), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
draw.SimpleText(plpoints.."/"..speedup.." скорость (2,5%)",'menubutfontf1',w*0.3,h*0.14,Color(230,230,230), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
draw.SimpleText(plpoints.."/"..ammoup.." патроны (5%)",'menubutfontf1',w*0.3,h*0.17,Color(230,230,230), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
draw.SimpleText(plpoints.."/"..rpgup.." взрывчатка (1ед)",'menubutfontf1',w*0.3,h*0.2,Color(230,230,230), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
draw.SimpleText("Во время ивентов опыт X2",'menubutfontf1li',w*0.15,h*0.525,Color(230,230,230), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
draw.SimpleText(pllevel,'menubutfontf1li',w*0.145,h*0.55,Color(230,230,230), TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
draw.SimpleText(pllevel + 1,'menubutfontf1li',w*0.31,h*0.55,Color(230,230,230), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
draw.SimpleText(plxp.."/"..xpneed,'menubutfontf1li',w*0.23,h*0.55,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end

textfadepanel8:AlphaTo(255,0.5)
textfadepanel9:AlphaTo(255,0.5)

local pointssendc = Color(100,100,200,255)
pointssend = vgui.Create( "DButton", f1menu ) 
pointssend:SetText( " " )					
pointssend:SetPos( ScrW()*0.125,ScrH()*0.23 )					
pointssend:SetSize( ScrW()*0.1515,ScrH()*0.04 )
pointssend:SetAlpha(0)
pointssend:AlphaTo(255,0.75)
function pointssend:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, pointssendc )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText('УЛУЧШИТЬ','menubutfontf1',w*0.5,h*0.125,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end
pointssend.OnCursorEntered = function()
pointssendc = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
pointssend.OnCursorExited = function()
pointssendc = Color( 100, 100, 200, 255 )
end
pointssend.DoClick = function()
if ((hpup + armorup + staminaup + speedup + ammoup + rpgup) <= (plpoints + 0)) then
if ((hpup1 != "null") or (armorup1 != "null") or (staminaup1 != "null") or (speedup1 != "null") or (ammoup1 != "null") or (rpgup1 != "null")) then
local function reportclsendrep2()
net.Start('f1menu_to_hud_srvpointsset')
net.WriteEntity(LocalPlayer())
net.WriteString(hpup)
net.WriteString(armorup)
net.WriteString(staminaup)
net.WriteString(speedup)
net.WriteString(ammoup)
net.WriteString(rpgup)
net.WriteString(hpup1)
net.WriteString(armorup1)
net.WriteString(staminaup1)
net.WriteString(speedup1)
net.WriteString(ammoup1)
net.WriteString(rpgup1)
net.SendToServer()
end
reportclsendrep2()
pointbut:DoClick()
end
end
end

end)
------------------------------------------------------------------------------------------------------------------+++
end





local sixbut = vgui.Create( 'DButton', f1menu ) 
sixbut:SetText( '' )				
sixbut:SetPos( ScrW()*-0.1, ScrH()*0.5 )			
sixbut:SetSize( ScrW()*0.12, ScrH()*0.05 )	
sixbut:SetAlpha(0)		
function sixbut:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, sixbutc )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText('Оружие','menubutfontf1',w*0.05,h*0.2,Color(230,230,230), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
end
sixbut.OnCursorEntered = function()
sixbutc = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
sixbut.OnCursorExited = function()
if IsValid( textfadepanel6 ) then return end
sixbutc = Color( 100, 100, 200, 255 )
end
sixbut.DoClick = function()
if IsValid( TextEntryKEK23 ) then
TextEntryKEK23:Remove()
end
if IsValid( DComboBoxkeksik2283 ) then
DComboBoxkeksik2283:Remove()
end
if IsValid( DermaButtonka ) then
DermaButtonka:Remove()
textfadepanel:SetAlpha(0)
end
if IsValid( DermaButtonkad ) then
DermaButtonkad:Remove()
textfadepanel:SetAlpha(0)
end
if IsValid( richtextusjaloba ) then
richtextusjaloba:Remove()
textfadepanel:SetAlpha(0)
end
if IsValid( character3 ) then
character3:Remove()
textfadepanel:SetAlpha(0)
end
if IsValid( Dcombohtlbox ) then
Dcombohtlbox:Remove()
end
if IsValid( htmldocs ) then
htmldocs:Remove()
end
if IsValid( radioconnectionsframe ) then 
radioconnectionsframe:Remove()
end
if IsValid( Radiochannelinsert ) then 
Radiochannelinsert:Remove()
end
if IsValid( radioconnections ) then 
radioconnections:Remove()
end
if IsValid( radioconnectbut ) then 
radioconnectbut:Remove()
end
if IsValid( radiodisconnectbut ) then 
radiodisconnectbut:Remove()
end
if IsValid( textfadepanel5 ) then 
textfadepanel5:Remove()
end
if IsValid( textfadepanel7 ) then 
textfadepanel7:Remove()
end
if IsValid(batonkafordefc) then
batonkafordefc:Remove()
batonkafordefc2:Remove()
batonkafordefc3:Remove()
batonkafordefc4:Remove()
batonkafordefc5:Remove()
Textprikazzadan:Remove()
butforsendprikaz:Remove()
butforsendprikazcl:Remove()
end
if IsValid(textintercomdist) then
textintercomdist:Remove()
butonforinterdist:Remove()
inercomonbut:Remove()
inercomonbut2:Remove()
end
if IsValid(textfadepanel8) then
textfadepanel8:Remove()
textfadepanel9:Remove()
hpbut:Remove()
hpbut2:Remove()
armorbut:Remove()
armorbut2:Remove()
staminbut:Remove()
staminbut2:Remove()
runbut:Remove()
runbut2:Remove()
ammobut:Remove()
ammobut2:Remove()
rpgbut:Remove()
rpgbut2:Remove()
pointssend:Remove()
end
if IsValid(moneysend) then
moneysend:Remove()
weaponmodeldc17:Remove()
weaponmodeldc15a:Remove()
weaponmodeldc15s:Remove()
end
homebutc = Color( 100, 100, 200, 255 )
secbutc = Color(100,100,200, 255)
tributc = Color(100,100,200, 255)
forbutc = Color(100,100,200, 255)
fivebutc = Color(100,100,200, 255)
sevenbutc = Color(100,100,200, 255)
pointbutc = Color(100,100,200, 255)
------------------------------------------------------------------------------------------------------------------+++

local function f1cmdchecks()
net.Start('f1menu_to_hud_srvmoney')
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
f1cmdchecks()
net.Receive("f1menu_to_hud_clientmoney", function()
local moneyg = net.ReadString()
local dc15s = net.ReadString()
local dc15a = net.ReadString()
local dc17 = net.ReadString()
local redc = Color(255,0,0,255)
local greenc = Color(0,255,0,255)
------+++

local dc15scolor = Color(100,100,200, 255)

local dc15acolor = Color(100,100,200, 255)

local dc17color = Color(100,100,200, 255)
if IsValid( textfadepanel6 ) then 
textfadepanel6:Remove()
end
textfadepanel6 = vgui.Create( "DPanel", f1menu ) 	
textfadepanel6:SetPos(0, 0)			
textfadepanel6:SetSize(ScrW(), ScrH()) 				
textfadepanel6:SetAlpha(0)
textfadepanel6:SetMouseInputEnabled( false )	
function textfadepanel6:Paint( w, h )
draw.SimpleText("РК - "..moneyg.." > ждите обновлений",'menubutfontf1',w*0.14,h*0.01,Color(230,230,230), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

draw.RoundedBox( 1, w*0.14, h*0.05, w*0.075, h*0.1, dc15scolor )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( w*0.14, h*0.05, w*0.075, h*0.1 )

-------

draw.RoundedBox( 1, w*0.22, h*0.05, w*0.075, h*0.1, dc15acolor )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( w*0.22, h*0.05, w*0.075, h*0.1 )

-------

draw.RoundedBox( 1, w*0.3, h*0.05, w*0.075, h*0.1, dc17color )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( w*0.3, h*0.05, w*0.075, h*0.1 )

-------
end
textfadepanel6:AlphaTo(255,0.5)

--STARTPUSHKI

weaponmodeldc15s = vgui.Create( "DModelPanel", f1menu )
weaponmodeldc15s:SetPos( ScrW()*0.14, ScrH()*0.05 )
weaponmodeldc15s:SetSize( ScrW()*0.075, ScrH()*0.1 )
weaponmodeldc15s:SetModel( "models/sw_battlefront/weapons/dc15s_carbine.mdl" )
function weaponmodeldc15s:LayoutEntity( Entity ) 
return 
end
weaponmodeldc15s:SetDirectionalLight(BOX_RIGHT, color_white)
  local mn, mx = weaponmodeldc15s:GetEntity():GetRenderBounds()
  local size = 0
  size = math.max(size, math.abs(mn.x) + math.abs(mx.x))
  size = math.max(size, math.abs(mn.y) + math.abs(mx.y))
  size = math.max(size, math.abs(mn.z) + math.abs(mx.z))
  weaponmodeldc15s:SetFOV(20)
  weaponmodeldc15s:SetCamPos(Vector(
    size - 45,
    size + 30,
    size
    )
  )
  weaponmodeldc15s:SetLookAt((mn + mx) * 0.5)
weaponmodeldc15s.OnCursorEntered = function()
surface.PlaySound('garrysmod/ui_hover.wav')
dc15scolor = Color(155,155,255, 255) 
end 
weaponmodeldc15s.OnCursorExited = function()
dc15scolor = Color(100,100,200, 255) 
end
weaponmodeldc15s.DoClick = function()
----------
local howmach = "?"
local tireup = "?"
local moneycost = "?"
local whatisit = "?"
local whatisit1 = "?"
local whatisit2 = "?"
local whatisit3 = "?"
local needmoney = "?"
if dc15s == "null" then
howmach = "15000"
tireup = "1"
moneycost = "?"
whatisit = "магазин +10"
whatisit1 = "урон +1"
whatisit2 = ""
whatisit3 = ""
needmoney = "15000"
elseif dc15s == "rw_sw_dc15s1" then
howmach = "20000"
tireup = "2"
moneycost = "?"
whatisit = "скорострельность +25"
whatisit1 = "урон +1"
whatisit2 = ""
whatisit3 = ""
needmoney = "20000"
elseif dc15s == "rw_sw_dc15s2" then
howmach = "25000"
tireup = "3"
moneycost = "?"
whatisit = "магазин +5"
whatisit1 = "урон +3"
whatisit2 = ""
whatisit3 = ""
needmoney = "25000"
elseif dc15s == "rw_sw_dc15s3" then
howmach = "30000"
tireup = "4"
moneycost = "?"
whatisit = "магазин +10"
whatisit1 = ""
whatisit2 = ""
whatisit3 = ""
needmoney = "30000"
elseif dc15s == "rw_sw_dc15s4" then
howmach = "35000"
tireup = "5"
moneycost = "?"
whatisit = "скорострельность +50"
whatisit1 = "урон +5"
whatisit2 = "режим: стан"
whatisit3 = ""
needmoney = "35000"
else
howmach = "0"
tireup = " MAX"
moneycost = "?"
whatisit = ""
whatisit1 = ""
whatisit2 = ""
whatisit3 = ""
needmoney = "0"
end
local faded_black = Color( 0, 0, 0, 250 )

local upgradepanel = vgui.Create( "DFrame" )
upgradepanel:SetSize( ScrW()*0.32, ScrH()*0.4 ) 				
upgradepanel:Center() 						
upgradepanel:SetTitle( "" )				
upgradepanel:SetDraggable( true )			
upgradepanel:MakePopup()						
upgradepanel.Paint = function( self, w, h )	
draw.RoundedBox( 2, 0, 0, w, h, faded_black )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText( "улучшение dc-15s > ур"..tireup, "menubutfontf1li", w*0.01, h*0.025, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
draw.SimpleText( "стоимость "..howmach.." рк", "menubutfontf1li", w*0.01, h*0.075, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
draw.SimpleText( whatisit, "menubutfontf1li", w*0.01, h*0.15, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
draw.SimpleText( whatisit1, "menubutfontf1li", w*0.01, h*0.2, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
draw.SimpleText( whatisit2, "menubutfontf1li", w*0.01, h*0.25, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
draw.SimpleText( whatisit3, "menubutfontf1li", w*0.01, h*0.3, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
end

weaponmodeldc15s1 = vgui.Create( "DModelPanel", upgradepanel )
weaponmodeldc15s1:SetPos( ScrW()*0.04, ScrH()*0.05 )
weaponmodeldc15s1:SetSize( ScrW()*0.225, ScrH()*0.3 )
weaponmodeldc15s1:SetModel( "models/sw_battlefront/weapons/dc15s_carbine.mdl" )
weaponmodeldc15s1:SetMouseInputEnabled( false )
function weaponmodeldc15s1:LayoutEntity( Entity ) 
return 
end
weaponmodeldc15s1:SetDirectionalLight(BOX_RIGHT, color_white)
  local mn, mx = weaponmodeldc15s1:GetEntity():GetRenderBounds()
  local size = 0
  size = math.max(size, math.abs(mn.x) + math.abs(mx.x))
  size = math.max(size, math.abs(mn.y) + math.abs(mx.y))
  size = math.max(size, math.abs(mn.z) + math.abs(mx.z))
  weaponmodeldc15s1:SetFOV(20)
  weaponmodeldc15s1:SetCamPos(Vector(
    size - 45,
    size + 30,
    size
    )
  )
weaponmodeldc15s1:SetLookAt((mn + mx) * 0.5)

if dc15s != "rw_sw_dc15s5" then
local pointssendc = Color(100,100,200,255)
pointssend = vgui.Create( "DButton", upgradepanel ) 
pointssend:SetText( " " )					
pointssend:SetPos( ScrW()*0.08,ScrH()*0.35 )					
pointssend:SetSize( ScrW()*0.1515,ScrH()*0.04 )
pointssend:SetAlpha(0)
pointssend:AlphaTo(255,0.75)
function pointssend:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, pointssendc )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText('УЛУЧШИТЬ','menubutfontf1',w*0.5,h*0.125,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end
pointssend.OnCursorEntered = function()
pointssendc = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
pointssend.OnCursorExited = function()
pointssendc = Color( 100, 100, 200, 255 )
end
pointssend.DoClick = function()
if needmoney + 0 <= moneyg + 0 then
local function firweap()
net.Start("srv_weaponshop_first")
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
firweap()
upgradepanel:Remove()
sixbut.DoClick()
end
end
end
----------
end

-------+++++++--------

weaponmodeldc15a = vgui.Create( "DModelPanel", f1menu )
weaponmodeldc15a:SetPos( ScrW()*0.22, ScrH()*0.05 )
weaponmodeldc15a:SetSize( ScrW()*0.075, ScrH()*0.1 )
weaponmodeldc15a:SetModel( "models/sw_battlefront/weapons/dc15a_rifle.mdl" )
function weaponmodeldc15a:LayoutEntity( Entity ) 
return 
end
weaponmodeldc15a:SetDirectionalLight(BOX_RIGHT, color_white)
  local mn, mx = weaponmodeldc15a:GetEntity():GetRenderBounds()
  local size = 0
  size = math.max(size, math.abs(mn.x) + math.abs(mx.x))
  size = math.max(size, math.abs(mn.y) + math.abs(mx.y))
  size = math.max(size, math.abs(mn.z) + math.abs(mx.z))
  weaponmodeldc15a:SetFOV(35)
  weaponmodeldc15a:SetCamPos(Vector(
    size - 45,
    size + 15,
    size
    )
  )
  weaponmodeldc15a:SetLookAt((mn + mx) * 0.4)
weaponmodeldc15a.OnCursorEntered = function()
surface.PlaySound('garrysmod/ui_hover.wav')
dc15acolor = Color(155,155,255, 255) 
end 
weaponmodeldc15a.OnCursorExited = function()
dc15acolor = Color(100,100,200, 255)
end
weaponmodeldc15a.DoClick = function()
----------
local howmach = "?"
local tireup = "?"
local moneycost = "?"
local whatisit = "?"
local whatisit1 = "?"
local whatisit2 = "?"
local whatisit3 = "?"
local needmoney = "?"
if dc15a == "null" then
howmach = "15000"
tireup = "1"
moneycost = "?"
whatisit = "урон +5"
whatisit1 = ""
whatisit2 = ""
whatisit3 = ""
needmoney = "15000"
elseif dc15a == "rw_sw_dc15a1" then
howmach = "20000"
tireup = "2"
moneycost = "?"
whatisit = "скорострельность +25"
whatisit1 = "магазин +5"
whatisit2 = ""
whatisit3 = ""
needmoney = "20000"
elseif dc15a == "rw_sw_dc15a2" then
howmach = "25000"
tireup = "3"
moneycost = "?"
whatisit = "скорострельность +25"
whatisit1 = "урон +5"
whatisit2 = ""
whatisit3 = ""
needmoney = "25000"
elseif dc15a == "rw_sw_dc15a3" then
howmach = "30000"
tireup = "4"
moneycost = "?"
whatisit = "магазин +10"
whatisit1 = "режим: мощный выстрел"
whatisit2 = ""
whatisit3 = ""
needmoney = "30000"
elseif dc15a == "rw_sw_dc15a4" then
howmach = "35000"
tireup = "5"
moneycost = "?"
whatisit = "скорострельность +50"
whatisit1 = ""
whatisit2 = ""
whatisit3 = ""
needmoney = "35000"
else
howmach = "0"
tireup = " MAX"
moneycost = "?"
whatisit = ""
whatisit1 = ""
whatisit2 = ""
whatisit3 = ""
needmoney = "0"
end
local faded_black = Color( 0, 0, 0, 250 )

local upgradepanel = vgui.Create( "DFrame" )
upgradepanel:SetSize( ScrW()*0.32, ScrH()*0.4 ) 				
upgradepanel:Center() 						
upgradepanel:SetTitle( "" )				
upgradepanel:SetDraggable( true )			
upgradepanel:MakePopup()						
upgradepanel.Paint = function( self, w, h )	
draw.RoundedBox( 2, 0, 0, w, h, faded_black )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText( "улучшение dc-15a > ур"..tireup, "menubutfontf1li", w*0.01, h*0.025, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
draw.SimpleText( "стоимость "..howmach.." рк", "menubutfontf1li", w*0.01, h*0.075, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
draw.SimpleText( whatisit, "menubutfontf1li", w*0.01, h*0.15, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
draw.SimpleText( whatisit1, "menubutfontf1li", w*0.01, h*0.2, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
draw.SimpleText( whatisit2, "menubutfontf1li", w*0.01, h*0.25, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
draw.SimpleText( whatisit3, "menubutfontf1li", w*0.01, h*0.3, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
end

weaponmodeldc15a1 = vgui.Create( "DModelPanel", upgradepanel )
weaponmodeldc15a1:SetPos( ScrW()*0.04, ScrH()*0.05 )
weaponmodeldc15a1:SetSize( ScrW()*0.225, ScrH()*0.3 )
weaponmodeldc15a1:SetMouseInputEnabled( false )
weaponmodeldc15a1:SetModel( "models/sw_battlefront/weapons/dc15a_rifle.mdl" )
function weaponmodeldc15a1:LayoutEntity( Entity ) 
return 
end
weaponmodeldc15a1:SetDirectionalLight(BOX_RIGHT, color_white)
  local mn, mx = weaponmodeldc15a1:GetEntity():GetRenderBounds()
  local size = 0
  size = math.max(size, math.abs(mn.x) + math.abs(mx.x))
  size = math.max(size, math.abs(mn.y) + math.abs(mx.y))
  size = math.max(size, math.abs(mn.z) + math.abs(mx.z))
  weaponmodeldc15a1:SetFOV(35)
  weaponmodeldc15a1:SetCamPos(Vector(
    size - 45,
    size + 15,
    size
    )
  )
weaponmodeldc15a1:SetLookAt((mn + mx) * 0.4)

if dc15a != "rw_sw_dc15a5" then
local pointssendc = Color(100,100,200,255)
pointssend = vgui.Create( "DButton", upgradepanel ) 
pointssend:SetText( " " )					
pointssend:SetPos( ScrW()*0.08,ScrH()*0.35 )					
pointssend:SetSize( ScrW()*0.1515,ScrH()*0.04 )
pointssend:SetAlpha(0)
pointssend:AlphaTo(255,0.75)
function pointssend:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, pointssendc )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText('УЛУЧШИТЬ','menubutfontf1',w*0.5,h*0.125,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end
pointssend.OnCursorEntered = function()
pointssendc = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
pointssend.OnCursorExited = function()
pointssendc = Color( 100, 100, 200, 255 )
end
pointssend.DoClick = function()
if needmoney + 0 <= moneyg + 0 then
local function secweap()
net.Start("srv_weaponshop_sec")
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
secweap()
upgradepanel:Remove()
sixbut.DoClick()
end
end
end
----------
end

-------+++++++--------
weaponmodeldc17 = vgui.Create( "DModelPanel", f1menu )
weaponmodeldc17:SetPos( ScrW()*0.3, ScrH()*0.05 )
weaponmodeldc17:SetSize( ScrW()*0.075, ScrH()*0.1 )
weaponmodeldc17:SetModel( "models/sw_battlefront/weapons/dc17_blaster.mdl" )
function weaponmodeldc17:LayoutEntity( Entity ) 
return 
end
weaponmodeldc17:SetDirectionalLight(BOX_RIGHT, color_white)
  local mn, mx = weaponmodeldc17:GetEntity():GetRenderBounds()
  local size = 0
  size = math.max(size, math.abs(mn.x) + math.abs(mx.x))
  size = math.max(size, math.abs(mn.y) + math.abs(mx.y))
  size = math.max(size, math.abs(mn.z) + math.abs(mx.z))
  weaponmodeldc17:SetFOV(20)
  weaponmodeldc17:SetCamPos(Vector(
    size - 15,
    size + 30,
    size
    )
  )
  weaponmodeldc17:SetLookAt((mn + mx) * 0.5)
weaponmodeldc17.OnCursorEntered = function()
surface.PlaySound('garrysmod/ui_hover.wav')
dc17color = Color(155,155,255, 255)
end 
weaponmodeldc17.OnCursorExited = function()
dc17color = Color(100,100,200, 255)
end
weaponmodeldc17.DoClick = function()
----------
local howmach = "?"
local tireup = "?"
local moneycost = "?"
local whatisit = "?"
local whatisit1 = "?"
local whatisit2 = "?"
local whatisit3 = "?"
local needmoney = "?"
if dc17 == "null" then
howmach = "15000"
tireup = "1"
moneycost = "?"
whatisit = "магазин +10"
whatisit1 = "урон +1"
whatisit2 = ""
whatisit3 = ""
needmoney = "15000"
elseif dc17 == "rw_sw_dc171" then
howmach = "20000"
tireup = "2"
moneycost = "?"
whatisit = "скорострельность +25"
whatisit1 = "урон +1"
whatisit2 = ""
whatisit3 = ""
needmoney = "20000"
elseif dc17 == "rw_sw_dc172" then
howmach = "25000"
tireup = "3"
moneycost = "?"
whatisit = "магазин +5"
whatisit1 = "урон +3"
whatisit2 = ""
whatisit3 = ""
needmoney = "25000"
elseif dc17 == "rw_sw_dc173" then
howmach = "30000"
tireup = "4"
moneycost = "?"
whatisit = "магазин +10"
whatisit1 = ""
whatisit2 = ""
whatisit3 = ""
needmoney = "30000"
elseif dc17 == "rw_sw_dc174" then
howmach = "35000"
tireup = "5"
moneycost = "?"
whatisit = "скорострельность +50"
whatisit1 = "урон +5"
whatisit2 = "режим: стан"
whatisit3 = ""
needmoney = "35000"
else
howmach = "0"
tireup = " MAX"
moneycost = "?"
whatisit = ""
whatisit1 = ""
whatisit2 = ""
whatisit3 = ""
needmoney = "0"
end
local faded_black = Color( 0, 0, 0, 250 )

local upgradepanel = vgui.Create( "DFrame" )
upgradepanel:SetSize( ScrW()*0.32, ScrH()*0.4 ) 				
upgradepanel:Center() 						
upgradepanel:SetTitle( "" )				
upgradepanel:SetDraggable( true )			
upgradepanel:MakePopup()						
upgradepanel.Paint = function( self, w, h )	
draw.RoundedBox( 2, 0, 0, w, h, faded_black )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText( "улучшение dc-17 > ур"..tireup, "menubutfontf1li", w*0.01, h*0.025, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
draw.SimpleText( "стоимость "..howmach.." рк", "menubutfontf1li", w*0.01, h*0.075, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
draw.SimpleText( whatisit, "menubutfontf1li", w*0.01, h*0.15, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
draw.SimpleText( whatisit1, "menubutfontf1li", w*0.01, h*0.2, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
draw.SimpleText( whatisit2, "menubutfontf1li", w*0.01, h*0.25, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
draw.SimpleText( whatisit3, "menubutfontf1li", w*0.01, h*0.3, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
end

weaponmodeldc171 = vgui.Create( "DModelPanel", upgradepanel )
weaponmodeldc171:SetPos( ScrW()*0.04, ScrH()*0.05 )
weaponmodeldc171:SetSize( ScrW()*0.225, ScrH()*0.3 )
weaponmodeldc171:SetMouseInputEnabled( false )
weaponmodeldc171:SetModel( "models/sw_battlefront/weapons/dc17_blaster.mdl" )
function weaponmodeldc171:LayoutEntity( Entity ) 
return 
end
weaponmodeldc171:SetDirectionalLight(BOX_RIGHT, color_white)
  local mn, mx = weaponmodeldc171:GetEntity():GetRenderBounds()
  local size = 0
  size = math.max(size, math.abs(mn.x) + math.abs(mx.x))
  size = math.max(size, math.abs(mn.y) + math.abs(mx.y))
  size = math.max(size, math.abs(mn.z) + math.abs(mx.z))
  weaponmodeldc171:SetFOV(20)
  weaponmodeldc171:SetCamPos(Vector(
    size - 15,
    size + 30,
    size
    )
  )
  weaponmodeldc171:SetLookAt((mn + mx) * 0.5)

if dc17 != "rw_sw_dc175" then
local pointssendc = Color(100,100,200,255)
pointssend = vgui.Create( "DButton", upgradepanel ) 
pointssend:SetText( " " )					
pointssend:SetPos( ScrW()*0.08,ScrH()*0.35 )					
pointssend:SetSize( ScrW()*0.1515,ScrH()*0.04 )
pointssend:SetAlpha(0)
pointssend:AlphaTo(255,0.75)
function pointssend:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, pointssendc )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText('УЛУЧШИТЬ','menubutfontf1',w*0.5,h*0.125,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end
pointssend.OnCursorEntered = function()
pointssendc = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
pointssend.OnCursorExited = function()
pointssendc = Color( 100, 100, 200, 255 )
end
pointssend.DoClick = function()
if needmoney + 0 <= moneyg + 0 then
local function fourweap()
net.Start("srv_weaponshop_four")
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
fourweap()
upgradepanel:Remove()
sixbut.DoClick()
end
end
end
----------
end

local moneysendc = Color(100,100,200,255)
moneysend = vgui.Create( "DButton", f1menu ) 
moneysend:SetText( " " )					
moneysend:SetPos( ScrW()*0.4425,ScrH()*0.55 )					
moneysend:SetSize( ScrW()*0.1515,ScrH()*0.04 )
moneysend:SetAlpha(0)
moneysend:AlphaTo(255,0.75)
function moneysend:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, moneysendc )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText('ПОЛУЧИТЬ','menubutfontf1',w*0.5,h*0.125,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end
moneysend.OnCursorEntered = function()
moneysendc = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
moneysend.OnCursorExited = function()
moneysendc = Color( 100, 100, 200, 255 )
end
moneysend.DoClick = function()
local function fourweap()
net.Start("srv_weaponshop_getall")
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
fourweap()
end

------+++
end)
------------------------------------------------------------------------------------------------------------------+++
end





local sevenbut = vgui.Create( 'DButton', f1menu ) 
sevenbut:SetText( '' )				
sevenbut:SetPos( ScrW()*-0.1, ScrH()*0.55 )			
sevenbut:SetSize( ScrW()*0.12, ScrH()*0.05 )	
sevenbut:SetAlpha(0)		
function sevenbut:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, sevenbutc )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText('Донат','menubutfontf1',w*0.05,h*0.2,Color(230,230,230), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
end
sevenbut.OnCursorEntered = function()
sevenbutc = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
sevenbut.OnCursorExited = function()
if IsValid( textfadepanel7 ) then return end
sevenbutc = Color( 100, 100, 200, 255 )
end
sevenbut.DoClick = function()
if IsValid( TextEntryKEK23 ) then
TextEntryKEK23:Remove()
end
if IsValid( DComboBoxkeksik2283 ) then
DComboBoxkeksik2283:Remove()
end
if IsValid( DermaButtonka ) then
DermaButtonka:Remove()
textfadepanel:SetAlpha(0)
end
if IsValid( DermaButtonkad ) then
DermaButtonkad:Remove()
textfadepanel:SetAlpha(0)
end
if IsValid( richtextusjaloba ) then
richtextusjaloba:Remove()
textfadepanel:SetAlpha(0)
end
if IsValid( character3 ) then
character3:Remove()
textfadepanel:SetAlpha(0)
end
if IsValid( Dcombohtlbox ) then
Dcombohtlbox:Remove()
end
if IsValid( htmldocs ) then
htmldocs:Remove()
end
if IsValid( radioconnectionsframe ) then 
radioconnectionsframe:Remove()
end
if IsValid( Radiochannelinsert ) then 
Radiochannelinsert:Remove()
end
if IsValid( radioconnections ) then 
radioconnections:Remove()
end
if IsValid( radioconnectbut ) then 
radioconnectbut:Remove()
end
if IsValid( radiodisconnectbut ) then 
radiodisconnectbut:Remove()
end
if IsValid( textfadepanel5 ) then 
textfadepanel5:Remove()
end
if IsValid( textfadepanel6 ) then 
textfadepanel6:Remove()
end
if IsValid(batonkafordefc) then
batonkafordefc:Remove()
batonkafordefc2:Remove()
batonkafordefc3:Remove()
batonkafordefc4:Remove()
batonkafordefc5:Remove()
Textprikazzadan:Remove()
butforsendprikaz:Remove()
butforsendprikazcl:Remove()
end
if IsValid(textintercomdist) then
textintercomdist:Remove()
butonforinterdist:Remove()
inercomonbut:Remove()
inercomonbut2:Remove()
end
if IsValid(textfadepanel8) then
textfadepanel8:Remove()
textfadepanel9:Remove()
hpbut:Remove()
hpbut2:Remove()
armorbut:Remove()
armorbut2:Remove()
staminbut:Remove()
staminbut2:Remove()
runbut:Remove()
runbut2:Remove()
ammobut:Remove()
ammobut2:Remove()
rpgbut:Remove()
rpgbut2:Remove()
pointssend:Remove()
end
if IsValid(moneysend) then
moneysend:Remove()
weaponmodeldc17:Remove()
weaponmodeldc15a:Remove()
weaponmodeldc15s:Remove()
end
homebutc = Color( 100, 100, 200, 255 )
secbutc = Color(100,100,200, 255)
tributc = Color(100,100,200, 255)
forbutc = Color(100,100,200, 255)
fivebutc = Color(100,100,200, 255)
sixbutc = Color(100,100,200, 255)
pointbutc = Color(100,100,200, 255)
------------------------------------------------------------------------------------------------------------------+++

if IsValid( textfadepanel7 ) then 
textfadepanel7:Remove()
end
textfadepanel7 = vgui.Create( "DPanel", f1menu ) 	
textfadepanel7:SetPos(0, 0)			
textfadepanel7:SetSize(ScrW(), ScrH()) 				
textfadepanel7:SetAlpha(0)
textfadepanel7:SetMouseInputEnabled( false )	
function textfadepanel7:Paint( w, h )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
draw.SimpleText('Не доступно на ОБТ...','menubutfontf1',w*0.35,h*0.25,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
draw.SimpleText("Тут можно будет занести денег",'menubutfontf1',w*0.35,h*0.3,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end

textfadepanel7:AlphaTo(255,0.5)
------------------------------------------------------------------------------------------------------------------+++
end

timer.Simple( 0.1, function() if IsValid(homebut) then homebut:AlphaTo(255,0.25) homebut:MoveTo(ScrW()*0, ScrH()*0, 0.2) end; if IsValid(secbut) then secbut:AlphaTo(255,0.25) secbut:MoveTo(ScrW()*0, ScrH()*0.05, 0.25) end; if IsValid(tribut) then tribut:AlphaTo(255,0.25) tribut:MoveTo(ScrW()*0, ScrH()*0.1, 0.3) end; if IsValid(forbut) then forbut:AlphaTo(255,0.25) forbut:MoveTo(ScrW()*0, ScrH()*0.15, 0.35) end; if IsValid(fivebut) then fivebut:AlphaTo(255,0.25) fivebut:MoveTo(ScrW()*0, ScrH()*0.2, 0.4) end; if IsValid(pointbut) then pointbut:AlphaTo(255,0.25) pointbut:MoveTo(ScrW()*0, ScrH()*0.45, 0.3) end; if IsValid(sixbut) then sixbut:AlphaTo(255,0.25) sixbut:MoveTo(ScrW()*0, ScrH()*0.5, 0.25) end; if IsValid(sevenbut) then sevenbut:AlphaTo(255,0.25) sevenbut:MoveTo(ScrW()*0, ScrH()*0.55, 0.2) end; end )	

end
--++
end
----
end)