if CLIENT then return end
util.AddNetworkString("moneynotifysendclaienus")
timer.Create( "timermonyiventserv", 300, 0, function ()
if string.Split( game.GetIPAddress(), ":" )[1]..":27016" == game.GetIPAddress() then
for i, v in pairs(player.GetAll()) do
-------------------------------------------------------------------------	
local randomize = math.random( 100, 500 )
local money = file.Read("users/"..v:SteamID64().."/money/money.txt", "data")
local boost = file.Read("users/"..v:SteamID64().."/money/moneyboost.txt", "data")
local readypoip = money + randomize * boost
file.Write("users/"..v:SteamID64().."/money/money.txt", readypoip)

local function pointsnotifyc()
net.Start("moneynotifysendclaienus")
net.WriteString("+ "..randomize.." кредитов, у вас сейчас: "..readypoip)
net.Send(v)
end
pointsnotifyc()
-------------------------------------------------------------------------	
end
end
end)
