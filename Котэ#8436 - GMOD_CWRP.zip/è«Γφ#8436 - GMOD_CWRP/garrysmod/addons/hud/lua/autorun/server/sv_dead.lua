if CLIENT then return end
local function respawntime(pl)
	return 1
end

    Deadinfo = {}

	util.AddNetworkString("RespawnTimer")
	hook.Add("PlayerDeath", "RespawnTimer", function(pPlayer)
		pPlayer.deadtime = RealTime()

        Deadinfo = Deadinfo or {}

		net.Start("RespawnTimer")
			net.WriteBool(true)
            if Deadinfo[pPlayer] then
                net.WriteTable(Deadinfo[pPlayer])
            else
                net.WriteTable({})
            end
		net.Send(pPlayer)

        Deadinfo[pPlayer] = nil
	end)

	hook.Add("PlayerDeathThink", "RespawnTimer", function(pPlayer)
		if pPlayer.deadtime and RealTime() - pPlayer.deadtime < respawntime(pPlayer) then
			return false
		end
	end)

	hook.Add("PlayerSpawn", "HideRespawnTimer", function(pPlayer)
		net.Start("RespawnTimer")
			net.WriteBool(false)
		net.Send(pPlayer)
	end)

    hook.Add("EntityTakeDamage", "DeathScreen_EntityTakeDamage", function( target, dmginfo )
        if target:IsPlayer() then
            Deadinfo[target] = Deadinfo[target] or {}

            local att = dmginfo:GetAttacker()

            -- local name = att:IsWorld() and 'worldspawn' or ( att.Name and att:Name() or ( att.Nick and att:Nick() or 'worldspawn' ) )
            local attacker = att:IsWorld() and 'worldspawn' or ( att.Name and file.Read("users/"..att:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..att:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..att:SteamID64().."/number/number.txt", "data") or ( att.Nick and file.Read("users/"..att:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..att:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..att:SteamID64().."/number/number.txt", "data") or 'worldspawn' ) )
            -- local tm_c = not att:IsWorld() and team.GetColor(att:Team()) or color_white
            local tm_c = color_white
            if not att:IsWorld() and att.Team and att:Team() then
                tm_c = team.GetColor(att:Team())
            end
            local att_color = att:IsWorld() and '<colour=255, 165, 0, 255>' or string.format('<colour=%s, %s, %s, %s>', tm_c.r, tm_c.g, tm_c.b, 255)
            table.insert(Deadinfo[target], {
                attacker = attacker,
                att_color = '<colour=255, 165, 0, 255>',
                damage = dmginfo:GetDamage()
            })
            -- print(dmginfo:GetAttacker(), dmginfo:GetDamage())
            -- dmginfo:ScaleDamage( 0.5 ) // Damage is now half of what you would normally take.
    end
end)