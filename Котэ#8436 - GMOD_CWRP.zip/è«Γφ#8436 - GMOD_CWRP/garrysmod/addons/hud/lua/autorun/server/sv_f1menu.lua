if CLIENT then return end
util.AddNetworkString("homebutt_f1menu")
util.AddNetworkString("homebutt_f1menu_server")
net.Receive("homebutt_f1menu_server", function()
local igrok = net.ReadEntity()
local function WLHUDsts()
net.Start('homebutt_f1menu')
net.WriteString(file.Read("users/"..igrok:SteamID64().."/name/name.txt", "data"))
net.WriteString(file.Read("users/"..igrok:SteamID64().."/number/number.txt", "data"))
net.WriteString(file.Read("users/"..igrok:SteamID64().."/legion/legion.txt", "data"))
net.WriteString(file.Read("users/"..igrok:SteamID64().."/rank/rank.txt", "data"))
net.WriteString(file.Read("users/"..igrok:SteamID64().."/spec/spec.txt", "data"))
net.WriteString(file.Read("users/"..igrok:SteamID64().."/admin/admin.txt"))
net.WriteString(file.Read("users/"..igrok:SteamID64().."/model/model.txt"))
net.WriteString(file.Read("users/"..igrok:SteamID64().."/skin/skin.txt"))
net.WriteString(file.Read("users/"..igrok:SteamID64().."/bodygroups/bodygroups.txt"))
net.WriteString(file.Read("users/"..igrok:SteamID64().."/warns/warns.txt"))
net.Send(igrok)
end
WLHUDsts()
end)

util.AddNetworkString("f1menu_cmdbutclient")
util.AddNetworkString("f1menu_cmdbutserver")
net.Receive("f1menu_cmdbutserver", function()
local igrok = net.ReadEntity()
local pladmin = file.Read("users/"..igrok:SteamID64().."/admin/admin.txt")
if (pladmin == "user") then
local function f1cmdcheck()
net.Start('f1menu_cmdbutclient')
net.WriteEntity(igrok)
net.Send(igrok)
end
f1cmdcheck()
end
end)

util.AddNetworkString("f1menu_to_hud_serverprikaz")
util.AddNetworkString("f1menu_to_hud_clientprikazupdate")
net.Receive("f1menu_to_hud_serverprikaz", function()
local igrok = net.ReadEntity()
local prikaz = net.ReadString()
local pladmin = file.Read("users/"..igrok:SteamID64().."/admin/admin.txt")
local ranks = file.Read("users/"..igrok:SteamID64().."/rank/rank.txt")
local names = file.Read("users/"..igrok:SteamID64().."/name/name.txt")
local legions = file.Read("users/"..igrok:SteamID64().."/legion/legion.txt")
local numbs = file.Read("users/"..igrok:SteamID64().."/number/number.txt")
if (pladmin == "commander" or pladmin == "admin" or pladmin == "highadmin" or pladmin == "owner") then
if prikaz == "null" then file.Write("server/prikaz.txt", "null") else
file.Write("server/prikaz.txt", "("..legions.." | "..names.." | "..numbs.." | "..ranks..") -> "..prikaz)
prikaz = "("..legions.." | "..names.." | "..numbs.." | "..ranks..") -> "..prikaz
end
local function f1cmdchecks()
net.Start('f1menu_to_hud_clientprikazupdate')
net.WriteEntity(igrok)
net.WriteString(prikaz)
net.Broadcast()
end
f1cmdchecks()
end
end)

util.AddNetworkString("f1menu_to_hud_intercomdist")
net.Receive("f1menu_to_hud_intercomdist", function()
local igrok = net.ReadEntity()
local distint = net.ReadString()
local kekaz = (distint + 0)
local pladmin = file.Read("users/"..igrok:SteamID64().."/admin/admin.txt")
if (pladmin == "commander" or pladmin == "admin" or pladmin == "highadmin" or pladmin == "owner") then
file.Write("users/"..igrok:SteamID64().."/radio/interdist.txt", kekaz)
end
end)

util.AddNetworkString("f1menu_to_hud_intercomon")
net.Receive("f1menu_to_hud_intercomon", function()
local igrok = net.ReadEntity()
local pladmin = file.Read("users/"..igrok:SteamID64().."/admin/admin.txt")
if (pladmin == "commander" or pladmin == "admin" or pladmin == "highadmin" or pladmin == "owner") then
file.Write("users/"..igrok:SteamID64().."/radio/intercom.txt", "true")
end
end)

util.AddNetworkString("f1menu_to_hud_intercomoff")
net.Receive("f1menu_to_hud_intercomoff", function()
local igrok = net.ReadEntity()
local pladmin = file.Read("users/"..igrok:SteamID64().."/admin/admin.txt")
if (pladmin == "commander" or pladmin == "admin" or pladmin == "highadmin" or pladmin == "owner") then
file.Write("users/"..igrok:SteamID64().."/radio/intercom.txt", "false")
end
end)

----------

util.AddNetworkString("f1menu_to_hud_srvmoney")
util.AddNetworkString("f1menu_to_hud_clientmoney")
net.Receive("f1menu_to_hud_srvmoney", function()
local igrok = net.ReadEntity()
local money = file.Read("users/"..igrok:SteamID64().."/money/money.txt")
local dc15s = file.Read("weaponshop/"..igrok:SteamID64().."/weapons/weaponfirst.txt")
local dc15a = file.Read("weaponshop/"..igrok:SteamID64().."/weapons/weaponsec.txt")
local dc17 = file.Read("weaponshop/"..igrok:SteamID64().."/weapons/weaponfour.txt")
local function f1cmdchecks()
net.Start('f1menu_to_hud_clientmoney')
net.WriteString(money)
net.WriteString(dc15s)
net.WriteString(dc15a)
net.WriteString(dc17)
net.Send(igrok)
end
f1cmdchecks()
end)

util.AddNetworkString("srv_weaponshop_first")
net.Receive("srv_weaponshop_first", function()
local player = net.ReadEntity()
local money = file.Read("users/"..player:SteamID64().."/money/money.txt")
local dc15s = file.Read("weaponshop/"..player:SteamID64().."/weapons/weaponfirst.txt")
if dc15s == "null" then
if money + 0 >= 15000 then
file.Write("users/"..player:SteamID64().."/money/money.txt", money - 15000)
file.Write("weaponshop/"..player:SteamID64().."/weapons/weaponfirst.txt", "rw_sw_dc15s1")
end
elseif dc15s == "rw_sw_dc15s1" then
if money + 0 >= 20000 then
file.Write("users/"..player:SteamID64().."/money/money.txt", money - 20000)
file.Write("weaponshop/"..player:SteamID64().."/weapons/weaponfirst.txt", "rw_sw_dc15s2")
end
elseif dc15s == "rw_sw_dc15s2" then
if money + 0 >= 25000 then
file.Write("users/"..player:SteamID64().."/money/money.txt", money - 25000)
file.Write("weaponshop/"..player:SteamID64().."/weapons/weaponfirst.txt", "rw_sw_dc15s3")
end
elseif dc15s == "rw_sw_dc15s3" then
if money + 0 >= 30000 then
file.Write("users/"..player:SteamID64().."/money/money.txt", money - 30000)
file.Write("weaponshop/"..player:SteamID64().."/weapons/weaponfirst.txt", "rw_sw_dc15s4")
end
elseif dc15s == "rw_sw_dc15s4" then
if money + 0 >= 35000 then
file.Write("users/"..player:SteamID64().."/money/money.txt", money - 35000)
file.Write("weaponshop/"..player:SteamID64().."/weapons/weaponfirst.txt", "rw_sw_dc15s5")
end
end
end)

util.AddNetworkString("srv_weaponshop_sec")
net.Receive("srv_weaponshop_sec", function()
local player = net.ReadEntity()
local money = file.Read("users/"..player:SteamID64().."/money/money.txt")
local dc15a = file.Read("weaponshop/"..player:SteamID64().."/weapons/weaponsec.txt")
if dc15a == "null" then
if money + 0 >= 15000 then
file.Write("users/"..player:SteamID64().."/money/money.txt", money - 15000)
file.Write("weaponshop/"..player:SteamID64().."/weapons/weaponsec.txt", "rw_sw_dc15a1")
end
elseif dc15a == "rw_sw_dc15a1" then
if money + 0 >= 20000 then
file.Write("users/"..player:SteamID64().."/money/money.txt", money - 20000)
file.Write("weaponshop/"..player:SteamID64().."/weapons/weaponsec.txt", "rw_sw_dc15a2")
end
elseif dc15a == "rw_sw_dc15a2" then
if money + 0 >= 25000 then
file.Write("users/"..player:SteamID64().."/money/money.txt", money - 25000)
file.Write("weaponshop/"..player:SteamID64().."/weapons/weaponsec.txt", "rw_sw_dc15a3")
end
elseif dc15a == "rw_sw_dc15a3" then
if money + 0 >= 30000 then
file.Write("users/"..player:SteamID64().."/money/money.txt", money - 30000)
file.Write("weaponshop/"..player:SteamID64().."/weapons/weaponsec.txt", "rw_sw_dc15a4")
end
elseif dc15a == "rw_sw_dc15a4" then
if money + 0 >= 35000 then
file.Write("users/"..player:SteamID64().."/money/money.txt", money - 35000)
file.Write("weaponshop/"..player:SteamID64().."/weapons/weaponsec.txt", "rw_sw_dc15a5")
end
end
end)

util.AddNetworkString("srv_weaponshop_four")
net.Receive("srv_weaponshop_four", function()
local player = net.ReadEntity()
local money = file.Read("users/"..player:SteamID64().."/money/money.txt")
local dc17 = file.Read("weaponshop/"..player:SteamID64().."/weapons/weaponfour.txt")
if dc17 == "null" then
if money + 0 >= 15000 then
file.Write("users/"..player:SteamID64().."/money/money.txt", money - 15000)
file.Write("weaponshop/"..player:SteamID64().."/weapons/weaponfour.txt", "rw_sw_dc171")
end
elseif dc17 == "rw_sw_dc171" then
if money + 0 >= 20000 then
file.Write("users/"..player:SteamID64().."/money/money.txt", money - 20000)
file.Write("weaponshop/"..player:SteamID64().."/weapons/weaponfour.txt", "rw_sw_dc172")
end
elseif dc17 == "rw_sw_dc172" then
if money + 0 >= 25000 then
file.Write("users/"..player:SteamID64().."/money/money.txt", money - 25000)
file.Write("weaponshop/"..player:SteamID64().."/weapons/weaponfour.txt", "rw_sw_dc173")
end
elseif dc17 == "rw_sw_dc173" then
if money + 0 >= 30000 then
file.Write("users/"..player:SteamID64().."/money/money.txt", money - 30000)
file.Write("weaponshop/"..player:SteamID64().."/weapons/weaponfour.txt", "rw_sw_dc174")
end
elseif dc17 == "rw_sw_dc174" then
if money + 0 >= 35000 then
file.Write("users/"..player:SteamID64().."/money/money.txt", money - 35000)
file.Write("weaponshop/"..player:SteamID64().."/weapons/weaponfour.txt", "rw_sw_dc175")
end
end
end)

util.AddNetworkString("srv_weaponshop_getall")
net.Receive("srv_weaponshop_getall", function()
local player = net.ReadEntity()
local dc15s = file.Read("weaponshop/"..player:SteamID64().."/weapons/weaponfirst.txt")
local dc15a = file.Read("weaponshop/"..player:SteamID64().."/weapons/weaponsec.txt")
local dc17 = file.Read("weaponshop/"..player:SteamID64().."/weapons/weaponfour.txt")
local weap1 = file.Read("users/"..player:SteamID64().."/weaponfirst/weaponfirst.txt", "data")
local weap2 = file.Read("users/"..player:SteamID64().."/weaponsecond/weaponsecond.txt", "data")
local gren = file.Read("users/"..player:SteamID64().."/weapongrenade/weapongrenade.txt", "data")
local gren2 = file.Read("users/"..player:SteamID64().."/weapongrenade2/weapongrenade2.txt", "data")
local knife = file.Read("users/"..player:SteamID64().."/weaponknife/weaponknife.txt", "data")
local wlutil = file.Read("users/"..player:SteamID64().."/utiles/utiles.txt", "data")
local wlutil2 = file.Read("users/"..player:SteamID64().."/utiles2/utiles2.txt", "data")
-----_DC15s
if dc15s != "null" then

if weap1 == "rw_sw_dc15s" then
file.Write("users/"..player:SteamID64().."/weaponfirst/weaponfirst.txt", dc15s)
player:StripWeapon( weap1 )
player:Give(dc15s, true)
elseif weap2 == "rw_sw_dc15s" then
file.Write("users/"..player:SteamID64().."/weaponsecond/weaponsecond.txt", dc15s)
player:StripWeapon( weap2 )
player:Give(dc15s, true)
elseif gren == "rw_sw_dc15s" then
file.Write("users/"..player:SteamID64().."/weapongrenade/weapongrenade.txt", dc15s)
player:StripWeapon( gren )
player:Give(dc15s, true)
elseif gren2 == "rw_sw_dc15s" then
file.Write("users/"..player:SteamID64().."/weapongrenade2/weapongrenade2.txt", dc15s)
player:StripWeapon( gren2 )
player:Give(dc15s, true)
elseif knife == "rw_sw_dc15s" then
file.Write("users/"..player:SteamID64().."/weaponknife/weaponknife.txt", dc15s)
player:StripWeapon( knife )
player:Give(dc15s, true)
elseif wlutil == "rw_sw_dc15s" then
file.Write("users/"..player:SteamID64().."/utiles/utiles.txt", dc15s)
player:StripWeapon( wlutil )
player:Give(dc15s, true)
elseif wlutil2 == "rw_sw_dc15s" then
file.Write("users/"..player:SteamID64().."/utiles2/utiles2.txt", dc15s)
player:StripWeapon( wlutil2 )
player:Give(dc15s, true)
end

if weap1 == "rw_sw_dc15s1" then
file.Write("users/"..player:SteamID64().."/weaponfirst/weaponfirst.txt", dc15s)
player:StripWeapon( weap1 )
player:Give(dc15s, true)
elseif weap2 == "rw_sw_dc15s1" then
file.Write("users/"..player:SteamID64().."/weaponsecond/weaponsecond.txt", dc15s)
player:StripWeapon( weap2 )
player:Give(dc15s, true)
elseif gren == "rw_sw_dc15s1" then
file.Write("users/"..player:SteamID64().."/weapongrenade/weapongrenade.txt", dc15s)
player:StripWeapon( gren )
player:Give(dc15s, true)
elseif gren2 == "rw_sw_dc15s1" then
file.Write("users/"..player:SteamID64().."/weapongrenade2/weapongrenade2.txt", dc15s)
player:StripWeapon( gren2 )
player:Give(dc15s, true)
elseif knife == "rw_sw_dc15s1" then
file.Write("users/"..player:SteamID64().."/weaponknife/weaponknife.txt", dc15s)
player:StripWeapon( knife )
player:Give(dc15s, true)
elseif wlutil == "rw_sw_dc15s1" then
file.Write("users/"..player:SteamID64().."/utiles/utiles.txt", dc15s)
player:StripWeapon( wlutil )
player:Give(dc15s, true)
elseif wlutil2 == "rw_sw_dc15s1" then
file.Write("users/"..player:SteamID64().."/utiles2/utiles2.txt", dc15s)
player:StripWeapon( wlutil2 )
player:Give(dc15s, true)
end

if weap1 == "rw_sw_dc15s2" then
file.Write("users/"..player:SteamID64().."/weaponfirst/weaponfirst.txt", dc15s)
player:StripWeapon( weap1 )
player:Give(dc15s, true)
elseif weap2 == "rw_sw_dc15s2" then
file.Write("users/"..player:SteamID64().."/weaponsecond/weaponsecond.txt", dc15s)
player:StripWeapon( weap2 )
player:Give(dc15s, true)
elseif gren == "rw_sw_dc15s2" then
file.Write("users/"..player:SteamID64().."/weapongrenade/weapongrenade.txt", dc15s)
player:StripWeapon( gren )
player:Give(dc15s, true)
elseif gren2 == "rw_sw_dc15s2" then
file.Write("users/"..player:SteamID64().."/weapongrenade2/weapongrenade2.txt", dc15s)
player:StripWeapon( gren2 )
player:Give(dc15s, true)
elseif knife == "rw_sw_dc15s2" then
file.Write("users/"..player:SteamID64().."/weaponknife/weaponknife.txt", dc15s)
player:StripWeapon( knife )
player:Give(dc15s, true)
elseif wlutil == "rw_sw_dc15s2" then
file.Write("users/"..player:SteamID64().."/utiles/utiles.txt", dc15s)
player:StripWeapon( wlutil )
player:Give(dc15s, true)
elseif wlutil2 == "rw_sw_dc15s2" then
file.Write("users/"..player:SteamID64().."/utiles2/utiles2.txt", dc15s)
player:StripWeapon( wlutil2 )
player:Give(dc15s, true)
end

if weap1 == "rw_sw_dc15s3" then
file.Write("users/"..player:SteamID64().."/weaponfirst/weaponfirst.txt", dc15s)
player:StripWeapon( weap1 )
player:Give(dc15s, true)
elseif weap2 == "rw_sw_dc15s3" then
file.Write("users/"..player:SteamID64().."/weaponsecond/weaponsecond.txt", dc15s)
player:StripWeapon( weap2 )
player:Give(dc15s, true)
elseif gren == "rw_sw_dc15s3" then
file.Write("users/"..player:SteamID64().."/weapongrenade/weapongrenade.txt", dc15s)
player:StripWeapon( gren )
player:Give(dc15s, true)
elseif gren2 == "rw_sw_dc15s3" then
file.Write("users/"..player:SteamID64().."/weapongrenade2/weapongrenade2.txt", dc15s)
player:StripWeapon( gren2 )
player:Give(dc15s, true)
elseif knife == "rw_sw_dc15s3" then
file.Write("users/"..player:SteamID64().."/weaponknife/weaponknife.txt", dc15s)
player:StripWeapon( knife )
player:Give(dc15s, true)
elseif wlutil == "rw_sw_dc15s3" then
file.Write("users/"..player:SteamID64().."/utiles/utiles.txt", dc15s)
player:StripWeapon( wlutil )
player:Give(dc15s, true)
elseif wlutil2 == "rw_sw_dc15s3" then
file.Write("users/"..player:SteamID64().."/utiles2/utiles2.txt", dc15s)
player:StripWeapon( wlutil2 )
player:Give(dc15s, true)
end

if weap1 == "rw_sw_dc15s4" then
file.Write("users/"..player:SteamID64().."/weaponfirst/weaponfirst.txt", dc15s)
player:StripWeapon( weap1 )
player:Give(dc15s, true)
elseif weap2 == "rw_sw_dc15s4" then
file.Write("users/"..player:SteamID64().."/weaponsecond/weaponsecond.txt", dc15s)
player:StripWeapon( weap2 )
player:Give(dc15s, true)
elseif gren == "rw_sw_dc15s4" then
file.Write("users/"..player:SteamID64().."/weapongrenade/weapongrenade.txt", dc15s)
player:StripWeapon( gren )
player:Give(dc15s, true)
elseif gren2 == "rw_sw_dc15s4" then
file.Write("users/"..player:SteamID64().."/weapongrenade2/weapongrenade2.txt", dc15s)
player:StripWeapon( gren2 )
player:Give(dc15s, true)
elseif knife == "rw_sw_dc15s4" then
file.Write("users/"..player:SteamID64().."/weaponknife/weaponknife.txt", dc15s)
player:StripWeapon( knife )
player:Give(dc15s, true)
elseif wlutil == "rw_sw_dc15s4" then
file.Write("users/"..player:SteamID64().."/utiles/utiles.txt", dc15s)
player:StripWeapon( wlutil )
player:Give(dc15s, true)
elseif wlutil2 == "rw_sw_dc15s4" then
file.Write("users/"..player:SteamID64().."/utiles2/utiles2.txt", dc15s)
player:StripWeapon( wlutil2 )
player:Give(dc15s, true)
end

if weap1 == "rw_sw_dc15s5" then
file.Write("users/"..player:SteamID64().."/weaponfirst/weaponfirst.txt", dc15s)
player:StripWeapon( weap1 )
player:Give(dc15s, true)
elseif weap2 == "rw_sw_dc15s5" then
file.Write("users/"..player:SteamID64().."/weaponsecond/weaponsecond.txt", dc15s)
player:StripWeapon( weap2 )
player:Give(dc15s, true)
elseif gren == "rw_sw_dc15s5" then
file.Write("users/"..player:SteamID64().."/weapongrenade/weapongrenade.txt", dc15s)
player:StripWeapon( gren )
player:Give(dc15s, true)
elseif gren2 == "rw_sw_dc15s5" then
file.Write("users/"..player:SteamID64().."/weapongrenade2/weapongrenade2.txt", dc15s)
player:StripWeapon( gren2 )
player:Give(dc15s, true)
elseif knife == "rw_sw_dc15s5" then
file.Write("users/"..player:SteamID64().."/weaponknife/weaponknife.txt", dc15s)
player:StripWeapon( knife )
player:Give(dc15s, true)
elseif wlutil == "rw_sw_dc15s5" then
file.Write("users/"..player:SteamID64().."/utiles/utiles.txt", dc15s)
player:StripWeapon( wlutil )
player:Give(dc15s, true)
elseif wlutil2 == "rw_sw_dc15s5" then
file.Write("users/"..player:SteamID64().."/utiles2/utiles2.txt", dc15s)
player:StripWeapon( wlutil2 )
player:Give(dc15s, true)
end

end
--------DC15S

------DC15A
if dc15a != "null" then

if weap1 == "rw_sw_dc15a" then
file.Write("users/"..player:SteamID64().."/weaponfirst/weaponfirst.txt", dc15a)
player:StripWeapon( weap1 )
player:Give(dc15a, true)
elseif weap2 == "rw_sw_dc15a" then
file.Write("users/"..player:SteamID64().."/weaponsecond/weaponsecond.txt", dc15a)
player:StripWeapon( weap2 )
player:Give(dc15a, true)
elseif gren == "rw_sw_dc15a" then
file.Write("users/"..player:SteamID64().."/weapongrenade/weapongrenade.txt", dc15a)
player:StripWeapon( gren )
player:Give(dc15a, true)
elseif gren2 == "rw_sw_dc15a" then
file.Write("users/"..player:SteamID64().."/weapongrenade2/weapongrenade2.txt", dc15a)
player:StripWeapon( gren2 )
player:Give(dc15a, true)
elseif knife == "rw_sw_dc15a" then
file.Write("users/"..player:SteamID64().."/weaponknife/weaponknife.txt", dc15a)
player:StripWeapon( knife )
player:Give(dc15a, true)
elseif wlutil == "rw_sw_dc15a" then
file.Write("users/"..player:SteamID64().."/utiles/utiles.txt", dc15a)
player:StripWeapon( wlutil )
player:Give(dc15a, true)
elseif wlutil2 == "rw_sw_dc15a" then
file.Write("users/"..player:SteamID64().."/utiles2/utiles2.txt", dc15a)
player:StripWeapon( wlutil2 )
player:Give(dc15a, true)
end

if weap1 == "rw_sw_dc15a1" then
file.Write("users/"..player:SteamID64().."/weaponfirst/weaponfirst.txt", dc15a)
player:StripWeapon( weap1 )
player:Give(dc15a, true)
elseif weap2 == "rw_sw_dc15a1" then
file.Write("users/"..player:SteamID64().."/weaponsecond/weaponsecond.txt", dc15a)
player:StripWeapon( weap2 )
player:Give(dc15a, true)
elseif gren == "rw_sw_dc15a1" then
file.Write("users/"..player:SteamID64().."/weapongrenade/weapongrenade.txt", dc15a)
player:StripWeapon( gren )
player:Give(dc15a, true)
elseif gren2 == "rw_sw_dc15a1" then
file.Write("users/"..player:SteamID64().."/weapongrenade2/weapongrenade2.txt", dc15a)
player:StripWeapon( gren2 )
player:Give(dc15a, true)
elseif knife == "rw_sw_dc15a1" then
file.Write("users/"..player:SteamID64().."/weaponknife/weaponknife.txt", dc15a)
player:StripWeapon( knife )
player:Give(dc15a, true)
elseif wlutil == "rw_sw_dc15a1" then
file.Write("users/"..player:SteamID64().."/utiles/utiles.txt", dc15a)
player:StripWeapon( wlutil )
player:Give(dc15a, true)
elseif wlutil2 == "rw_sw_dc15a1" then
file.Write("users/"..player:SteamID64().."/utiles2/utiles2.txt", dc15a)
player:StripWeapon( wlutil2 )
player:Give(dc15a, true)
end

if weap1 == "rw_sw_dc15a2" then
file.Write("users/"..player:SteamID64().."/weaponfirst/weaponfirst.txt", dc15a)
player:StripWeapon( weap1 )
player:Give(dc15a, true)
elseif weap2 == "rw_sw_dc15a2" then
file.Write("users/"..player:SteamID64().."/weaponsecond/weaponsecond.txt", dc15a)
player:StripWeapon( weap2 )
player:Give(dc15a, true)
elseif gren == "rw_sw_dc15a2" then
file.Write("users/"..player:SteamID64().."/weapongrenade/weapongrenade.txt", dc15a)
player:StripWeapon( gren )
player:Give(dc15a, true)
elseif gren2 == "rw_sw_dc15a2" then
file.Write("users/"..player:SteamID64().."/weapongrenade2/weapongrenade2.txt", dc15a)
player:StripWeapon( gren2 )
player:Give(dc15a, true)
elseif knife == "rw_sw_dc15a2" then
file.Write("users/"..player:SteamID64().."/weaponknife/weaponknife.txt", dc15a)
player:StripWeapon( knife )
player:Give(dc15a, true)
elseif wlutil == "rw_sw_dc15a2" then
file.Write("users/"..player:SteamID64().."/utiles/utiles.txt", dc15a)
player:StripWeapon( wlutil )
player:Give(dc15a, true)
elseif wlutil2 == "rw_sw_dc15a2" then
file.Write("users/"..player:SteamID64().."/utiles2/utiles2.txt", dc15a)
player:StripWeapon( wlutil2 )
player:Give(dc15a, true)
end

if weap1 == "rw_sw_dc15a3" then
file.Write("users/"..player:SteamID64().."/weaponfirst/weaponfirst.txt", dc15a)
player:StripWeapon( weap1 )
player:Give(dc15a, true)
elseif weap2 == "rw_sw_dc15a3" then
file.Write("users/"..player:SteamID64().."/weaponsecond/weaponsecond.txt", dc15a)
player:StripWeapon( weap2 )
player:Give(dc15a, true)
elseif gren == "rw_sw_dc15a3" then
file.Write("users/"..player:SteamID64().."/weapongrenade/weapongrenade.txt", dc15a)
player:StripWeapon( gren )
player:Give(dc15a, true)
elseif gren2 == "rw_sw_dc15a3" then
file.Write("users/"..player:SteamID64().."/weapongrenade2/weapongrenade2.txt", dc15a)
player:StripWeapon( gren2 )
player:Give(dc15a, true)
elseif knife == "rw_sw_dc15a3" then
file.Write("users/"..player:SteamID64().."/weaponknife/weaponknife.txt", dc15a)
player:StripWeapon( knife )
player:Give(dc15a, true)
elseif wlutil == "rw_sw_dc15a3" then
file.Write("users/"..player:SteamID64().."/utiles/utiles.txt", dc15a)
player:StripWeapon( wlutil )
player:Give(dc15a, true)
elseif wlutil2 == "rw_sw_dc15a3" then
file.Write("users/"..player:SteamID64().."/utiles2/utiles2.txt", dc15a)
player:StripWeapon( wlutil2 )
player:Give(dc15a, true)
end

if weap1 == "rw_sw_dc15a4" then
file.Write("users/"..player:SteamID64().."/weaponfirst/weaponfirst.txt", dc15a)
player:StripWeapon( weap1 )
player:Give(dc15a, true)
elseif weap2 == "rw_sw_dc15a4" then
file.Write("users/"..player:SteamID64().."/weaponsecond/weaponsecond.txt", dc15a)
player:StripWeapon( weap2 )
player:Give(dc15a, true)
elseif gren == "rw_sw_dc15a4" then
file.Write("users/"..player:SteamID64().."/weapongrenade/weapongrenade.txt", dc15a)
player:StripWeapon( gren )
player:Give(dc15a, true)
elseif gren2 == "rw_sw_dc15a4" then
file.Write("users/"..player:SteamID64().."/weapongrenade2/weapongrenade2.txt", dc15a)
player:StripWeapon( gren2 )
player:Give(dc15a, true)
elseif knife == "rw_sw_dc15a4" then
file.Write("users/"..player:SteamID64().."/weaponknife/weaponknife.txt", dc15a)
player:StripWeapon( knife )
player:Give(dc15a, true)
elseif wlutil == "rw_sw_dc15a4" then
file.Write("users/"..player:SteamID64().."/utiles/utiles.txt", dc15a)
player:StripWeapon( wlutil )
player:Give(dc15a, true)
elseif wlutil2 == "rw_sw_dc15a4" then
file.Write("users/"..player:SteamID64().."/utiles2/utiles2.txt", dc15a)
player:StripWeapon( wlutil2 )
player:Give(dc15a, true)
end

if weap1 == "rw_sw_dc15a5" then
file.Write("users/"..player:SteamID64().."/weaponfirst/weaponfirst.txt", dc15a)
player:StripWeapon( weap1 )
player:Give(dc15a, true)
elseif weap2 == "rw_sw_dc15a5" then
file.Write("users/"..player:SteamID64().."/weaponsecond/weaponsecond.txt", dc15a)
player:StripWeapon( weap2 )
player:Give(dc15a, true)
elseif gren == "rw_sw_dc15a5" then
file.Write("users/"..player:SteamID64().."/weapongrenade/weapongrenade.txt", dc15a)
player:StripWeapon( gren )
player:Give(dc15a, true)
elseif gren2 == "rw_sw_dc15a5" then
file.Write("users/"..player:SteamID64().."/weapongrenade2/weapongrenade2.txt", dc15a)
player:StripWeapon( gren2 )
player:Give(dc15a, true)
elseif knife == "rw_sw_dc15a5" then
file.Write("users/"..player:SteamID64().."/weaponknife/weaponknife.txt", dc15a)
player:StripWeapon( knife )
player:Give(dc15a, true)
elseif wlutil == "rw_sw_dc15a5" then
file.Write("users/"..player:SteamID64().."/utiles/utiles.txt", dc15a)
player:StripWeapon( wlutil )
player:Give(dc15a, true)
elseif wlutil2 == "rw_sw_dc15a5" then
file.Write("users/"..player:SteamID64().."/utiles2/utiles2.txt", dc15a)
player:StripWeapon( wlutil2 )
player:Give(dc15a, true)
end

end
--------DC15A

--------DC17
if dc17 != "null" then

if weap1 == "rw_sw_dc17" then
file.Write("users/"..player:SteamID64().."/weaponfirst/weaponfirst.txt", dc17)
player:StripWeapon( weap1 )
player:Give(dc17, true)
elseif weap2 == "rw_sw_dc17" then
file.Write("users/"..player:SteamID64().."/weaponsecond/weaponsecond.txt", dc17)
player:StripWeapon( weap2 )
player:Give(dc17, true)
elseif gren == "rw_sw_dc17" then
file.Write("users/"..player:SteamID64().."/weapongrenade/weapongrenade.txt", dc17)
player:StripWeapon( gren )
player:Give(dc17, true)
elseif gren2 == "rw_sw_dc17" then
file.Write("users/"..player:SteamID64().."/weapongrenade2/weapongrenade2.txt", dc17)
player:StripWeapon( gren2 )
player:Give(dc17, true)
elseif knife == "rw_sw_dc17" then
file.Write("users/"..player:SteamID64().."/weaponknife/weaponknife.txt", dc17)
player:StripWeapon( knife )
player:Give(dc17, true)
elseif wlutil == "rw_sw_dc17" then
file.Write("users/"..player:SteamID64().."/utiles/utiles.txt", dc17)
player:StripWeapon( wlutil )
player:Give(dc17, true)
elseif wlutil2 == "rw_sw_dc17" then
file.Write("users/"..player:SteamID64().."/utiles2/utiles2.txt", dc17)
player:StripWeapon( wlutil2 )
player:Give(dc17, true)
end

if weap1 == "rw_sw_dc171" then
file.Write("users/"..player:SteamID64().."/weaponfirst/weaponfirst.txt", dc17)
player:StripWeapon( weap1 )
player:Give(dc17, true)
elseif weap2 == "rw_sw_dc171" then
file.Write("users/"..player:SteamID64().."/weaponsecond/weaponsecond.txt", dc17)
player:StripWeapon( weap2 )
player:Give(dc17, true)
elseif gren == "rw_sw_dc171" then
file.Write("users/"..player:SteamID64().."/weapongrenade/weapongrenade.txt", dc17)
player:StripWeapon( gren )
player:Give(dc17, true)
elseif gren2 == "rw_sw_dc171" then
file.Write("users/"..player:SteamID64().."/weapongrenade2/weapongrenade2.txt", dc17)
player:StripWeapon( gren2 )
player:Give(dc17, true)
elseif knife == "rw_sw_dc171" then
file.Write("users/"..player:SteamID64().."/weaponknife/weaponknife.txt", dc17)
player:StripWeapon( knife )
player:Give(dc17, true)
elseif wlutil == "rw_sw_dc171" then
file.Write("users/"..player:SteamID64().."/utiles/utiles.txt", dc17)
player:StripWeapon( wlutil )
player:Give(dc17, true)
elseif wlutil2 == "rw_sw_dc171" then
file.Write("users/"..player:SteamID64().."/utiles2/utiles2.txt", dc17)
player:StripWeapon( wlutil2 )
player:Give(dc17, true)
end

if weap1 == "rw_sw_dc172" then
file.Write("users/"..player:SteamID64().."/weaponfirst/weaponfirst.txt", dc17)
player:StripWeapon( weap1 )
player:Give(dc17, true)
elseif weap2 == "rw_sw_dc172" then
file.Write("users/"..player:SteamID64().."/weaponsecond/weaponsecond.txt", dc17)
player:StripWeapon( weap2 )
player:Give(dc17, true)
elseif gren == "rw_sw_dc172" then
file.Write("users/"..player:SteamID64().."/weapongrenade/weapongrenade.txt", dc17)
player:StripWeapon( gren )
player:Give(dc17, true)
elseif gren2 == "rw_sw_dc172" then
file.Write("users/"..player:SteamID64().."/weapongrenade2/weapongrenade2.txt", dc17)
player:StripWeapon( gren2 )
player:Give(dc17, true)
elseif knife == "rw_sw_dc172" then
file.Write("users/"..player:SteamID64().."/weaponknife/weaponknife.txt", dc17)
player:StripWeapon( knife )
player:Give(dc17, true)
elseif wlutil == "rw_sw_dc172" then
file.Write("users/"..player:SteamID64().."/utiles/utiles.txt", dc17)
player:StripWeapon( wlutil )
player:Give(dc17, true)
elseif wlutil2 == "rw_sw_dc172" then
file.Write("users/"..player:SteamID64().."/utiles2/utiles2.txt", dc17)
player:StripWeapon( wlutil2 )
player:Give(dc17, true)
end

if weap1 == "rw_sw_dc173" then
file.Write("users/"..player:SteamID64().."/weaponfirst/weaponfirst.txt", dc17)
player:StripWeapon( weap1 )
player:Give(dc17, true)
elseif weap2 == "rw_sw_dc173" then
file.Write("users/"..player:SteamID64().."/weaponsecond/weaponsecond.txt", dc17)
player:StripWeapon( weap2 )
player:Give(dc17, true)
elseif gren == "rw_sw_dc173" then
file.Write("users/"..player:SteamID64().."/weapongrenade/weapongrenade.txt", dc17)
player:StripWeapon( gren )
player:Give(dc17, true)
elseif gren2 == "rw_sw_dc173" then
file.Write("users/"..player:SteamID64().."/weapongrenade2/weapongrenade2.txt", dc17)
player:StripWeapon( gren2 )
player:Give(dc17, true)
elseif knife == "rw_sw_dc173" then
file.Write("users/"..player:SteamID64().."/weaponknife/weaponknife.txt", dc17)
player:StripWeapon( knife )
player:Give(dc17, true)
elseif wlutil == "rw_sw_dc173" then
file.Write("users/"..player:SteamID64().."/utiles/utiles.txt", dc17)
player:StripWeapon( wlutil )
player:Give(dc17, true)
elseif wlutil2 == "rw_sw_dc173" then
file.Write("users/"..player:SteamID64().."/utiles2/utiles2.txt", dc17)
player:StripWeapon( wlutil2 )
player:Give(dc17, true)
end

if weap1 == "rw_sw_dc174" then
file.Write("users/"..player:SteamID64().."/weaponfirst/weaponfirst.txt", dc17)
player:StripWeapon( weap1 )
player:Give(dc17, true)
elseif weap2 == "rw_sw_dc174" then
file.Write("users/"..player:SteamID64().."/weaponsecond/weaponsecond.txt", dc17)
player:StripWeapon( weap2 )
player:Give(dc17, true)
elseif gren == "rw_sw_dc174" then
file.Write("users/"..player:SteamID64().."/weapongrenade/weapongrenade.txt", dc17)
player:StripWeapon( gren )
player:Give(dc17, true)
elseif gren2 == "rw_sw_dc174" then
file.Write("users/"..player:SteamID64().."/weapongrenade2/weapongrenade2.txt", dc17)
player:StripWeapon( gren2 )
player:Give(dc17, true)
elseif knife == "rw_sw_dc174" then
file.Write("users/"..player:SteamID64().."/weaponknife/weaponknife.txt", dc17)
player:StripWeapon( knife )
player:Give(dc17, true)
elseif wlutil == "rw_sw_dc174" then
file.Write("users/"..player:SteamID64().."/utiles/utiles.txt", dc17)
player:StripWeapon( wlutil )
player:Give(dc17, true)
elseif wlutil2 == "rw_sw_dc174" then
file.Write("users/"..player:SteamID64().."/utiles2/utiles2.txt", dc17)
player:StripWeapon( wlutil2 )
player:Give(dc17, true)
end

if weap1 == "rw_sw_dc175" then
file.Write("users/"..player:SteamID64().."/weaponfirst/weaponfirst.txt", dc17)
player:StripWeapon( weap1 )
player:Give(dc17, true)
elseif weap2 == "rw_sw_dc175" then
file.Write("users/"..player:SteamID64().."/weaponsecond/weaponsecond.txt", dc17)
player:StripWeapon( weap2 )
player:Give(dc17, true)
elseif gren == "rw_sw_dc175" then
file.Write("users/"..player:SteamID64().."/weapongrenade/weapongrenade.txt", dc17)
player:StripWeapon( gren )
player:Give(dc17, true)
elseif gren2 == "rw_sw_dc175" then
file.Write("users/"..player:SteamID64().."/weapongrenade2/weapongrenade2.txt", dc17)
player:StripWeapon( gren2 )
player:Give(dc17, true)
elseif knife == "rw_sw_dc175" then
file.Write("users/"..player:SteamID64().."/weaponknife/weaponknife.txt", dc17)
player:StripWeapon( knife )
player:Give(dc17, true)
elseif wlutil == "rw_sw_dc175" then
file.Write("users/"..player:SteamID64().."/utiles/utiles.txt", dc17)
player:StripWeapon( wlutil )
player:Give(dc17, true)
elseif wlutil2 == "rw_sw_dc175" then
file.Write("users/"..player:SteamID64().."/utiles2/utiles2.txt", dc17)
player:StripWeapon( wlutil2 )
player:Give(dc17, true)
end

end
--------DC17
end)

---------

util.AddNetworkString("f1menu_to_hud_srvpoints")
util.AddNetworkString("f1menu_to_hud_clientpoints")
net.Receive("f1menu_to_hud_srvpoints", function()
local igrok = net.ReadEntity()
local points = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
local xp = file.Read("users/"..igrok:SteamID64().."/level/xp.txt")
local level = file.Read("users/"..igrok:SteamID64().."/level/level.txt")
local hpboost = file.Read("users/"..igrok:SteamID64().."/level/hpboost.txt")
local armorboost = file.Read("users/"..igrok:SteamID64().."/level/armorboost.txt")
local statminaboost = file.Read("users/"..igrok:SteamID64().."/level/statminaboost.txt")
local speedboost = file.Read("users/"..igrok:SteamID64().."/level/speedboost.txt")
local ammoboost = file.Read("users/"..igrok:SteamID64().."/level/ammoboost.txt")
local granboost = file.Read("users/"..igrok:SteamID64().."/level/granboost.txt")
local function f1cmdchecks()
net.Start('f1menu_to_hud_clientpoints')
net.WriteString(points)
net.WriteString(xp)
net.WriteString(level)
net.WriteString(hpboost)
net.WriteString(armorboost)
net.WriteString(statminaboost)
net.WriteString(speedboost)
net.WriteString(ammoboost)
net.WriteString(granboost)
net.Send(igrok)
end
f1cmdchecks()
end)

util.AddNetworkString("f1menu_to_hud_srvpointsset")
net.Receive("f1menu_to_hud_srvpointsset", function()
local igrok = net.ReadEntity()
local hpboost = net.ReadString()
local armorboost = net.ReadString()
local statminaboost = net.ReadString()
local speedboost = net.ReadString()
local ammoboost = net.ReadString()
local granboost = net.ReadString()
local hpboost1 = net.ReadString()
local armorboost1 = net.ReadString()
local statminaboost1 = net.ReadString()
local speedboost1 = net.ReadString()
local ammoboost1 = net.ReadString()
local granboost1 = net.ReadString()
local hpboost2 = file.Read("users/"..igrok:SteamID64().."/level/hpboost.txt")
local armorboost2 = file.Read("users/"..igrok:SteamID64().."/level/armorboost.txt")
local statminaboost2 = file.Read("users/"..igrok:SteamID64().."/level/statminaboost.txt")
local speedboost2 = file.Read("users/"..igrok:SteamID64().."/level/speedboost.txt")
local ammoboost2 = file.Read("users/"..igrok:SteamID64().."/level/ammoboost.txt")
local granboost2 = file.Read("users/"..igrok:SteamID64().."/level/granboost.txt")

if hpboost1 == "hpup10" and hpboost2 == "1" then
local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 30 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 30)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.5")
end
elseif hpboost1 == "hpup10" and hpboost2 == "1.05" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 29 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 29)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.5")
end
elseif hpboost1 == "hpup10" and hpboost2 == "1.1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 28 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 28)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.5")
end
elseif hpboost1 == "hpup10" and hpboost2 == "1.15" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 26 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 26)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.5")
end
elseif hpboost1 == "hpup10" and hpboost2 == "1.2" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 24 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 24)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.5")
end
elseif hpboost1 == "hpup10" and hpboost2 == "1.25" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 21 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 21)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.5")
end
elseif hpboost1 == "hpup10" and hpboost2 == "1.3" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 18 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 18)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.5")
end
elseif hpboost1 == "hpup10" and hpboost2 == "1.35" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 14 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 14)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.5")
end
elseif hpboost1 == "hpup10" and hpboost2 == "1.4" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 10 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 10)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.5")
end
elseif hpboost1 == "hpup10" and hpboost2 == "1.45" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 5 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 5)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.5")
end
end

if hpboost1 == "hpup9" and hpboost2 == "1" then
local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 25 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 25)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.45")
end
elseif hpboost1 == "hpup9" and hpboost2 == "1.05" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 24 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 24)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.45")
end
elseif hpboost1 == "hpup9" and hpboost2 == "1.1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 23 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 23)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.45")
end
elseif hpboost1 == "hpup9" and hpboost2 == "1.15" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 21 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 21)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.45")
end
elseif hpboost1 == "hpup9" and hpboost2 == "1.2" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 19 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 19)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.45")
end
elseif hpboost1 == "hpup9" and hpboost2 == "1.25" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 16 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 16)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.45")
end
elseif hpboost1 == "hpup9" and hpboost2 == "1.3" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 13 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 13)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.45")
end
elseif hpboost1 == "hpup9" and hpboost2 == "1.35" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 9 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 9)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.45")
end
elseif hpboost1 == "hpup9" and hpboost2 == "1.4" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 5 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 5)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.45")
end
end

if hpboost1 == "hpup8" and hpboost2 == "1" then
local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 20 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 20)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.4")
end
elseif hpboost1 == "hpup8" and hpboost2 == "1.05" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 19 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 19)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.4")
end
elseif hpboost1 == "hpup8" and hpboost2 == "1.1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 18 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 18)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.4")
end
elseif hpboost1 == "hpup8" and hpboost2 == "1.15" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 16 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 16)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.4")
end
elseif hpboost1 == "hpup8" and hpboost2 == "1.2" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 14 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 14)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.4")
end
elseif hpboost1 == "hpup8" and hpboost2 == "1.25" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 11 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 11)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.4")
end
elseif hpboost1 == "hpup8" and hpboost2 == "1.3" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 8 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 8)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.4")
end
elseif hpboost1 == "hpup8" and hpboost2 == "1.35" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 4 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 4)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.4")
end
end

if hpboost1 == "hpup7" and hpboost2 == "1" then
local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 16 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 16)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.35")
end
elseif hpboost1 == "hpup7" and hpboost2 == "1.05" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 15 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 15)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.35")
end
elseif hpboost1 == "hpup7" and hpboost2 == "1.1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 14 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 14)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.35")
end
elseif hpboost1 == "hpup7" and hpboost2 == "1.15" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 12 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 12)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.35")
end
elseif hpboost1 == "hpup7" and hpboost2 == "1.2" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 10 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 10)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.35")
end
elseif hpboost1 == "hpup7" and hpboost2 == "1.25" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 7 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 7)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.35")
end
elseif hpboost1 == "hpup7" and hpboost2 == "1.3" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 4 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 4)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.35")
end
end

if hpboost1 == "hpup6" and hpboost2 == "1" then
local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 12 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 12)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.3")
end
elseif hpboost1 == "hpup6" and hpboost2 == "1.05" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 11 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 11)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.3")
end
elseif hpboost1 == "hpup6" and hpboost2 == "1.1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 10 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 10)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.3")
end
elseif hpboost1 == "hpup6" and hpboost2 == "1.15" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 8 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 8)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.3")
end
elseif hpboost1 == "hpup6" and hpboost2 == "1.2" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 6 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 6)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.3")
end
elseif hpboost1 == "hpup6" and hpboost2 == "1.25" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 3 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 3)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.3")
end
end

if hpboost1 == "hpup5" and hpboost2 == "1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 9 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 9)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.25")
end
elseif hpboost1 == "hpup5" and hpboost2 == "1.05" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 8 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 8)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.25")
end
elseif hpboost1 == "hpup5" and hpboost2 == "1.1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 7 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 7)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.25")
end
elseif hpboost1 == "hpup5" and hpboost2 == "1.15" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 5 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 5)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.25")
end
elseif hpboost1 == "hpup5" and hpboost2 == "1.2" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 3 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 3)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.25")
end
end

if hpboost1 == "hpup4" and hpboost2 == "1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 6 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 6)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.2")
end
elseif hpboost1 == "hpup4" and hpboost2 == "1.05" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 5 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 5)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.2")
end
elseif hpboost1 == "hpup4" and hpboost2 == "1.1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 4 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 4)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.2")
end
elseif hpboost1 == "hpup4" and hpboost2 == "1.15" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 2 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 2)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.2")
end
end

if hpboost1 == "hpup3" and hpboost2 == "1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 4 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 4)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.15")
end
elseif hpboost1 == "hpup3" and hpboost2 == "1.05" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 3 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 3)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.15")
end
elseif hpboost1 == "hpup3" and hpboost2 == "1.1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 2 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 2)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.15")
end
end

if hpboost1 == "hpup2" and hpboost2 == "1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 2 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 2)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.1")
end
elseif hpboost1 == "hpup2" and hpboost2 == "1.05" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 1 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 1)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.1")
end
end

if hpboost1 == "hpup1" and hpboost2 == "1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 1 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 1)
file.Write("users/"..igrok:SteamID64().."/level/hpboost.txt", "1.05")
end
end



----



if armorboost1 == "armorup10" and armorboost2 == "1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 30 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 30)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.5")
end
elseif armorboost1 == "armorup10" and armorboost2 == "1.05" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 29 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 29)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.5")
end
elseif armorboost1 == "armorup10" and armorboost2 == "1.1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 28 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 28)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.5")
end
elseif armorboost1 == "armorup10" and armorboost2 == "1.15" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 26 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 26)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.5")
end
elseif armorboost1 == "armorup10" and armorboost2 == "1.2" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 24 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 24)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.5")
end
elseif armorboost1 == "armorup10" and armorboost2 == "1.25" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 21 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 21)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.5")
end
elseif armorboost1 == "armorup10" and armorboost2 == "1.3" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 18 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 18)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.5")
end
elseif armorboost1 == "armorup10" and armorboost2 == "1.35" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 14 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 14)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.5")
end
elseif armorboost1 == "armorup10" and armorboost2 == "1.4" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 10 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 10)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.5")
end
elseif armorboost1 == "armorup10" and armorboost2 == "1.45" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 5 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 5)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.5")
end
end

if armorboost1 == "armorup9" and armorboost2 == "1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 25 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 25)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.45")
end
elseif armorboost1 == "armorup9" and armorboost2 == "1.05" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 24 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 24)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.45")
end
elseif armorboost1 == "armorup9" and armorboost2 == "1.1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 23 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 23)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.45")
end
elseif armorboost1 == "armorup9" and armorboost2 == "1.15" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 21 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 21)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.45")
end
elseif armorboost1 == "armorup9" and armorboost2 == "1.2" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 19 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 19)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.45")
end
elseif armorboost1 == "armorup9" and armorboost2 == "1.25" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 16 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 16)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.45")
end
elseif armorboost1 == "armorup9" and armorboost2 == "1.3" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 13 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 13)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.45")
end
elseif armorboost1 == "armorup9" and armorboost2 == "1.35" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 9 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 9)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.45")
end
elseif armorboost1 == "armorup9" and armorboost2 == "1.4" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 5 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 5)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.45")
end
end

if armorboost1 == "armorup8" and armorboost2 == "1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 20 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 20)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.4")
end
elseif armorboost1 == "armorup8" and armorboost2 == "1.05" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 19 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 19)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.4")
end
elseif armorboost1 == "armorup8" and armorboost2 == "1.1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 18 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 18)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.4")
end
elseif armorboost1 == "armorup8" and armorboost2 == "1.15" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 16 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 16)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.4")
end
elseif armorboost1 == "armorup8" and armorboost2 == "1.2" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 14 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 14)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.4")
end
elseif armorboost1 == "armorup8" and armorboost2 == "1.25" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 11 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 11)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.4")
end
elseif armorboost1 == "armorup8" and armorboost2 == "1.3" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 8 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 8)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.4")
end
elseif armorboost1 == "armorup8" and armorboost2 == "1.35" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 4 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 4)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.4")
end
end

if armorboost1 == "armorup7" and armorboost2 == "1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 16 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 16)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.35")
end
elseif armorboost1 == "armorup7" and armorboost2 == "1.05" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 15 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 15)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.35")
end
elseif armorboost1 == "armorup7" and armorboost2 == "1.1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 14 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 14)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.35")
end
elseif armorboost1 == "armorup7" and armorboost2 == "1.15" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 12 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 12)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.35")
end
elseif armorboost1 == "armorup7" and armorboost2 == "1.2" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 10 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 10)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.35")
end
elseif armorboost1 == "armorup7" and armorboost2 == "1.25" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 7 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 7)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.35")
end
elseif armorboost1 == "armorup7" and armorboost2 == "1.3" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 4 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 4)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.35")
end
end

if armorboost1 == "armorup6" and armorboost2 == "1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 12 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 12)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.3")
end
elseif armorboost1 == "armorup6" and armorboost2 == "1.05" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 11 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 11)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.3")
end
elseif armorboost1 == "armorup6" and armorboost2 == "1.1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 10 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 10)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.3")
end
elseif armorboost1 == "armorup6" and armorboost2 == "1.15" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 8 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 8)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.3")
end
elseif armorboost1 == "armorup6" and armorboost2 == "1.2" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 6 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 6)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.3")
end
elseif armorboost1 == "armorup6" and armorboost2 == "1.25" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 3 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 3)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.3")
end
end

if armorboost1 == "armorup5" and armorboost2 == "1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 9 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 9)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.25")
end
elseif armorboost1 == "armorup5" and armorboost2 == "1.05" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 8 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 8)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.25")
end
elseif armorboost1 == "armorup5" and armorboost2 == "1.1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 7 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 7)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.25")
end
elseif armorboost1 == "armorup5" and armorboost2 == "1.15" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 5 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 5)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.25")
end
elseif armorboost1 == "armorup5" and armorboost2 == "1.2" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 3 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 3)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.25")
end
end

if armorboost1 == "armorup4" and armorboost2 == "1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 6 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 6)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.2")
end
elseif armorboost1 == "armorup4" and armorboost2 == "1.05" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 5 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 5)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.2")
end
elseif armorboost1 == "armorup4" and armorboost2 == "1.1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 4 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 4)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.2")
end
elseif armorboost1 == "armorup4" and armorboost2 == "1.15" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 2 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 2)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.2")
end
end

if armorboost1 == "armorup3" and armorboost2 == "1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 4 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 4)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.15")
end
elseif armorboost1 == "armorup3" and armorboost2 == "1.05" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 3 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 3)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.15")
end
elseif armorboost1 == "armorup3" and armorboost2 == "1.1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 2 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 2)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.15")
end
end

if armorboost1 == "armorup2" and armorboost2 == "1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 2 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 2)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.1")
end
elseif armorboost1 == "armorup2" and armorboost2 == "1.05" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 1 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 1)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.1")
end
end

if armorboost1 == "armorup1" and armorboost2 == "1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 1 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 1)
file.Write("users/"..igrok:SteamID64().."/level/armorboost.txt", "1.05")
end
end



----



if statminaboost1 == "staminaup10" and statminaboost2 == "1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 30 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 30)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.5")
end
elseif statminaboost1 == "staminaup10" and statminaboost2 == "1.05" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 29 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 29)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.5")
end
elseif statminaboost1 == "staminaup10" and statminaboost2 == "1.1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 28 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 28)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.5")
end
elseif statminaboost1 == "staminaup10" and statminaboost2 == "1.15" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 26 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 26)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.5")
end
elseif statminaboost1 == "staminaup10" and statminaboost2 == "1.2" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 24 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 24)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.5")
end
elseif statminaboost1 == "staminaup10" and statminaboost2 == "1.25" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 21 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 21)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.5")
end
elseif statminaboost1 == "staminaup10" and statminaboost2 == "1.3" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 18 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 18)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.5")
end
elseif statminaboost1 == "staminaup10" and statminaboost2 == "1.35" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 14 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 14)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.5")
end
elseif statminaboost1 == "staminaup10" and statminaboost2 == "1.4" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 10 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 10)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.5")
end
elseif statminaboost1 == "staminaup10" and statminaboost2 == "1.45" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 5 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 5)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.5")
end
end

if statminaboost1 == "staminaup9" and statminaboost2 == "1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 25 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 25)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.45")
end
elseif statminaboost1 == "staminaup9" and statminaboost2 == "1.05" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 24 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 24)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.45")
end
elseif statminaboost1 == "staminaup9" and statminaboost2 == "1.1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 23 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 23)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.45")
end
elseif statminaboost1 == "staminaup9" and statminaboost2 == "1.15" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 21 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 21)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.45")
end
elseif statminaboost1 == "staminaup9" and statminaboost2 == "1.2" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 19 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 19)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.45")
end
elseif statminaboost1 == "staminaup9" and statminaboost2 == "1.25" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 16 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 16)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.45")
end
elseif statminaboost1 == "staminaup9" and statminaboost2 == "1.3" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 13 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 13)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.45")
end
elseif statminaboost1 == "staminaup9" and statminaboost2 == "1.35" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 9 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 9)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.45")
end
elseif statminaboost1 == "staminaup9" and statminaboost2 == "1.4" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 5 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 5)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.45")
end
end

if statminaboost1 == "staminaup8" and statminaboost2 == "1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 20 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 20)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.4")
end
elseif statminaboost1 == "staminaup8" and statminaboost2 == "1.05" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 19 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 19)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.4")
end
elseif statminaboost1 == "staminaup8" and statminaboost2 == "1.1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 18 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 18)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.4")
end
elseif statminaboost1 == "staminaup8" and statminaboost2 == "1.15" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 16 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 16)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.4")
end
elseif statminaboost1 == "staminaup8" and statminaboost2 == "1.2" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 14 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 14)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.4")
end
elseif statminaboost1 == "staminaup8" and statminaboost2 == "1.25" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 11 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 11)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.4")
end
elseif statminaboost1 == "staminaup8" and statminaboost2 == "1.3" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 8 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 8)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.4")
end
elseif statminaboost1 == "staminaup8" and statminaboost2 == "1.35" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 4 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 4)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.4")
end
end

if statminaboost1 == "staminaup7" and statminaboost2 == "1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 16 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 16)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.35")
end
elseif statminaboost1 == "staminaup7" and statminaboost2 == "1.05" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 15 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 15)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.35")
end
elseif statminaboost1 == "staminaup7" and statminaboost2 == "1.1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 14 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 14)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.35")
end
elseif statminaboost1 == "staminaup7" and statminaboost2 == "1.15" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 12 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 12)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.35")
end
elseif statminaboost1 == "staminaup7" and statminaboost2 == "1.2" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 10 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 10)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.35")
end
elseif statminaboost1 == "staminaup7" and statminaboost2 == "1.25" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 7 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 7)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.35")
end
elseif statminaboost1 == "staminaup7" and statminaboost2 == "1.3" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 4 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 4)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.35")
end
end

if statminaboost1 == "staminaup6" and statminaboost2 == "1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 12 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 12)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.3")
end
elseif statminaboost1 == "staminaup6" and statminaboost2 == "1.05" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 11 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 11)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.3")
end
elseif statminaboost1 == "staminaup6" and statminaboost2 == "1.1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 10 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 10)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.3")
end
elseif statminaboost1 == "staminaup6" and statminaboost2 == "1.15" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 8 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 8)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.3")
end
elseif statminaboost1 == "staminaup6" and statminaboost2 == "1.2" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 6 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 6)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.3")
end
elseif statminaboost1 == "staminaup6" and statminaboost2 == "1.25" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 3 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 3)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.3")
end
end

if statminaboost1 == "staminaup5" and statminaboost2 == "1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 9 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 9)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.25")
end
elseif statminaboost1 == "staminaup5" and statminaboost2 == "1.05" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 8 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 8)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.25")
end
elseif statminaboost1 == "staminaup5" and statminaboost2 == "1.1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 7 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 7)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.25")
end
elseif statminaboost1 == "staminaup5" and statminaboost2 == "1.15" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 5 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 5)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.25")
end
elseif statminaboost1 == "staminaup5" and statminaboost2 == "1.2" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 3 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 3)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.25")
end
end

if statminaboost1 == "staminaup4" and statminaboost2 == "1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 6 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 6)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.2")
end
elseif statminaboost1 == "staminaup4" and statminaboost2 == "1.05" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 5 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 5)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.2")
end
elseif statminaboost1 == "staminaup4" and statminaboost2 == "1.1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 4 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 4)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.2")
end
elseif statminaboost1 == "staminaup4" and statminaboost2 == "1.15" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 2 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 2)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.2")
end
end

if statminaboost1 == "staminaup3" and statminaboost2 == "1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 4 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 4)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.15")
end
elseif statminaboost1 == "staminaup3" and statminaboost2 == "1.05" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 3 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 3)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.15")
end
elseif statminaboost1 == "staminaup3" and statminaboost2 == "1.1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 2 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 2)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.15")
end
end

if statminaboost1 == "staminaup2" and statminaboost2 == "1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 2 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 2)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.1")
end
elseif statminaboost1 == "staminaup2" and statminaboost2 == "1.05" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 1 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 1)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.1")
end
end

if statminaboost1 == "staminaup1" and statminaboost2 == "1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 1 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 1)
file.Write("users/"..igrok:SteamID64().."/level/statminaboost.txt", "1.05")
end
end


----


if speedboost1 == "speedup8" and speedboost2 == "1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 20 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 20)
file.Write("users/"..igrok:SteamID64().."/level/speedboost.txt", "1.2")
end
elseif speedboost1 == "speedup8" and speedboost2 == "1.025" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 19 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 19)
file.Write("users/"..igrok:SteamID64().."/level/speedboost.txt", "1.2")
end
elseif speedboost1 == "speedup8" and speedboost2 == "1.05" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 18 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 18)
file.Write("users/"..igrok:SteamID64().."/level/speedboost.txt", "1.2")
end
elseif speedboost1 == "speedup8" and speedboost2 == "1.075" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 16 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 16)
file.Write("users/"..igrok:SteamID64().."/level/speedboost.txt", "1.2")
end
elseif speedboost1 == "speedup8" and speedboost2 == "1.1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 14 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 14)
file.Write("users/"..igrok:SteamID64().."/level/speedboost.txt", "1.2")
end
elseif speedboost1 == "speedup8" and speedboost2 == "1.125" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 11 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 11)
file.Write("users/"..igrok:SteamID64().."/level/speedboost.txt", "1.2")
end
elseif speedboost1 == "speedup8" and speedboost2 == "1.15" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 8 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 8)
file.Write("users/"..igrok:SteamID64().."/level/speedboost.txt", "1.2")
end
elseif speedboost1 == "speedup8" and speedboost2 == "1.175" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 4 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 4)
file.Write("users/"..igrok:SteamID64().."/level/speedboost.txt", "1.2")
end
end

if speedboost1 == "speedup7" and speedboost2 == "1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 16 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 16)
file.Write("users/"..igrok:SteamID64().."/level/speedboost.txt", "1.175")
end
elseif speedboost1 == "speedup7" and speedboost2 == "1.025" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 15 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 15)
file.Write("users/"..igrok:SteamID64().."/level/speedboost.txt", "1.175")
end
elseif speedboost1 == "speedup7" and speedboost2 == "1.05" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 14 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 14)
file.Write("users/"..igrok:SteamID64().."/level/speedboost.txt", "1.175")
end
elseif speedboost1 == "speedup7" and speedboost2 == "1.075" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 12 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 12)
file.Write("users/"..igrok:SteamID64().."/level/speedboost.txt", "1.175")
end
elseif speedboost1 == "speedup7" and speedboost2 == "1.1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 10 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 10)
file.Write("users/"..igrok:SteamID64().."/level/speedboost.txt", "1.175")
end
elseif speedboost1 == "speedup7" and speedboost2 == "1.125" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 7 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 7)
file.Write("users/"..igrok:SteamID64().."/level/speedboost.txt", "1.175")
end
elseif speedboost1 == "speedup7" and speedboost2 == "1.15" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 4 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 4)
file.Write("users/"..igrok:SteamID64().."/level/speedboost.txt", "1.175")
end
end

if speedboost1 == "speedup6" and speedboost2 == "1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 12 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 12)
file.Write("users/"..igrok:SteamID64().."/level/speedboost.txt", "1.15")
end
elseif speedboost1 == "speedup6" and speedboost2 == "1.025" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 11 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 11)
file.Write("users/"..igrok:SteamID64().."/level/speedboost.txt", "1.15")
end
elseif speedboost1 == "speedup6" and speedboost2 == "1.05" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 10 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 10)
file.Write("users/"..igrok:SteamID64().."/level/speedboost.txt", "1.15")
end
elseif speedboost1 == "speedup6" and speedboost2 == "1.075" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 8 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 8)
file.Write("users/"..igrok:SteamID64().."/level/speedboost.txt", "1.15")
end
elseif speedboost1 == "speedup6" and speedboost2 == "1.1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 6 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 6)
file.Write("users/"..igrok:SteamID64().."/level/speedboost.txt", "1.15")
end
elseif speedboost1 == "speedup6" and speedboost2 == "1.125" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 3 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 3)
file.Write("users/"..igrok:SteamID64().."/level/speedboost.txt", "1.15")
end
end

if speedboost1 == "speedup5" and speedboost2 == "1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 9 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 9)
file.Write("users/"..igrok:SteamID64().."/level/speedboost.txt", "1.125")
end
elseif speedboost1 == "speedup5" and speedboost2 == "1.025" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 8 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 8)
file.Write("users/"..igrok:SteamID64().."/level/speedboost.txt", "1.125")
end
elseif speedboost1 == "speedup5" and speedboost2 == "1.05" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 7 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 7)
file.Write("users/"..igrok:SteamID64().."/level/speedboost.txt", "1.125")
end
elseif speedboost1 == "speedup5" and speedboost2 == "1.075" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 5 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 5)
file.Write("users/"..igrok:SteamID64().."/level/speedboost.txt", "1.125")
end
elseif speedboost1 == "speedup5" and speedboost2 == "1.1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 3 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 3)
file.Write("users/"..igrok:SteamID64().."/level/speedboost.txt", "1.125")
end
end

if speedboost1 == "speedup4" and speedboost2 == "1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 6 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 6)
file.Write("users/"..igrok:SteamID64().."/level/speedboost.txt", "1.1")
end
elseif speedboost1 == "speedup4" and speedboost2 == "1.025" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 5 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 5)
file.Write("users/"..igrok:SteamID64().."/level/speedboost.txt", "1.1")
end
elseif speedboost1 == "speedup4" and speedboost2 == "1.05" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 4 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 4)
file.Write("users/"..igrok:SteamID64().."/level/speedboost.txt", "1.1")
end
elseif speedboost1 == "speedup4" and speedboost2 == "1.075" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 2 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 2)
file.Write("users/"..igrok:SteamID64().."/level/speedboost.txt", "1.1")
end
end

if speedboost1 == "speedup3" and speedboost2 == "1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 4 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 4)
file.Write("users/"..igrok:SteamID64().."/level/speedboost.txt", "1.075")
end
elseif speedboost1 == "speedup3" and speedboost2 == "1.025" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 3 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 3)
file.Write("users/"..igrok:SteamID64().."/level/speedboost.txt", "1.075")
end
elseif speedboost1 == "speedup3" and speedboost2 == "1.05" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 2 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 2)
file.Write("users/"..igrok:SteamID64().."/level/speedboost.txt", "1.075")
end
end

if speedboost1 == "speedup2" and speedboost2 == "1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 2 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 2)
file.Write("users/"..igrok:SteamID64().."/level/speedboost.txt", "1.05")
end
elseif speedboost1 == "speedup2" and speedboost2 == "1.025" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 1 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 1)
file.Write("users/"..igrok:SteamID64().."/level/speedboost.txt", "1.05")
end
end

if speedboost1 == "speedup1" and speedboost2 == "1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 1 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 1)
file.Write("users/"..igrok:SteamID64().."/level/speedboost.txt", "1.025")
end
end


----


if ammoboost1 == "ammoup10" and ammoboost2 == "1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 30 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 30)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.5")
end
elseif ammoboost1 == "ammoup10" and ammoboost2 == "1.05" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 29 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 29)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.5")
end
elseif ammoboost1 == "ammoup10" and ammoboost2 == "1.1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 28 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 28)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.5")
end
elseif ammoboost1 == "ammoup10" and ammoboost2 == "1.15" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 26 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 26)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.5")
end
elseif ammoboost1 == "ammoup10" and ammoboost2 == "1.2" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 24 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 24)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.5")
end
elseif ammoboost1 == "ammoup10" and ammoboost2 == "1.25" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 21 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 21)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.5")
end
elseif ammoboost1 == "ammoup10" and ammoboost2 == "1.3" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 18 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 18)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.5")
end
elseif ammoboost1 == "ammoup10" and ammoboost2 == "1.35" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 14 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 14)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.5")
end
elseif ammoboost1 == "ammoup10" and ammoboost2 == "1.4" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 10 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 10)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.5")
end
elseif ammoboost1 == "ammoup10" and ammoboost2 == "1.45" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 5 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 5)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.5")
end
end

if ammoboost1 == "ammoup9" and ammoboost2 == "1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 25 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 25)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.45")
end
elseif ammoboost1 == "ammoup9" and ammoboost2 == "1.05" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 24 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 24)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.45")
end
elseif ammoboost1 == "ammoup9" and ammoboost2 == "1.1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 23 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 23)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.45")
end
elseif ammoboost1 == "ammoup9" and ammoboost2 == "1.15" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 21 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 21)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.45")
end
elseif ammoboost1 == "ammoup9" and ammoboost2 == "1.2" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 19 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 19)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.45")
end
elseif ammoboost1 == "ammoup9" and ammoboost2 == "1.25" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 16 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 16)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.45")
end
elseif ammoboost1 == "ammoup9" and ammoboost2 == "1.3" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 13 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 13)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.45")
end
elseif ammoboost1 == "ammoup9" and ammoboost2 == "1.35" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 9 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 9)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.45")
end
elseif ammoboost1 == "ammoup9" and ammoboost2 == "1.4" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 5 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 5)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.45")
end
end

if ammoboost1 == "ammoup8" and ammoboost2 == "1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 20 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 20)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.4")
end
elseif ammoboost1 == "ammoup8" and ammoboost2 == "1.05" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 19 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 19)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.4")
end
elseif ammoboost1 == "ammoup8" and ammoboost2 == "1.1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 18 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 18)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.4")
end
elseif ammoboost1 == "ammoup8" and ammoboost2 == "1.15" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 16 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 16)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.4")
end
elseif ammoboost1 == "ammoup8" and ammoboost2 == "1.2" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 14 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 14)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.4")
end
elseif ammoboost1 == "ammoup8" and ammoboost2 == "1.25" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 11 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 11)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.4")
end
elseif ammoboost1 == "ammoup8" and ammoboost2 == "1.3" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 8 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 8)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.4")
end
elseif ammoboost1 == "ammoup8" and ammoboost2 == "1.35" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 4 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 4)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.4")
end
end

if ammoboost1 == "ammoup7" and ammoboost2 == "1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 16 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 16)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.35")
end
elseif ammoboost1 == "ammoup7" and ammoboost2 == "1.05" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 15 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 15)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.35")
end
elseif ammoboost1 == "ammoup7" and ammoboost2 == "1.1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 14 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 14)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.35")
end
elseif ammoboost1 == "ammoup7" and ammoboost2 == "1.15" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 12 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 12)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.35")
end
elseif ammoboost1 == "ammoup7" and ammoboost2 == "1.2" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 10 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 10)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.35")
end
elseif ammoboost1 == "ammoup7" and ammoboost2 == "1.25" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 7 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 7)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.35")
end
elseif ammoboost1 == "ammoup7" and ammoboost2 == "1.3" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 4 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 4)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.35")
end
end

if ammoboost1 == "ammoup6" and ammoboost2 == "1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 12 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 12)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.3")
end
elseif ammoboost1 == "ammoup6" and ammoboost2 == "1.05" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 11 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 11)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.3")
end
elseif ammoboost1 == "ammoup6" and ammoboost2 == "1.1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 10 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 10)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.3")
end
elseif ammoboost1 == "ammoup6" and ammoboost2 == "1.15" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 8 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 8)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.3")
end
elseif ammoboost1 == "ammoup6" and ammoboost2 == "1.2" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 6 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 6)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.3")
end
elseif ammoboost1 == "ammoup6" and ammoboost2 == "1.25" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 3 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 3)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.3")
end
end

if ammoboost1 == "ammoup5" and ammoboost2 == "1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 9 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 9)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.25")
end
elseif ammoboost1 == "ammoup5" and ammoboost2 == "1.05" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 8 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 8)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.25")
end
elseif ammoboost1 == "ammoup5" and ammoboost2 == "1.1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 7 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 7)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.25")
end
elseif ammoboost1 == "ammoup5" and ammoboost2 == "1.15" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 5 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 5)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.25")
end
elseif ammoboost1 == "ammoup5" and ammoboost2 == "1.2" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 3 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 3)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.25")
end
end

if ammoboost1 == "ammoup4" and ammoboost2 == "1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 6 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 6)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.2")
end
elseif ammoboost1 == "ammoup4" and ammoboost2 == "1.05" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 5 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 5)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.2")
end
elseif ammoboost1 == "ammoup4" and ammoboost2 == "1.1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 4 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 4)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.2")
end
elseif ammoboost1 == "ammoup4" and ammoboost2 == "1.15" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 2 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 2)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.2")
end
end

if ammoboost1 == "ammoup3" and ammoboost2 == "1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 4 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 4)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.15")
end
elseif ammoboost1 == "ammoup3" and ammoboost2 == "1.05" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 3 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 3)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.15")
end
elseif ammoboost1 == "ammoup3" and ammoboost2 == "1.1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 2 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 2)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.15")
end
end

if ammoboost1 == "ammoup2" and ammoboost2 == "1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 2 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 2)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.1")
end
elseif ammoboost1 == "ammoup2" and ammoboost2 == "1.05" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 1 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 1)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.1")
end
end

if ammoboost1 == "ammoup1" and ammoboost2 == "1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 1 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 1)
file.Write("users/"..igrok:SteamID64().."/level/ammoboost.txt", "1.05")
end
end


----


if granboost1 == "rpgup3" and granboost2 == "0" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 9 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 9)
file.Write("users/"..igrok:SteamID64().."/level/granboost.txt", "3")
end
elseif granboost1 == "rpgup3" and granboost2 == "1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 8 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 8)
file.Write("users/"..igrok:SteamID64().."/level/granboost.txt", "3")
end
elseif granboost1 == "rpgup3" and granboost2 == "2" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 5 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 5)
file.Write("users/"..igrok:SteamID64().."/level/granboost.txt", "3")
end
end

if granboost1 == "rpgup2" and granboost2 == "0" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 4 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 4)
file.Write("users/"..igrok:SteamID64().."/level/granboost.txt", "2")
end
elseif granboost1 == "rpgup2" and granboost2 == "1" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 3 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 3)
file.Write("users/"..igrok:SteamID64().."/level/granboost.txt", "2")
end
end

if granboost1 == "rpgup1" and granboost2 == "0" then
	local ptspl = file.Read("users/"..igrok:SteamID64().."/money/points.txt")
if (ptspl + 0) >= 1 then
file.Write("users/"..igrok:SteamID64().."/money/points.txt", ptspl - 1)
file.Write("users/"..igrok:SteamID64().."/level/granboost.txt", "1")
end
end

end)