if CLIENT then return end

timecodesendmassive = 0

util.AddNetworkString("HUDinfosendclient")
util.AddNetworkString("HUDserversend")
net.Receive("HUDserversend", function()
local playeadm = net.ReadString()
local igrok = net.ReadEntity()
local playerwhoneed = net.ReadEntity()
local function WLHUDsts()
net.Start('HUDinfosendclient')
net.WriteString(file.Read("users/"..playeadm.."/name/name.txt", "data"))
net.WriteString(file.Read("users/"..playeadm.."/number/number.txt", "data"))
net.WriteString(file.Read("users/"..playeadm.."/legion/legion.txt", "data"))
net.WriteString(file.Read("users/"..playeadm.."/rank/rank.txt", "data"))
net.WriteString(file.Read("users/"..playeadm.."/spec/spec.txt", "data"))
net.WriteString(file.Read("users/"..playerwhoneed:SteamID64().."/admin/admin.txt"))
net.WriteEntity(igrok)
net.Send(playerwhoneed)
end
WLHUDsts()
end)

util.AddNetworkString("HUDvoicesendclient")
util.AddNetworkString("HUDvoiceserversend")
net.Receive("HUDvoiceserversend", function()
local playeadm = net.ReadString()
local igrok = net.ReadEntity()
local playerwhoneed = net.ReadEntity()
local function WLHUDst()
net.Start('HUDvoicesendclient')
net.WriteString(file.Read("users/"..playeadm.."/name/name.txt", "data"))
net.WriteString(file.Read("users/"..playeadm.."/legion/legion.txt", "data"))
net.WriteString(file.Read("users/"..playeadm.."/rank/rank.txt", "data"))
net.WriteString(file.Read("users/"..playeadm.."/number/number.txt", "data"))
net.WriteEntity(igrok)
net.Send(playerwhoneed)
end
WLHUDst()
end)

util.AddNetworkString("HUDmyinfog")
util.AddNetworkString("HUDmyservg")
net.Receive("HUDmyservg", function()
local usersend = net.ReadEntity()
local function HUDmysend()
net.Start('HUDmyinfog')
net.WriteString(file.Read("users/"..usersend:SteamID64().."/name/name.txt", "data"))
net.WriteString(file.Read("users/"..usersend:SteamID64().."/number/number.txt", "data"))
net.WriteString(file.Read("users/"..usersend:SteamID64().."/legion/legion.txt", "data"))
net.WriteString(file.Read("users/"..usersend:SteamID64().."/rank/rank.txt", "data"))
net.WriteString(file.Read("users/"..usersend:SteamID64().."/spec/spec.txt", "data"))
net.WriteString(file.Read("users/"..usersend:SteamID64().."/admin/admin.txt", "data"))
net.WriteString( table.getn(allreporters82uas2) )
net.WriteString(file.Read("users/"..usersend:SteamID64().."/radio/radio.txt", "data"))
net.WriteString(file.Read("users/"..usersend:SteamID64().."/radio/radioon.txt", "data"))
net.WriteString(file.Read("server/defc.txt", "data"))
net.WriteString(file.Read("server/prikaz.txt", "data"))
net.WriteString(file.Read("users/"..usersend:SteamID64().."/admin/cloak.txt", "data"))
net.WriteString(file.Read("users/"..usersend:SteamID64().."/radio/interdist.txt", "data"))
net.WriteString(file.Read("users/"..usersend:SteamID64().."/radio/intercom.txt", "data"))
net.WriteString(file.Read("users/"..usersend:SteamID64().."/admin/frozen.txt", "data"))
net.WriteString(file.Read("users/"..usersend:SteamID64().."/level/statminaboost.txt", "data"))
net.Send(usersend)
end
HUDmysend()
end)

util.AddNetworkString("HUDmyinforadio")
util.AddNetworkString("HUDmyservradio")
net.Receive("HUDmyservradio", function()
local user = net.ReadString()
local usersend = net.ReadEntity()
local allply = net.ReadEntity()
local function HUDmysend2()
net.Start('HUDmyinforadio')
net.WriteString(file.Read("users/"..user.."/radio/radio.txt", "data"))
net.WriteString(file.Read("users/"..allply:SteamID64().."/radio/radio.txt", "data"))
net.WriteString(file.Read("users/"..allply:SteamID64().."/name/name.txt", "data"))
net.WriteString(file.Read("users/"..allply:SteamID64().."/number/number.txt", "data"))
net.WriteString(file.Read("users/"..allply:SteamID64().."/legion/legion.txt", "data"))
net.Send(usersend)
end
HUDmysend2()
end)

util.AddNetworkString("changeradiovoiceactivestate263")
net.Receive("changeradiovoiceactivestate263", function()
local user = net.ReadEntity()
local radon = file.Read("users/"..user:SteamID64().."/radio/radioon.txt", "data")
if radon == "on" then
file.Write("users/"..user:SteamID64().."/radio/radioon.txt", "null")
else
file.Write("users/"..user:SteamID64().."/radio/radioon.txt", "on")
end
end)

util.AddNetworkString("HUDESCSENDCLIENT_OS")
util.AddNetworkString("HUDESCSERVERSND")
net.Receive("HUDESCSERVERSND", function()
local playerwhoneed = net.ReadEntity()
local function WLHUDsts()
net.Start('HUDESCSENDCLIENT_OS')
net.WriteString(file.Read("users/"..playerwhoneed:SteamID64().."/name/name.txt", "data"))
net.WriteString(file.Read("users/"..playerwhoneed:SteamID64().."/number/number.txt", "data"))
net.WriteString(file.Read("users/"..playerwhoneed:SteamID64().."/legion/legion.txt", "data"))
net.WriteString(file.Read("users/"..playerwhoneed:SteamID64().."/rank/rank.txt", "data"))
net.WriteString(file.Read("users/"..playerwhoneed:SteamID64().."/spec/spec.txt", "data"))
net.WriteString(file.Read("users/"..playerwhoneed:SteamID64().."/admin/admin.txt"))
net.WriteString(file.Read("users/"..playerwhoneed:SteamID64().."/model/model.txt"))
net.WriteString(file.Read("users/"..playerwhoneed:SteamID64().."/bodygroups/bodygroups.txt"))
net.WriteString(file.Read("users/"..playerwhoneed:SteamID64().."/skin/skin.txt"))
net.Send(playerwhoneed)
end
WLHUDsts()
end)

util.AddNetworkString("defchudsendservergreen")
util.AddNetworkString("defchudsendservergreen_cl")
net.Receive("defchudsendservergreen", function()
local player = net.ReadEntity()
local pladmin = file.Read("users/"..player:SteamID64().."/admin/admin.txt")
local ranks = file.Read("users/"..player:SteamID64().."/rank/rank.txt")
local names = file.Read("users/"..player:SteamID64().."/name/name.txt")
local legions = file.Read("users/"..player:SteamID64().."/legion/legion.txt")
local numbs = file.Read("users/"..player:SteamID64().."/number/number.txt")
if timecodesendmassive < SysTime() then
if (pladmin == "commander" or pladmin == "admin" or pladmin == "highadmin" or pladmin == "owner") then
timecodesendmassive = SysTime() + 25
file.Write("server/defc.txt", "G")
local function f1cmdchecks()
net.Start('defchudsendservergreen_cl')
net.WriteEntity(player)
net.WriteString(legions.." | "..names.." | "..numbs.." | "..ranks)
net.Broadcast()
end
f1cmdchecks()
end
end
end)

util.AddNetworkString("defchudsendserveryellow")
util.AddNetworkString("defchudsendserveryellow_cl")
net.Receive("defchudsendserveryellow", function()
local player = net.ReadEntity()
local pladmin = file.Read("users/"..player:SteamID64().."/admin/admin.txt")
local ranks = file.Read("users/"..player:SteamID64().."/rank/rank.txt")
local names = file.Read("users/"..player:SteamID64().."/name/name.txt")
local legions = file.Read("users/"..player:SteamID64().."/legion/legion.txt")
local numbs = file.Read("users/"..player:SteamID64().."/number/number.txt")
if timecodesendmassive < SysTime() then
if (pladmin == "commander" or pladmin == "admin" or pladmin == "highadmin" or pladmin == "owner") then
timecodesendmassive = SysTime() + 25
file.Write("server/defc.txt", "Y")
local function f1cmdchecks()
net.Start('defchudsendserveryellow_cl')
net.WriteEntity(player)
net.WriteString(legions.." | "..names.." | "..numbs.." | "..ranks)
net.Broadcast()
end
f1cmdchecks()
end
end
end)

util.AddNetworkString("defchudsendserverred")
util.AddNetworkString("defchudsendserverred_cl")
net.Receive("defchudsendserverred", function()
local player = net.ReadEntity()
local pladmin = file.Read("users/"..player:SteamID64().."/admin/admin.txt")
local ranks = file.Read("users/"..player:SteamID64().."/rank/rank.txt")
local names = file.Read("users/"..player:SteamID64().."/name/name.txt")
local legions = file.Read("users/"..player:SteamID64().."/legion/legion.txt")
local numbs = file.Read("users/"..player:SteamID64().."/number/number.txt")
if timecodesendmassive < SysTime() then
if (pladmin == "commander" or pladmin == "admin" or pladmin == "highadmin" or pladmin == "owner") then
timecodesendmassive = SysTime() + 25
file.Write("server/defc.txt", "R")
local function f1cmdchecks()
net.Start('defchudsendserverred_cl')
net.WriteEntity(player)
net.WriteString(legions.." | "..names.." | "..numbs.." | "..ranks)
net.Broadcast()
end
f1cmdchecks()
end
end
end)

util.AddNetworkString("defchudsendserverviolet")
util.AddNetworkString("defchudsendserverviolet_cl")
net.Receive("defchudsendserverviolet", function()
local player = net.ReadEntity()
local pladmin = file.Read("users/"..player:SteamID64().."/admin/admin.txt")
local ranks = file.Read("users/"..player:SteamID64().."/rank/rank.txt")
local names = file.Read("users/"..player:SteamID64().."/name/name.txt")
local legions = file.Read("users/"..player:SteamID64().."/legion/legion.txt")
local numbs = file.Read("users/"..player:SteamID64().."/number/number.txt")
if timecodesendmassive < SysTime() then
if (pladmin == "commander" or pladmin == "admin" or pladmin == "highadmin" or pladmin == "owner") then
timecodesendmassive = SysTime() + 25
file.Write("server/defc.txt", "V")
local function f1cmdchecks()
net.Start('defchudsendserverviolet_cl')
net.WriteEntity(player)
net.WriteString(legions.." | "..names.." | "..numbs.." | "..ranks)
net.Broadcast()
end
f1cmdchecks()
end
end
end)

util.AddNetworkString("defchudsendserverblack")
util.AddNetworkString("defchudsendserverblack_cl")
net.Receive("defchudsendserverblack", function()
local player = net.ReadEntity()
local pladmin = file.Read("users/"..player:SteamID64().."/admin/admin.txt")
local ranks = file.Read("users/"..player:SteamID64().."/rank/rank.txt")
local names = file.Read("users/"..player:SteamID64().."/name/name.txt")
local legions = file.Read("users/"..player:SteamID64().."/legion/legion.txt")
local numbs = file.Read("users/"..player:SteamID64().."/number/number.txt")
if timecodesendmassive < SysTime() then
if (pladmin == "commander" or pladmin == "admin" or pladmin == "highadmin" or pladmin == "owner") then
timecodesendmassive = SysTime() + 25
file.Write("server/defc.txt", "B")
local function f1cmdchecks()
net.Start('defchudsendserverblack_cl')
net.WriteEntity(player)
net.WriteString(legions.." | "..names.." | "..numbs.." | "..ranks)
net.Broadcast()
end
f1cmdchecks()
end
end
end)