if CLIENT then return end
util.AddNetworkString("pointnotifyforplayersda")
timer.Create( "timerlevelallplayers", 300, 0, function ()
for i, v in pairs(player.GetAll()) do
-------------------------------------------------------------------------	
local randomize = math.random( 10, 40 )
local xpdata = file.Read("users/"..v:SteamID64().."/level/xp.txt", "data")
local boost = file.Read("users/"..v:SteamID64().."/level/booster.txt", "data")
local level = file.Read("users/"..v:SteamID64().."/level/level.txt", "data")
local points = file.Read("users/"..v:SteamID64().."/money/points.txt", "data")
local readypoip = xpdata + randomize * boost
if string.Split( game.GetIPAddress(), ":" )[1]..":27016" == game.GetIPAddress() then
readypoip = xpdata + randomize * boost * 2
end
file.Write("users/"..v:SteamID64().."/level/xp.txt", readypoip)

xpdata = file.Read("users/"..v:SteamID64().."/level/xp.txt", "data")
local xpnumb = (xpdata + 0)

if (level == "0") then
if xpnumb >= 120 then
file.Write("users/"..v:SteamID64().."/level/xp.txt", readypoip - 120)
file.Write("users/"..v:SteamID64().."/level/level.txt", level + 1)
file.Write("users/"..v:SteamID64().."/money/points.txt", points + 1)
readypoip = readypoip - 120
end
elseif (level == "1") then
if xpnumb >= 150 then
file.Write("users/"..v:SteamID64().."/level/xp.txt", readypoip - 150)
file.Write("users/"..v:SteamID64().."/level/level.txt", level + 1)
file.Write("users/"..v:SteamID64().."/money/points.txt", points + 1)
readypoip = readypoip - 150
end
elseif (level == "2") then
if xpnumb >= 190 then
file.Write("users/"..v:SteamID64().."/level/xp.txt", readypoip - 190)
file.Write("users/"..v:SteamID64().."/level/level.txt", level + 1)
file.Write("users/"..v:SteamID64().."/money/points.txt", points + 1)
readypoip = readypoip - 190
end
elseif (level == "3") then
if xpnumb >= 240 then
file.Write("users/"..v:SteamID64().."/level/xp.txt", readypoip - 240)
file.Write("users/"..v:SteamID64().."/level/level.txt", level + 1)
file.Write("users/"..v:SteamID64().."/money/points.txt", points + 1)
readypoip = readypoip - 240
end
elseif (level == "4") then
if xpnumb >= 300 then
file.Write("users/"..v:SteamID64().."/level/xp.txt", readypoip - 300)
file.Write("users/"..v:SteamID64().."/level/level.txt", level + 1)
file.Write("users/"..v:SteamID64().."/money/points.txt", points + 1)
readypoip = readypoip - 300
end
elseif (level == "5") then
if xpnumb >= 400 then
file.Write("users/"..v:SteamID64().."/level/xp.txt", readypoip - 400)
file.Write("users/"..v:SteamID64().."/level/level.txt", level + 1)
file.Write("users/"..v:SteamID64().."/money/points.txt", points + 1)
readypoip = readypoip - 400
end
elseif (level == "6") then
if xpnumb >= 500 then
file.Write("users/"..v:SteamID64().."/level/xp.txt", readypoip - 500)
file.Write("users/"..v:SteamID64().."/level/level.txt", level + 1)
file.Write("users/"..v:SteamID64().."/money/points.txt", points + 1)
readypoip = readypoip - 500
end
elseif (level == "7") then
if xpnumb >= 600 then
file.Write("users/"..v:SteamID64().."/level/xp.txt", readypoip - 600)
file.Write("users/"..v:SteamID64().."/level/level.txt", level + 1)
file.Write("users/"..v:SteamID64().."/money/points.txt", points + 1)
readypoip = readypoip - 600
end
elseif (level == "8") then
if xpnumb >= 700 then
file.Write("users/"..v:SteamID64().."/level/xp.txt", readypoip - 700)
file.Write("users/"..v:SteamID64().."/level/level.txt", level + 1)
file.Write("users/"..v:SteamID64().."/money/points.txt", points + 1)
readypoip = readypoip - 700
end
elseif (level == "9") then
if xpnumb >= 800 then
file.Write("users/"..v:SteamID64().."/level/xp.txt", readypoip - 800)
file.Write("users/"..v:SteamID64().."/level/level.txt", level + 1)
file.Write("users/"..v:SteamID64().."/money/points.txt", points + 1)
readypoip = readypoip - 800
end
elseif (level == "10") then
if xpnumb >= 1000 then
file.Write("users/"..v:SteamID64().."/level/xp.txt", readypoip - 1000)
file.Write("users/"..v:SteamID64().."/level/level.txt", level + 1)
file.Write("users/"..v:SteamID64().."/money/points.txt", points + 1)
readypoip = readypoip - 1000
end
else
if xpnumb >= 1000 then
file.Write("users/"..v:SteamID64().."/level/xp.txt", readypoip - 1000)
file.Write("users/"..v:SteamID64().."/level/level.txt", level + 1)
file.Write("users/"..v:SteamID64().."/money/points.txt", points + 1)
readypoip = readypoip - 1000
end
end

local levelafter = file.Read("users/"..v:SteamID64().."/level/level.txt", "data")
local textlevel = "null"
if (level + 0) < (levelafter + 0) then
textlevel = "+LevelUP - "..levelafter
end
local function pointsnotifyc()
net.Start("pointnotifyforplayersda")
net.WriteString("+"..randomize.." XP, у вас сейчас: "..readypoip.." XP")
net.WriteString(textlevel)
net.Send(v)
end
pointsnotifyc()
-------------------------------------------------------------------------	
end
end)