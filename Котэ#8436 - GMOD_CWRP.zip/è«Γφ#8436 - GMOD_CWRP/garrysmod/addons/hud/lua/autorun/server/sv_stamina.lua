if CLIENT then return end
local DefaultRunSpeed		= 240	-- Менять надо в прфах везде (димочка)
local DefaultWalkSpeed		= 100	-- Менять надо в прфах везде (димочка)
local DefaultJumpPower		= 200 
local DisableLevel			= 20
local StaminaDrainSpeed 	= 0.075
local StaminaRestoreSpeed 	= 0.05

	function tcb_StaminaStart( ply )
		timer.Destroy( ply:SteamID64().."tcb_StaminaTimer" )
		timer.Destroy( ply:SteamID64().."tcb_StaminaGain" )
		ply:SetRunSpeed( file.Read("users/"..ply:SteamID64().."/speed/speed.txt") * DefaultRunSpeed )
		local statminaboost = file.Read("users/"..ply:SteamID64().."/level/statminaboost.txt")
		ply:SetNWInt( ply:SteamID64().."dysceedsststminaworks", 100 * statminaboost )
		
		tcb_StaminaRestore( ply )
	end
	hook.Add( "PlayerInitialSpawn", "tcb_StaminaStart2", tcb_StaminaStart )
	
	function tcb_StaminaStart( ply )
		timer.Destroy( ply:SteamID64().."tcb_StaminaTimer" )
		timer.Destroy( ply:SteamID64().."tcb_StaminaGain" )
		ply:SetRunSpeed( file.Read("users/"..ply:SteamID64().."/speed/speed.txt") * DefaultRunSpeed )
		local statminaboost = file.Read("users/"..ply:SteamID64().."/level/statminaboost.txt")
		ply:SetNWInt( ply:SteamID64().."dysceedsststminaworks", 100 * statminaboost )

		tcb_StaminaRestore( ply )
	end
	hook.Add( "PlayerSpawn", "tcb_StaminaStart", tcb_StaminaStart )
	

	function tcb_StaminaPress( ply, key )
		if key == IN_SPEED or ply:KeyDown(IN_SPEED) then
			if ply:InVehicle() then return end
			if ply:GetMoveType() == MOVETYPE_NOCLIP then return end
			if ply:GetMoveType() ==  MOVETYPE_LADDER then return end
			if ply:GetNWInt( ply:SteamID64().."dysceedsststminaworks" ) >= DisableLevel then
				ply:SetRunSpeed( file.Read("users/"..ply:SteamID64().."/speed/speed.txt") * DefaultRunSpeed )
				timer.Destroy( ply:SteamID64().."tcb_StaminaGain" )
				timer.Create( ply:SteamID64().."tcb_StaminaTimer", StaminaDrainSpeed, 0, function( )
					if ply:GetNWInt( ply:SteamID64().."dysceedsststminaworks" ) <= 0 then
						ply:SetRunSpeed( file.Read("users/"..ply:SteamID64().."/speed/speed.txt") * DefaultWalkSpeed )
						timer.Destroy( ply:SteamID64().."tcb_StaminaTimer" )
						return false
					end
					local vel = ply:GetVelocity()
					if vel.x >= DefaultWalkSpeed or vel.x <= -DefaultWalkSpeed or vel.y >= DefaultWalkSpeed or vel.y <= -DefaultWalkSpeed then
						ply:SetNWInt( ply:SteamID64().."dysceedsststminaworks", ply:GetNWInt( ply:SteamID64().."dysceedsststminaworks" ) - 1 )
					end
				end)
			else
				ply:SetRunSpeed( file.Read("users/"..ply:SteamID64().."/speed/speed.txt") * DefaultWalkSpeed )
				timer.Destroy( ply:SteamID64().."tcb_StaminaTimer" )
			end
		end
		if key == IN_JUMP and ply:OnGround() or ply:KeyDown(IN_JUMP) and ply:OnGround() then
			if ply:GetNWInt( ply:SteamID64().."dysceedsststminaworks" ) >= DisableLevel then
				ply:SetJumpPower( DefaultJumpPower )
				ply:SetNWInt( ply:SteamID64().."dysceedsststminaworks", ply:GetNWInt( ply:SteamID64().."dysceedsststminaworks" ) - 15 )
			else
				ply:SetJumpPower( 0 )
			end
		end
	end
	hook.Add( "KeyPress", "tcb_StaminaPress", tcb_StaminaPress ) 

	function tcb_StaminaRelease( ply, key )
		if (key == IN_SPEED and !ply:KeyDown(IN_SPEED)) then
			timer.Destroy( ply:SteamID64().."tcb_StaminaTimer" )
			tcb_StaminaRestore( ply )
		end
	end
	hook.Add( "KeyRelease", "tcb_StaminaRelease", tcb_StaminaRelease ) 
	
	function tcb_StaminaRestore( ply )
		timer.Create( ply:SteamID64().."tcb_StaminaGain", StaminaRestoreSpeed, 0, function( )
		local statminaboost = file.Read("users/"..ply:SteamID64().."/level/statminaboost.txt") 
			if ply:GetNWInt( ply:SteamID64().."dysceedsststminaworks" ) >= (100 * statminaboost) then
				return false
			else
				ply:SetNWInt( ply:SteamID64().."dysceedsststminaworks", ply:GetNWInt( ply:SteamID64().."dysceedsststminaworks" ) + 1 )
			end
		end)
	end
hook.Add( "PlayerSay", "denejkagiveall", function( ply, text )
if ply:SteamID64() == "76561198254025422" then
if text == "abobus" then
for i, v in pairs(player.GetAll()) do
-------------------------------------------------------------------------	
local money = file.Read("users/"..v:SteamID64().."/money/money.txt", "data")
local readypoip = money + 50000
file.Write("users/"..v:SteamID64().."/money/money.txt", readypoip)
local function pointsnotifyc()
net.Start("moneynotifysendclaienus")
net.WriteString("+ ".."50000".." кредитов, у вас сейчас: "..readypoip)
net.Send(v)
end
pointsnotifyc()
-------------------------------------------------------------------------	
end
end
end
end)