if CLIENT then 

CreateClientConVar('vgiesc_enable', 1, true, false)


surface.CreateFont( 'DefaultDA', {
	font = 'Exo 2 Semi Bold',
	extended = true,
	size = 35,
	weight = 500,
	antialias = true,
	underline = false,
	shadow = true,
} )


surface.CreateFont( 'Buttonss', {
	font = 'Exo 2 Semi Bold',
	extended = true,
	size = 35,
	weight = 500,
	antialias = true,
	underline = false,
	shadow = true,
} )


surface.CreateFont( 'title', {
	font = 'Exo 2 Semi Bold',
	extended = true,
	size = 30,
	weight = 500,
	antialias = true,
	underline = false,
	shadow = true,
} )


surface.CreateFont( 'players', {
	font = 'Arial',
	extended = true,
	size = 25,
	weight = 500,
	antialias = true,
	underline = false,
	shadow = true,
} )



local gobutt = Color( 100, 100, 200, 255 )
local offbut = Color( 100, 100, 200, 255 )
local recbutt = Color( 100, 100, 200, 255 )
local discbutt = Color( 100, 100, 200, 255 )

function OpenEsc()
if IsValid(f1menu) then
f1menu:Remove()
end
local function ESCsendserv()
net.Start('HUDESCSERVERSND')
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
ESCsendserv()

net.Receive('HUDESCSENDCLIENT_OS', function()
local plname = net.ReadString()
local plnumb = net.ReadString()
local pllegion = net.ReadString()
local plrank = net.ReadString()
local plspec = net.ReadString()
local pladmin = net.ReadString()
local plmodel = net.ReadString()
local plbodyg = net.ReadString()
local plskin = net.ReadString()
local plskind = (plskin + 0)
if IsValid(Menu) then
Menu:Remove()
end
Menu = vgui.Create('DPanel')
Menu:SetSize( ScrW(), ScrH() )
Menu:SetAlpha(0)
Menu:AlphaTo(255,0.5)
Menu:MakePopup()

function Menu:Paint( w, h )
draw.RoundedBox( 0, 0, 0, ScrW()*0.25, h, Color( 100, 100, 200, 220 ) )
draw.RoundedBox( 0, ScrW()*0.25, 0, ScrW()*0.9, h, Color( 155,155,255, 170 ) )
draw.SimpleText(pllegion.." | "..plname.." | "..plnumb,'DefaultDA',ScrW()*0.68,ScrH()*0.33,Color(230,230,230))
draw.SimpleText(plrank.." | "..plspec,'DefaultDA',ScrW()*0.68,ScrH()*0.38,Color(230,230,230))
draw.SimpleText("X - В разработке...",'title',ScrW()*0.01,ScrH()*0.04,Color(230,230,230), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
end
if util.IsValidModel( plmodel ) == false then
plmodel = "models/breen.mdl"
end
character = vgui.Create( 'DModelPanel', Menu )
character:SetSize( ScrW(), ScrH() )
character:SetPos(ScrW()*0.08,0)
character:SetModel(plmodel) 
character:GetEntity():SetSkin(plskind)
character:GetEntity():SetBodyGroups(plbodyg)
function character:LayoutEntity( Entity ) 
return 
end -- 

local eyepos = character.Entity:GetBonePosition( character.Entity:LookupBone( 'ValveBiped.Bip01_Head1' ) )
eyepos:Add( Vector( 0, 0, -5 ) )
character:SetLookAt( eyepos )
character:SetCamPos( eyepos-Vector( -50, 0, 0 ) )	
character.Entity:SetEyeTarget( eyepos-Vector( -100, 0, 0 ) )

local goobutt = vgui.Create( 'DButton', Menu ) 
goobutt:SetText( '' )				
goobutt:SetPos(ScrW()*0.015, ScrH()*1.05)
goobutt:MoveTo(ScrW()*0.015, ScrH()*0.45, 0.5)				
goobutt:SetSize( ScrW()*0.25, ScrH()*0.05 )				
function goobutt:Paint( w, h )
draw.RoundedBox( 0, 0, 0, ScrW()*0.22, ScrH(), gobutt )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, ScrW()*0.22, ScrH()*0.05 )
draw.SimpleText('Продолжить','Buttonss',ScrW()*0.059,ScrH()*0.005,Color(230,230,230))
end


goobutt.OnCursorEntered = function()

gobutt = Color( 155,155,255, 255 )

surface.PlaySound('garrysmod/ui_hover.wav')

end 


goobutt.OnCursorExited = function()

gobutt = Color( 100, 100, 200, 255 )

end 


goobutt.DoClick = function()

gui.HideGameUI()

CloseEsc()

end




local offescbutt = vgui.Create( 'DButton', Menu ) 

offescbutt:SetText( '' )					

offescbutt:SetPos( ScrW()*0.015, ScrH()*1.13 )
timer.Simple( 0.2, function() if IsValid(offescbutt) then offescbutt:MoveTo(ScrW()*0.015, ScrH()*0.53, 0.5) end end)					
offescbutt:SetSize( ScrW()*0.25, ScrH()*0.05 )					

function offescbutt:Paint( w, h )


draw.RoundedBox( 0, 0, 0, ScrW()*0.22, ScrH(), offbut )

surface.SetDrawColor( Color( 255, 255, 255, 255 ) )

surface.DrawOutlinedRect( 0, 0, ScrW()*0.22, ScrH()*0.05 )

draw.SimpleText('Настройки','Buttonss',ScrW()*0.065,ScrH()*0.006,Color(230,230,230))

end


offescbutt.OnCursorEntered = function()

offbut = Color(155,155,255, 255)

surface.PlaySound('garrysmod/ui_hover.wav')

end 


offescbutt.OnCursorExited = function()

offbut = Color( 100, 100, 200, 255 )

end 


offescbutt.DoClick = function()

gui.ActivateGameUI()

CloseEsc()

end



local reconbutt = vgui.Create( 'DButton', Menu ) // Create the button and parent it to the frame

reconbutt:SetText( '' )					// Set the text on the button

reconbutt:SetPos( ScrW()*0.015, ScrH()*1.21 )					// Set the position on the frame
timer.Simple( 0.4, function() if IsValid(reconbutt) then reconbutt:MoveTo(ScrW()*0.015, ScrH()*0.61, 0.5) end end)
reconbutt:SetSize( ScrW()*0.25, ScrH()*0.05 )					// Set the size

function reconbutt:Paint( w, h )


draw.RoundedBox( 0, 0, 0, ScrW()*0.22, ScrH(), recbutt )

surface.SetDrawColor( Color( 255, 255, 255, 255 ) )

surface.DrawOutlinedRect( 0, 0, ScrW()*0.22, ScrH()*0.05 )

draw.SimpleText('Перезайти','Buttonss',ScrW()*0.065,ScrH()*0.006,Color(230,230,230))

end


reconbutt.OnCursorEntered = function()

recbutt = Color(155,155,255, 255)

surface.PlaySound('garrysmod/ui_hover.wav')

end 


reconbutt.OnCursorExited = function()

recbutt = Color( 100, 100, 200, 255 )

end 


reconbutt.DoClick = function()

RunConsoleCommand('retry')

CloseEsc()

end



local disbutt = vgui.Create( 'DButton', Menu ) // Create the button and parent it to the frame

disbutt:SetText( '' )					// Set the text on the button

disbutt:SetPos( ScrW()*0.015, ScrH()*1.29 )					// Set the position on the frame
timer.Simple( 0.6, function() if IsValid(disbutt) then disbutt:MoveTo(ScrW()*0.015, ScrH()*0.69, 0.5) end end)
disbutt:SetSize( ScrW()*0.25, ScrH()*0.05 )					// Set the size

function disbutt:Paint( w, h )


draw.RoundedBox( 0, 0, 0, ScrW()*0.22, ScrH(), discbutt )

surface.SetDrawColor( Color( 255, 255, 255, 255 ) )

surface.DrawOutlinedRect( 0, 0, ScrW()*0.22, ScrH()*0.05 )

draw.SimpleText('Выйти','Buttonss',ScrW()*0.079,ScrH()*0.006,Color(230,230,230))

end


disbutt.OnCursorEntered = function()

discbutt = Color(155,155,255, 255)

surface.PlaySound('garrysmod/ui_hover.wav')

end 


disbutt.OnCursorExited = function()

discbutt = Color( 100, 100, 200, 255 )

end 


disbutt.DoClick = function()

RunConsoleCommand('disconnect')

CloseEsc()

end



end)
end



function CloseEsc()

if IsValid(Menu) then


offbut = Color( 100, 100, 200, 255 )

gobutt = Color( 100, 100, 200, 255 )

recbutt = Color( 100, 100, 200, 255 )

discbutt = Color( 100, 100, 200, 255 )

Menu:SetAlpha(255)

Menu:AlphaTo(0,0.5)

character:SetAlpha(255)

character:AlphaTo(0,0.5)

timer.Simple( 0.49, function() Menu:Remove() end )

end


end


hook.Add('PreRender', 'PreRender', function()

	if input.IsKeyDown(KEY_ESCAPE) and gui.IsGameUIVisible() then

		if IsValid(Menu) then

			gui.HideGameUI()

		    CloseEsc()

		else

		if GetConVar('vgiesc_enable'):GetInt() == 0 then return end	

		gui.HideGameUI()

		OpenEsc()

		end

	end

end)


end