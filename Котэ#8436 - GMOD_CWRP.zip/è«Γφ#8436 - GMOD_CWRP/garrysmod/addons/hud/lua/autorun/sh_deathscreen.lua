local function respawntime(pl)
	return 1
end



if CLIENT then

	-- local pp_params = {}
	-- pp_params["$pp_colour_addr"] = 0
	-- pp_params["$pp_colour_addg"] = 0
	-- pp_params["$pp_colour_addb"] = 0

	-- pp_params["$pp_colour_brightness"] = 1
	-- pp_params["$pp_colour_contrast"] = 0.3
	-- pp_params["$pp_colour_colour"] = 1

	-- pp_params["$pp_colour_mulr"] = 0
	-- pp_params["$pp_colour_mulg"] = 0
	-- pp_params["$pp_colour_mulb"] = 0


	-- hook.Add("RenderScreenspaceEffects", "RespawnTimer", function()
	-- 	-- if LocalPlayer():Alive() then
	-- 	-- 	pp_params["$pp_colour_colour"] = 1
	-- 	-- 	pp_params["$pp_colour_brightness"] = 1
	-- 	-- else
	-- 	-- 	DrawColorModify(pp_params)
	-- 	-- 	pp_params["$pp_colour_colour"] = Lerp(FrameTime(), pp_params["$pp_colour_colour"], 0.2)
	-- 	-- 	pp_params["$pp_colour_brightness"] = Lerp(FrameTime(), pp_params["$pp_colour_brightness"], 0)
	-- 	-- end
	-- end)

    local alpha_lerp, alpha = 0, 0
	net.Receive("RespawnTimer", function()
		if net.ReadBool() then
			local dead = RealTime()
            -- PrintTable(net.ReadTable() or {})
            local dmginfo = net.ReadTable() or {}

            alpha = 160
            local markup_string = ''

            if dmginfo then
                for i, case in pairs(dmginfo) do
                    markup_string = markup_string..'<font=InfoHP>'..case.att_color..tostring(case.attacker)..'</colour> нанёс вам <colour=214, 45, 32, 255>'..tostring( math.Round(case.damage) )..'</colour> урона </font>\n'
                end
            end

            local parsed = markup.Parse( markup_string )

			hook.Add("HUDPaint", "RespawnTimer", function()
				local time = math.Round(respawntime() - RealTime() + dead, 2)
                alpha_lerp = Lerp(FrameTime()*6,alpha_lerp or 0,alpha or 0) or 0

                local w, h = ScrW(), ScrH()

                draw.RoundedBox(0,0,0,w,h,Color(52, 73, 94, alpha_lerp))

                parsed:Draw( 30, 60, 0, 0 )

                local h = parsed:GetHeight()
				draw.SimpleText(('Вот ты и погиб...'), "InfoHP", 30, 70+h, color_white, 0, 0)

				if time > 0 then
					draw.SimpleText('До возрождения '..time..' секунд', "InfoHP", ScrW()*0.45, ScrH()*0.9, color_white, TEXT_ALIGN_LEFT, 0)
				else
					draw.SimpleText('Нажмите любую кнопку для возрождения', "InfoHP", ScrW()*0.5, ScrH()*0.9, color_white, TEXT_ALIGN_CENTER, 0)
				end
			end)



			hook.Add("Think", "RespawnTimerMusic", function()
				if (RealTime() - dead) < 1 then return end

				hook.Remove("Think", "RespawnTimerMusic")

				if LocalPlayer():Alive() then return end
				if not system.HasFocus() then return end
			end)
			system.FlashWindow()
		else
			hook.Remove("HUDPaint", "RespawnTimer")
		end

	end)

	hook.Add("CalcView", "FirstPersonDeath", function(pPlayer, pos, ang, fov, nearz, farz)
		if (pPlayer:Alive() or !IsValid(pPlayer.eRagdoll)) then return end

		local rag = pPlayer.eRagdoll
		local eyeattach = rag:LookupAttachment('eyes')

		if (!eyeattach) then return end
		local eyes = rag:GetAttachment(eyeattach)

		if (!eyes) then return end
		return {origin = eyes.Pos, angles = eyes.Ang, fov = fov}
	end)
end
