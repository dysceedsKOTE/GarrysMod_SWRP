if SERVER then return end
net.Receive("pointnotifyforplayersda", function()
local text = net.ReadString()
local leveltext = net.ReadString()
notification.AddLegacy( text, 0, 10 )
if leveltext != "null" then
notification.AddLegacy( leveltext, 0, 10 )
end
end)

net.Receive("moneynotifysendclaienus", function()
local text = net.ReadString()
local leveltext = net.ReadString()
notification.AddLegacy( text, 0, 10 )
end)