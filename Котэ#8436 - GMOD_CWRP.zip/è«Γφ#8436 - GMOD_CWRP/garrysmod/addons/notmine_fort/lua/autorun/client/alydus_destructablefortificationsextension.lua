// Destructable Fortifications Extension by Alydus

// If you'd like to modify this, go ahead, but please leave appropriate credit.
// Please do not reupload this code to the workshop, as it creates a multitude of problems - however, you can download it from the workshop and install it on your server to modify.
// Additionally, note that this addon will not function if the fortification builder tablet is not installed.

alydusDestructableFortificationExtension = true