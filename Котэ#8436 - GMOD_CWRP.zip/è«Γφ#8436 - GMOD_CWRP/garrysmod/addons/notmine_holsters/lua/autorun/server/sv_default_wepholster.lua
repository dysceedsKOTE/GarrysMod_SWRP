if CLIENT then return end
--[[
   __  ___        __      __                                
  /  |/  /__ ____/ /__   / /  __ __                         
 / /|_/ / _ `/ _  / -_) / _ \/ // /                         
/_/  /_/\_,_/\_,_/\__/ /_.__/\_, /                          
   ___       __             /___/         ___           __  
  / _ \___  / /_ _____ ___ / /____ ____  / _ \__ ______/ /__
 / ___/ _ \/ / // / -_|_-</ __/ -_) __/ / // / // / __/  '_/
/_/   \___/_/\_, /\__/___/\__/\__/_/   /____/\_,_/\__/_/\_\ 
            /___/                                           
https://steamcommunity.com/profiles/76561198057599363
]]
WepHolster.defData = {}
----------------------------------------------------------------
----------------------------------------------------------------
-- Half-Life 2 Weapons
----------------------------------------------------------------
WepHolster.defData["rw_sw_dc17"] = {}
WepHolster.defData["rw_sw_dc17"].Model = "models/sw_battlefront/weapons/dc17_blaster.mdl"
WepHolster.defData["rw_sw_dc17"].Bone = "ValveBiped.Bip01_Pelvis"
WepHolster.defData["rw_sw_dc17"].BoneOffset = {Vector(-4, -8, -0.6), Angle(-90, -90, -65)}
----------------------------------------------------------------
WepHolster.defData["rw_sw_z6"] = {}
WepHolster.defData["rw_sw_z6"].Model = "models/sw_battlefront/weapons/z6_rotary_cannon.mdl"
WepHolster.defData["rw_sw_z6"].Bone = "ValveBiped.Bip01_Spine2"
WepHolster.defData["rw_sw_z6"].BoneOffset = {Vector(4.6, -20, 9), Angle(90, 0, 0)}
----------------------------------------------------------------
WepHolster.defData["rw_sw_rps6"] = {}
WepHolster.defData["rw_sw_rps6"].Model = "models/rps6/zl_rps-6.mdl"
WepHolster.defData["rw_sw_rps6"].Bone = "ValveBiped.Bip01_Spine2"
WepHolster.defData["rw_sw_rps6"].BoneOffset = {Vector(4.6, -1.6, -7.6), Angle(90, 0, 0)}
----------------------------------------------------------------
WepHolster.defData["rw_sw_dc15a"] = {}
WepHolster.defData["rw_sw_dc15a"].Model = "models/sw_battlefront/weapons/dc15a_rifle.mdl"
WepHolster.defData["rw_sw_dc15a"].Bone = "ValveBiped.Bip01_Spine2"
WepHolster.defData["rw_sw_dc15a"].BoneOffset = {Vector(2.4, -3, -7.844), Angle(0, 0, 0)}
----------------------------------------------------------------
WepHolster.defData["rw_sw_dc15x"] = {}
WepHolster.defData["rw_sw_dc15x"].Model = "models/sw_battlefront/weapons/dc15a_rifle.mdl"
WepHolster.defData["rw_sw_dc15x"].Bone = "ValveBiped.Bip01_Spine2"
WepHolster.defData["rw_sw_dc15x"].BoneOffset = {Vector(2.4, -3, -7.844), Angle(0, 0, 0)}
----------------------------------------------------------------
WepHolster.defData["rw_sw_dc15s"] = {}
WepHolster.defData["rw_sw_dc15s"].Model = "models/sw_battlefront/weapons/dc15s_carbine.mdl"
WepHolster.defData["rw_sw_dc15s"].Bone = "ValveBiped.Bip01_Pelvis"
WepHolster.defData["rw_sw_dc15s"].BoneOffset = {Vector(0, 5.6, -6), Angle(90, 0, 180)}
----------------------------------------------------------------
WepHolster.defData["rw_sw_valken38x"] = {}
WepHolster.defData["rw_sw_valken38x"].Model = "models/sw_battlefront/weapons/valken_38x.mdl"
WepHolster.defData["rw_sw_valken38x"].Bone = "ValveBiped.Bip01_Spine2"
WepHolster.defData["rw_sw_valken38x"].BoneOffset = {Vector(5.4, -1.8, -1.5), Angle(-180, 0, -45)}