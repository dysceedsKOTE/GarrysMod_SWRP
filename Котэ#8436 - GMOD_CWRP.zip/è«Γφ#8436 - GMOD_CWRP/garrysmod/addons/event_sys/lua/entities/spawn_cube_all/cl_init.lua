include('shared.lua')

function ENT:Draw()
	self:DrawModel()
	
end

surface.CreateFont( 'buttonammo', {
	font = 'Exo 2 Semi Bold',
	extended = true,
	size = 30,
	weight = 500,
	antialias = true,
	underline = false,
	shadow = true,
} )

local function Draw3DText( pos, ang, scale, text, flipView )
	if ( flipView ) then
		-- Flip the angle 180 degrees around the UP axis
		ang:RotateAroundAxis( Vector( 0, 0, 1 ), 180 )
	end

	cam.Start3D2D( pos, ang, scale )
		-- Actually draw the text. Customize this to your liking.
		draw.DrawText( text, "InfoHP", 0, 0, Color( 100, 100, 200, 255 ), TEXT_ALIGN_CENTER )
	cam.End3D2D()
end