ENT.Base = "base_gmodentity"
ENT.Type = "anim"

ENT.PrintName = "Спаункуб глобальный"
ENT.Author = "dysceeds"
ENT.Category = "X - CWRP"

ENT.Spawnable = true
ENT.AdminOnly = true