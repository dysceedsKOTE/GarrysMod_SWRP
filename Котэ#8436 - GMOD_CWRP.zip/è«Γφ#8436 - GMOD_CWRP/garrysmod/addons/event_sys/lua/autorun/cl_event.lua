if SERVER then return end

hook.Add( "PlayerBindPress", "PlayerBindPressExample2", function( ply, bind, pressed, bcode )
if (bcode == 93) then
return true
end
end)

hook.Add( "PlayerButtonDown", "pLAYER_F2menu", function( ply, button )
----
if ( IsFirstTimePredicted() ) then
--++
if button == 93 then
-------------------------------------------------------------------+++++++++++++++++----------------------------------------------------------------------------------
local function toserverf1menu()
net.Start('homebutt_f2menu_server')
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
toserverf1menu()
net.Receive("homebutt_f2menu", function()
local name = net.ReadString()
local number = net.ReadString()
local legion = net.ReadString()
local rank = net.ReadString()
local spec = net.ReadString()
local admin = net.ReadString()
local model = net.ReadString()
local skin = net.ReadString()
local bodygroups = net.ReadString()
local warns = net.ReadString()
local maps = net.ReadTable()
if ((admin == "owner") or (admin == "highadmin") or (admin == "admin")) then
-------------------------------------------------------- NET


f1menu = vgui.Create( "DFrame" ) 	
f1menu:SetPos(ScrW()*0.2, ScrH()*0.1)			
f1menu:SetSize(ScrW()*0.6, ScrH()*0.6) 				
f1menu:SetTitle( "" )
f1menu:SetAlpha(0)
f1menu:AlphaTo(255,0.25)
f1menu:MoveTo(ScrW()*0.2, ScrH()*0.2, 0.2) 		
f1menu:MakePopup() 
function f1menu:Paint( w, h )
draw.RoundedBox( 0, w*0.2, 0, w*0.8, h, Color( 100, 100, 200, 220 ) )
draw.RoundedBox( 0, 0, 0, w*0.2, h, Color( 155,155,255, 170 ) )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( w*0.2, 0, w*0.8, h )
surface.DrawOutlinedRect( 0, 0, w*0.2, h )
end




local homebut = vgui.Create( 'DButton', f1menu ) 
homebut:SetText( '' )				
homebut:SetPos( ScrW()*-0.1, 0 )			
homebut:SetSize( ScrW()*0.12, ScrH()*0.05 )	
homebut:SetAlpha(0)		
function homebut:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, homebutc )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText('Основное','menubutfontf1',w*0.05,h*0.2,Color(230,230,230), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
end
homebut.OnCursorEntered = function()
homebutc = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
homebut.OnCursorExited = function()
if IsValid( textfadepanel ) then return end;
homebutc = Color( 100, 100, 200, 255 )
end 
homebut.DoClick = function()
--++---------------------------------------------------------------------------------------------------------------
if IsValid( textfadepanel ) then 
textfadepanel:Remove()
mapselector:Remove()
end
if IsValid(mapselectionframe) then
mapselectionframe:Remove()
end
textfadepanel = vgui.Create( "DPanel", f1menu ) 	
textfadepanel:SetPos(0, 0)			
textfadepanel:SetSize(ScrW(), ScrH()) 				
textfadepanel:SetAlpha(0)
textfadepanel:SetMouseInputEnabled( false )	
function textfadepanel:Paint( w, h )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
end

mapselector = vgui.Create( "DListView", f1menu )
mapselector:SetPos(ScrW()*0.125, ScrH()*0.01)			
mapselector:SetSize(ScrW()*0.1, ScrH()*0.2) 
mapselector:SetMultiSelect( false ) 
mapselector:SetAlpha(0)
mapselector:AlphaTo(255,0.5)
mapselector:AddColumn( "Карты" )
for i, v in ipairs( maps ) do
mapselector:AddLine( string.gsub(v, ".bsp", "") )
end
mapselector.OnRowSelected = function( lst, index, pnl )
if IsValid(mapselectionframe) then
mapselectionframe:Remove()
end
mapselectionframe = vgui.Create( "DFrame" )
mapselectionframe:SetSize( 400, 200 )
mapselectionframe:Center()
mapselectionframe:MakePopup()
mapselectionframe:SetTitle("Сменить карту на "..pnl:GetColumnText( 1 ))
local DermaButton = vgui.Create( "DButton", mapselectionframe )
DermaButton:SetText( "Подтвердить" )                  
DermaButton:SetPos( 67, 100 )                   
DermaButton:SetSize( 250, 30 )                  
DermaButton.DoClick = function()
local function sendchangemap()
net.Start("f2menu_event_changemap")
net.WriteEntity(LocalPlayer())
net.WriteString(pnl:GetColumnText( 1 ))
net.SendToServer()
end
sendchangemap()
end
end

if string.Split( game.GetIPAddress(), ":" )[1]..":27015" != game.GetIPAddress() then
local kakabat = Color(100,100,200,255)
buttonvenatorreturn = vgui.Create( "DButton", f1menu ) 
buttonvenatorreturn:SetText( " " )					
buttonvenatorreturn:SetPos( ScrW()*0.25,ScrH()*0.01 )					
buttonvenatorreturn:SetSize( ScrW()*0.15,ScrH()*0.04 )
buttonvenatorreturn:SetAlpha(0)
buttonvenatorreturn:AlphaTo(255,0.75)
function buttonvenatorreturn:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, kakabat )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText('НА ВЕНАТОР','menubutfontf1',w*0.49,h*0.125,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end
buttonvenatorreturn.OnCursorEntered = function()
kakabat = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
buttonvenatorreturn.OnCursorExited = function()
kakabat = Color( 100, 100, 200, 255 )
end
buttonvenatorreturn.DoClick = function()
local function venatorgo()
net.Start("f2menu_event_venator")
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
venatorgo()
end
end

textfadepanel:AlphaTo(255,0.5)
--++----------------------------------------------------------------------------------------------------------------
end
homebut.DoClick()
homebutc = Color(155,155,255, 255)
timer.Simple( 0.1, function() homebut:AlphaTo(255,0.25) homebut:MoveTo(ScrW()*0, ScrH()*0, 0.2) end)





-------------------------------------------------------- NET
end
end)
-------------------------------------------------------------------+++++++++++++++++----------------------------------------------------------------------------------
end
--++
end
----
end)