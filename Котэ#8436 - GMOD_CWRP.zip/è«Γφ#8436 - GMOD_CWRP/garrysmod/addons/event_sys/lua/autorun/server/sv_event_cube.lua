if CLIENT then return end
util.AddNetworkString("eventcube1_send_client")
util.AddNetworkString("sendtoserver_cube_nuber1")

util.AddNetworkString("sendtoserver_cube_nuber1_on")
util.AddNetworkString("sendtoserver_cube_nuber1_off")

net.Receive("sendtoserver_cube_nuber1_on", function()
local player = net.ReadEntity()
local admin = file.Read("users/"..player:SteamID64().."/admin/admin.txt", "data")
if admin == "admin" or admin == "highadmin" or admin == "owner" then
file.Write("event/server1.txt", "open")
end
end)

net.Receive("sendtoserver_cube_nuber1_off", function()
local player = net.ReadEntity()
local admin = file.Read("users/"..player:SteamID64().."/admin/admin.txt", "data")
if admin == "admin" or admin == "highadmin" or admin == "owner" then
file.Write("event/server1.txt", "close")
end
end)