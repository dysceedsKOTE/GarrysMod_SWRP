if CLIENT then return end

if string.Split( game.GetIPAddress(), ":" )[1]..":27016" == game.GetIPAddress() then
hook.Add( "PlayerAuthed", "eventserverauthed_hook1", function( ply, steamid, uniqueid )
if file.Read("event/server1.txt") == "close" then
-----------
if not file.Exists( "users/"..ply:SteamID64().."/admin/admin.txt", "data" ) then return ply:Kick("Это ивентовый сервер, отправляйтесь на базу. Ивент сейчас не проводится") end
if file.Read("users/"..ply:SteamID64().."/admin/admin.txt") == "admin" or file.Read("users/"..ply:SteamID64().."/admin/admin.txt") == "highadmin" or file.Read("users/"..ply:SteamID64().."/admin/admin.txt") == "owner" then
else
ply:Kick("Это ивентовый сервер, отправляйтесь на базу. Ивент сейчас не проводится")
end
-----------
end
end)
end

if string.Split( game.GetIPAddress(), ":" )[1]..":27017" == game.GetIPAddress() then
hook.Add( "PlayerAuthed", "eventserverauthed_hook2", function( ply, steamid, uniqueid )
if file.Read("event/server2.txt") == "close" then
-----------
if not file.Exists( "users/"..ply:SteamID64().."/admin/admin.txt", "data" ) then return ply:Kick("Это ивентовый сервер, отправляйтесь на базу. Ивент сейчас не проводится") end
if file.Read("users/"..ply:SteamID64().."/admin/admin.txt") == "admin" or file.Read("users/"..ply:SteamID64().."/admin/admin.txt") == "highadmin" or file.Read("users/"..ply:SteamID64().."/admin/admin.txt") == "owner" then
else
ply:Kick("Это ивентовый сервер, отправляйтесь на базу. Ивент сейчас не проводится")
end
-----------
end
end)
end



util.AddNetworkString("homebutt_f2menu")
util.AddNetworkString("homebutt_f2menu_server")
net.Receive("homebutt_f2menu_server", function()
local igrok = net.ReadEntity()
local lc_maps = file.Find("maps/*.bsp", "GAME")
local function WLHUDsts()
net.Start('homebutt_f2menu')
net.WriteString(file.Read("users/"..igrok:SteamID64().."/name/name.txt", "data"))
net.WriteString(file.Read("users/"..igrok:SteamID64().."/number/number.txt", "data"))
net.WriteString(file.Read("users/"..igrok:SteamID64().."/legion/legion.txt", "data"))
net.WriteString(file.Read("users/"..igrok:SteamID64().."/rank/rank.txt", "data"))
net.WriteString(file.Read("users/"..igrok:SteamID64().."/spec/spec.txt", "data"))
net.WriteString(file.Read("users/"..igrok:SteamID64().."/admin/admin.txt"))
net.WriteString(file.Read("users/"..igrok:SteamID64().."/model/model.txt"))
net.WriteString(file.Read("users/"..igrok:SteamID64().."/skin/skin.txt"))
net.WriteString(file.Read("users/"..igrok:SteamID64().."/bodygroups/bodygroups.txt"))
net.WriteString(file.Read("users/"..igrok:SteamID64().."/warns/warns.txt"))
net.WriteTable(lc_maps)
net.Send(igrok)
end
WLHUDsts()
end)

util.AddNetworkString("f2menu_event_changemap")
net.Receive("f2menu_event_changemap", function()
local player = net.ReadEntity()
local map = net.ReadString()
local pladmin = file.Read("users/"..player:SteamID64().."/admin/admin.txt", "data")
if pladmin == "admin" or pladmin == "highadmin" or pladmin == "owner" then
RunConsoleCommand( "changelevel", map )
end
end)

util.AddNetworkString("f2menu_event_venator")
net.Receive("f2menu_event_venator", function()
local player = net.ReadEntity()
local pladmin = file.Read("users/"..player:SteamID64().."/admin/admin.txt", "data")
if pladmin == "admin" or pladmin == "highadmin" or pladmin == "owner" then
RunConsoleCommand( "kickall", "Ивент окончен, возвращайтесь на базу!" )
if string.Split( game.GetIPAddress(), ":" )[1]..":27016" == game.GetIPAddress() then
file.Write("event/server1.txt", "close")
end
if string.Split( game.GetIPAddress(), ":" )[1]..":27017" == game.GetIPAddress() then
file.Write("event/server2.txt", "close")
end
end
end)

hook.Add( "PlayerSpawn", "spawncubeallspawn_make", function(ply)
if IsValid(ents.FindByName( "spawn_cube_all" )[math.random(1, table.getn(ents.FindByName( "spawn_cube_all" )))]) then
local spawncube = ents.FindByName( "spawn_cube_all" )[math.random(1, table.getn(ents.FindByName( "spawn_cube_all" )))]
ply:SetPos(spawncube:GetPos())
end
end)