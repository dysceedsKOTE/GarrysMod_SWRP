if CLIENT then return end
concommand.Add("model", function( ply, cmd, args )
if not file.Exists("users/"..args[1], "data") then return PrintMessage(HUD_PRINTTALK, 'Пользователь '..args[1]..' не найден!') end;
if file.Read("users/"..ply:SteamID64().."/admin/admin.txt", "data") == "owner" then
file.Write("users/"..args[1].."/model/model.txt", args[2])
ply:SetModel(file.Read("users/"..ply:SteamID64().."/model/model.txt", "data"))
elseif file.Read("users/"..ply:SteamID64().."/admin/admin.txt", "data") == "highadmin" then
file.Write("users/"..args[1].."/model/model.txt", args[2])
ply:SetModel(file.Read("users/"..ply:SteamID64().."/model/model.txt", "data"))
elseif file.Read("users/"..ply:SteamID64().."/admin/admin.txt", "data") == "admin" then
file.Write("users/"..args[1].."/model/model.txt", args[2])
ply:SetModel(file.Read("users/"..ply:SteamID64().."/model/model.txt", "data"))
elseif file.Read("users/"..ply:SteamID64().."/admin/admin.txt", "data") == "commander" then
file.Write("users/"..args[1].."/model/model.txt", args[2])
ply:SetModel(file.Read("users/"..ply:SteamID64().."/model/model.txt", "data"))
else ply:ChatPrint("НЕ ДОСТАТОЧНО ПРАВ!") end
end)