-- SETTINGS
HaloSettings = {}
HaloSettings.weburl = "https://discord.gg/ga8xPWu"
HaloSettings.start = "Играть"
HaloSettings.web = "Discord"
HaloSettings.quit = "Выйти"


if SERVER then
util.AddNetworkString("MenuChangeSkinZSvan")
net.Receive('MenuChangeSkinZSvan', function()
local plsam = net.ReadEntity()
file.Write("users/"..plsam:SteamID64().."/model/model.txt", "models/aussiwozzi/phase1clones/captain.mdl")
file.Write("users/"..plsam:SteamID64().."/rank/rank.txt", "РДВ")
plsam:Spawn()
end)
util.AddNetworkString("MenuChangeNames2")
net.Receive('MenuChangeNames2', function()
local plname = net.ReadString()
local plsam = net.ReadEntity()
file.Write("users/"..plsam:SteamID64().."/name/name.txt", plname)
plsam:Spawn()
end)
	util.AddNetworkString("lauchHaloMenu")
	hook.Add( "PlayerAuthed", "Makespawnplayerhook23", function (ply)
	timer.Create( ply:SteamID64().."Unique1sss2s", 2, 2, function()
		net.Start("lauchHaloMenu")
			net.WriteEntity(ply)
			net.WriteString(file.Read("users/"..ply:SteamID64().."/model/model.txt", "data"))
			net.WriteString(file.Read("users/"..ply:SteamID64().."/skin/skin.txt", "data"))
			net.WriteString(file.Read("users/"..ply:SteamID64().."/bodygroups/bodygroups.txt", "data"))
			net.WriteString(file.Read("users/"..ply:SteamID64().."/name/name.txt", "data"))
			net.WriteString(file.Read("users/"..ply:SteamID64().."/number/number.txt", "data"))
			net.WriteString(file.Read("users/"..ply:SteamID64().."/legion/legion.txt", "data"))
			net.WriteString(file.Read("users/"..ply:SteamID64().."/rank/rank.txt", "data"))
			net.WriteString(file.Read("users/"..ply:SteamID64().."/spec/spec.txt", "data"))
		net.Send(ply)
	end)
	end)
	hook.Add( "PlayerInitialSpawn", "Makespawnplayerhook2334", function (ply)
	timer.Create( ply:SteamID64().."Unique1sss2sd", 2, 2, function()
		net.Start("lauchHaloMenu")
			net.WriteEntity(ply)
			net.WriteString(file.Read("users/"..ply:SteamID64().."/model/model.txt", "data"))
			net.WriteString(file.Read("users/"..ply:SteamID64().."/skin/skin.txt", "data"))
			net.WriteString(file.Read("users/"..ply:SteamID64().."/bodygroups/bodygroups.txt", "data"))
			net.WriteString(file.Read("users/"..ply:SteamID64().."/name/name.txt", "data"))
			net.WriteString(file.Read("users/"..ply:SteamID64().."/number/number.txt", "data"))
			net.WriteString(file.Read("users/"..ply:SteamID64().."/legion/legion.txt", "data"))
			net.WriteString(file.Read("users/"..ply:SteamID64().."/rank/rank.txt", "data"))
			net.WriteString(file.Read("users/"..ply:SteamID64().."/spec/spec.txt", "data"))
		net.Send(ply)
	end)
	end)
end


if CLIENT then
	function OpenHaloMenu()
		local NEnt = net.ReadEntity()
		local NEntmodel = net.ReadString()
		local NEntskin = net.ReadString()
		local NEntbodygroups = net.ReadString()
		local NEntname = net.ReadString()
		local NEntnumber = net.ReadString()
		local NEntlegion = net.ReadString()
		local NEntrank = net.ReadString()
		local NEntspec = net.ReadString()
		local NEntskind = (NEntskin + 0)
surface.CreateFont( 'joinsectornames2', {
	font = 'Exo 2 Semi Bold',
	extended = true,
	size = 20,
	weight = 500,
	antialias = true,
	underline = false,
	shadow = true,
} )
		local W , H = ScrW(), ScrH()
if IsValid(Base) then return end
		surface.PlaySound( "halo/theme.mp3" )
		Base = vgui.Create( "DFrame" )
		Base:SetPos( 0, 0 )
		Base:SetSize( W, H )
		Base:SetTitle( "" )
		Base:SetDraggable( false )
		Base:ShowCloseButton( false )
		Base:MakePopup()
		local coclpaint = Color(230, 230, 230, 0)
		Base.Paint = function( self, w, h )
			draw.RoundedBox( 0, 0, 0, w, h, Color(100, 100, 200, 255) )
			draw.RoundedBox( 0, w*0.4, h*0.2, w*0.2, h*0.7, Color( 155,155,255, 170 ) )
			if (NEntname == "ГАММА") then
			draw.SimpleText("Новый персонаж",'joinsectornames2',w*0.405,h*0.2,coclpaint)
			end
			if (NEntname != "ГАММА") then
			draw.SimpleText(NEntlegion.." / "..NEntname.." / "..NEntnumber,'joinsectornames2',w*0.405,h*0.2,Color(230,230,230))
			draw.SimpleText(NEntrank.." / "..NEntspec,'joinsectornames2',w*0.405,h*0.22,Color(230,230,230))
		end
		end
if NEntmodel == "models/error.mdl" then
NEntmodel = "models/breen.mdl"
end
character2 = vgui.Create( 'DModelPanel', Base )
character2:SetSize( ScrW()*0.4, ScrH()*0.7 )
character2:SetPos(ScrW()*0.3,ScrH()*0.2)
character2:SetModel(NEntmodel) 
character2:GetEntity():SetSkin(NEntskind)
character2:GetEntity():SetBodyGroups(NEntbodygroups)
character2:SetMouseInputEnabled( false )
function character2:LayoutEntity( Entity ) 
return 
end -- 
Menud = vgui.Create('DButton', Base)
local Menuds = Color( 155,155,255, 0 )
Menud:SetText( '' )	
Menud:SetSize( ScrW()*0.2, ScrH()*0.7 )
Menud:SetPos(ScrW()*0.4,ScrH()*0.2)
Menud.Paint = function( self, w, h )
draw.RoundedBox(0, 0, 0, w, h, Menuds)
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect(0, 0, w, h)
end
Menud.OnCursorEntered = function()
Menuds = Color( 155,155,255, 100 )
surface.PlaySound('garrysmod/ui_hover.wav')
coclpaint = Color(230, 230, 230, 255)
end 
Menud.OnCursorExited = function()
Menuds = Color( 155,155,255, 0 )
coclpaint = Color(230, 230, 230, 0)
end
Menud.DoClick = function()
coclpaint = Color(230, 230, 230, 0)
if (NEntname != "ГАММА") then
Base:Remove()
RunConsoleCommand( "stopsound"  )
RunConsoleCommand("rate", "300000")
RunConsoleCommand("r_decals", "0")
RunConsoleCommand("r_cleardecals")
RunConsoleCommand("violence_ablood", "0")
RunConsoleCommand("violence_agibs", "0")
RunConsoleCommand("violence_hblood", "0")
RunConsoleCommand("violence_hgibs", "0")
local function MDLsend()
local playadm = LocalPlayer()
net.Start('MDLserversend')   
net.WriteEntity(playadm)
net.SendToServer()
end
MDLsend()
else
Bases = vgui.Create( "DFrame", Base )
Bases:SetPos( ScrW()*0.4, ScrH()*0.2 )
Bases:SetSize( ScrW()*0.2, ScrH()*0.7 )
Bases:SetTitle( "Создание персонажа" )
Bases:SetDraggable( false )
Bases:ShowCloseButton( false )
Bases:MakePopup()

local TextEntryPH = vgui.Create( "DTextEntry", Bases )
TextEntryPH:Dock( TOP )
TextEntryPH:DockMargin( 0, 5, 0, 0 )
TextEntryPH:SetPlaceholderText( "Позывной" )
TextEntryPH.OnEnter = function( self )
end

local richtext = vgui.Create("RichText", Bases)
richtext:Dock(TOP)
richtext:DockMargin( 0, 5, 0, 0 )
richtext:SetSize(ScrW(), ScrH()*0.25)
richtext:SetText("Введите свой позывной, он не должен содержать в себе оскорблений, странных наборов букв, цифр. За нарушение этих требований вы можете получить наказание. Позывной должен быть более 4-ёх букв и менее 12-и.")
richtext.Paint = function( self, w, h )
draw.RoundedBox( 0, 0, 0, w, h, Color( 30,30,30, 170 ) )
end
local richnovtext = "Для новых игроков. Вам проведут обучение и краткий экскурс в мир Звездных Воин, покажут базу и познакомят с основными правилами базы. Помимо всего перечисленного, вам запрещено покидать кадетку без прохождения обучения."
local richtext2 = vgui.Create("RichText", Bases)
richtext2:Dock(TOP)
richtext2:DockMargin( 0, 5, 0, 0 )
richtext2:SetSize(ScrW(), ScrH()*0.25)
richtext2:SetText(richnovtext)
richtext2.Paint = function( self, w, h )
draw.RoundedBox( 0, 0, 0, w, h, Color( 30,30,30, 170 ) )
end
local DComboBoxkeksik22832 = vgui.Create( "DComboBox", Bases)
DComboBoxkeksik22832:Dock(TOP)
DComboBoxkeksik22832:DockMargin( 0, 5, 0, 0 )
DComboBoxkeksik22832:SetValue( "Новичок" )
DComboBoxkeksik22832:AddChoice( "Новичок" )
DComboBoxkeksik22832:AddChoice( "Эксперт" )
DComboBoxkeksik22832.OnSelect = function( self, index, value )
if (value == "Новичок") then
richtext2:SetText("Для новых игроков. Вам проведут обучение и краткий экскурс в мир Звездных Воин, покажут базу и познакомят с основными правилами базы. Помимо всего перечисленного, вам запрещено покидать кадетку без прохождения обучения.")
end
if (value == "Эксперт") then
richtext2:SetText("Для бывалых игроков. Вам сразу же будет выдано звание рядовой, однако командиры, чтобы убедиться, что вы и правда бывалый игрок, будут вас опрашивать дополнительно. Помимо у вас будет отличная форма от обычных рядовых. Вы также можете покидать кадетку и вступать в подразделения.")
end
end
Bases.Paint = function( self, w, h )
draw.RoundedBox( 0, 0, 0, w, h, Color( 155,155,255, 170 ) )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect(0, 0, w, h)
end
local DermaButtons = Color(100, 100, 200, 0)
local DermaButton = vgui.Create( "DButton", Bases)
DermaButton:SetText( "" )					
DermaButton:Dock(TOP)
DermaButton:DockMargin( 0, 5, 0, 0 )					
DermaButton:SetSize( ScrW(), ScrH()*0.05 )	
function DermaButton:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, DermaButtons )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect(0, 0, w, h)
draw.SimpleText('Создать','joinsectornames2', w*0.5, h*0.25,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end
DermaButton.OnCursorEntered = function()
DermaButtons = Color(100, 100, 200, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
DermaButton.OnCursorExited = function()
DermaButtons = Color(100, 100, 200, 0)
end				
DermaButton.DoClick = function()
--				
local textstring = TextEntryPH:GetValue()
local yesstring = string.gsub(textstring, "%s+", "")
if (string.len(yesstring) > 4 and string.len(yesstring) < 12) then
if (textstring != "ГАММА") then
--+
if (DComboBoxkeksik22832:GetValue() == "Новичок") then
local function namesendstartplay()
net.Start('MenuChangeNames2')
net.WriteString(yesstring)
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
namesendstartplay()
Base:Remove()
RunConsoleCommand( "stopsound"  )
RunConsoleCommand("rate", "300000")
RunConsoleCommand("r_decals", "0")
RunConsoleCommand("r_cleardecals")
RunConsoleCommand("violence_ablood", "0")
RunConsoleCommand("violence_agibs", "0")
RunConsoleCommand("violence_hblood", "0")
RunConsoleCommand("violence_hgibs", "0")
local function MDLsend()
local playadm = LocalPlayer()
net.Start('MDLserversend')   
net.WriteEntity(playadm)
net.SendToServer()
end
MDLsend()
end
--+
if (DComboBoxkeksik22832:GetValue() == "Эксперт") then
local function namesendstartplay()
net.Start('MenuChangeNames2')
net.WriteString(yesstring)
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
namesendstartplay()
local function skinzvansendstartplay()
net.Start('MenuChangeSkinZSvan')
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
skinzvansendstartplay()
Base:Remove()
RunConsoleCommand( "stopsound"  )
RunConsoleCommand("rate", "300000")
RunConsoleCommand("r_decals", "0")
RunConsoleCommand("r_cleardecals")
RunConsoleCommand("violence_ablood", "0")
RunConsoleCommand("violence_agibs", "0")
RunConsoleCommand("violence_hblood", "0")
RunConsoleCommand("violence_hgibs", "0")
local function MDLsend()
local playadm = LocalPlayer()
net.Start('MDLserversend')   
net.WriteEntity(playadm)
net.SendToServer()
end
MDLsend()
end
--+
end
end
--			
end
end
end
end
	net.Receive("lauchHaloMenu", OpenHaloMenu)
end