-- I hope you enjoy yourself. There isn't much to this add-on, just removing all of the keyvalues from the improved combine. Someone needed to do it.
-- Made by acj2001, original template script made by Ehsaan.

local Category2 = "X - CWRP" -- Category name

local NPC = {
	Name 		=	"B1 - Стандартный",
	Class 		=	"npc_combine_s",
	Category	=	Category2,
	Weapons 	=	{ "rw_sw_e5" },
	Model 		=	"models/lightnings_edits/npc_droids/b1_battledroid_assault.mdl"
}
list.Set( "NPC", "b1_standart", NPC )

local NPC = {
	Name 		=	"B1 - Снайпер",
	Class 		=	"npc_combine_s",
	Category	=	Category2,
	Weapons 	=	{ "rw_sw_e5s" },
	Model 		=	"models/lightnings_edits/npc_droids/b1_battledroid_specialist.mdl"
}
list.Set( "NPC", "b1_spec", NPC )

local NPC = {
	Name 		=	"B1 - Тяжёлый",
	Class 		=	"npc_combine_s",
	Category	=	Category2,
	Weapons 	=	{ "rw_sw_e5c" },
	Model 		=	"models/lightnings_edits/npc_droids/b1_battledroid_heavyz6.mdl"
}
list.Set( "NPC", "b1_heavy", NPC )

local NPC = {
	Name 		=	"B1 - Офицер",
	Class 		=	"npc_combine_s",
	Category	=	Category2,
	Weapons 	=	{ "rw_sw_rg4d" },
	Model 		=	"models/lightnings_edits/npc_droids/b1_battledroid_officer.mdl"
}
list.Set( "NPC", "b1_officer", NPC )

local NPC = {
	Name 		=	"B2 - Стандартный",
	Class 		=	"npc_combine_s",
	Category	=	Category2,
	Weapons 	=	{ "rw_sw_b2rp_blaster" },
	Model 		=	"models/lightnings_edits/npc_droids/b2_battledroid.mdl"
}
list.Set( "NPC", "b2_standart", NPC )