include("shared.lua")

local VisibleTime = 0
local smVisible = 0
local zoom_mat = Material( "vgui/zoom" )
local mat = Material( "sprites/light_glow02_add" )

local function DrawCircle( X, Y, radius ) -- handy draw circle function. I should make this a global function at some point
	local segmentdist = 360 / ( 2 * math.pi * radius / 2 )
	
	for a = 0, 360, segmentdist do
		surface.DrawLine( X + math.cos( math.rad( a ) ) * radius, Y - math.sin( math.rad( a ) ) * radius, X + math.cos( math.rad( a + segmentdist ) ) * radius, Y - math.sin( math.rad( a + segmentdist ) ) * radius )
	end
end

function ENT:LFSHudPaintPassenger( X, Y, ply )
	if ply ~= self:GetGunner() then return end

	local UsingGunCam = self.ToggledView
	
	local HitPlane = Vector(X*0.5,Y*0.5,0)

	local ID = self:LookupAttachment( "muzzle" )
	local Attachment = self:GetAttachment( ID )

	if Attachment then
		-- for the crosshair to be accurate CLIENT aiming code has to be exactly the same as SERVER aiming code
		
		local Dir = ply:EyeAngles():Forward()
		local TargetDir = Attachment.Ang:Forward()
		local Forward = self:LocalToWorldAngles( Angle(20,0,0) ):Forward()
		local AimDirToForwardDir = math.deg( math.acos( math.Clamp( Forward:Dot( Dir ) ,-1,1) ) )
		if AimDirToForwardDir > 100 then
			TargetDir = Dir
		end
		
		local Trace = util.TraceLine( {
			start = Attachment.Pos,
			endpos = (Attachment.Pos + TargetDir  * 50000),
			filter = self
		} )
		
		local pToScreen = Trace.HitPos:ToScreen()
		
		HitPlane = Vector(pToScreen.x,pToScreen.y,0)
	end
	
	local Time = CurTime()
	

	
	local Visible = VisibleTime > Time
	smVisible = smVisible + ((Visible and 1 or 0) - smVisible) * FrameTime() * 10
	
	local wobl = ((VisibleTime - 1.9 > Time) and  self:GetAmmoLaserCannon() > 0) and math.cos( Time * 300 ) * 6 or 0
	
	local vD = 5 + (5 + wobl)
	local vD2 = 10 + (10 + wobl)
	surface.SetDrawColor( Color(255,255,255,255) )
	surface.DrawLine( HitPlane.x + vD, HitPlane.y, HitPlane.x + vD2, HitPlane.y ) 
	surface.DrawLine( HitPlane.x - vD, HitPlane.y, HitPlane.x - vD2, HitPlane.y ) 
	surface.DrawLine( HitPlane.x, HitPlane.y + vD, HitPlane.x, HitPlane.y + vD2 ) 
	surface.DrawLine( HitPlane.x, HitPlane.y - vD, HitPlane.x, HitPlane.y - vD2 ) 
	
	local HitPlane = HitPlane + Vector(1,1,0)
	surface.SetDrawColor( Color(0,0,0,50) )
	surface.DrawLine( HitPlane.x + vD, HitPlane.y, HitPlane.x + vD2, HitPlane.y ) 
	surface.DrawLine( HitPlane.x - vD, HitPlane.y, HitPlane.x - vD2, HitPlane.y ) 
	surface.DrawLine( HitPlane.x, HitPlane.y + vD, HitPlane.x, HitPlane.y + vD2 ) 
	surface.DrawLine( HitPlane.x, HitPlane.y - vD, HitPlane.x, HitPlane.y - vD2 ) 
	

	
	if not UsingGunCam then return end
	
	local X = ScrW() * 0.5
	local Y = ScrH() * 0.5
	
	self.curZoom = self.curZoom or 90
	
	local Scale = (2.5 - self.curZoom / 70)
	
	local R = X * 0.2 * Scale
	
	surface.SetDrawColor( Color(255,255,255,50) )
	DrawCircle( X, Y, R * 0.8 )
	DrawCircle( X, Y, R )
	
	surface.SetDrawColor( Color(0,0,0,50) )
	DrawCircle( X + 1, Y + 1, R * 0.8 )
	DrawCircle( X + 1, Y + 1, R )
	
	for i = 3, 43 do
		surface.SetDrawColor( Color(255,255,255,100) )
		surface.DrawLine( X + R * 0.19 * i, Y + R * 0.05, X + R * 0.19 * i, Y - R * 0.05 )
		surface.DrawLine( X - R * 0.19 * i, Y + R * 0.05, X - R * 0.19 * i, Y - R * 0.05 )
		
		surface.SetDrawColor( Color(0,0,0,50) )
		surface.DrawLine( X + R * 0.19 * i + 1, Y + R * 0.05 + 1, X + R * 0.19 * i + 1, Y - R * 0.05 + 1 )
		surface.DrawLine( X - R * 0.19 * i + 1, Y + R * 0.05 + 1, X - R * 0.19 * i + 1, Y - R * 0.05 + 1 )
	end

	surface.SetDrawColor( Color(255,255,255,255) )
	surface.SetMaterial(zoom_mat ) 
	surface.DrawTexturedRectRotated( X + X * 0.5, Y * 0.5, X, Y, 0 )
	surface.DrawTexturedRectRotated( X + X * 0.5, Y + Y * 0.5, Y, X, 270 )
	surface.DrawTexturedRectRotated( X * 0.5, Y * 0.5, Y, X, 90 )
	surface.DrawTexturedRectRotated( X * 0.5, Y + Y * 0.5, X, Y, 180 )
end

function ENT:GunCamera( view, ply )
	if ply == self:GetGunner() then
		local Zoom = ply:KeyDown( IN_ATTACK2 )
		
		local zIn = ply:KeyDown( IN_FORWARD ) and 1 or 0
		local zOut = ply:KeyDown( IN_BACK ) and 1 or 0
		
		if self.oldZoom ~= Zoom then
			self.oldZoom = Zoom
			if Zoom then
				self.ToggledView = not self.ToggledView
			else
				self.curZoom = 100
			end
		end
		
		self.curZoom = self.curZoom and math.Clamp(self.curZoom + (zOut - zIn) * FrameTime() * 100,20,90) or 0
		
		if self.ToggledView then
			local ID = self:LookupAttachment( "muzzle" )
			local Attachment = self:GetAttachment( ID )

			if Attachment then
				view.origin = Attachment.Pos + Attachment.Ang:Up() * 15 + Attachment.Ang:Forward() * 5
			else
				view.origin = self:LocalToWorld( Vector(-395,0,115) )
			end
			
			view.fov = self.curZoom
		end
	end
	
	if self.oldToggledView ~= self.ToggledView then
		self.oldToggledView = self.ToggledView
		
		if self.ToggledView then
			surface.PlaySound("weapons/sniper/sniper_zoomin.wav")
		else
			surface.PlaySound("weapons/sniper/sniper_zoomout.wav")
		end
	end
	
	return view
end

function ENT:LFSCalcViewFirstPerson( view, ply )
	local ply = LocalPlayer()
	
	local Pod = ply:GetVehicle()
	
	if not IsValid( Pod ) then return view end

if ply == self:GetDriver() then
view.origin = self:GetPos() + self:GetForward()*193 + self:GetRight()*0 + self:GetUp()*148


	elseif Pod == self:GetCoPilotGunnerSeat() then
	view.origin = self:GetPos() + self:GetForward()*109 + self:GetRight()*0 + self:GetUp()*177

return view end

	if ply == self:GetGunner() then
	view.origin = self:GetPos() + self:GetForward()*-356 + self:GetRight()*0 + self:GetUp()*135
	return self:GunCamera( view, ply )
end

if ply == self:GetDriver() then return view end -- dont change view if the player is pilot or copilot
	return self:LFSCalcViewThirdPerson( view, ply, true )
end

function ENT:LFSCalcViewThirdPerson( view, ply, FirstPerson )
	local ply = LocalPlayer()
	
	local Pod = ply:GetVehicle()
	
	if not IsValid( Pod ) then return view end
	
	if ply == self:GetDriver() then
		local radius = 700
		radius = radius + radius * Pod:GetCameraDistance()
		
		view.origin = self:LocalToWorld( Vector(0,0,350) )
		
		local TargetOrigin = view.origin - view.angles:Forward() * radius  + view.angles:Up() * 750 * 0.1
		local WallOffset = 1

		local tr = util.TraceHull( {
			start = view.origin,
			endpos = TargetOrigin,
			filter = function( e )
				local c = e:GetClass()
				local collide = not c:StartWith( "prop_physics" ) and not c:StartWith( "prop_dynamic" ) and not c:StartWith( "prop_ragdoll" ) and not e:IsVehicle() and not c:StartWith( "gmod_" ) and not c:StartWith( "player" ) and not e.LFS
				
				return collide
			end,
			mins = Vector( -WallOffset, -WallOffset, -WallOffset ),
			maxs = Vector( WallOffset, WallOffset, WallOffset ),
		} )
		
		view.origin = tr.HitPos
		
		if tr.Hit and not tr.StartSolid then
			view.origin = view.origin + tr.HitNormal * WallOffset
		end
	
	elseif Pod == self:GetCoPilotGunnerSeat() then
		local radius = 700
		radius = radius + radius * Pod:GetCameraDistance()
		
		view.origin = self:LocalToWorld( Vector(-100,0,350) )
		
		local TargetOrigin = view.origin - view.angles:Forward() * radius  + view.angles:Up() * 750 * 0.1
		local WallOffset = 1

		local tr = util.TraceHull( {
			start = view.origin,
			endpos = TargetOrigin,
			filter = function( e )
				local c = e:GetClass()
				local collide = not c:StartWith( "prop_physics" ) and not c:StartWith( "prop_dynamic" ) and not c:StartWith( "prop_ragdoll" ) and not e:IsVehicle() and not c:StartWith( "gmod_" ) and not c:StartWith( "player" ) and not e.LFS
				
				return collide
			end,
			mins = Vector( -WallOffset, -WallOffset, -WallOffset ),
			maxs = Vector( WallOffset, WallOffset, WallOffset ),
		} )
		
		view.origin = tr.HitPos
		
		if tr.Hit and not tr.StartSolid then
			view.origin = view.origin + tr.HitNormal * WallOffset
		end	
	
		return view
	end

	if ply == self:GetDriver() then
	
	elseif ply == self:GetGunner() then
		local radius = 500
		radius = radius + radius * Pod:GetCameraDistance()
		
		view.origin = self:LocalToWorld( Vector(-300,0,350) )
		
		local TargetOrigin = view.origin - view.angles:Forward() * radius  + view.angles:Up() * 750 * 0.1
		local WallOffset = 1

		local tr = util.TraceHull( {
			start = view.origin,
			endpos = TargetOrigin,
			filter = function( e )
				local c = e:GetClass()
				local collide = not c:StartWith( "prop_physics" ) and not c:StartWith( "prop_dynamic" ) and not c:StartWith( "prop_ragdoll" ) and not e:IsVehicle() and not c:StartWith( "gmod_" ) and not c:StartWith( "player" ) and not e.LFS
				
				return collide
			end,
			mins = Vector( -WallOffset, -WallOffset, -WallOffset ),
			maxs = Vector( WallOffset, WallOffset, WallOffset ),
		} )
		
		view.origin = tr.HitPos
		
		if tr.Hit and not tr.StartSolid then
			view.origin = view.origin + tr.HitNormal * WallOffset
		end
		
 	return self:GunCamera( view, ply )
	else
		view.angles = ply:GetVehicle():LocalToWorldAngles( ply:EyeAngles() )
		
		if FirstPerson then
			view.origin = view.origin + Pod:GetUp() * 40
		else
			view.origin = ply:GetShootPos() + Pod:GetUp() * 40
			
			local radius = 800
			radius = radius + radius * Pod:GetCameraDistance()
			
			local TargetOrigin = view.origin - view.angles:Forward() * radius
			
			local WallOffset = 4

			local tr = util.TraceHull( {
				start = view.origin,
				endpos = TargetOrigin,
				filter = function( e )
					local c = e:GetClass()
					local collide = not c:StartWith( "prop_physics" ) and not c:StartWith( "prop_dynamic" ) and not c:StartWith( "prop_ragdoll" ) and not e:IsVehicle() and not c:StartWith( "gmod_" ) and not c:StartWith( "player" ) and not e.LFS
					
					return collide
				end,
				mins = Vector( -WallOffset, -WallOffset, -WallOffset ),
				maxs = Vector( WallOffset, WallOffset, WallOffset ),
			} )
			
			view.drawviewer = true
			view.origin = tr.HitPos
			
			if tr.Hit and not tr.StartSolid then
				view.origin = view.origin + tr.HitNormal * WallOffset
			end
		end
	end
	
	return view
end

function ENT:DamageFX()
	local HP = self:GetHP()
	if HP == 0 or HP > self:GetMaxHP() * 0.5 then return end
	
	self.nextDFX = self.nextDFX or 0
	
	if self.nextDFX < CurTime() then
		self.nextDFX = CurTime() + 0.05
		for k,v in pairs( {Vector(-292.59,17.24,222.76),Vector(-210.1,-73.75,262.84),Vector(-168.9,165.15,167.43),Vector(108.54,63.55,34.34),Vector(-163.98,-328.13,95.87),Vector(11.07,-42.54,164.04),Vector(-244.12,-54.53,91.08) } ) do
		local effectdata = EffectData()
			effectdata:SetOrigin( self:LocalToWorld( v ) )
		util.Effect( "lfs_blacksmoke", effectdata )
		end
	end
end

function ENT:ExhaustFX()
	local FullThrottle = self:GetThrottlePercent() >= 50
	
	if self.OldFullThrottle ~= FullThrottle then
		self.OldFullThrottle = FullThrottle
		if FullThrottle then 
			self:EmitSound( "LAAT_BOOST" )
		end
	end
end

function ENT:CalcEngineSound( RPM, Pitch, Doppler )
	if self.ENG then
		self.ENG:ChangePitch(  math.Clamp(math.Clamp(  80 + Pitch * 25, 50,255) + Doppler,0,255) )
		self.ENG:ChangeVolume( math.Clamp( -1 + Pitch * 6, 0.5,1) )
	end
	
	if self.DIST then
		local ply = LocalPlayer()
		local DistMul = math.min( (self:GetPos() - ply:GetPos()):Length() / 8000, 1) ^ 2
		self.DIST:ChangePitch(  math.Clamp( 100 + Doppler * 0.2,0,255) )
		self.DIST:ChangeVolume( math.Clamp( -1.5 + Pitch * 6, 1,1) * DistMul )
	end
	
	local OnGround = self:GetIsGroundTouching()
	if self.OldGroundTouching == nil then self.OldGroundTouching = true end
	
	if OnGround ~= self.OldGroundTouching then
		self.OldGroundTouching = OnGround
		if not OnGround then
			self:EmitSound( "LAAT_TAKEOFF" )
		else
			self:EmitSound( "LAAT_LANDING" )
		end
	end
end

function ENT:EngineActiveChanged( bActive )
	if bActive then
		self.ENG = CreateSound( self, "LAAT_ENGINE" )
		self.ENG:PlayEx(0,0)
		
		self.DIST = CreateSound( self, "LAAT_DIST" )
		self.DIST:PlayEx(0,0)
	else
		self:SoundStop()
	end
end

function ENT:OnRemove()
	self:SoundStop()
end

function ENT:SoundStop()
	if self.ENG then
		self.ENG:Stop()
	end
	
	if self.DIST then
		self.DIST:Stop()
	end
end

function ENT:AnimFins()
end

function ENT:AnimRotor()
end

function ENT:AnimCabin()
end

function ENT:AnimLandingGear()
end