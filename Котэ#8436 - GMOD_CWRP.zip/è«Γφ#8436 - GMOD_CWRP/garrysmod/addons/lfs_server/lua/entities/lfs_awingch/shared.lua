--DO NOT EDIT OR REUPLOAD THIS FILE
ENT.Type            = "anim"
DEFINE_BASECLASS( "lunasflightschool_basescript" )

ENT.PrintName = "RZ-1 A-Wing"
ENT.Author = "ch5"
ENT.Information = ""
ENT.Category = "[LFS]"

ENT.Spawnable		= true 
ENT.AdminSpawnable	= false

ENT.MDL = "models/33/A-Wing.mdl" 

ENT.GibModels = {
    "models/33/A-Wing_Cluster_1.mdl", 
	"models/33/A-Wing_Cluster_2.mdl", 
	"models/XQM/jetwing2medium.mdl",
	"models/XQM/jetwing2medium.mdl",
	"models/XQM/jetbody2fuselage.mdl",
	"models/XQM/jettailpiece1medium.mdl",
	"models/XQM/pistontype1huge.mdl",
}

ENT.AITEAM = 2

ENT.Mass = 2000
ENT.Inertia = Vector(250000,250000,250000)
ENT.Drag = 1

ENT.SeatPos = Vector(-12,0,0)
ENT.SeatAng = Angle(0,-90,15)

ENT.IdleRPM = 1
ENT.MaxRPM = 3800
ENT.LimitRPM = 3800

ENT.RotorPos = Vector(40,0,0)
ENT.WingPos = Vector(60,0,0)
ENT.ElevatorPos = Vector(-300,0,0)
ENT.RudderPos = Vector(-300,0,0)

ENT.MaxVelocity = 3800

ENT.MaxThrust = 26000

ENT.MaxTurnPitch = 1200
ENT.MaxTurnYaw = 1200
ENT.MaxTurnRoll = 600

ENT.MaxPerfVelocity = 1500

ENT.MaxHealth = 850
ENT.MaxShield = 350

ENT.Stability = 0.7

ENT.VerticalTakeoff = true 
ENT.MaxThrustVtol = 8500

ENT.MaxPrimaryAmmo = 2500
ENT.MaxSecondaryAmmo = 12

sound.Add( {
	name = "RZ1 RG9",
	channel = CHAN_WEAPON,
	volume = 1.0,
	level = 105,
	pitch = {0, 0},
	sound = {
"lfs/sharedok1/rz2cannon.wav",
"lfs/sharedok1/rz2cannon6.wav",
"lfs/sharedok1/rz2cannon5.wav",
"lfs/sharedok1/rz2cannon4.wav",
"lfs/sharedok1/rz2cannon3.wav",
"lfs/sharedok1/rz2cannon2.wav",
		
	
	}
} )
sound.Add( {
	name = "a_tone",
	channel = CHAN_STATIC,
	volume = 0.7,
	level = 120,
	pitch = { 0, 0 },
	sound = "lfs/sharedok1/a_tone.wav"
} )

sound.Add( {
	name = "RZ1 Concussion",
	channel = CHAN_WEAPON,
	volume = 1.0,
	level = 105,
	pitch = {0, 0},
	sound = "lfs/sharedok1/RZ2_A-Wing_Concussion.wav"
} )

sound.Add( {
	name = "intt",
	channel = CHAN_STATIC,
	volume = 1.0,
	level = 120,
	pitch = { 95, 90 },
	sound = "lfs/sharedok1/a_interior.wav"
} )

sound.Add( {
	name = "alarmm",
	channel = CHAN_STATIC,
	volume = 1.0,
	level = 40,
	pitch = { 0,0 },
	sound = "lfs/sharedok1/a_alarm.wav"
} )