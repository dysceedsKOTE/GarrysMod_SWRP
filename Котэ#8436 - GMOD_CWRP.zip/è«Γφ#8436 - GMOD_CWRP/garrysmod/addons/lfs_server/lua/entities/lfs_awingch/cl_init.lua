--DO NOT EDIT OR REUPLOAD THIS FILE

include("shared.lua")

function ENT:LFSCalcViewFirstPerson( view )

return view

end

function ENT:LFSCalcViewThirdPerson( view, ply ) 
	local ply = LocalPlayer()
	
	local Pod = ply:GetVehicle()
	
	if not IsValid( Pod ) then return view end
	
	if ply == self:GetDriver() then
		local radius = 600
		radius = radius + radius * Pod:GetCameraDistance()
		
		view.origin = self:LocalToWorld( Vector(0,0,0) )
		
		local TargetOrigin = view.origin - view.angles:Forward() * radius  + view.angles:Up() * radius * 0.2
		local WallOffset = 1

		local tr = util.TraceHull( {
			start = view.origin,
			endpos = TargetOrigin,
			filter = function( e )
				local c = e:GetClass()
				local collide = not c:StartWith( "prop_physics" ) and not c:StartWith( "prop_dynamic" ) and not c:StartWith( "prop_ragdoll" ) and not e:IsVehicle() and not c:StartWith( "gmod_" ) and not c:StartWith( "player" ) and not e.LFS
				
				return collide
			end,
			mins = Vector( -WallOffset, -WallOffset, -WallOffset ),
			maxs = Vector( WallOffset, WallOffset, WallOffset ),
		} )
		
		view.origin = tr.HitPos
		
		if tr.Hit and not tr.StartSolid then
			view.origin = view.origin + tr.HitNormal * WallOffset
		end
		
		return view
   end
end

function ENT:LFSHudPaint( X, Y, data, ply ) 
end

function ENT:LFSHudPaintPassenger( X, Y, ply ) 
end

function ENT:CalcEngineSound( RPM, Pitch, Doppler )
local ply = LocalPlayer()
	local mypos = self:GetPos()
	local plypos = ply:GetPos() + (self.FirstPerson and Vector(0,0,0) or -ply:EyeAngles():Forward() * 50000)
	local IsInFront = self:WorldToLocal( plypos ).x > -100

	local daVol = math.min( (plypos - mypos):Length() / 7000,0.7 )

	if self.ENG then
		self.ENG:ChangePitch(  math.Clamp(math.Clamp(  70 + Pitch * 45, 50,255) + Doppler,0,255) )
		self.ENG:ChangeVolume( math.Clamp( -1 + Pitch * 6, 0.5,1) )
		
	if self.INTERIOR then
		self.INTERIOR:ChangePitch( math.Clamp(70 + Pitch * 33,0,255) )
		self.INTERIOR:ChangeVolume( self.FirstPerson and 0.7 or 0 )
		
		if self.MIX then
		self.MIX:ChangePitch( math.Clamp(70 + Pitch * 33,0,255) )
		self.MIX:ChangeVolume( self.FirstPerson and 0.7 or 0 )
		
         end
      end
   end
end

function ENT:EngineActiveChanged( bActive )
if bActive then
		self.ENG = CreateSound( self, "a_tone" )
		self.ENG:PlayEx(0,0)
		
        self.INTERIOR = CreateSound( LocalPlayer(), "intt" )
		self.INTERIOR:PlayEx(0,0)
		
		self.MIX = CreateSound( LocalPlayer(), "lfs/sharedok1/a_mixer.wav" )
		self.MIX:PlayEx(0,0)

		
	else
		self:SoundStop()
   end
end

function ENT:OnRemove()
	self:SoundStop()
	
	if IsValid( self.TheRotor ) then 
       self.TheRotor:Remove()
	end
	
	if IsValid( self.Cockpit ) then
	self.Cockpit:Remove()
end

if self.pEmitter then
	self.pEmitter:Finish()
   end
end

function ENT:SoundStop()
	if self.ENG then
		self.ENG:Stop()
	end
	if self.INTERIOR then
		self.INTERIOR:Stop()
	end
	if self.MIX then
		self.MIX:Stop()
   end
end

function ENT:AnimFins()
	local FT = FrameTime() * 10
	local Pitch = self:GetRotPitch()
	local Yaw = self:GetRotYaw()
	self.smPitch = self.smPitch and self.smPitch + (Pitch - self.smPitch) * FT or 0
	self.smYaw = self.smYaw and self.smYaw + (Yaw - self.smYaw) * FT or 0
	
	self:ManipulateBoneAngles( 11, Angle( 0,0,-self.smPitch/3) )

	self:ManipulateBoneAngles( 10, Angle( -self.smYaw/2) )
end

function ENT:AnimRotor()
end

function ENT:AnimCabin()

local bOn = self:GetActive()
	
	local TVal = bOn and 0 or 1
	
	local Speed = FrameTime() * 2
	
	self.SMcOpen = self.SMcOpen and self.SMcOpen + math.Clamp(TVal - self.SMcOpen,-Speed,Speed) or 0
	
	self:ManipulateBonePosition( 1, Vector(0,0, self.SMcOpen * 2) ) 
	
	self:ManipulateBoneAngles( 1, Angle(0,0,self.SMcOpen *-70) ) 
	
end

function ENT:ExhaustFX()
	if not self:GetEngineActive() then return end
	
	self.nextEFX = self.nextEFX or 0
	
	local THR = (self:GetRPM() - self.IdleRPM) / (self.LimitRPM - self.IdleRPM)
	
	self.BoostAdd = self.BoostAdd and (self.BoostAdd - self.BoostAdd * FrameTime()) or 0
	
	if self.nextEFX < CurTime() then
		self.nextEFX = CurTime() + 0.01
		
		local emitter = ParticleEmitter( self:GetPos(), false )

		if emitter then
			local Mirror = false
			for i = 0,1 do
				local Sub = Mirror and 1 or -1
				local vOffset = self:LocalToWorld( Vector(-120,-50 * Sub,0) )
				local vNormal = -self:GetForward()

				vOffset = vOffset + vNormal * 5

				local particle = emitter:Add( "effects/muzzleflash2", vOffset )
				if not particle then return end

				particle:SetVelocity( vNormal * math.Rand(500,1000) + self:GetVelocity() )
				particle:SetLifeTime( 0 )
				particle:SetDieTime( 0.1 )
				particle:SetStartAlpha( 255 )
				particle:SetEndAlpha( 0 )
				particle:SetStartSize( math.Rand(15,25) )
				particle:SetEndSize( math.Rand(0,10) )
				particle:SetRoll( math.Rand(-1,1) * 100 )
				
				particle:SetColor(255, 255, 0)
			
				Mirror = true
			end
			
			emitter:Finish()
		end
	end
end

local mat = Material( "sprites/light_glow02_add" )
function ENT:Draw()
    self:DrawModel()
	local ply = LocalPlayer()
	if not IsValid( ply ) then return end
	local Pod = ply:GetVehicle()
	if ply == self:GetDriver() then
		if IsValid( Pod ) then
			if Pod:GetThirdPersonMode() then
				self:DrawModel()
				self.FirstPerson = false
			else
				self.FirstPerson = true
			end
		else
			self:DrawModel()
			self.FirstPerson = false
		end
	else
		self:DrawModel()
		self.FirstPerson = false
	end

	if not self:GetEngineActive() then return end
	
	local Boost = self.BoostAdd or 0
	
	local Size = 100 + (self:GetRPM() / self:GetLimitRPM()) * 10 + Boost

	render.SetMaterial( mat )
	render.DrawSprite( self:LocalToWorld( Vector(-120,-52,1.5) ), Size, Size, Color( 255, 165, 0, 0) )
	render.DrawSprite( self:LocalToWorld( Vector(-120,52,1.5) ), Size, Size, Color( 255, 165,0, 0) )
	
	render.DrawSprite( self:LocalToWorld( Vector(-130,-52,1.5) ), Size, Size, Color( 255, 165, 0, 0) )
	render.DrawSprite( self:LocalToWorld( Vector(-130,52,1.5) ), Size, Size, Color( 255, 165,0, 0) )
	
	render.DrawSprite( self:LocalToWorld( Vector(-110,-52,1.5) ), Size, Size, Color( 255, 165, 0, 0) )
	render.DrawSprite( self:LocalToWorld( Vector(-110,52,1.5) ), Size, Size, Color( 255, 165,0, 0) )
	render.DrawSprite( self:LocalToWorld( Vector(-100,-52,1.5) ), Size, Size, Color( 255, 165, 0, 0) )
	render.DrawSprite( self:LocalToWorld( Vector(-100,52,1.5) ), Size, Size, Color( 255, 165,0, 0) )
	
end