--DO NOT EDIT OR REUPLOAD THIS FILE

AddCSLuaFile( "shared.lua" )
AddCSLuaFile( "cl_init.lua" )
include("shared.lua")

function ENT:SpawnFunction( ply, tr, ClassName )

	if not tr.Hit then return end

	local ent = ents.Create( ClassName )
	ent:SetPos( tr.HitPos + tr.HitNormal * 100 )
	ent:Spawn()
	ent:Activate()

	return ent

end

function ENT:RunOnSpawn()
end

function ENT:PrimaryAttack()
	if not self:CanPrimaryAttack() then return end

	self:EmitSound( "RZ1 RG9" )
	
	self:SetNextPrimary( 0.0835)
	
	local fP = { Vector(110,90,0), Vector(110,-90,0) }

	self.NumPrim = self.NumPrim and self.NumPrim + 1 or 1
	if self.NumPrim > 2 then self.NumPrim = 1 end
	
	local startpos =  self:GetRotorPos()
	local TracePlane = util.TraceHull( {
		start = startpos,
		endpos = (startpos + self:GetForward() * 50000),
		mins = Vector( -0, -0, -0 ),
		maxs = Vector( 0, 0, 0 ),
		filter = self
	} )
	
	local bullet = {}
	bullet.Num 	= 1
	bullet.Src 	= self:LocalToWorld( fP[self.NumPrim] )
	bullet.Dir 	= (TracePlane.HitPos - bullet.Src):GetNormalized()
	bullet.Spread 	= Vector( 0.0005,  0.0005, 0 )
	bullet.Tracer	= 1
	bullet.TracerName = "lfs_laser_red_large"
	bullet.Force	= 100
	bullet.HullSize = 40
	bullet.Damage	= 50
	bullet.Attacker = self:GetDriver()
	bullet.AmmoType = "Pistol"
	bullet.Callback = function(att, tr, dmginfo)
		dmginfo:SetDamageType(DMG_AIRBOAT)
	end
	self:FireBullets( bullet )
	
	self:TakePrimaryAmmo()

end

function ENT:SecondaryAttack()
    if self:GetAI() then return end
	if not self:CanSecondaryAttack() then return end
	
	self:SetNextSecondary( 0.40 )

	self:TakeSecondaryAmmo()

	self:EmitSound( "RZ1 Concussion" )
	
	self.MirrorSecondary = not self.MirrorSecondary
	
	local Mirror = self.MirrorSecondary and -1 or 1
	
	local startpos =  self:GetRotorPos()
	local tr = util.TraceHull( {
		start = startpos,
		endpos = (startpos + self:GetForward() * 50000),
		mins = Vector( -0, -0, -0 ),
		maxs = Vector( 0, 0, 0 ),
		filter = function( e )
			local collide = e ~= self
			return collide
		end
	} )
	
	local ent = ents.Create( "lunasflightschool_missile" )
	local Pos = self:LocalToWorld( Vector(160,49 * Mirror,-10) )
	ent:SetPos( Pos )
	ent:SetAngles( (tr.HitPos - Pos):Angle() )
	ent:Spawn()
	ent:Activate()
	ent:SetAttacker( self:GetDriver() )
	ent:SetInflictor( self )
	ent:SetStartVelocity( self:GetVelocity():Length() )
	ent:SetDirtyMissile( false )
	
	if tr.Hit then
		local Target = tr.Entity
		if IsValid( Target ) then
			if Target:GetClass():lower() ~= "lunasflightschool_missile" then
				ent:SetLockOn( Target )
				ent:SetStartVelocity( 0 )
			end
		end
	end
	
	constraint.NoCollide( ent, self, 0, 0 ) 
end

function ENT:HandleWeapons(Fire1, Fire2)
	local Driver = self:GetDriver()
	
	if IsValid( Driver ) then
		if self:GetAmmoPrimary() > 0 then
			Fire1 = Driver:KeyDown( IN_ATTACK )
		end
		if self:GetAmmoSecondary() > 0 then
			Fire2 = Driver:KeyDown( IN_ATTACK2 )
		end
	end
	
	if Fire1 then
		self:PrimaryAttack()
	end
	
	if Fire2 then
		self:SecondaryAttack()
	end
end

function ENT:RunOnSpawn()
	self:PlayAnimation("action_bac")
	self:SetLGear( 1 )
	self.LandingGearUp = false
end

function ENT:OnLandingGearToggled( bOn )
	self:EmitSound( "vehicles/tank_readyfire1.wav" )
	if bOn then
	 	 self:PlayAnimation("action_for")
    else
	     self:PlayAnimation("action_bac")
   end
end

function ENT:HandleLandingGear()
	local Driver = self:GetDriver()
	if IsValid( Driver ) then
		local KeyJump = Driver:KeyDown( IN_JUMP )
		if self.OldKeyJump ~= KeyJump then
			self.OldKeyJump = KeyJump
			if KeyJump then
				self:ToggleLandingGear()
				self:PhysWake()
			end
		end
	end
	local TVal = self.LandingGearUp and 0 or 1
	local Speed = FrameTime() * 0.5
	self:SetLGear( self:GetLGear() + math.Clamp(TVal - self:GetLGear(),-Speed,Speed) )
	if istable( self.LandingGearPlates ) then
		for _, v in pairs( self.LandingGearPlates ) do
			if IsValid( v ) then
				local pObj = v:GetPhysicsObject()
				if IsValid( pObj ) then
					pObj:SetMass( 1 + 2000 * self:GetLGear() ^ 10 )
				end
			end
		end
	end
end

function ENT:InitWheels()
	local GearPlates = {
		Vector(60,0,-45),
		Vector(-60,-30,-45),
		Vector(-60,30,-45),
	}
	self.LandingGearPlates = {}
	for _, v in pairs( GearPlates ) do
		local Plate = ents.Create( "prop_physics" )
		if IsValid( Plate ) then
			Plate:SetPos( self:LocalToWorld( v ) )
			Plate:SetAngles( self:LocalToWorldAngles( Angle(0,0,0) ) )
			Plate:SetModel( "models/hunter/plates/plate05x05.mdl" )
			Plate:Spawn()
			Plate:Activate()
			Plate:SetNoDraw( true )
			Plate:DrawShadow( false )
			Plate.DoNotDuplicate = tru
			local pObj = Plate:GetPhysicsObject()
			if not IsValid( pObj ) then
				self:Remove()
				return
			end
			pObj:EnableMotion(false)
			pObj:SetMass( 1500 )
			table.insert( self.LandingGearPlates, Plate )
			self:DeleteOnRemove( Plate )
			self:dOwner( Plate )
			constraint.Weld( self, Plate, 0, 0, 0,false, true ) 
			constraint.NoCollide( Plate, self, 0, 0 ) 
			pObj:EnableMotion( true )
			pObj:EnableDrag( false ) 
			Plate:SetPos( self:GetPos() )
		else
			self:Remove()
		end
	end
	timer.Simple( 0.5, function()
		if not IsValid( self ) then return end
		local PObj = self:GetPhysicsObject()
		if IsValid( PObj ) then 
			PObj:EnableMotion( true )
		end
		self:PhysWake() 
	end)
end

function ENT:OnEngineStarted()
self:SetBodygroup( 2, 1 )
end

function ENT:OnEngineStopped()
self:SetBodygroup( 2, 0 )
end

function ENT:CreateAI()
self:SetBodygroup( 1, 1 )
end

function ENT:RemoveAI() 
self:SetBodygroup( 1, 0 )
end