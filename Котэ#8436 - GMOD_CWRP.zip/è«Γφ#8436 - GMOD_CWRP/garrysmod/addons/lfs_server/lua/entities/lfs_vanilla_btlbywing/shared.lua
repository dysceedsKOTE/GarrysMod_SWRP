-- YOU CAN EDIT AND REUPLOAD THIS FILE.
-- HOWEVER MAKE SURE TO RENAME THE FOLDER TO AVOID CONFLICTS

ENT.Type            = "anim"
DEFINE_BASECLASS( "lunasflightschool_basescript" )

ENT.PrintName = "BTL-B Y-Wing Starfighter"
ENT.Author = "VanillaNekoNYAN"
ENT.Information = ""
ENT.Category = "[LFS] Vanilla"

ENT.Spawnable		= true -- set to "true" to make it spawnable
ENT.AdminSpawnable	= false

ENT.MDL = "models/ywing/ywing_btlb_test.mdl" -- model forward direction must be facing to X+

ENT.AITEAM = 2 -- 0 = FFA  1 = bad guys  2 = good guys

ENT.Mass = 2000
ENT.Inertia = Vector(150000,150000,150000)
ENT.Drag = -1

ENT.SeatPos = Vector(310,0,55)
ENT.SeatAng = Angle(0,-90,0)

ENT.IdleRPM = 1
ENT.MaxRPM = 2500
ENT.LimitRPM = 3000

ENT.RotorPos = Vector(0,0,0)
ENT.WingPos = Vector(100,0,0)
ENT.ElevatorPos = Vector(-300,0,0)
ENT.RudderPos = Vector(-300,0,0)

ENT.MaxVelocity = 2100

ENT.MaxThrust = 48000

ENT.MaxTurnPitch = 800
ENT.MaxTurnYaw = 600
ENT.MaxTurnRoll = 300

ENT.MaxPerfVelocity = 1200

ENT.MaxHealth = 1600
ENT.MaxShield = 600

ENT.Stability = 0.7

ENT.VerticalTakeoff = true -- move vertically with landing gear out? REQUIRES ENT.Stability
--ENT.VtolAllowInputBelowThrottle = 10 -- number is in % of throttle. Removes the landing gear dependency. Vtol mode will always be active when throttle is below this number. In this mode up movement is done with "Shift" key instead of W
ENT.MaxThrustVtol = 12000 -- amount of vertical thrust

ENT.MaxPrimaryAmmo = 1500   -- set to a positive number if you want to use weapons. set to -1 if you dont
ENT.MaxSecondaryAmmo = 20 -- set to a positive number if you want to use weapons. set to -1 if you dont

util.PrecacheModel("models/ywing/ywing_btlb_test_cockpit.mdl")
util.PrecacheModel("models/ywing/ywing_btlb_turret.mdl")
util.PrecacheModel("models/ywing/ywing_btlb_guns.mdl")

function ENT:AddDataTables() -- use this to add networkvariables instead of ENT:SetupDataTables().
	--[[DO NOT USE SLOTS SMALLER THAN 10]]--
end

sound.Add( {
	name = "VANILLA_BTLBWYING_HUM",
	channel = CHAN_STATIC,
	volume = 0.8,
	level = 125,
	sound = "vanilla/btlbywing/vanilla_ywing_dist.wav"
} )

sound.Add( {
	name = "VANILLA_BTLBWYING_ENG",
	channel = CHAN_STATIC,
	volume = 0.8,
	level = 125,
	sound = "vanilla/btlbywing/vanilla_ywing_eng.wav"
} )

sound.Add( {
	name = "VANILLA_BTLBWYING_FIRE",
	channel = CHAN_WEAPON,
	volume = 0.3,
	level = 125,
	pitch = {95, 98},
	sound = "vanilla/btlbywing/vanilla_ywing_wep2.wav"
} )

sound.Add( {
	name = "VANILLA_BTLBWYING_FIRE2",
	channel = CHAN_WEAPON,
	volume = 0.8,
	level = 125,
	pitch = {95, 98},
	sound = "vanilla/btlbywing/vanilla_ywing_fire2.wav"
} )
