-- YOU CAN EDIT AND REUPLOAD THIS FILE.
-- HOWEVER MAKE SURE TO RENAME THE FOLDER TO AVOID CONFLICTS

include("shared.lua")

local mat = Material( "sprites/light_glow02_add" )

function ENT:Initialize()
	self:SpawnvCockpit()
	self:SpawnvTurret()
	self:SpawnvGuns()
end

function ENT:Draw()
	self:DrawModel()
	self.vCockpit:DrawModel()
	self.vTurret:DrawModel()
	self.vGuns:DrawModel()

	if not self:GetEngineActive() then return end

	local Boost = self.BoostAdd or 0

	local Size = 100 + (self:GetRPM() / self:GetLimitRPM()) * 100 + Boost

	render.SetMaterial( mat )
	render.DrawSprite( self:LocalToWorld( Vector(-620,240,60) ), Size, Size, Color( 255, 25, 25, 255) )
	render.DrawSprite( self:LocalToWorld( Vector(-620,-240,60) ), Size, Size, Color( 255, 25, 25, 255) )
end

function ENT:LFSCalcViewFirstPerson( view, ply ) -- modify first person camera view here
	--[[
	if ply == self:GetDriver() then
		-- driver view
	elseif ply == self:GetGunner() then
		-- gunner view
	else
		-- everyone elses view
	end
	]]--

	return view
end

function ENT:LFSCalcViewThirdPerson( view, ply ) -- modify third person camera view here
	local ply = LocalPlayer()

	local Pod = ply:GetVehicle()

	if not IsValid( Pod ) then return view end

	if ply == self:GetDriver() then
		local radius = 850
		radius = radius + radius * Pod:GetCameraDistance()

		view.origin = self:LocalToWorld( Vector(0,0,0) )

		local TargetOrigin = view.origin - view.angles:Forward() * radius  + view.angles:Up() * 1250 * 0.2
		local WallOffset = 1

		local tr = util.TraceHull( {
			start = view.origin,
			endpos = TargetOrigin,
			filter = function( e )
				local c = e:GetClass()
				local collide = not c:StartWith( "prop_physics" ) and not c:StartWith( "prop_dynamic" ) and not c:StartWith( "prop_ragdoll" ) and not e:IsVehicle() and not c:StartWith( "gmod_" ) and not c:StartWith( "player" ) and not e.LFS

				return collide
			end,
			mins = Vector( -WallOffset, -WallOffset, -WallOffset ),
			maxs = Vector( WallOffset, WallOffset, WallOffset ),
		} )

		view.origin = tr.HitPos

		if tr.Hit and not tr.StartSolid then
			view.origin = view.origin + tr.HitNormal * WallOffset
		end

		return view
	end
end


function ENT:DamageFX()

	local HP = self:GetHP()

	if HP == 0 or HP > self:GetMaxHP() * 0.5 then return end



	self.nextDFX = self.nextDFX or 0



	if self.nextDFX < CurTime() then

		self.nextDFX = CurTime() + 0.05



		local effectdata = EffectData()

			effectdata:SetOrigin( self:GetPos() - self:GetForward() * 500 + self:GetRight() * 250 + self:GetUp() * 50 )

		util.Effect( "lfs_blacksmoke", effectdata )

		local effectdata2 = EffectData()
			effectdata2:SetOrigin( self:GetPos() - self:GetUp() * 10 )
		util.Effect( "lfs_blacksmoke", effectdata2 )

	end

end

function ENT:LFSHudPaint( X, Y, data, ply ) -- driver only
end

function ENT:LFSHudPaintPassenger( X, Y, ply ) -- all except driver
	surface.SetDrawColor(255,255,255,255)
	surface.DrawLine(ScrW() / 2 - 25,ScrH() / 2,ScrW() / 2 - 15,ScrH() / 2)
	surface.DrawLine(ScrW() / 2 + 25,ScrH() / 2,ScrW() / 2 + 15,ScrH() / 2)
	surface.DrawLine(ScrW() / 2,ScrH() / 2 + 25,ScrW() / 2,ScrH() / 2 + 15)
	surface.DrawLine(ScrW() / 2,ScrH() / 2 - 25,ScrW() / 2,ScrH() / 2 - 15)
	surface.DrawCircle(ScrW() / 2,ScrH() / 2,15,255,255,255,255)
end

function ENT:CalcEngineSound( RPM, Pitch, Doppler )
	if self.ENG then
		self.ENG:ChangePitch(  math.Clamp( 60 + Pitch * 40 + Doppler,0,255) )
		self.ENG:ChangeVolume( math.Clamp( Pitch, 0.5,1) )
	end
end

function ENT:EngineActiveChanged( bActive )
	if bActive then
		self.ENG = CreateSound(self,"VANILLA_BTLBWYING_ENG")
		self.ENG:PlayEx(0,0)
		self.DIST = CreateSound(self,"VANILLA_BTLBWYING_HUM")
		self.DIST:PlayEx(0,0)
	else
		self:SoundStop()
	end
end

function ENT:SpawnvCockpit()
	self.vCockpit = ents.CreateClientProp("models/ywing/ywing_btlb_test_cockpit.mdl")
	self.vCockpit:SetPos(self:GetPos() + Vector(5,0,0))
	self.vCockpit:SetAngles(self:GetAngles())
	self.vCockpit:SetParent(self)
	self.vCockpit:SetNoDraw(true)
	self.vCockpit:Spawn()
end

function ENT:SpawnvTurret()
	self.vTurret = ents.CreateClientProp("models/ywing/ywing_btlb_turret.mdl")
	self.vTurret:SetPos(self:GetPos() + Vector(257,0,102))
	self.vTurret:SetAngles(self:GetAngles())
	self.vTurret:SetParent(self)
	self.vTurret:SetNoDraw(true)
	self.vTurret:Spawn()
end

function ENT:SpawnvGuns()
	self.vGuns = ents.CreateClientProp("models/ywing/ywing_btlb_guns.mdl")
	self.vGuns:SetPos(self.vTurret:GetPos() + Vector(-17,0,8))
	self.vGuns:SetAngles(self.vTurret:GetAngles())
	self.vGuns:SetParent(self.vTurret)
	self.vGuns:SetNoDraw(true)
	self.vGuns:Spawn()
end


function ENT:OnRemove()
	self:SoundStop()

	if IsValid( self.TheRotor ) then -- if we have an rotor
		self.TheRotor:Remove() -- remove it
	end

	if IsValid( self.vGuns ) then -- if we have an rotor
		self.vGuns:Remove() -- remove it
	end

	if IsValid( self.vTurret ) then -- if we have an rotor
		self.vTurret:Remove() -- remove it
	end

	if IsValid( self.vCockpit ) then -- if we have an rotor
		self.vCockpit:Remove() -- remove it
	end
end

function ENT:SoundStop()
	if self.ENG then
		self.ENG:Stop()
	end
end

function ENT:AnimFins()
	local Driver = self:GetDriver()
	local Gunner = self:GetGunner()

	local HasGunner = IsValid( Gunner )

	if not IsValid( Driver ) and not HasGunner then return end

	if HasGunner then Driver = Gunner end

	local EyeAngles = self:WorldToLocalAngles( Driver:EyeAngles() )
	EyeAngles:RotateAroundAxis( EyeAngles:Up(), 180 )

	local Yaw = math.Clamp( EyeAngles.y,-45,45)
	local Pitch = math.Clamp( EyeAngles.p,-15,15 )

	if not Driver:KeyDown( IN_WALK ) and not HasGunner then
		Yaw = 0
		Pitch = 0
	end

	local vanAngle = Angle(Pitch,Yaw,0)

	self.vGuns:SetAngles((Angle(self.vTurret:GetAngles())) + vanAngle)

	--self.vTurret:SetAngles((self:GetAngles())+(Angle(0,Yaw,0)))
	self.vTurret:SetAngles(self:GetAngles())
end

function ENT:AnimCabin()
end

function ENT:AnimLandingGear()
	--[[ function gets called each frame by the base script. you can do whatever you want here ]]--
end

function ENT:ExhaustFX()
	--[[ function gets called each frame by the base script. you can do whatever you want here ]]--
end
