-- YOU CAN EDIT AND REUPLOAD THIS FILE.
-- HOWEVER MAKE SURE TO RENAME THE FOLDER TO AVOID CONFLICTS
AddCSLuaFile( "shared.lua" )
AddCSLuaFile( "cl_init.lua" )
include("shared.lua")

function ENT:SpawnFunction( ply, tr, ClassName ) -- called by garry
	if not tr.Hit then return end

	local ent = ents.Create( ClassName )
	ent:SetPos( tr.HitPos + tr.HitNormal * 20 ) -- spawn 20 units above ground
	ent:Spawn()
	ent:Activate()

	return ent
end

function ENT:OnTick() -- use this instead of "think"
	self.AstroAng = self.AstroAng or 0
	self.nextAstro = self.nextAstro or 0
	if self.nextAstro < CurTime() then
		self.nextAstro = CurTime() + math.Rand(0.5,2)
		self.AstroAng = math.Rand(-180,180)

		if math.random(0,8) == 4 then
			self:EmitSound( "lfs/naboo_n1_starfighter/astromech/" .. math.random(1,11) .. ".ogg" )
		end
	end
end

function ENT:RunOnSpawn() -- called when the vehicle is spawned
	local SpawnedPod = self:AddPassengerSeat( Vector(257,0,85), Angle(0,90,0) ) -- add a passenger seat, store it inside "SpawnedPod" local variable

	SpawnedPod.ExitPos = Vector(257,0,110)  -- assigns an exit pos for SpawnedPod

	self:SetGunnerSeat( SpawnedPod ) -- set our SpawnedPod as gunner seat using the inbuild gunner functions.
							-- Gunner seat will automatically trigger crosshair enable for the player who is sitting in it.
							-- You can get the player who sitting in this pod using self:GetGunner()
							-- If you want to add more gunners you will have to write your own functions
end

function ENT:OnRemove()
end

function ENT:SetNextAltPrimary( delay )
	self.NextAltPrimary = CurTime() + delay
end

function ENT:CanAltPrimaryAttack()
	self.NextAltPrimary = self.NextAltPrimary or 0
	return self.NextAltPrimary < CurTime()
end

function ENT:AltPrimaryAttack( Driver, Pod )

	if not self:CanAltPrimaryAttack() then return end

	if not IsValid( Pod ) then Pod = self:GetDriverSeat() end
	if not IsValid( Driver ) then Driver = Pod:GetDriver() end

	if not IsValid( Pod ) then return end
	if not IsValid( Driver ) then return end

	local EyeAngles = Pod:WorldToLocalAngles( Driver:EyeAngles() )
	local Forward = -self:GetForward()

	local AimDirToForwardDir = math.deg( math.acos( math.Clamp( Forward:Dot( EyeAngles:Forward() ) ,-1,1) ) )
	if AimDirToForwardDir > 50 then return end

	self:EmitSound( "VANILLA_BTLBWYING_FIRE" )

	self:SetNextAltPrimary( 0.25 )

	local startpos =  self:GetRotorPos()
	local TracePlane = util.TraceHull( {
		start = startpos,
		endpos = startpos + EyeAngles:Forward() * 50000,
		mins = Vector( -10, -10, -10 ),
		maxs = Vector( 10, 10, 10 ),
		filter = self
	} )

	self.MirrorPrimary = not self.MirrorPrimary

	local fp = { Vector(200,20,115),Vector(200,-20,115) }

	self.NumPrim = self.NumPrim and self.NumPrim + 1 or 1
	if self.NumPrim > 2 then self.NumPrim = 1 end

	local bullet = {}
	bullet.Num 	= 1
	bullet.Src 	= self:LocalToWorld(fp[self.NumPrim])
	bullet.Dir 	= (TracePlane.HitPos - bullet.Src):GetNormalized()
	bullet.Spread 	= Vector( 0.04,  0.04, 0 )
	bullet.Tracer	= 1
	bullet.TracerName	= "lfs_laser_blue"
	bullet.Force	= 100
	bullet.HullSize 	= 20
	bullet.Damage	= 125
	bullet.Attacker 	= Driver
	bullet.AmmoType = "Pistol"
	bullet.Callback = function(att, tr, dmginfo)
		dmginfo:SetDamageType(DMG_AIRBOAT)
	end
	self:FireBullets( bullet )
end


function ENT:PrimaryAttack()
	if not self:CanPrimaryAttack() then return end

	self:SetNextPrimary( 0.25 )

	--[[ do primary attack code here ]]--
	self:EmitSound( "VANILLA_BTLBWYING_FIRE" )

	local Driver = self:GetDriver()

	local fp = { Vector(450,-22,47),Vector(450,22,47) }

	self.NumPrim = self.NumPrim and self.NumPrim + 1 or 1
	if self.NumPrim > 2 then self.NumPrim = 1 end

	local bullet = {}
	bullet.Num 	= 1
	bullet.Src 	= self:LocalToWorld(fp[self.NumPrim])
	bullet.Dir 	= self:GetForward()
	bullet.Spread 	= Vector( 0.015,  0.015, 0 )
	bullet.Tracer	= 1
	bullet.TracerName	= "lfs_laser_blue"
	bullet.Force	= 10
	bullet.HullSize 	= 5
	bullet.Damage	= 20
	bullet.Attacker 	= Driver
	bullet.AmmoType = "Pistol"

	self:FireBullets( bullet )

	self:TakePrimaryAmmo()
end

function ENT:SecondaryAttack()
	if not self:CanSecondaryAttack() then return end

	self:SetNextSecondary( 0.5 )

	self:TakeSecondaryAmmo()

	self:EmitSound( "VANILLA_BTLBWYING_FIRE2" )

	self.MirrorSecondary = not self.MirrorSecondary

	local Mirror = self.MirrorSecondary and -1 or 1

	local startpos =  self:GetRotorPos()
	local tr = util.TraceHull( {
		start = startpos,
		endpos = startpos + self:GetForward() * 50000,
		mins = Vector( -40, -40, -40 ),
		maxs = Vector( 40, 40, 40 ),
		filter = function( e )
			local collide = e ~= self
			return collide
		end
	} )

	local ent = ents.Create( "lunasflightschool_missile" )
	local Pos = self:LocalToWorld( Vector(98.49,-24.94 * Mirror,47.94) )
	ent:SetPos( Pos )
	ent:SetAngles( (tr.HitPos - Pos):Angle() )
	ent:Spawn()
	ent:Activate()
	ent:SetAttacker( self:GetDriver() )
	ent:SetInflictor( self )
	ent:SetStartVelocity(self:GetVelocity():Length())
	ent:SetDirtyMissile( true )

	if tr.Hit then
		local Target = tr.Entity
		if IsValid( Target ) and Target:GetClass():lower() ~= "lunasflightschool_missile" then
			ent:SetLockOn( Target )
			ent:SetStartVelocity( 0 )
		end
	end

	constraint.NoCollide( ent, self, 0, 0 )
end

function ENT:HandleWeapons(Fire1, Fire2)
	local Driver = self:GetDriver()
	local Gunner = self:GetGunner()
	local HasGunner = IsValid( Gunner )

	local FireTurret = false

	if IsValid( Driver ) then
		if self:GetAmmoPrimary() > 0 then
			Fire1 = Driver:KeyDown( IN_ATTACK )
		end

		FireTurret = Driver:KeyDown( IN_WALK )

		if self:GetAmmoSecondary() > 0 then
			Fire2 = Driver:KeyDown( IN_ATTACK2 )
		end
	end

	if Fire1 then
		if FireTurret and not HasGunner then
			self:AltPrimaryAttack()
		else
			self:PrimaryAttack()
		end
	end

	if HasGunner and Gunner:KeyDown( IN_ATTACK ) then
		self:AltPrimaryAttack( Gunner, self:GetGunnerSeat() )
	end

	if self.OldFire2 ~= Fire2 then
		if Fire2 then
			self:SecondaryAttack()
		end
		self.OldFire2 = Fire2
	end
end

function ENT:CreateAI() -- called when the ai gets enabled
end

function ENT:RemoveAI() -- called when the ai gets disabled
end

function ENT:OnKeyThrottle( bPressed )
	--if self:CanSound() then -- makes sure the player cant spam sounds
		--if bPressed then -- if throttle key is pressed
			--self:EmitSound( "buttons/button3.wav" )
			--self:DelayNextSound( 1 ) -- when the next sound should be allowed to be played
		--else
			--self:EmitSound( "buttons/button11.wav" )
			--self:DelayNextSound( 0.5 )
		--end
	--end
end

--[[
function ENT:ApplyThrustVtol( PhysObj, vDirection, fForce )
	PhysObj:ApplyForceOffset( vDirection * fForce,  self:GetElevatorPos() )
	PhysObj:ApplyForceOffset( vDirection * fForce,  self:GetWingPos() )
end

function ENT:ApplyThrust( PhysObj, vDirection, fForce )
	PhysObj:ApplyForceOffset( vDirection * fForce, self:GetRotorPos() )
end
]]--

function ENT:OnEngineStarted()
	--[[ play engine start sound? ]]--
end

function ENT:OnEngineStopped()
	--[[ play engine stop sound? ]]--
end

function ENT:OnVtolMode( IsOn )
	--[[ called when vtol mode is activated / deactivated ]]--
end

function ENT:OnLandingGearToggled( bOn )
	self:EmitSound( "vehicles/tank_readyfire1.wav" )

	--if bOn then
		--[[ set bodygroup of landing gear down? ]]--
	--else
		--[[ set bodygroup of landing gear up? ]]--
	--end
end
