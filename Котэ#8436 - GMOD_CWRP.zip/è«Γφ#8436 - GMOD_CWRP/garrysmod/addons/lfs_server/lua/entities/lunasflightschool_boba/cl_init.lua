
include("shared.lua")

function ENT:LFSCalcViewFirstPerson( view, ply )
	if ply == self:GetDriver() or ply == self:GetGunner() then return view end -- dont change view if the player is pilot or copilot
	
	local Pod = ply:GetVehicle()
	
	if not IsValid( Pod ) then return view end
	
	local radius = 930
	
	local TargetOrigin = self:LocalToWorld( Vector(0,0,550) ) - view.angles:Forward() * radius  + view.angles:Up() * radius * 0.1
	local WallOffset = 4

	local tr = util.TraceHull( {
		start = view.origin,
		endpos = TargetOrigin,
		filter = function( e )
			local c = e:GetClass()
			local collide = not c:StartWith( "prop_physics" ) and not c:StartWith( "prop_dynamic" ) and not c:StartWith( "prop_ragdoll" ) and not e:IsVehicle() and not c:StartWith( "gmod_" ) and not c:StartWith( "player" ) and not e.LFS
			
			return collide
		end,
		mins = Vector( -WallOffset, -WallOffset, -WallOffset ),
		maxs = Vector( WallOffset, WallOffset, WallOffset ),
	} )
	
	view.origin = tr.HitPos
	
	if tr.Hit and not tr.StartSolid then
		view.origin = view.origin + tr.HitNormal * WallOffset
	end
	
	return view
end

function ENT:LFSCalcViewThirdPerson( view, ply )
	local ply = LocalPlayer()
	if ply == self:GetDriver() then 
	
	local Pod = ply:GetVehicle()
	
	if not IsValid( Pod ) then return view end
	
	local radius = 930
	
	local TargetOrigin = self:LocalToWorld( Vector(0,0,550) ) - view.angles:Forward() * radius  + view.angles:Up() * radius * 0.1
	local WallOffset = 4

	local tr = util.TraceHull( {
		start = view.origin,
		endpos = TargetOrigin,
		filter = function( e )
			local c = e:GetClass()
			local collide = not c:StartWith( "prop_physics" ) and not c:StartWith( "prop_dynamic" ) and not c:StartWith( "prop_ragdoll" ) and not e:IsVehicle() and not c:StartWith( "gmod_" ) and not c:StartWith( "player" ) and not e.LFS
			
			return collide
		end,
		mins = Vector( -WallOffset, -WallOffset, -WallOffset ),
		maxs = Vector( WallOffset, WallOffset, WallOffset ),
	} )
	
	view.origin = tr.HitPos
	
	if tr.Hit and not tr.StartSolid then
		view.origin = view.origin + tr.HitNormal * WallOffset
	end
	
	return view
end

	return self:LFSCalcViewFirstPerson( view, ply ) -- lets call the first person camera function so we dont have to do the same code twice. This will force the same view for both first and thirdperson
end

function ENT:ExhaustFX()
	if not self:GetEngineActive() then return end
	
	self.nextEFX = self.nextEFX or 0
	
	local THR = (self:GetRPM() - self.IdleRPM) / (self.LimitRPM - self.IdleRPM)
	
	local Driver = self:GetDriver()
	if IsValid( Driver ) then
		local W = Driver:KeyPressed( IN_FORWARD )
		if W ~= self.oldW then
			self.oldW = W
			if W then
				self.BoostAdd = 80
			end
		end
	end
	
	self.BoostAdd = self.BoostAdd and (self.BoostAdd - self.BoostAdd * FrameTime()) or 0
end

function ENT:CalcEngineSound( RPM, Pitch, Doppler )
	if self.ENG then
		self.ENG:ChangePitch(  math.Clamp(math.Clamp(  60 + Pitch * 50, 80,255) + Doppler,0,255) )
		self.ENG:ChangeVolume( math.Clamp( -1 + Pitch * 6, 0.5,1) )
	end
	
	if self.DIST then
		self.DIST:ChangePitch(  math.Clamp(math.Clamp(  Pitch * 100, 50,255) + Doppler * 1.25,0,255) )
		self.DIST:ChangeVolume( math.Clamp( -1.5 + Pitch * 6, 0.5,1) )
	end
end

function ENT:EngineActiveChanged( bActive )
	if bActive then
		self.ENG = CreateSound( self, "SLAVEI_ENGINE" )
		self.ENG:PlayEx(0,0)
		
		self.DIST = CreateSound( self, "SLAVEI_DIST" )
		self.DIST:PlayEx(0,0)
	else
		self:SoundStop()
	end
end

function ENT:OnRemove()
	self:SoundStop()
end

function ENT:SoundStop()
	if self.DIST then
		self.DIST:Stop()
	end
	
	if self.ENG then
		self.ENG:Stop()
	end
end

function ENT:AnimFins()
end

function ENT:AnimRotor()
end

function ENT:AnimCabin()
end

function ENT:AnimLandingGear()
end

local mat = Material( "sprites/light_glow02_add" )
function ENT:Draw()
	self:DrawModel()
	
	if not self:GetEngineActive() then return end
	
	local Boost = self.BoostAdd or 0
	
	local Size = 400 + (self:GetRPM() / self:GetLimitRPM()) * 40 + Boost

	render.SetMaterial( mat )
	render.DrawSprite( self:LocalToWorld( Vector(-155,-46,313.5) ), Size, Size, Color( 255, 240, 150, 255) )
	render.DrawSprite( self:LocalToWorld( Vector(-155,44,313.5) ), Size, Size, Color( 255, 240, 150, 255) )
	render.DrawSprite( self:LocalToWorld( Vector(-158,50,408.6) ), Size, Size, Color( 255, 240, 150, 255) )	
	render.DrawSprite( self:LocalToWorld( Vector(-158,15,408.6) ), Size, Size, Color( 255, 240, 150, 255) )	
	render.DrawSprite( self:LocalToWorld( Vector(-158,-15,408.6) ), Size, Size, Color( 255, 240, 150, 255) )	
	render.DrawSprite( self:LocalToWorld( Vector(-158,-50,408.6) ), Size, Size, Color( 255, 240, 150, 255) )	
end

