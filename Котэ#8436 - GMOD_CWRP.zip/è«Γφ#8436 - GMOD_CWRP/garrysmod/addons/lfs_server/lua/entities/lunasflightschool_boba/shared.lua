
ENT.Type            = "anim"
DEFINE_BASECLASS( "lunasflightschool_basescript" )

ENT.PrintName = "Slave I (Boba Fett)"
ENT.Author = "ϟLightning Boltϟ"
ENT.Information = ""
ENT.Category = "[LFS] Star Wars"

ENT.Spawnable		= true
ENT.AdminSpawnable		= false

ENT.MDL = "models/firespray/firespray1.mdl"

ENT.GibModels = {
	"models/XQM/wingpiece2.mdl",
	"models/XQM/wingpiece2.mdl",
	"models/XQM/jetwing2medium.mdl",
	"models/XQM/jetwing2medium.mdl",
	"models/props_c17/TrapPropeller_Engine.mdl",
	"models/props_junk/Shoe001a.mdl",
	"models/XQM/jetbody2fuselage.mdl",
	"models/XQM/jettailpiece1medium.mdl",
	"models/XQM/pistontype1huge.mdl",
}

ENT.AITEAM = 1

ENT.Mass = 5000
ENT.Inertia = Vector(900000,900000,900000)
ENT.Drag = -1

ENT.SeatPos = Vector(15,-1,360)
ENT.SeatAng = Angle(0,-92,0)

ENT.IdleRPM = 0
ENT.MaxRPM = 2700
ENT.LimitRPM = 3200

ENT.RotorPos = Vector(20,0,390)
ENT.WingPos = Vector(120.47,0,370)
ENT.ElevatorPos = Vector(-410,0,380)
ENT.RudderPos = Vector(-410,0,380)

ENT.MaxVelocity = 3200

ENT.MaxThrust = 80000

ENT.MaxTurnPitch = 870
ENT.MaxTurnYaw = 600
ENT.MaxTurnRoll = 200

ENT.MaxPerfVelocity = 1500

ENT.MaxHealth = 6000
ENT.MaxShield = 2300

ENT.Stability = 1

ENT.MaxPrimaryAmmo = 3000
ENT.MaxSecondaryAmmo = 20

ENT.VerticalTakeoff = true
ENT.VtolAllowInputBelowThrottle = 10
ENT.MaxThrustVtol = 10000

sound.Add( {
	name = "SLAVEI_FIRE",
	channel = CHAN_ITEM,
	volume = 1.0,
	level = 125,
	pitch = {97, 97},
	sound = "lfs/slaveI/Firespray Laser 1A2.mp3"
} )

sound.Add( {
	name = "SLAVEI_FIRE2",
	channel = CHAN_WEAPON,
	volume = 1.0,
	level = 125,
	pitch = {95, 105},
    sound = "lfs/naboo_n1_starfighter/proton_fire.mp3"
} )

sound.Add( {
	name = "SLAVEI_ENGINE",
	channel = CHAN_STATIC,
	volume = 1.0,
	level = 125,
	sound = "lfs/slaveI/slave1_fly_loop.wav"
} )

sound.Add( {
	name = "SLAVEI_DIST",
	channel = CHAN_STATIC,
	volume = 1.0,
	level = 125,
	sound = "lfs/slaveI/Slave I EXT.wav"
} )

sound.Add( {
	name = "SLAVEI_BOOST",
	channel = CHAN_STATIC,
	volume = 1.0,
	level = 125,
	sound = "lfs/slaveI/Slave I Accelerate.mp3"
} )

sound.Add( {
	name = "SLAVEI_BRAKE",
	channel = CHAN_STATIC,
	volume = 1.0,
	level = 125,
	sound = "lfs/slaveI/Slave I Hiss 1C.mp3"
} )
