AddCSLuaFile( "shared.lua" )
AddCSLuaFile( "cl_init.lua" )
include("shared.lua")

function ENT:PrimaryAttack()
	if self:GetIsCarried() then return end
	if not self:CanPrimaryAttack() or not self.MainGunDir then return end

	local ID1 = self:LookupAttachment( "muzzle_left" )
	local ID2 = self:LookupAttachment( "muzzle_right" )

	local Muzzle1 = self:GetAttachment( ID1 )
	local Muzzle2 = self:GetAttachment( ID2 )
	
	if not Muzzle1 or not Muzzle2 then return end
	
	local FirePos = {
		[1] = Muzzle1,
		[2] = Muzzle2,
	}
	
	self.FireIndex = self.FireIndex and self.FireIndex + 1 or 1
	
	if self.FireIndex > 2 then
		self.FireIndex = 1
		self:SetNextPrimary( 0 )
	else
		if self.FireIndex == 2 then
			self:SetNextPrimary( 0.5 )
		else
			self:SetNextPrimary( 0 )
		end
	end
	
	self:EmitSound( "TX_FIRE" )

	local Pos = FirePos[self.FireIndex].Pos
	local Dir =  FirePos[self.FireIndex].Ang:Up()
	
		if math.deg( math.acos( math.Clamp( Dir:Dot( self.MainGunDir ) ,-1,1) ) ) < 8 then
		Dir = self.MainGunDir
	end
	
	local bullet = {}
	bullet.Num 	= 1
	bullet.Src 	= Pos
	bullet.Dir 	= Dir
	bullet.Spread 	= Vector( 0.01,  0.01, 0 )
	bullet.Tracer	= 1
	bullet.TracerName	= "lfs_laser_blue"
	bullet.Force	= 100
	bullet.HullSize 	= 22
	bullet.Damage	= 150
	bullet.Attacker 	= self:GetDriver()
	bullet.AmmoType = "Pistol"
	bullet.Callback = function(att, tr, dmginfo)
		if tr.Entity.IsSimfphyscar then
			dmginfo:SetDamageType(DMG_DIRECT)
		else
			dmginfo:SetDamageType(DMG_AIRBOAT)
		end
	end
	self:FireBullets( bullet )
	
	self:PlayAnimation( "fire_gun" )
	self:TakePrimaryAmmo()
end

function ENT:SecondaryAttack()
	if self:GetIsCarried() then return end
	if not self:CanAltSecondaryAttack() or not self.MainGunDir then return end
	if self:GetLGear() > 0.01 then return end

	local ID1 = self:LookupAttachment( "left_launch_tube_1" )
	local ID2 = self:LookupAttachment( "right_launch_tube_1" )
	local ID3 = self:LookupAttachment( "left_launch_tube_2" )
	local ID4 = self:LookupAttachment( "right_launch_tube_2" )
	local ID5 = self:LookupAttachment( "left_launch_tube_3" )
	local ID6 = self:LookupAttachment( "right_launch_tube_3" )

	local Muzzle1 = self:GetAttachment( ID1 )
	local Muzzle2 = self:GetAttachment( ID2 )
	local Muzzle3 = self:GetAttachment( ID3 )
	local Muzzle4 = self:GetAttachment( ID4 )
	local Muzzle5 = self:GetAttachment( ID5 )
	local Muzzle6 = self:GetAttachment( ID6 )
	
	if not Muzzle1 or not Muzzle2 then return end
	
	local FirePos = {
		[1] = Muzzle1,
		[2] = Muzzle2,
		[3] = Muzzle3,
		[4] = Muzzle4,
		[5] = Muzzle5,
		[6] = Muzzle6,
	}
	
	self.FireIndex = self.FireIndex and self.FireIndex + 1 or 1
	
	if self.FireIndex > 6 then
		self.FireIndex = 1
		self:SetNextAltSecondary( 1 )
	else
		if self.FireIndex == 6 then
			self:SetNextAltSecondary( 3 )
		else
			self:SetNextAltSecondary( 1 )
		end
	end
	
	self:EmitSound( "TX_ROCKET" )

	local Pos = FirePos[self.FireIndex].Pos
	local Dir =  FirePos[self.FireIndex].Ang:Up()
	
	if math.deg( math.acos( math.Clamp( Dir:Dot( self.MainGunDir ) ,-1,1) ) ) < 8 then
		Dir = self.MainGunDir
	end
	
	local ent = ents.Create( "lunasflightschool_tx130_missile" )
	ent:SetPos( Pos )
	ent:SetAngles( Dir:Angle() )
	ent:Spawn()
	ent:Activate()
	ent:SetAttacker( self:GetTurretDriver() )
	ent:SetInflictor( self )
	ent:SetStartVelocity( 10000 )
	ent:SetCleanMissile( true )
	
	constraint.NoCollide( ent, self, 0, 0 )
	
	self:TakeSecondaryAmmo()
end

function ENT:MainGunPoser( EyeAngles )
	
	self.MainGunDir = EyeAngles:Forward()
	
	local startpos = self:GetRotorPos()
	local TracePlane = util.TraceHull( {
		start = startpos,
		endpos = (startpos + self.MainGunDir * 50000),
		mins = Vector( -10, -10, -10 ),
		maxs = Vector( 10, 10, 10 ),
		filter = {self}
	} )
	
	local AimAngles = self:WorldToLocalAngles( (TracePlane.HitPos - self:LocalToWorld( Vector(11.962392,0,115.135384)) ):GetNormalized():Angle() )
	
	self:SetPoseParameter("sidegun_pitch", AimAngles.p )

	local ID = self:LookupAttachment( "muzzle_left" )
	local Muzzle = self:GetAttachment( ID )
	
	if Muzzle then
		self:SetFrontInRange( math.deg( math.acos( math.Clamp( Muzzle.Ang:Up():Dot( self.MainGunDir ) ,-1,1) ) ) < 15 )
	end
end

function ENT:OnTick()
	local Pod = self:GetDriverSeat()
	if not IsValid( Pod ) then return end
	
	local Driver = Pod:GetDriver()
	
	local FT = FrameTime()
	
	local PObj = self:GetPhysicsObject()
	local MassCenterL = PObj:GetMassCenter()	
	local MassCenter = self:LocalToWorld( MassCenterL )
	self:SetMassCenter( MassCenter )
	
	local Forward = self:GetForward()
	local Right = self:GetRight()
	local Up = self:GetUp()
	
	self:DoTrace()
	
	local Trace = self.GroundTrace
	if self.WaterTrace.Fraction <= Trace.Fraction and !self.IgnoreWater and self:GetEngineActive() then
		Trace = self.WaterTrace
	end
	
	local IsOnGround = Trace.Hit and math.deg( math.acos( math.Clamp( Trace.HitNormal:Dot( Vector(0,0,1) ) ,-1,1) ) ) < 70
	PObj:EnableGravity( not IsOnGround )
	
	local EyeAngles = Angle(0,0,0)
	local KeyForward = false
	local KeyBack = false
	local KeyLeft = false
	local KeyRight = false
	
	local Sprint = false
	
	if IsValid( Driver ) then
		EyeAngles = Driver:EyeAngles()
		KeyForward = Driver:lfsGetInput( "+THROTTLE" ) or self.IsTurnMove
		KeyBack = Driver:lfsGetInput( "-THROTTLE" )
		if self.CanMoveSideways then
			KeyLeft = Driver:lfsGetInput( "+ROLL" )
			KeyRight = Driver:lfsGetInput( "-ROLL" )
		end
		
		if KeyBack then
			KeyForward = false
		end
		
		if KeyLeft then
			KeyRight = false
		end
		
		Sprint = Driver:lfsGetInput( "VSPEC" ) or Driver:lfsGetInput( "+PITCH" ) or Driver:lfsGetInput( "-PITCH" )
		
		self:MainGunPoser( Pod:WorldToLocalAngles( EyeAngles ) )
	end
	local MoveSpeed = Sprint and self.BoostSpeed or self.MoveSpeed
	
	if (IsOnGround) then
		local pos = Vector( self:GetPos().x, self:GetPos().y, Trace.HitPos.z + self.HeightOffset)
		local speedVector = Vector(0,0,0)
		
		if IsValid( Driver ) && !Driver:lfsGetInput( "FREELOOK" ) && self:GetEngineActive() then
			local lookAt = Vector(0,-1,0)
			lookAt:Rotate(Angle(0,Pod:WorldToLocalAngles( EyeAngles ).y,0))
			self.StoredForwardVector = lookAt
		else
			local lookAt = Vector(0,-1,0)
			lookAt:Rotate(Angle(0,self:GetAngles().y,0))
			self.StoredForwardVector = lookAt
		end
		
		local ang = self:LookRotation( self.StoredForwardVector, Trace.HitNormal ) - Angle(0,0,90)
		if self:GetEngineActive() then
			speedVector = Forward * ((KeyForward and MoveSpeed or 0) - (KeyBack and MoveSpeed or 0)) + Right * ((KeyLeft and MoveSpeed or 0) - (KeyRight and MoveSpeed or 0))
		end
		
		self.deltaV = LerpVector( self.LerpMultiplier * FT, self.deltaV, speedVector )
		self:SetDeltaV( self.deltaV )
		pos = pos + self.deltaV
		self:SetIsMoving(pos != self:GetPos())
		
		self.ShadowParams.pos = pos
		self.ShadowParams.angle = ang
		PObj:ComputeShadowControl( self.ShadowParams )
	end
	
	local GunnerPod = self:GetGunnerSeat()
	if IsValid( GunnerPod ) then
		local Gunner = GunnerPod:GetDriver()
		if Gunner ~= self:GetGunner() then
			self:SetTurretDriver( Gunner )
		end
	end
	
	local TurretPod = self:GetTurretSeat()
	if IsValid( TurretPod ) then
		local TurretDriver = TurretPod:GetDriver()
		if TurretDriver ~= self:GetTurretDriver() then
			self:SetTurretDriver( TurretDriver )
		end
	end
	self:Gunner( self:GetGunner(), GunnerPod )
	self:Turret( self:GetTurretDriver(), TurretPod )

	
	EndSpeedM = self:GetForwardVelocity()/150
	
	local Driver = self:GetDriver()
	if not IsValid( Driver ) then return end
	
	if not self:GetEngineActive() then return end
	local yaw = Driver:GetVehicle():WorldToLocalAngles( Driver:EyeAngles() )
	local EyeAngles = self:EyeAngles()
	local rot = math.AngleDifference(yaw.y, EyeAngles.y)
	rot = math.Clamp( rot,-10,10)
	local Ang = Angle(0,rot,0)
	self:ManipulateBoneAngles(5, Ang)
	self:ManipulateBoneAngles(13, Ang)
end

function ENT:OnKeyThrottle( bPressed )
	if bPressed then
	self.SMLG = self.SMLG and self.SMLG + (9 *  self:GetLGear() - self.SMLG) * FrameTime() * 0 or 0
	
	local Ang = 9 - self.SMLG
	self:ManipulateBoneAngles( 1, Angle(0,-Ang,0) )
	self:ManipulateBoneAngles( 9, Angle(0,Ang,0) )
	end
	
	if not bPressed then
	self.SMLG = self.SMLG and self.SMLG + (0 *  self:GetLGear() - self.SMLG) * FrameTime() * 0 or 0
	
	local Ang = 0 - self.SMLG
	self:ManipulateBoneAngles( 1, Angle(0,Ang,0) )
	self:ManipulateBoneAngles( 9, Angle(0,Ang,0) )
	end
end

function ENT:OnLandingGearToggled( bOn )
	self:EmitSound( "TX_ROCKETPODS" )
end

function ENT:OnEngineStarted()
	self:EmitSound( "lfs/tx130/engine_start.wav" )
	self.HeightOffset = 27
end

function ENT:OnEngineStopped()
	self:EmitSound( "lfs/tx130/engine_stop.wav" )
	self.HeightOffset = 7
end