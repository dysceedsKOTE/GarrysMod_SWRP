AddCSLuaFile( "shared.lua" )
AddCSLuaFile( "cl_init.lua" )
include("shared.lua")

function ENT:SpawnFunction( ply, tr, ClassName )

	if not tr.Hit then return end

	local ent = ents.Create( ClassName )
	ent.dOwnerEntLFS = ply
	ent:SetPos( tr.HitPos + tr.HitNormal * 8 )
	ent:Spawn()
	ent:Activate()

	return ent

end

function ENT:RunOnSpawn()
	self:SetBodygroup( 3, 1 )
	self:SetBodygroup( 4, 1 )
	self:SetBodygroup( 8, 2 )
	
	self:GetDriverSeat().ExitPos = Vector(306.46,-0.1,16)
	
	local CoPilotGunnerSeat = ( self:AddPassengerSeat( Vector(111,0,155), Angle(0,-90,-0) ) ) 
	CoPilotGunnerSeat.ExitPos = Vector(276.33,76.56,15.86)	 
	self:SetCoPilotGunnerSeat( CoPilotGunnerSeat )
	
	local GunnerSeat = ( self:AddPassengerSeat( Vector(-360,2.54,221.12), Angle(0,90,-0) ) ) --Rear gunner
	GunnerSeat.ExitPos = Vector(276.33,-76.56,15.86)	
	self:SetGunnerSeat( GunnerSeat )	

--Front Left Row	
	self:AddPassengerSeat(Vector(19.41,40.76,10.9), Angle(0,0,0) ).ExitPos = Vector(115.77,154.56,14.49)
	self:AddPassengerSeat(Vector(-5.56,43.88,10.9), Angle(0,0,0) ).ExitPos = Vector(74.8,157.16,14.49)
	self:AddPassengerSeat(Vector(-32.01,46.43,10.9), Angle(0,0,0) ).ExitPos = Vector(32.41,166.1,14.49)
	self:AddPassengerSeat(Vector(-58.72,48.14,10.9), Angle(0,0,0) ).ExitPos = Vector(-8.29,167.99,14.49)
	self:AddPassengerSeat(Vector(-85.23,50.12,10.9), Angle(0,0,0) ).ExitPos = Vector(-48.96,172.58,14.49)
	self:AddPassengerSeat(Vector(-112.4,49.18,10.9), Angle(0,0,0) ).ExitPos = Vector(-86.43,178.4,14.49)
	self:AddPassengerSeat(Vector(-139.76,49.84,11.5), Angle(0,0,0) ).ExitPos = Vector(-127.53,185.21,14.49)

--Back Left Row
	self:AddPassengerSeat(Vector(-155.75,21.04,10.9), Angle(0,0,0) ).ExitPos = Vector(132.69,96.19,14.49)
	self:AddPassengerSeat(Vector(5.25,20,10.9), Angle(0,0,0) ).ExitPos = Vector(89.09,104.88,14.49)
	self:AddPassengerSeat(Vector(-20.59,21.04,10.9), Angle(0,0,0) ).ExitPos = Vector(48.19,112.75,14.49)
	self:AddPassengerSeat(Vector(-46.96,21.04,10.9), Angle(0,0,0) ).ExitPos = Vector(8.41,116.04,14.49)
	self:AddPassengerSeat(Vector(-73.15,21.04,10.9), Angle(0,0,0) ).ExitPos = Vector(-30.13,118.89,14.49)
	self:AddPassengerSeat(Vector(-82.15,21.04,10.9), Angle(0,0,0) ).ExitPos = Vector(-70.09,122.32,14.49)
	self:AddPassengerSeat(Vector(-100.63,21.04,10.9), Angle(0,0,0) ).ExitPos = Vector(-106.89,124.54,14.49)	
	self:AddPassengerSeat(Vector(-127.65,21.04,10.9), Angle(0,0,0) ).ExitPos = Vector(-148.5,130.52,14.49)

--Front Right Row	
	self:AddPassengerSeat(Vector(19.41,-40.76,10.9), Angle(0,180,0) ).ExitPos = Vector(115.77,-154.56,14.49)
	self:AddPassengerSeat(Vector(-5.56,-43.88,10.9), Angle(0,180,0) ).ExitPos = Vector(74.8,-157.16,14.49)
	self:AddPassengerSeat(Vector(-32.01,-46.43,10.9), Angle(0,180,0) ).ExitPos = Vector(32.41,-166.1,14.49)
	self:AddPassengerSeat(Vector(-58.72,-48.14,10.9), Angle(0,180,0) ).ExitPos = Vector(-8.29,-167.99,14.49)
	self:AddPassengerSeat(Vector(-85.23,-50.12,10.9), Angle(0,180,0) ).ExitPos = Vector(-48.96,-172.58,14.49)
	self:AddPassengerSeat(Vector(-112.4,-49.18,10.9), Angle(0,180,0) ).ExitPos = Vector(-86.43,-178.4,14.49)
	self:AddPassengerSeat(Vector(-139.76,-49.84,11.5), Angle(0,180,0) ).ExitPos = Vector(-127.53,-185.21,14.49)

--Back Right Row
	self:AddPassengerSeat(Vector(-155.75,-21.04,10.9), Angle(0,180,0) ).ExitPos = Vector(132.69,-96.19,14.49)
	self:AddPassengerSeat(Vector(5.25,20,-10.9), Angle(0,180,0) ).ExitPos = Vector(89.09,-104.88,14.49)
	self:AddPassengerSeat(Vector(-20.59,-21.04,10.9), Angle(0,180,0) ).ExitPos = Vector(48.19,-112.75,14.49)
	self:AddPassengerSeat(Vector(-46.96,-21.04,10.9), Angle(0,180,0) ).ExitPos = Vector(8.41,-116.04,14.49)
	self:AddPassengerSeat(Vector(-73.15,-21.04,10.9), Angle(0,180,0) ).ExitPos = Vector(-30.13,-118.89,14.49)
	self:AddPassengerSeat(Vector(-82.15,-21.04,10.9), Angle(0,180,0) ).ExitPos = Vector(-70.09,-122.32,14.49)
	self:AddPassengerSeat(Vector(-100.63,-21.04,10.9), Angle(0,180,0) ).ExitPos = Vector(-106.89,-124.54,14.49)	
	self:AddPassengerSeat(Vector(-127.65,-21.04,10.9), Angle(0,180,0) ).ExitPos = Vector(-148.5,-130.52,14.49)

end

function ENT:PrimaryAttack()
	if not self:CanPrimaryAttack() then return end

	self:EmitSound( "LAAT_FIRE" )
	
	self:SetNextPrimary( 0.15 )
	
	local startpos =  self:GetRotorPos()
	local TracePlane = util.TraceHull( {
		start = startpos,
		endpos = (startpos + self:GetForward() * 50000),
		mins = Vector( -10, -10, -10 ),
		maxs = Vector( 10, 10, 10 ),
		filter = self
	} )	
	
	for i = 0,1 do
		self.MirrorPrimary = not self.MirrorPrimary
		
		local Mirror = self.MirrorPrimary and -1 or 1
		
		local bullet = {}
		bullet.Num 	= 1
		bullet.Src 	= self:LocalToWorld( Vector(350,55 * Mirror,25) ) 
		bullet.Dir 	= (TracePlane.HitPos - bullet.Src):GetNormalized()
		bullet.Spread 	= Vector( 0.018, 0.01, 0 )
		bullet.Tracer	= 1
		bullet.TracerName	= "lfs_laser_green"
		bullet.Force	= 100
		bullet.HullSize 	= 25
		bullet.Damage	= 16
		bullet.Attacker 	= self:GetDriver()
		bullet.AmmoType = "Pistol"
		bullet.Callback = function(att, tr, dmginfo)
			dmginfo:SetDamageType(DMG_AIRBOAT)
		end
		self:FireBullets( bullet )
		
		self:TakePrimaryAmmo()
		end
end

function ENT:SetNextAltPrimary( delay )
	self.NextAltPrimary = CurTime() + delay
end

function ENT:CanAltPrimaryAttack()
	self.NextAltPrimary = self.NextAltPrimary or 0
	return self.NextAltPrimary < CurTime()
end

function ENT:AltPrimaryAttack( Driver, Pod, Dir )
	if not self:CanAltPrimaryAttack() then return end
	
	if not IsValid( Pod ) then Pod = self:GetDriverSeat() end
	if not IsValid( Driver ) then Driver = Pod:GetDriver() end
	
	if not IsValid( Pod ) then return end
	if not IsValid( Driver ) then return end
	
	local EyeAngles = Pod:WorldToLocalAngles( Driver:EyeAngles() )
	local Forward = -self:GetForward()
	
	local AimDirToForwardDir = math.deg( math.acos( math.Clamp( Forward:Dot( EyeAngles:Forward() ) ,-1,1) ) )
	if AimDirToForwardDir < 160 then return end
	
	self:EmitSound( "LAAT_FIRE" )
	
	self:SetNextAltPrimary( 0.15 )
	
	local startpos =  self:GetRotorPos()
	local TracePlane = util.TraceHull( {
		start = startpos,
		endpos = (startpos + EyeAngles:Forward() * 50000),
		mins = Vector( -10, -10, -10 ),
		maxs = Vector( 10, 10, 10 ),
		filter = self
	} )	
	
	for i = 0,1 do
		self.MirrorPrimary = not self.MirrorPrimary
		
		local Mirror = self.MirrorPrimary and -1 or 1
		
		local bullet = {}
		bullet.Num 	= 1
		bullet.Src 	= self:LocalToWorld( Vector(350,55 * Mirror,25) ) 
		bullet.Dir 	= (TracePlane.HitPos - bullet.Src):GetNormalized()
		bullet.Spread 	= Vector( 0.018, 0.01, 0 )
		bullet.Tracer	= 1
		bullet.TracerName	= "lfs_laser_green"
		bullet.Force	= 100
		bullet.HullSize 	= 25
		bullet.Damage	= 16
		bullet.Attacker 	= self:GetDriver()
		bullet.AmmoType = "Pistol"
		bullet.Callback = function(att, tr, dmginfo)
			dmginfo:SetDamageType(DMG_AIRBOAT)
		end
		self:FireBullets( bullet )
		
		self:TakePrimaryAmmo()
		end
end

function ENT:SecondaryAttack()
	if not self:CanSecondaryAttack() then return end
	if self:GetAI() then return end
	self:SetNextSecondary( 1 )

	self:TakeSecondaryAmmo()

	self:EmitSound( "LAAT_ALTFIRE" )
	
	self.MirrorPrimary = not self.MirrorPrimary
	
	local Mirror = self.MirrorPrimary and -1 or 1
	
	local startpos =  self:GetRotorPos()
	local tr = util.TraceHull( {
		start = startpos,
		endpos = (startpos + self:GetForward() * 50000),
		mins = Vector( -40, -40, -40 ),
		maxs = Vector( 40, 40, 40 ),
		filter = function( e )
			local collide = e ~= self
			return collide
		end
	} )

		for i = 0,1 do
		self.MirrorPrimary = not self.MirrorPrimary
		
		local Mirror = self.MirrorPrimary and -1 or 1	
	
	local fP = { ( Vector(20,66 * Mirror,285) ) }
	
	self.NumPrim = self.NumPrim and self.NumPrim + 1 or 1
	if self.NumPrim > 1 then self.NumPrim = 1 end	
	
	local ent = ents.Create( "lunasflightschool_missile" )
	local Pos = self:LocalToWorld( fP[self.NumPrim] )
	ent:SetPos( Pos )
	ent:SetAngles( (tr.HitPos - Pos):Angle() )
	ent:Spawn()
	ent:Activate()
	ent:SetAttacker( self:GetDriver() )
	ent:SetInflictor( self )
	ent:SetStartVelocity( self:GetVelocity():Length() )
	ent:SetCleanMissile( true )
	
	if tr.Hit then
		local Target = tr.Entity
		if IsValid( Target ) then
			if Target:GetClass():lower() ~= "lunasflightschool_missile" then
				ent:SetLockOn( Target )
				ent:SetStartVelocity( 0 )
			end
		end
	end
	
	constraint.NoCollide( ent, self, 0, 0 ) 
	end
end

function ENT:GetCoPilotGunner()
	local PodFirst = self:GetCoPilotGunnerSeat()
	
	if IsValid( PodFirst ) then
		return PodFirst:GetDriver()
	else 
		return NULL
	end
end

function ENT:CanCoPilotGunnerFire()
	self.NextCoPilotGunnerFire = isnumber( self.NextCoPilotGunnerFire ) and self.NextCoPilotGunnerFire or 0
	
	return self.NextCoPilotGunnerFire < CurTime()
end

function ENT:SetNextCoPilotGunnerFire( delay )
	self.NextCoPilotGunnerFire = CurTime() + delay
end

function ENT:TakeCoPilotGunnerAmmo()
	self:SetAmmoCoPilotGunner( math.max(self:GetAmmoCoPilotGunner() - 1,0) )
end

function ENT:CoPilotGunnerFire( Attacker )
	if not self:CanCoPilotGunnerFire() then return end

	self:EmitSound( "LAAT_ROCKETS" )
	
	self:TakeCoPilotGunnerAmmo()
	
	local startpos =  self:GetRotorPos()
	local tr = util.TraceHull( {
		start = startpos,
		endpos = (startpos + self:GetForward() * 50000),
		mins = Vector( -40, -40, -40 ),
		maxs = Vector( 40, 40, 40 ),
		filter = function( e )
			local collide = e ~= self
			return collide
		end
	} )
	
	local rocketpos = {
		self:GetPos()+self:GetForward()*-150+self:GetUp()*138+self:GetRight()*255,	
		self:GetPos()+self:GetForward()*-150+self:GetUp()*135+self:GetRight()*-257,	
		self:GetPos()+self:GetForward()*-150+self:GetUp()*130+self:GetRight()*264,
		self:GetPos()+self:GetForward()*-150+self:GetUp()*130+self:GetRight()*-266,
		self:GetPos()+self:GetForward()*-150+self:GetUp()*127+self:GetRight()*276,	
		self:GetPos()+self:GetForward()*-150+self:GetUp()*127+self:GetRight()*-276,
		self:GetPos()+self:GetForward()*-150+self:GetUp()*122+self:GetRight()*286,
		self:GetPos()+self:GetForward()*-150+self:GetUp()*122+self:GetRight()*-286,
	}	
		
	local ent = ents.Create( "lunasflightschool_laat_missile" )
	local mPos
	if (self:GetAmmoCoPilotGunner()+1)%8 == 0 then
		mPos = rocketpos[1]
		self:SetNextCoPilotGunnerFire( 0.25 )

	elseif (self:GetAmmoCoPilotGunner()+1)%8 == 7 then
		mPos = rocketpos[2]
		self:SetNextCoPilotGunnerFire( 0.25 )

	elseif (self:GetAmmoCoPilotGunner()+1)%8 == 6 then
		mPos = rocketpos[3]
		self:SetNextCoPilotGunnerFire( 0.25 )

	elseif (self:GetAmmoCoPilotGunner()+1)%8 == 5 then
		mPos = rocketpos[4]
		self:SetNextCoPilotGunnerFire( 0.25 )


	elseif (self:GetAmmoCoPilotGunner()+1)%8 == 4 then
		mPos = rocketpos[5]
		self:SetNextCoPilotGunnerFire( 0.25 )

	elseif (self:GetAmmoCoPilotGunner()+1)%8 == 3 then
		mPos = rocketpos[6]
		self:SetNextCoPilotGunnerFire( 0.25 )

	elseif (self:GetAmmoCoPilotGunner()+1)%8 == 2 then
		mPos = rocketpos[7]
		self:SetNextCoPilotGunnerFire( 0.25 )

	else
		mPos = rocketpos[8]
		self:SetNextCoPilotGunnerFire( 4 )
	end

	local Ang = self:WorldToLocal( mPos ).y > 0 and -1 or 1
	ent:SetPos( mPos )
	ent:SetAngles( self:LocalToWorldAngles( Angle(0,Ang,0) ) )
	ent:Spawn()
	ent:Activate()
	ent:SetAttacker( self:GetDriver() )
	ent:SetInflictor( self )
	ent:SetStartVelocity( self:GetVelocity():Length() )
	
	if self:GetAI() then
		local enemy = self:AIGetTarget()
		if IsValid(enemy) then
			if math.random(1,8) != 1 then
				if string.find(enemy:GetClass(),"lunasflightschool") then
					if enemy:GetClass() == "lunasflightschool_laat_missile" then return end
					ent:SetLockOn(enemy)
					ent:SetStartVelocity(0)
				end
			end
		end
	else
		if tr.Hit then
			local Target = tr.Entity
			if IsValid(Target) then
				if Target:GetClass():lower() ~= "lunasflightschool_laat_missile" then
					ent:SetLockOn(Target)
					ent:SetStartVelocity(0)
				end
			end
		end
	end
	constraint.NoCollide(ent,self,0,0) 
end

function ENT:CanTurretRearFire()
	self.NextTurretRearFire = isnumber( self.NextTurretRearFire ) and self.NextTurretRearFire or 0
	
	return self.NextTurretRearFire < CurTime()
end

function ENT:SetNextTurretRearFire( delay )
	self.NextTurretRearFire = CurTime() + delay
end

function ENT:TurretRearFire( Driver, Pod, Dir )
	if not self:CanTurretRearFire() then return end
	
	if not IsValid( Pod ) then return end
	if not IsValid( Driver ) then return end
	
	self:EmitSound( "LAAT_FIRE" )
	
	self:SetNextTurretRearFire( 0.10 )	
	
	-- ignore attachment angles and make aiming 100% accurate to player view direction
	local Forward = self:LocalToWorldAngles( Angle(20,0,0) ):Forward()
	local AimDirToForwardDir = math.deg( math.acos( math.Clamp( Forward:Dot( Dir ) ,-1,1) ) )
	if AimDirToForwardDir > 100 then 
		TargetDir = Dir
	end
	
	local MuzzlePos = self:LocalToWorld(Vector(-520,2,110))
	
	local bullet = {}
	bullet.Num 	= 1
	bullet.Src 	= MuzzlePos
	bullet.Dir 	= TargetDir
	bullet.Spread 	= Vector( 0.02,  0.02, 0 )
	bullet.Tracer	= 1
	bullet.TracerName	= "lfs_laser_green"
	bullet.Force	= 100
	bullet.HullSize 	= 20
	bullet.Damage	= 22
	bullet.Attacker 	= Driver
	bullet.AmmoType = "Pistol"
	bullet.Callback = function(att, tr, dmginfo)
		dmginfo:SetDamageType(DMG_AIRBOAT)
	end
	self:FireBullets( bullet )

end

function ENT:OnGravityModeChanged( b )
end

function ENT:OnKeyThrottle( bPressed )
end

function ENT:OnEngineStopped()
	self:SetGravityMode( true )
end

function ENT:OnVtolMode( IsOn )
end

function ENT:HitGround()
	local tr = util.TraceLine( {
		start = self:LocalToWorld( Vector(0,0,100) ),
		endpos = self:LocalToWorld( Vector(0,0,-20) ),
		filter = function( ent ) 
			if ( ent == self ) then 
				return false
			end
		end
	} )
	
	return tr.Hit 
end


function ENT:OnKeyThrottle( bPressed )
end

function ENT:CreateAI()
	self:SetBodygroup( 8, 3 )
end

function ENT:RemoveAI()
	self:SetBodygroup( 8, 2 ) 
end

function ENT:HandleWeapons(Fire1, Fire2, Fire3)
	local Driver = self:GetDriver()
	
	local Gunner = self:GetGunner()
	local GunnerSeat = self:GetGunnerSeat()
	local GunnerDir = self:GetForward()
	local HasGunner = IsValid( Gunner )
	local CoPilotGunner = self:GetCoPilotGunner()
	local GunnerFire = false
	local FirstGunnerFire = false
		
	if IsValid( Driver ) then
		if self:GetAmmoPrimary() > 0 then
			Fire1 = Driver:KeyDown( IN_ATTACK )
		end
	
		FireTurret = Driver:KeyDown( IN_WALK )	
	
		if self:GetAmmoSecondary() > 0 then
			Fire2 = Driver:KeyDown( IN_ATTACK2 )
		end
	end	
	
	if IsValid( CoPilotGunner ) then
		CoPilotGunnerFire = CoPilotGunner:KeyDown( IN_ATTACK )
		
		if CoPilotGunnerFire then
			if self:GetAmmoCoPilotGunner() > 0 then
				self:CoPilotGunnerFire()
			end
		end
	end
	
	if IsValid( Gunner ) and IsValid( GunnerSeat ) then
		local EyeAng = Gunner:EyeAngles()
		local GunnerAng = GunnerSeat:WorldToLocalAngles( EyeAng )
		
		Gunner:CrosshairDisable()	
		
		GunnerDir = GunnerAng:Forward()
		
			Fire3 = Gunner:KeyDown( IN_ATTACK )
	
	if Fire3 then
		-- self:TurretRearFire( Gunner, self:GetGunnerSeat() )
		self:TurretRearFire( Gunner, GunnerSeat, GunnerDir )
			end	
		end
	
	if Fire1 then
		if FireTurret and not HasGunner then
			self:AltPrimaryAttack()
		else
			self:PrimaryAttack()
		end
end

	if Fire2 then
		self:SecondaryAttack()
	end
end

-- --(8,3)fullclose (8,2)fullopen (8,1)halfopen
function ENT:OnLandingGearToggled( bOn )
	self:EmitSound( "lfs/laat/Flaps.mp3" )
	if self:GetAI() then return end
	
	local Driver = self:GetDriver()
	
	if not IsValid( Driver ) then return end
	
	if Driver:KeyDown( IN_ZOOM ) then
		local ToggleHatch = not self:GetRearHatch()
		self:SetRearHatch( ToggleHatch )
		
		if ToggleHatch then
			self:EmitSound( "lfs/laat/door_open.wav" )
			self:SetBodygroup( 9, 1 )
		else
			self:EmitSound( "lfs/laat/door_close.wav" )
			self:SetBodygroup( 9, 0 )
		end
	else
		local DoorMode = self:GetDoorMode() + 1

		self:SetDoorMode( DoorMode )
			
		if DoorMode == 1 then
			self:SetBodygroup( 8, 1 )
			self:EmitSound( "lfs/laat/door_close_large.wav" )
		end
			
		if DoorMode == 2 then
			self:SetBodygroup( 8, 3 )
			self:EmitSound( "lfs/laat/door_close.wav" )
		end
			
		if DoorMode == 3 then
			self:SetBodygroup( 8, 1 )
			self:EmitSound( "lfs/laat/door_open.wav" )
		end
			
		if DoorMode >= 4 then
			self:SetDoorMode( 0 )
			self:SetBodygroup( 8, 2 )
			self:EmitSound( "lfs/laat/door_open_large.wav" )
		end
	end
end