ENT.Type            = "anim"
DEFINE_BASECLASS( "lunasflightschool_basescript_gunship" )

ENT.PrintName = "ARC LAAT/i Republic Gunship (Green)"
ENT.Author = "Lightning Bolt"
ENT.Information = ""
ENT.Category = "[LFS] Star Wars"

ENT.Spawnable		= true
ENT.AdminSpawnable		= false

ENT.UseLAATAnimHook = true

ENT.MDL = "models/ish/starwars/laat/laat_mk2.mdl"

ENT.GibModels = {
	"models/XQM/wingpiece2.mdl",
	"models/XQM/wingpiece2.mdl",
	"models/XQM/jetwing2medium.mdl",
	"models/XQM/jetwing2medium.mdl",
	"models/props_c17/TrapPropeller_Engine.mdl",
	"models/props_junk/Shoe001a.mdl",
	"models/XQM/jetbody2fuselage.mdl",
	"models/XQM/jettailpiece1medium.mdl",
	"models/XQM/pistontype1huge.mdl",
}

ENT.AITEAM = 2

ENT.Mass = 5000
ENT.Drag = 0

ENT.SeatPos = Vector(206,0,121)
ENT.SeatAng = Angle(0,-90,0)

ENT.MaxHealth = 3000

ENT.MaxPrimaryAmmo = 3000
ENT.MaxSecondaryAmmo = 100

ENT.MaxCoPilotGunnerAmmo = 200

ENT.IdleRPM = 0
ENT.MaxRPM = 2700
ENT.LimitRPM = 3100
ENT.RPMThrottleIncrement = 1300 

ENT.MaxTurnPitch = 70
ENT.MaxTurnYaw = 70
ENT.MaxTurnRoll = 70

ENT.PitchDamping = 2
ENT.YawDamping = 2
ENT.RollDamping = 1

ENT.TurnForcePitch = 6000
ENT.TurnForceYaw = 6000
ENT.TurnForceRoll = 4000

ENT.RotorPos = Vector(210,-20,130)

ENT.MaxVelocity = 2600

ENT.MaxThrust = 1800

ENT.VerticalTakeoff = true
ENT.VtolAllowInputBelowThrottle = 100
ENT.MaxThrustVtol = 400

function ENT:AddDataTables()
	self:NetworkVar( "Int",12, "DoorMode" )
	self:NetworkVar( "Entity",20, "CoPilotGunnerSeat" )
	self:NetworkVar( "Int",21, "AmmoCoPilotGunner", { KeyName = "CoPilotGunnerAmmo", Edit = { type = "Int", order = 5,min = 0, max = self.MaxCoPilotGunnerAmmo, category = "Weapons"} } )
	self:SetAmmoCoPilotGunner( self.MaxCoPilotGunnerAmmo )
	self:NetworkVar( "Bool",22, "RearHatch" )
end

sound.Add( {
	name = "LAAT_FIRE",
	channel = CHAN_WEAPON,
	volume = 0.8,
	level = 125,
	pitch = {90, 90},
	sound = "lfs/naboo_n1_starfighter/fire.mp3"
} )

sound.Add( {
	name = "LAAT_ALTFIRE",
	channel = CHAN_ITEM,
	volume = 1.0,
	level = 125,
	pitch = 100,
    sound = "lfs/laat/rockets/photon_fire.mp3"
} )

sound.Add( {
	name = "LAAT_ROCKETS",
	channel = CHAN_ITEM,
	volume = 1.0,
	level = 125,
	pitch = {100, 100},
    sound = "^lfs/laat/rockets/rocket_ignite1.mp3","^lfs/laat/rockets/rocket_ignite2.mp3","^lfs/laat/rockets/rocket_ignite3.mp3","^lfs/laat/rockets/rocket_ignite4.mp3","^lfs/laat/rockets/rocket_ignite5.mp3"
} )

sound.Add( {
	name = "LAAT_ENGINE",
	channel = CHAN_STATIC,
	volume = 0.8,
	level = 125,
	sound = "lfs/laat/eng_repGunship_mid_lp.wav"
} )

sound.Add( {
	name = "LAAT_TAKEOFF",
	channel = CHAN_STATIC,
	volume = 0.8,
	level = 125,
	sound = {"^lfs/laat/takeoff_01.mp3","^lfs/laat/takeoff_02.mp3","^lfs/laat/takeoff_03.mp3"}
} )

sound.Add( {
	name = "LAAT_BOOST",
	channel = CHAN_STATIC,
	volume = 0.8,
	level = 125,
	sound = {"^lfs/laat/boost_02.mp3","^lfs/laat/boost_03.mp3","^lfs/laat/boost_04.mp3"}
} )

sound.Add( {
	name = "LAAT_LANDING",
	channel = CHAN_STATIC,
	volume = 0.8,
	level = 125,
	sound = {"^lfs/laat/land_01.wav","^lfs/laat/land_02.mp3"}
} )

sound.Add( {
	name = "LAAT_DIST",
	channel = CHAN_STATIC,
	volume = 1.0,
	level = 125,
	sound = "^lfs/laat/eng_dist.wav"
} )




hook.Add("CalcMainActivity", "!!!lfs_LAAT_passengeranims", function(ply)
	local Ent = ply:lfsGetPlane()
	
	if not IsValid( Ent ) then return end
	if not Ent.UseLAATAnimHook then return end
	
	local Pod = ply:GetVehicle()
	
	if Pod == Ent:GetDriverSeat() or Pod == Ent:GetGunnerSeat() or Pod == Ent:GetCoPilotGunnerSeat() then return end
	
	if ply.m_bWasNoclipping then 
		ply.m_bWasNoclipping = nil 
		ply:AnimResetGestureSlot( GESTURE_SLOT_CUSTOM ) 
		
		if CLIENT then 
			ply:SetIK( true )
		end 
	end 
	
	ply.CalcIdeal = ACT_STAND
	ply.CalcSeqOverride = ply:LookupSequence( "idle_all_02" )

	if ply:GetAllowWeaponsInVehicle() and IsValid( ply:GetActiveWeapon() ) then
		
		local holdtype = ply:GetActiveWeapon():GetHoldType()
		
		if holdtype == "smg" then 
			holdtype = "smg1"
		end

		local seqid = ply:LookupSequence( "idle_" .. holdtype )
		
		if seqid ~= -1 then
			ply.CalcSeqOverride = seqid
		end
	end

	return ply.CalcIdeal, ply.CalcSeqOverride
end)