AddCSLuaFile( "shared.lua" )
AddCSLuaFile( "cl_init.lua" )
include("shared.lua")

function ENT:SpawnFunction( ply, tr, ClassName )
	if not tr.Hit then return end

	local ent = ents.Create( ClassName )
	ent.dOwnerEntLFS = ply 
	ent:SetPos( tr.HitPos + tr.HitNormal * 3 ) 
	ent:Spawn()
	ent:Activate()

	return ent
end

function ENT:OnTick()
	self.AstroAng = self.AstroAng or 0
	self.nextAstro = self.nextAstro or 0
	if self.nextAstro < CurTime() then
		self.nextAstro = CurTime() + math.Rand(0.5,2)
		self.AstroAng = math.Rand(-180,180)
		
		if math.random(0,8) == 4 then
			self:EmitSound( "lfs/naboo_n1_starfighter/astromech/"..math.random(1,11)..".ogg" )
		end
	end
end

function ENT:RunOnSpawn()
	self.CurrentDroid = self.DroidModels[(1)];
	self:SpawnDroid(self:GetPos()+self:GetUp()*32+self:GetRight()*-50+self:GetForward()*-8)
	self:GetDriverSeat().ExitPos = Vector(11.69,129.23,13.67)
end

function ENT:PrimaryAttack()
	if self:GetLGear() > 0.01 then return end
	if not self:CanPrimaryAttack() then return end

	self:EmitSound( "JEDISF_FIRE" )
	
	self:SetNextPrimary( 0.08 )
	
	local fP = { Vector(26,64.7,23), Vector(26,-69.7,24) }

	self.NumPrim = self.NumPrim and self.NumPrim + 1 or 1
	if self.NumPrim > 2 then self.NumPrim = 1 end
	
	local startpos =  self:GetRotorPos()
	local TracePlane = util.TraceHull( {
		start = startpos,
		endpos = (startpos + self:GetForward() * 50000),
		mins = Vector( -10, -10, -10 ),
		maxs = Vector( 10, 10, 10 ),
		filter = function( e )
			local collide = e ~= self
			return collide
		end
	} )
	
	local bullet = {}
	bullet.Num 	= 1
	bullet.Src 	= self:LocalToWorld( fP[self.NumPrim] )
	bullet.Dir 	= (TracePlane.HitPos - bullet.Src):GetNormalized()
	bullet.Spread 	= Vector( 0.01,  0.01, 0 )
	bullet.Tracer	= 1
	bullet.TracerName	= "lfs_laser_green"
	bullet.Force	= 100
	bullet.HullSize 	= 40
	bullet.Damage	= 28
	bullet.Attacker 	= self:GetDriver()
	bullet.AmmoType = "Pistol"
	bullet.Callback = function(att, tr, dmginfo)
		dmginfo:SetDamageType(DMG_AIRBOAT)
	end
	self:FireBullets( bullet )
	
	self:TakePrimaryAmmo()
end

function ENT:SecondaryAttack()
	if self:GetLGear() > 0.01 then return end
	if not self:CanPrimaryAttack() then return end

	self:EmitSound( "JEDISF_FIRE2" )
	
	self:SetNextPrimary( 0.24 )
	
	for i = 0,1 do
		self.MirrorPrimary = not self.MirrorPrimary
		
		local Mirror = self.MirrorPrimary and -1 or 1
		
		local bullet = {}
		bullet.Num 	= 1
		bullet.Src 	= self:LocalToWorld( Vector(26,69 * Mirror,25) )
		bullet.Dir 	= self:LocalToWorldAngles( Angle(0,0,0) ):Forward()
		bullet.Spread 	= Vector( 0.01,  0.01, 0 )
		bullet.Tracer	= 1
	bullet.TracerName	= "lfs_laser_green"
	bullet.Force	= 100
	bullet.HullSize 	= 40
	bullet.Damage	= 45
	bullet.Attacker 	= self:GetDriver()
	bullet.AmmoType = "Pistol"
	bullet.Callback = function(att, tr, dmginfo)
		dmginfo:SetDamageType(DMG_AIRBOAT)
		
		local effectdata = EffectData()
			effectdata:SetOrigin( tr.HitPos )
		util.Effect( "helicoptermegabomb", effectdata )
		end
		self:FireBullets( bullet )
		
		self:TakeSecondaryAmmo()
		end
end


function ENT:OnKeyThrottle( bPressed )
if self:CanSound() then
	if bPressed then
		if self:CanSound() then
			self:EmitSound( "ETA2_BOOST" )
			self:DelayNextSound( 1 )
		end
	else
		if (self:GetRPM() + 1) > self:GetMaxRPM() then
			if self:CanSound() then
				self:EmitSound( "ETA2_BRAKE" )
				self:DelayNextSound( 0.5 )
				end
			end
		end
	end
end

function ENT:CreateAI()
end

function ENT:RemoveAI()
end

function ENT:HandleActive()
	local Pod = self:GetDriverSeat()
	
	if not IsValid( Pod ) then
		self:SetActive( false )
		return
	end
	
	local Driver = Pod:GetDriver()
	
	if Driver ~= self:GetDriver() then
		if IsValid( self:GetDriver() ) then
			self:GetDriver():SetNoDraw( false )
		end
		if IsValid( Driver ) then
			Driver:SetNoDraw( true )
		end
		
		self:SetDriver( Driver )
		self:SetActive( IsValid( Driver ) )
		
		if self:GetActive() then
			self:EmitSound( "vehicles/atv_ammo_close.wav" )
		else
			self:EmitSound( "vehicles/atv_ammo_open.wav" )
		end
	end
end

function ENT:HandleWeapons(Fire1, Fire2)
	local Driver = self:GetDriver()
	
	if IsValid( Driver ) then
		if self:GetAmmoPrimary() > 0 then
			Fire1 = Driver:KeyDown( IN_ATTACK )
		end
		if self:GetAmmoSecondary() > 0 then
			Fire2 = Driver:KeyDown( IN_ATTACK2 )
		end
	end
	
	if Fire1 then
		self:PrimaryAttack()
	end
	
	if Fire2 then
		self:SecondaryAttack()
	end
end

function ENT:OnLandingGearToggled( bOn )
	self:EmitSound( "lfs/jsf/Flaps.mp3" )
	
	if bOn then
	self:SetSequence( "attack" )
	else
	self:SetSequence( "idle" )
	end
end