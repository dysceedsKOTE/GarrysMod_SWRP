ENT.Type            = "anim"
DEFINE_BASECLASS( "lunasflightschool_basescript" )

ENT.PrintName = "Geonosian Starfighter"
ENT.Author = "ϟLightning Boltϟ"
ENT.Information = ""
ENT.Category = "[LFS] Star Wars"

ENT.Spawnable		= true
ENT.AdminSpawnable		= false

ENT.MDL = "models/geon/geon1.mdl"

ENT.GibModels = {
	"models/XQM/wingpiece2.mdl",
	"models/XQM/wingpiece2.mdl",
	"models/XQM/jetwing2medium.mdl",
	"models/XQM/jetwing2medium.mdl",
	"models/props_c17/TrapPropeller_Engine.mdl",
	"models/props_junk/Shoe001a.mdl",
	"models/XQM/jetbody2fuselage.mdl",
	"models/XQM/jettailpiece1medium.mdl",
	"models/XQM/pistontype1huge.mdl",
}

ENT.AITEAM = 1

ENT.Mass = 2000
ENT.Inertia = Vector(150000,150000,150000)
ENT.Drag = 1

ENT.SeatPos = Vector(-35,0,62)
ENT.SeatAng = Angle(0,-90,0)

ENT.IdleRPM = 0
ENT.MaxRPM = 2800
ENT.LimitRPM = 3200

ENT.RotorPos = Vector(-55.05,0,56.56)
ENT.WingPos = Vector(112.88,0,54.63)
ENT.ElevatorPos = Vector(-213.44,0,54.63)
ENT.RudderPos = Vector(-213.44,0,54.63)


ENT.MaxVelocity = 2900

ENT.MaxThrust = 28000

ENT.MaxTurnPitch = 950
ENT.MaxTurnYaw = 1500
ENT.MaxTurnRoll = 450

ENT.MaxPerfVelocity = 1

ENT.MaxHealth = 500

ENT.Stability = 0.7

ENT.VerticalTakeoff = true
ENT.VtolAllowInputBelowThrottle = 10
ENT.MaxThrustVtol = 10000

ENT.MaxPrimaryAmmo = 3000
ENT.MaxSecondaryAmmo = -1

sound.Add( {
	name = "GEO_FIRE",
	channel = CHAN_WEAPON,
	volume = 1.0,
	level = 125,
	pitch = {90, 90},
	sound = "lfs/geofighter/wpn_geonFighter_blaster_fire.mp3"
} )

sound.Add( {
	name = "GEO_ALTFIRE",
	channel = CHAN_ITEM,
	volume = 1.0,
	level = 125,
	pitch = {95, 105},
    sound = ""
} )

sound.Add( {
	name = "GEO_ENGINE",
	channel = CHAN_STATIC,
	volume = 1.0,
	level = 125,
	sound = "lfs/geofighter/eng_geonosianFtr_mid_lp.wav"
} )

sound.Add( {
	name = "GEO_DIST",
	channel = CHAN_STATIC,
	volume = 1.0,
	level = 125,
	sound = "lfs/geofighter/eng_geonosianFtr_hi_lp.wav"
} )
