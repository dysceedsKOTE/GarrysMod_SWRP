-- YOU CAN EDIT AND REUPLOAD THIS FILE.
-- HOWEVER MAKE SURE TO RENAME THE FOLDER TO AVOID CONFLICTS

include("shared.lua")

function ENT:Draw()
	self:DrawModel()

	if not self:GetEngineActive() then return end

	local Boost = self.BoostAdd or 0

	local Size = 100 + (self:GetRPM() / self:GetLimitRPM()) * 100 + Boost

	render.SetMaterial(Material( "sprites/light_glow02_add" ))
	render.DrawSprite( self:LocalToWorld( Vector(-120,0,12) ), Size, Size, Color( 25, 140, 150, 255) )
	render.DrawSprite( self:LocalToWorld( Vector(-120,0,-30) ), Size, Size, Color( 25, 140, 150, 255) )
end

function ENT:LFSCalcViewFirstPerson( view, ply ) -- modify first person camera view here
	--[[
	if ply == self:GetDriver() then
		-- driver view
	elseif ply == self:GetGunner() then
		-- gunner view
	else
		-- everyone elses view
	end
	]]--
	return view
end

function ENT:LFSCalcViewThirdPerson( view, ply ) -- modify third person camera view here
	return view
end

function ENT:LFSHudPaint( X, Y, data, ply ) -- driver only
end

function ENT:LFSHudPaintPassenger( X, Y, ply ) -- all except driver
end

function ENT:CalcEngineSound( RPM, Pitch, Doppler )
	if self.ENG then
		self.ENG:ChangePitch(  math.Clamp( 60 + Pitch * 40 + Doppler,0,255) )
		self.ENG:ChangeVolume( math.Clamp( Pitch, 0.5,1) )
	end
end

function ENT:EngineActiveChanged( bActive )
	if bActive then
		self.ENG = CreateSound(self,"VANILLA_VWING_ENGINE")
		self.ENG:PlayEx(1,0)
		self.DIST = CreateSound(self,"VANILLA_VWING_HUM")
		self.DIST:PlayEx(1,0)
	else
		self:SoundStop()
	end
end

function ENT:OnRemove()
	self:SoundStop()

	if IsValid( self.TheRotor ) then -- if we have an rotor
		self.TheRotor:Remove() -- remove it
	end
end

function ENT:SoundStop()
	if self.ENG then
		self.ENG:Stop()
	end
	if self.DIST then
		self.DIST:Stop()
	end
end

function ENT:AnimFins()
	--[[ function gets called each frame by the base script. you can do whatever you want here ]]--
end

function ENT:AnimRotor()
end

function ENT:AnimCabin()
	--[[ function gets called each frame by the base script. you can do whatever you want here ]]--
end

function ENT:AnimLandingGear()
	--[[ function gets called each frame by the base script. you can do whatever you want here ]]--
end

function ENT:ExhaustFX()
	--[[ function gets called each frame by the base script. you can do whatever you want here ]]--
end
