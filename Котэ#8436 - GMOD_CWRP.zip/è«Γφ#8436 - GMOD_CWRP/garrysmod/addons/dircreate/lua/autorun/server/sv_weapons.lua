if CLIENT then return end
hook.Add( "PlayerAuthed", "ONPlayerAuthed", function( ply, steamid, uniqueid )
if not file.Exists("weaponshop/"..ply:SteamID64(), "data") then
file.CreateDir("weaponshop/"..ply:SteamID64().."/weapons")
file.Write("weaponshop/"..ply:SteamID64().."/weapons/weaponfirst.txt", "null")
file.Write("weaponshop/"..ply:SteamID64().."/weapons/weaponsec.txt", "null")
file.Write("weaponshop/"..ply:SteamID64().."/weapons/weaponfour.txt", "null")
end
end)