if CLIENT then return end
hook.Add( "PlayerAuthed", "ONPlayerAuthed", function( ply, steamid, uniqueid )
	if not file.Exists("users/"..ply:SteamID64(), "data") then
	file.CreateDir("users/"..ply:SteamID64().."/model")
	file.Write("users/"..ply:SteamID64().."/model/model.txt", "models/aussiwozzi/phase1clones/sergeant.mdl")

	file.CreateDir("users/"..ply:SteamID64().."/bodygroups")
	file.Write("users/"..ply:SteamID64().."/bodygroups/bodygroups.txt", "000000")

	file.CreateDir("users/"..ply:SteamID64().."/skin")
	file.Write("users/"..ply:SteamID64().."/skin/skin.txt", "0")

	file.CreateDir("users/"..ply:SteamID64().."/size")
	file.Write("users/"..ply:SteamID64().."/size/size.txt", "1")

	file.CreateDir("users/"..ply:SteamID64().."/rank")
	file.Write("users/"..ply:SteamID64().."/rank/rank.txt", "РКТ")

	file.CreateDir("users/"..ply:SteamID64().."/spec")
	file.Write("users/"..ply:SteamID64().."/spec/spec.txt", "НЕ СПЕЦИАЛИСТ")

	file.CreateDir("users/"..ply:SteamID64().."/name")
    file.Write("users/"..ply:SteamID64().."/name/name.txt", "ГАММА")

	file.CreateDir("users/"..ply:SteamID64().."/number")
	file.Write("users/"..ply:SteamID64().."/number/number.txt", math.random( 1000, 9999 ))

	file.CreateDir("users/"..ply:SteamID64().."/legion")
	file.Write("users/"..ply:SteamID64().."/legion/legion.txt", "СК")

	file.CreateDir("users/"..ply:SteamID64().."/health")
	file.Write("users/"..ply:SteamID64().."/health/health.txt", "150")

	file.CreateDir("users/"..ply:SteamID64().."/armor")
	file.Write("users/"..ply:SteamID64().."/armor/armor.txt", "200")

	file.CreateDir("users/"..ply:SteamID64().."/speed")
	file.Write("users/"..ply:SteamID64().."/speed/speed.txt", "1")

	file.CreateDir("users/"..ply:SteamID64().."/grav")
	file.Write("users/"..ply:SteamID64().."/grav/grav.txt", "1")

	file.CreateDir("users/"..ply:SteamID64().."/admin")
	file.Write("users/"..ply:SteamID64().."/admin/admin.txt", "user")
	file.Write("users/"..ply:SteamID64().."/admin/frozen.txt", "false")
	file.Write("users/"..ply:SteamID64().."/admin/cloak.txt", "false")

	file.CreateDir("users/"..ply:SteamID64().."/warns")
	file.Write("users/"..ply:SteamID64().."/warns/warns.txt", "0")

	file.CreateDir("users/"..ply:SteamID64().."/weaponfirst")
	file.Write("users/"..ply:SteamID64().."/weaponfirst/weaponfirst.txt", "arms")

	file.CreateDir("users/"..ply:SteamID64().."/weaponsecond")
	file.Write("users/"..ply:SteamID64().."/weaponsecond/weaponsecond.txt", "arms")

	file.CreateDir("users/"..ply:SteamID64().."/weapongrenade")
	file.Write("users/"..ply:SteamID64().."/weapongrenade/weapongrenade.txt", "arms")

	file.CreateDir("users/"..ply:SteamID64().."/weapongrenade2")
	file.Write("users/"..ply:SteamID64().."/weapongrenade2/weapongrenade2.txt", "arms")

	file.CreateDir("users/"..ply:SteamID64().."/weaponknife")
	file.Write("users/"..ply:SteamID64().."/weaponknife/weaponknife.txt", "arms")

	file.CreateDir("users/"..ply:SteamID64().."/utiles")
    file.Write("users/"..ply:SteamID64().."/utiles/utiles.txt", "arms")

	file.CreateDir("users/"..ply:SteamID64().."/utiles2")
    file.Write("users/"..ply:SteamID64().."/utiles2/utiles2.txt", "arms")

    file.CreateDir("users/"..ply:SteamID64().."/entity")
    file.Write("users/"..ply:SteamID64().."/entity/entity.txt", "null")
    
	file.CreateDir("users/"..ply:SteamID64().."/money")
    file.Write("users/"..ply:SteamID64().."/money/money.txt", "0")
    file.Write("users/"..ply:SteamID64().."/money/moneyboost.txt", "1")
    file.Write("users/"..ply:SteamID64().."/money/points.txt", "0")

	file.CreateDir("users/"..ply:SteamID64().."/level")
    file.Write("users/"..ply:SteamID64().."/level/level.txt", "0")
    file.Write("users/"..ply:SteamID64().."/level/xp.txt", "0")
    file.Write("users/"..ply:SteamID64().."/level/booster.txt", "1")
    file.Write("users/"..ply:SteamID64().."/level/hpboost.txt", "1")
    file.Write("users/"..ply:SteamID64().."/level/armorboost.txt", "1")
    file.Write("users/"..ply:SteamID64().."/level/statminaboost.txt", "1")
    file.Write("users/"..ply:SteamID64().."/level/ammoboost.txt", "1")
    file.Write("users/"..ply:SteamID64().."/level/granboost.txt", "0")
    file.Write("users/"..ply:SteamID64().."/level/speedboost.txt", "1")

	file.CreateDir("users/"..ply:SteamID64().."/radio")
    file.Write("users/"..ply:SteamID64().."/radio/radio.txt", "null")
    file.Write("users/"..ply:SteamID64().."/radio/radioon.txt", "null")

	file.CreateDir("users/"..ply:SteamID64().."/banned")
    file.Write("users/"..ply:SteamID64().."/banned/banned.txt", "false")
    file.Write("users/"..ply:SteamID64().."/banned/timerbanned.txt", "null")
    file.Write("users/"..ply:SteamID64().."/banned/whobanned.txt", "none")
    file.Write("users/"..ply:SteamID64().."/banned/reason.txt", "none")
end
end)

hook.Add( "PlayerSpawn", "ONPlayerSpawndb", function( ply, steamid, uniqueid )
	if not file.Exists("users/"..ply:SteamID64(), "data") then
	file.CreateDir("users/"..ply:SteamID64().."/model")
	file.Write("users/"..ply:SteamID64().."/model/model.txt", "models/aussiwozzi/phase1clones/sergeant.mdl")

	file.CreateDir("users/"..ply:SteamID64().."/bodygroups")
	file.Write("users/"..ply:SteamID64().."/bodygroups/bodygroups.txt", "000000")

	file.CreateDir("users/"..ply:SteamID64().."/skin")
	file.Write("users/"..ply:SteamID64().."/skin/skin.txt", "0")

	file.CreateDir("users/"..ply:SteamID64().."/size")
	file.Write("users/"..ply:SteamID64().."/size/size.txt", "1")

	file.CreateDir("users/"..ply:SteamID64().."/rank")
	file.Write("users/"..ply:SteamID64().."/rank/rank.txt", "РКТ")

	file.CreateDir("users/"..ply:SteamID64().."/spec")
	file.Write("users/"..ply:SteamID64().."/spec/spec.txt", "НЕ СПЕЦИАЛИСТ")

	file.CreateDir("users/"..ply:SteamID64().."/name")
    file.Write("users/"..ply:SteamID64().."/name/name.txt", "ГАММА")

	file.CreateDir("users/"..ply:SteamID64().."/number")
	file.Write("users/"..ply:SteamID64().."/number/number.txt", math.random( 1000, 9999 ))

	file.CreateDir("users/"..ply:SteamID64().."/legion")
	file.Write("users/"..ply:SteamID64().."/legion/legion.txt", "СК")

	file.CreateDir("users/"..ply:SteamID64().."/health")
	file.Write("users/"..ply:SteamID64().."/health/health.txt", "150")

	file.CreateDir("users/"..ply:SteamID64().."/armor")
	file.Write("users/"..ply:SteamID64().."/armor/armor.txt", "200")

	file.CreateDir("users/"..ply:SteamID64().."/speed")
	file.Write("users/"..ply:SteamID64().."/speed/speed.txt", "1")

	file.CreateDir("users/"..ply:SteamID64().."/grav")
	file.Write("users/"..ply:SteamID64().."/grav/grav.txt", "1")

	file.CreateDir("users/"..ply:SteamID64().."/admin")
	file.Write("users/"..ply:SteamID64().."/admin/admin.txt", "user")
	file.Write("users/"..ply:SteamID64().."/admin/frozen.txt", "false")
	file.Write("users/"..ply:SteamID64().."/admin/cloak.txt", "false")

	file.CreateDir("users/"..ply:SteamID64().."/warns")
	file.Write("users/"..ply:SteamID64().."/warns/warns.txt", "0")

	file.CreateDir("users/"..ply:SteamID64().."/weaponfirst")
	file.Write("users/"..ply:SteamID64().."/weaponfirst/weaponfirst.txt", "arms")

	file.CreateDir("users/"..ply:SteamID64().."/weaponsecond")
	file.Write("users/"..ply:SteamID64().."/weaponsecond/weaponsecond.txt", "arms")

	file.CreateDir("users/"..ply:SteamID64().."/weapongrenade")
	file.Write("users/"..ply:SteamID64().."/weapongrenade/weapongrenade.txt", "arms")

	file.CreateDir("users/"..ply:SteamID64().."/weapongrenade2")
	file.Write("users/"..ply:SteamID64().."/weapongrenade2/weapongrenade2.txt", "arms")

	file.CreateDir("users/"..ply:SteamID64().."/weaponknife")
	file.Write("users/"..ply:SteamID64().."/weaponknife/weaponknife.txt", "arms")

	file.CreateDir("users/"..ply:SteamID64().."/utiles")
    file.Write("users/"..ply:SteamID64().."/utiles/utiles.txt", "arms")

	file.CreateDir("users/"..ply:SteamID64().."/utiles2")
    file.Write("users/"..ply:SteamID64().."/utiles2/utiles2.txt", "arms")

    file.CreateDir("users/"..ply:SteamID64().."/entity")
    file.Write("users/"..ply:SteamID64().."/entity/entity.txt", "null")
    
	file.CreateDir("users/"..ply:SteamID64().."/money")
    file.Write("users/"..ply:SteamID64().."/money/money.txt", "0")
    file.Write("users/"..ply:SteamID64().."/money/moneyboost.txt", "1")
    file.Write("users/"..ply:SteamID64().."/money/points.txt", "0")

	file.CreateDir("users/"..ply:SteamID64().."/level")
    file.Write("users/"..ply:SteamID64().."/level/level.txt", "0")
    file.Write("users/"..ply:SteamID64().."/level/xp.txt", "0")
    file.Write("users/"..ply:SteamID64().."/level/booster.txt", "1")
    file.Write("users/"..ply:SteamID64().."/level/hpboost.txt", "1")
    file.Write("users/"..ply:SteamID64().."/level/armorboost.txt", "1")
    file.Write("users/"..ply:SteamID64().."/level/statminaboost.txt", "1")
    file.Write("users/"..ply:SteamID64().."/level/ammoboost.txt", "1")
    file.Write("users/"..ply:SteamID64().."/level/granboost.txt", "0")
    file.Write("users/"..ply:SteamID64().."/level/speedboost.txt", "1")

	file.CreateDir("users/"..ply:SteamID64().."/radio")
    file.Write("users/"..ply:SteamID64().."/radio/radio.txt", "null")
    file.Write("users/"..ply:SteamID64().."/radio/radioon.txt", "null")

	file.CreateDir("users/"..ply:SteamID64().."/banned")
    file.Write("users/"..ply:SteamID64().."/banned/banned.txt", "false")
    file.Write("users/"..ply:SteamID64().."/banned/timerbanned.txt", "null")
    file.Write("users/"..ply:SteamID64().."/banned/whobanned.txt", "none")
    file.Write("users/"..ply:SteamID64().."/banned/reason.txt", "none")
end
end)

if not file.Exists("server", "data") then
file.CreateDir("server")
file.Write("server/defc.txt", "G")
file.Write("server/prikaz.txt", "null")
end

if not file.Exists("event", "data") then
file.CreateDir("event")
file.Write("event/server1.txt", "close")
file.Write("event/server2.txt", "close")
end