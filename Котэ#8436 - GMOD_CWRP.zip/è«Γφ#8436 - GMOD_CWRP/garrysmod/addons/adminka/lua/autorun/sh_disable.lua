concommand.Remove("bot")

hook.Add( "ChatText", "hide_joinleavemessages", function( index, name, text, type )
	if ( type == "joinleave" ) then
		return true
	end
end )