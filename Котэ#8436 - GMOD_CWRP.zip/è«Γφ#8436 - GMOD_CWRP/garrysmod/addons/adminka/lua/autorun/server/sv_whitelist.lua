if CLIENT then return end

hook.Add( "PlayerDeath", "wlrestorewhendie", function( victim, inflictor, attacker )
file.Write("users/"..victim:SteamID64().."/admin/cloak.txt", "false")
file.Write("users/"..victim:SteamID64().."/radio/intercom.txt", "false")
file.Write("users/"..victim:SteamID64().."/radio/interdist.txt", "0")
file.Write("users/"..victim:SteamID64().."/admin/frozen.txt", "false")
victim:Freeze(false)
end )

local oneleg = "СК"
local twoleg = "501-Л"
local trileg = "574-К"
local forleg = "41-К"
local fivleg = "ГК"
local sixleg = "Флот"
local sevleg = "ЭРК"
local eigleg = "НЕТ"
hook.Add( "PlayerInitialSpawn", "ABObashookinitspawnhgssd", function( ply )
ply:SetNWInt( ply:SteamID64().."headhp", "100" )
ply:SetNWInt( ply:SteamID64().."armlefthp", "100" )
ply:SetNWInt( ply:SteamID64().."armrighthp", "100" )
ply:SetNWInt( ply:SteamID64().."leglefthp", "100" )
ply:SetNWInt( ply:SteamID64().."legrighthp", "100" )
file.Write("users/"..ply:SteamID64().."/admin/cloak.txt", "false")
file.Write("users/"..ply:SteamID64().."/radio/intercom.txt", "false")
file.Write("users/"..ply:SteamID64().."/radio/interdist.txt", "0")
file.Write("users/"..ply:SteamID64().."/admin/frozen.txt", "false")
-------=
local hpboost = file.Read("users/"..ply:SteamID64().."/level/hpboost.txt", "data")
local armorboost = file.Read("users/"..ply:SteamID64().."/level/armorboost.txt", "data")
local speedboost = file.Read("users/"..ply:SteamID64().."/level/speedboost.txt", "data")
---=----
local legion = file.Read("users/"..ply:SteamID64().."/legion/legion.txt", "data")
local bodygrops = file.Read("users/"..ply:SteamID64().."/bodygroups/bodygroups.txt", "data")
local skines = file.Read("users/"..ply:SteamID64().."/skin/skin.txt", "data")
local mscale = file.Read("users/"..ply:SteamID64().."/size/size.txt", "data")
local healsth = file.Read("users/"..ply:SteamID64().."/health/health.txt", "data")
local armorks = file.Read("users/"..ply:SteamID64().."/armor/armor.txt", "data")
local speedok = file.Read("users/"..ply:SteamID64().."/speed/speed.txt", "data")
local gravok = file.Read("users/"..ply:SteamID64().."/grav/grav.txt", "data")
local firweap = file.Read("users/"..ply:SteamID64().."/weaponfirst/weaponfirst.txt", "data")
local secweap = file.Read("users/"..ply:SteamID64().."/weaponsecond/weaponsecond.txt", "data")
local gern = file.Read("users/"..ply:SteamID64().."/weapongrenade/weapongrenade.txt", "data")
local gern2 = file.Read("users/"..ply:SteamID64().."/weapongrenade2/weapongrenade2.txt", "data")
local knifek = file.Read("users/"..ply:SteamID64().."/weaponknife/weaponknife.txt", "data")
local utile = file.Read("users/"..ply:SteamID64().."/utiles/utiles.txt", "data")
local utile2 = file.Read("users/"..ply:SteamID64().."/utiles2/utiles2.txt", "data")
local entitis = file.Read("users/"..ply:SteamID64().."/entity/entity.txt", "data")
ply:SetModel(file.Read("users/"..ply:SteamID64().."/model/model.txt", "data"))
timer.Create( ply:SteamID64().."firstspawngivewl", 1, 2, function()
ply:SetHealth( healsth * hpboost )
ply:SetMaxHealth( healsth * hpboost)
ply:SetArmor( armorks * armorboost )
ply:SetMaxArmor( armorks * armorboost )
ply:SetWalkSpeed( speedok * 100 * speedboost )
ply:SetRunSpeed( speedok * 240 * speedboost )
ply:SetGravity( gravok )
ply:SetModelScale( mscale, 1 )
ply:SetViewOffset( Vector( 0, 0, 64 ) * Vector( 0, 0, mscale ) )
ply:SetViewOffsetDucked(Vector( 0, 0, 28 ) * Vector( 0, 0, mscale ))
if (legion == oneleg) then
ply:SetTeam(1)
elseif (legion == twoleg) then
ply:SetTeam(2)
elseif (legion == trileg) then
ply:SetTeam(3)
elseif (legion == forleg) then
ply:SetTeam(4)
elseif (legion == fivleg) then
ply:SetTeam(5)
elseif (legion == sixleg) then
ply:SetTeam(6)
elseif (legion == sevleg) then
ply:SetTeam(7)
elseif (legion == eigleg) then
ply:SetTeam(8)
else
ply:SetTeam(9)
end
end )
ply:SetBodyGroups( bodygrops )
ply:SetSkin( skines )
ply:Give( "arms" )
--ply:Give( firweap, true )
--ply:Give( secweap, true )
--ply:Give( gern )
--ply:Give( gern2 )
--ply:Give( knifek )
--ply:Give( utile )
--ply:Give( utile2 )
end)

hook.Add( "PlayerSpawn", "some_unique_na2me2", function( ply )
ply:SetNWInt( ply:SteamID64().."headhp", "100" )
ply:SetNWInt( ply:SteamID64().."armlefthp", "100" )
ply:SetNWInt( ply:SteamID64().."armrighthp", "100" )
ply:SetNWInt( ply:SteamID64().."leglefthp", "100" )
ply:SetNWInt( ply:SteamID64().."legrighthp", "100" )
file.Write("users/"..ply:SteamID64().."/admin/cloak.txt", "false")
file.Write("users/"..ply:SteamID64().."/radio/intercom.txt", "false")
file.Write("users/"..ply:SteamID64().."/radio/interdist.txt", "0")
file.Write("users/"..ply:SteamID64().."/admin/frozen.txt", "false")
-------=
local hpboost = file.Read("users/"..ply:SteamID64().."/level/hpboost.txt", "data")
local armorboost = file.Read("users/"..ply:SteamID64().."/level/armorboost.txt", "data")
local speedboost = file.Read("users/"..ply:SteamID64().."/level/speedboost.txt", "data")
---=----
local legion = file.Read("users/"..ply:SteamID64().."/legion/legion.txt", "data")
local bodygrops = file.Read("users/"..ply:SteamID64().."/bodygroups/bodygroups.txt", "data")
local skines = file.Read("users/"..ply:SteamID64().."/skin/skin.txt", "data")
local mscale = file.Read("users/"..ply:SteamID64().."/size/size.txt", "data")
local healsth = file.Read("users/"..ply:SteamID64().."/health/health.txt", "data")
local armorks = file.Read("users/"..ply:SteamID64().."/armor/armor.txt", "data")
local speedok = file.Read("users/"..ply:SteamID64().."/speed/speed.txt", "data")
local gravok = file.Read("users/"..ply:SteamID64().."/grav/grav.txt", "data")
local firweap = file.Read("users/"..ply:SteamID64().."/weaponfirst/weaponfirst.txt", "data")
local secweap = file.Read("users/"..ply:SteamID64().."/weaponsecond/weaponsecond.txt", "data")
local gern = file.Read("users/"..ply:SteamID64().."/weapongrenade/weapongrenade.txt", "data")
local gern2 = file.Read("users/"..ply:SteamID64().."/weapongrenade2/weapongrenade2.txt", "data")
local knifek = file.Read("users/"..ply:SteamID64().."/weaponknife/weaponknife.txt", "data")
local utile = file.Read("users/"..ply:SteamID64().."/utiles/utiles.txt", "data")
local utile2 = file.Read("users/"..ply:SteamID64().."/utiles2/utiles2.txt", "data")
local entitis = file.Read("users/"..ply:SteamID64().."/entity/entity.txt", "data")
ply:SetModel(file.Read("users/"..ply:SteamID64().."/model/model.txt", "data"))
timer.Create( ply:SteamID64().."firstspawngivewl2", 1, 2, function()
ply:SetHealth( healsth * hpboost )
ply:SetMaxHealth( healsth * hpboost )
ply:SetArmor( armorks * armorboost )
ply:SetMaxArmor( armorks * armorboost )
ply:SetWalkSpeed( speedok * 100 * speedboost )
ply:SetRunSpeed( speedok * 240 * speedboost )
ply:SetGravity( gravok )
ply:SetModelScale( mscale, 1 )
ply:SetViewOffset( Vector( 0, 0, 64 ) * Vector( 0, 0, mscale ) )
ply:SetViewOffsetDucked(Vector( 0, 0, 28 ) * Vector( 0, 0, mscale ))
if (legion == oneleg) then
ply:SetTeam(1)
elseif (legion == twoleg) then
ply:SetTeam(2)
elseif (legion == trileg) then
ply:SetTeam(3)
elseif (legion == forleg) then
ply:SetTeam(4)
elseif (legion == fivleg) then
ply:SetTeam(5)
elseif (legion == sixleg) then
ply:SetTeam(6)
elseif (legion == sevleg) then
ply:SetTeam(7)
elseif (legion == eigleg) then
ply:SetTeam(8)
else
ply:SetTeam(9)
end
end )
ply:SetBodyGroups( bodygrops )
ply:SetSkin( skines )
ply:Give( "arms" )
--ply:Give( firweap, true )
--ply:Give( secweap, true )
--ply:Give( gern )
--ply:Give( gern2 )
--ply:Give( knifek )
--ply:Give( utile )
--ply:Give( utile2 )
if (entitis != "null") then
local ent = ents.Create(entitis)
ent:SetPos( ply:GetPos() ) 
ent:Spawn()
ent:Use( ply, NULL, 1, 0 )
-----
--print(ent:EntIndex())
--ents.GetByIndex(ent:EntIndex()):Remove()
------
end
end)

hook.Add( "PlayerAuthed", "JoinNotification", function( ply, steamid, uniqueid )
local banned = file.Read("users/"..ply:SteamID64().."/banned/banned.txt", "data")
local banner = file.Read("users/"..ply:SteamID64().."/banned/whobanned.txt", "data")
local reasons = file.Read("users/"..ply:SteamID64().."/banned/reason.txt", "data")
--local timerbanned = file.Read("users/"..ply:SteamID64().."/banned/timerbanned.txt", "data")
--local timerbanned2 = timerbanned + 0
--if (timerbanned2 > 0) then game.KickID( ply:SteamID(), "Вы временно забанены на нашем сервере, вам осталось подождать: "..timerbanned2.." минут. А если интересно то вас заблокировал "..banner) end
if banned == "true" then game.KickID( ply:SteamID(), "Поздравляю вы заблокированы на нашем сервере. А если интересно то, вас заблокировал "..banner..". Причина сея бана: "..reasons) end
end)

util.AddNetworkString("whitelistclient")
util.AddNetworkString("whitelist")
net.Receive("whitelist", function()
local playeadm = net.ReadString()
local caller = net.ReadEntity()
local function WLCList()
net.Start('whitelistclient')
net.WriteString(file.Read("users/"..playeadm.."/name/name.txt", "data"))
net.WriteString(file.Read("users/"..playeadm.."/number/number.txt", "data"))
net.WriteString(file.Read("users/"..playeadm.."/legion/legion.txt", "data"))
net.WriteString(file.Read("users/"..playeadm.."/rank/rank.txt", "data"))
net.WriteString(playeadm)
net.Send(caller)
end
WLCList()
end)

util.AddNetworkString("whitelistclient2")
util.AddNetworkString("whitelist2")
net.Receive("whitelist2", function()
local playeadm = net.ReadString()
local caller = net.ReadEntity()
local function WLCList2()
net.Start('whitelistclient2')
net.WriteString(file.Read("users/"..playeadm.."/name/name.txt", "data"))
net.WriteString(file.Read("users/"..playeadm.."/number/number.txt", "data"))
net.WriteString(file.Read("users/"..playeadm.."/legion/legion.txt", "data"))
net.WriteString(file.Read("users/"..playeadm.."/rank/rank.txt", "data"))
net.WriteString(playeadm)
net.Send(caller)
end
WLCList2()
end)

util.AddNetworkString("wlistmodel")
net.Receive("wlistmodel", function()
local reasons = net.ReadString()
local banner = net.ReadString()
local user = net.ReadEntity()
local bannername = "?"
for i, v in pairs(player.GetAll()) do
        if v:SteamID64() == banner then    
        bannername = v:Name()
        end
end
if file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "owner" and file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" then
if util.IsValidProp( reasons ) then return end;
user:SetModel( reasons )
file.Write("users/"..user:SteamID64().."/model/model.txt", reasons)
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сменил модель на ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "highadmin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
if util.IsValidProp( reasons ) then return end;
user:SetModel( reasons )
file.Write("users/"..user:SteamID64().."/model/model.txt", reasons)
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сменил модель на ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "admin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
if util.IsValidProp( reasons ) then return end;
user:SetModel( reasons )
file.Write("users/"..user:SteamID64().."/model/model.txt", reasons)
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сменил модель на ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "commander" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "commander") then
if util.IsValidProp( reasons ) then return end;
user:SetModel( reasons )
file.Write("users/"..user:SteamID64().."/model/model.txt", reasons)
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сменил модель на ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "user" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "commander") then
if util.IsValidProp( reasons ) then return end;
user:SetModel( reasons )
file.Write("users/"..user:SteamID64().."/model/model.txt", reasons)
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сменил модель на ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
end
end)

util.AddNetworkString("wlistbodygroups")
net.Receive("wlistbodygroups", function()
local reasons = net.ReadString()
local banner = net.ReadString()
local user = net.ReadEntity()
local bannername = "?"
for i, v in pairs(player.GetAll()) do
        if v:SteamID64() == banner then    
        bannername = v:Name()
        end
end
if file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "owner" and file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" then
user:SetBodyGroups( reasons )
file.Write("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", reasons)
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сменил бодигруппы на ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "highadmin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
user:SetBodyGroups( reasons )
file.Write("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", reasons)
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сменил бодигруппы на ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "admin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
user:SetBodyGroups( reasons )
file.Write("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", reasons)
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сменил бодигруппы на ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "commander" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "commander") then
user:SetBodyGroups( reasons )
file.Write("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", reasons)
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сменил бодигруппы на ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "user" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "commander") then
user:SetBodyGroups( reasons )
file.Write("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", reasons)
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сменил бодигруппы на ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
end
end)

util.AddNetworkString("wlistskinsesd")
net.Receive("wlistskinsesd", function()
local reasons = net.ReadString()
local banner = net.ReadString()
local user = net.ReadEntity()
local bannername = "?"
for i, v in pairs(player.GetAll()) do
        if v:SteamID64() == banner then    
        bannername = v:Name()
        end
end
if file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "owner" and file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" then
user:SetSkin( reasons )
file.Write("users/"..user:SteamID64().."/skin/skin.txt", reasons)
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сменил скин на ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "highadmin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
user:SetSkin( reasons )
file.Write("users/"..user:SteamID64().."/skin/skin.txt", reasons)
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сменил скин на ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "admin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
user:SetSkin( reasons )
file.Write("users/"..user:SteamID64().."/skin/skin.txt", reasons)
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сменил скин на ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "commander" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "commander") then
user:SetSkin( reasons )
file.Write("users/"..user:SteamID64().."/skin/skin.txt", reasons)
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сменил скин на ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "user" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "commander") then
user:SetSkin( reasons )
file.Write("users/"..user:SteamID64().."/skin/skin.txt", reasons)
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сменил скин на ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
end
end)

util.AddNetworkString("wlistsize")
net.Receive("wlistsize", function()
local reason = net.ReadString()
local banner = net.ReadString()
local user = net.ReadEntity()
local reasons = (reason + 0)
local bannername = "?"
for i, v in pairs(player.GetAll()) do
        if v:SteamID64() == banner then    
        bannername = v:Name()
        end
end
if file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "owner" and file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" then
user:SetModelScale( reasons, 1 )
user:SetViewOffset( Vector( 0, 0, 64 ) * Vector( 0, 0, reasons ) )
user:SetViewOffsetDucked(Vector( 0, 0, 28 ) * Vector( 0, 0, reasons ))
file.Write("users/"..user:SteamID64().."/size/size.txt", reasons)
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сменил размер на ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "highadmin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
user:SetModelScale( reasons, 1 )
user:SetViewOffset( Vector( 0, 0, 64 ) * Vector( 0, 0, reasons ) )
user:SetViewOffsetDucked(Vector( 0, 0, 28 ) * Vector( 0, 0, reasons ))
file.Write("users/"..user:SteamID64().."/size/size.txt", reasons)
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сменил размер на ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "admin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
user:SetModelScale( reasons, 1 )
user:SetViewOffset( Vector( 0, 0, 64 ) * Vector( 0, 0, reasons ) )
user:SetViewOffsetDucked(Vector( 0, 0, 28 ) * Vector( 0, 0, reasons ))
file.Write("users/"..user:SteamID64().."/size/size.txt", reasons)
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сменил размер на ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "commander" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "commander") then
user:SetModelScale( reasons, 1 )
user:SetViewOffset( Vector( 0, 0, 64 ) * Vector( 0, 0, reasons ) )
user:SetViewOffsetDucked(Vector( 0, 0, 28 ) * Vector( 0, 0, reasons ))
file.Write("users/"..user:SteamID64().."/size/size.txt", reasons)
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сменил размер на ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "user" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "commander") then
user:SetModelScale( reasons, 1 )
user:SetViewOffset( Vector( 0, 0, 64 ) * Vector( 0, 0, reasons ) )
user:SetViewOffsetDucked(Vector( 0, 0, 28 ) * Vector( 0, 0, reasons ))
file.Write("users/"..user:SteamID64().."/size/size.txt", reasons)
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сменил размер на ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
end
end)

util.AddNetworkString("wlistpoziv")
net.Receive("wlistpoziv", function()
local reasons = net.ReadString()
local banner = net.ReadString()
local user = net.ReadEntity()
local bannername = "?"
for i, v in pairs(player.GetAll()) do
        if v:SteamID64() == banner then    
        bannername = v:Name()
        end
end
if file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "owner" and file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" then
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сменил позывной на ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
file.Write("users/"..user:SteamID64().."/name/name.txt", reasons)
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "highadmin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сменил позывной на ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
file.Write("users/"..user:SteamID64().."/name/name.txt", reasons)
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "admin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сменил позывной на ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
file.Write("users/"..user:SteamID64().."/name/name.txt", reasons)
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "commander" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "commander") then
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сменил позывной на ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
file.Write("users/"..user:SteamID64().."/name/name.txt", reasons)
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "user" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "commander") then
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сменил позывной на ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
file.Write("users/"..user:SteamID64().."/name/name.txt", reasons)
end
end)

util.AddNetworkString("wlistnum")
net.Receive("wlistnum", function()
local reason = net.ReadString()
local banner = net.ReadString()
local user = net.ReadEntity()
local reasons = (reason + 1 - 1)
local bannername = "?"
for i, v in pairs(player.GetAll()) do
        if v:SteamID64() == banner then    
        bannername = v:Name()
        end
end
if file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "owner" and file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" then
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сменил номер на ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
file.Write("users/"..user:SteamID64().."/number/number.txt", reasons)
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "highadmin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сменил номер на ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
file.Write("users/"..user:SteamID64().."/number/number.txt", reasons)
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "admin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сменил номер на ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
file.Write("users/"..user:SteamID64().."/number/number.txt", reasons)
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "commander" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "commander") then
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сменил номер на ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
file.Write("users/"..user:SteamID64().."/number/number.txt", reasons)
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "user" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "commander") then
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сменил номер на ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
file.Write("users/"..user:SteamID64().."/number/number.txt", reasons)
end
end)

util.AddNetworkString("wlistlegion")
net.Receive("wlistlegion", function()
local reasons = net.ReadString()
local banner = net.ReadString()
local user = net.ReadEntity()
local bannername = "?"
for i, v in pairs(player.GetAll()) do
        if v:SteamID64() == banner then    
        bannername = v:Name()
        end
end
if file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "owner" and file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" then
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сменил легион на ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
file.Write("users/"..user:SteamID64().."/legion/legion.txt", reasons)
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "highadmin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сменил легион на ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
file.Write("users/"..user:SteamID64().."/legion/legion.txt", reasons)
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "admin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сменил легион на ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
file.Write("users/"..user:SteamID64().."/legion/legion.txt", reasons)
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "commander" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "commander") then
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сменил легион на ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
file.Write("users/"..user:SteamID64().."/legion/legion.txt", reasons)
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "user" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "commander") then
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сменил легион на ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
file.Write("users/"..user:SteamID64().."/legion/legion.txt", reasons)
end
end)

util.AddNetworkString("wlrank")
net.Receive("wlrank", function()
local reasons = net.ReadString()
local banner = net.ReadString()
local user = net.ReadEntity()
local bannername = "?"
for i, v in pairs(player.GetAll()) do
        if v:SteamID64() == banner then    
        bannername = v:Name()
        end
end
if file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "owner" and file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" then
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сменил звание на ["..reasons.."] а было ["..file.Read("users/"..user:SteamID64().."/rank/rank.txt", "data").."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
file.Write("users/"..user:SteamID64().."/rank/rank.txt", reasons)
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "highadmin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сменил звание на ["..reasons.."] а было ["..file.Read("users/"..user:SteamID64().."/rank/rank.txt", "data").."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
file.Write("users/"..user:SteamID64().."/rank/rank.txt", reasons)
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "admin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сменил звание на ["..reasons.."] а было ["..file.Read("users/"..user:SteamID64().."/rank/rank.txt", "data").."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
file.Write("users/"..user:SteamID64().."/rank/rank.txt", reasons)
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "commander" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "commander") then
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сменил звание на ["..reasons.."] а было ["..file.Read("users/"..user:SteamID64().."/rank/rank.txt", "data").."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
file.Write("users/"..user:SteamID64().."/rank/rank.txt", reasons)
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "user" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "commander") then
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сменил звание на ["..reasons.."] а было ["..file.Read("users/"..user:SteamID64().."/rank/rank.txt", "data").."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
file.Write("users/"..user:SteamID64().."/rank/rank.txt", reasons)
end
end)

util.AddNetworkString("wlspec")
net.Receive("wlspec", function()
local reasons = net.ReadString()
local banner = net.ReadString()
local user = net.ReadEntity()
local bannername = "?"
for i, v in pairs(player.GetAll()) do
        if v:SteamID64() == banner then    
        bannername = v:Name()
        end
end
if file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "owner" and file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" then
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сменил специализации на ["..reasons.."] а было ["..file.Read("users/"..user:SteamID64().."/spec/spec.txt", "data").."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
file.Write("users/"..user:SteamID64().."/spec/spec.txt", reasons)
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "highadmin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сменил специализации на ["..reasons.."] а было ["..file.Read("users/"..user:SteamID64().."/spec/spec.txt", "data").."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
file.Write("users/"..user:SteamID64().."/spec/spec.txt", reasons)
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "admin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сменил специализации на ["..reasons.."] а было ["..file.Read("users/"..user:SteamID64().."/spec/spec.txt", "data").."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
file.Write("users/"..user:SteamID64().."/spec/spec.txt", reasons)
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "commander" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "commander") then
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сменил специализации на ["..reasons.."] а было ["..file.Read("users/"..user:SteamID64().."/spec/spec.txt", "data").."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
file.Write("users/"..user:SteamID64().."/spec/spec.txt", reasons)
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "user" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "commander") then
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сменил специализации на ["..reasons.."] а было ["..file.Read("users/"..user:SteamID64().."/spec/spec.txt", "data").."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
file.Write("users/"..user:SteamID64().."/spec/spec.txt", reasons)
end
end)

util.AddNetworkString("wlfirweap")
net.Receive("wlfirweap", function()
local reasons = net.ReadString()
local banner = net.ReadString()
local user = net.ReadEntity()
local bannername = "?"
for i, v in pairs(player.GetAll()) do
        if v:SteamID64() == banner then    
        bannername = v:Name()
        end
end
if file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "owner" and file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" then
file.Write("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", reasons)
user:Give( reasons )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL основное оружие ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "highadmin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
file.Write("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", reasons)
user:Give( reasons )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL основное оружие ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "admin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
file.Write("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", reasons)
user:Give( reasons )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL основное оружие ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "commander" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "commander") then
file.Write("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", reasons)
user:Give( reasons )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL основное оружие ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "user" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "commander") then
file.Write("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", reasons)
user:Give( reasons )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL основное оружие ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
end
end)

util.AddNetworkString("wlsecweap")
net.Receive("wlsecweap", function()
local reasons = net.ReadString()
local banner = net.ReadString()
local user = net.ReadEntity()
local bannername = "?"
for i, v in pairs(player.GetAll()) do
        if v:SteamID64() == banner then    
        bannername = v:Name()
        end
end
if file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "owner" and file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" then
file.Write("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", reasons)
user:Give( reasons )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL вторичное оружие ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "highadmin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
file.Write("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", reasons)
user:Give( reasons )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL вторичное оружие ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "admin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
file.Write("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", reasons)
user:Give( reasons )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL вторичное оружие ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "commander" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "commander") then
file.Write("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", reasons)
user:Give( reasons )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL вторичное оружие ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "user" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "commander") then
file.Write("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", reasons)
user:Give( reasons )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL вторичное оружие ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
end
end)

util.AddNetworkString("wlfirgren")
net.Receive("wlfirgren", function()
local reasons = net.ReadString()
local banner = net.ReadString()
local user = net.ReadEntity()
local bannername = "?"
for i, v in pairs(player.GetAll()) do
        if v:SteamID64() == banner then    
        bannername = v:Name()
        end
end
if file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "owner" and file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" then
file.Write("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", reasons)
user:Give( reasons )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL основная граната ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "highadmin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
file.Write("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", reasons)
user:Give( reasons )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL основная граната ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "admin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
file.Write("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", reasons)
user:Give( reasons )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL основная граната ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "commander" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "commander") then
file.Write("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", reasons)
user:Give( reasons )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL основная граната ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "user" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "commander") then
file.Write("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", reasons)
user:Give( reasons )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL основная граната ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
end
end)

util.AddNetworkString("wlsecgren")
net.Receive("wlsecgren", function()
local reasons = net.ReadString()
local banner = net.ReadString()
local user = net.ReadEntity()
local bannername = "?"
for i, v in pairs(player.GetAll()) do
        if v:SteamID64() == banner then    
        bannername = v:Name()
        end
end
if file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "owner" and file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" then
file.Write("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", reasons)
user:Give( reasons )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL вторичная граната ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "highadmin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
file.Write("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", reasons)
user:Give( reasons )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL вторичная граната ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "admin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
file.Write("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", reasons)
user:Give( reasons )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL вторичная граната ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "commander" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "commander") then
file.Write("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", reasons)
user:Give( reasons )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL вторичная граната ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "user" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "commander") then
file.Write("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", reasons)
user:Give( reasons )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL вторичная граната ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
end
end)

util.AddNetworkString("wlknife")
net.Receive("wlknife", function()
local reasons = net.ReadString()
local banner = net.ReadString()
local user = net.ReadEntity()
local bannername = "?"
for i, v in pairs(player.GetAll()) do
        if v:SteamID64() == banner then    
        bannername = v:Name()
        end
end
if file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "owner" and file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" then
file.Write("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", reasons)
user:Give( reasons )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL холодное оружие ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "highadmin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
file.Write("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", reasons)
user:Give( reasons )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL холодное оружие ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "admin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
file.Write("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", reasons)
user:Give( reasons )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL холодное оружие ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "commander" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "commander") then
file.Write("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", reasons)
user:Give( reasons )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL холодное оружие ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "user" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "commander") then
file.Write("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", reasons)
user:Give( reasons )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL холодное оружие ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
end
end)

util.AddNetworkString("wlutil")
net.Receive("wlutil", function()
local reasons = net.ReadString()
local banner = net.ReadString()
local user = net.ReadEntity()
local bannername = "?"
for i, v in pairs(player.GetAll()) do
        if v:SteamID64() == banner then    
        bannername = v:Name()
        end
end
if file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "owner" and file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" then
file.Write("users/"..user:SteamID64().."/utiles/utiles.txt", reasons)
user:Give( reasons )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL запасной слот ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "highadmin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
file.Write("users/"..user:SteamID64().."/utiles/utiles.txt", reasons)
user:Give( reasons )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL запасной слот ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "admin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
file.Write("users/"..user:SteamID64().."/utiles/utiles.txt", reasons)
user:Give( reasons )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL запасной слот ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "commander" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "commander") then
file.Write("users/"..user:SteamID64().."/utiles/utiles.txt", reasons)
user:Give( reasons )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL запасной слот ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "user" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "commander") then
file.Write("users/"..user:SteamID64().."/utiles/utiles.txt", reasons)
user:Give( reasons )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL запасной слот ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
end
end)

util.AddNetworkString("wlutil2")
net.Receive("wlutil2", function()
local reasons = net.ReadString()
local banner = net.ReadString()
local user = net.ReadEntity()
local bannername = "?"
for i, v in pairs(player.GetAll()) do
        if v:SteamID64() == banner then    
        bannername = v:Name()
        end
end
if file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "owner" and file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" then
file.Write("users/"..user:SteamID64().."/utiles2/utiles2.txt", reasons)
user:Give( reasons )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL запасной слот 2 ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "highadmin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
file.Write("users/"..user:SteamID64().."/utiles2/utiles2.txt", reasons)
user:Give( reasons )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL запасной слот 2 ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "admin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
file.Write("users/"..user:SteamID64().."/utiles2/utiles2.txt", reasons)
user:Give( reasons )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL запасной слот 2 ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "commander" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "commander") then
file.Write("users/"..user:SteamID64().."/utiles2/utiles2.txt", reasons)
user:Give( reasons )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL запасной слот 2 ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "user" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "commander") then
file.Write("users/"..user:SteamID64().."/utiles2/utiles2.txt", reasons)
user:Give( reasons )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL запасной слот 2 ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
end
end)

util.AddNetworkString("wlent")
net.Receive("wlent", function()
local reasons = net.ReadString()
local banner = net.ReadString()
local user = net.ReadEntity()
local bannername = "?"
for i, v in pairs(player.GetAll()) do
        if v:SteamID64() == banner then    
        bannername = v:Name()
        end
end
if file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "owner" and file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" then
file.Write("users/"..user:SteamID64().."/entity/entity.txt", reasons)
local ent = ents.Create(reasons)
ent:SetPos( user:GetPos() ) 
ent:Spawn()
ent:Use( user, NULL, 1, 0 )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL энтити ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "highadmin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
file.Write("users/"..user:SteamID64().."/entity/entity.txt", reasons)
local ent = ents.Create(reasons)
ent:SetPos( user:GetPos() ) 
ent:Spawn()
ent:Use( user, NULL, 1, 0 )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL энтити ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "admin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
file.Write("users/"..user:SteamID64().."/entity/entity.txt", reasons)
local ent = ents.Create(reasons)
ent:SetPos( user:GetPos() ) 
ent:Spawn()
ent:Use( user, NULL, 1, 0 )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL энтити ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "commander" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "commander") then
file.Write("users/"..user:SteamID64().."/entity/entity.txt", reasons)
local ent = ents.Create(reasons)
ent:SetPos( user:GetPos() ) 
ent:Spawn()
ent:Use( user, NULL, 1, 0 )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL энтити ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "user" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "commander") then
file.Write("users/"..user:SteamID64().."/entity/entity.txt", reasons)
local ent = ents.Create(reasons)
ent:SetPos( user:GetPos() ) 
ent:Spawn()
ent:Use( user, NULL, 1, 0 )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL энтити ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
end
end)

util.AddNetworkString("wlhealths")
net.Receive("wlhealths", function()
local reason = net.ReadString()
local banner = net.ReadString()
local user = net.ReadEntity()
local reasons = (reason + 0)
local bannername = "?"
for i, v in pairs(player.GetAll()) do
        if v:SteamID64() == banner then    
        bannername = v:Name()
        end
end
if file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "owner" and file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" then
local hpboost = file.Read("users/"..user:SteamID64().."/level/hpboost.txt", "data")
file.Write("users/"..user:SteamID64().."/health/health.txt", reasons)
user:SetHealth( reasons * hpboost )
user:SetMaxHealth( reasons * hpboost )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL здоровье ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "highadmin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
local hpboost = file.Read("users/"..user:SteamID64().."/level/hpboost.txt", "data")
file.Write("users/"..user:SteamID64().."/health/health.txt", reasons)
user:SetHealth( reasons * hpboost )
user:SetMaxHealth( reasons * hpboost )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL здоровье ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "admin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
local hpboost = file.Read("users/"..user:SteamID64().."/level/hpboost.txt", "data")
file.Write("users/"..user:SteamID64().."/health/health.txt", reasons)
user:SetHealth( reasons * hpboost )
user:SetMaxHealth( reasons * hpboost )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL здоровье ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "commander" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "commander") then
local hpboost = file.Read("users/"..user:SteamID64().."/level/hpboost.txt", "data")
file.Write("users/"..user:SteamID64().."/health/health.txt", reasons)
user:SetHealth( reasons * hpboost )
user:SetMaxHealth( reasons * hpboost )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL здоровье ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "user" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "commander") then
local hpboost = file.Read("users/"..user:SteamID64().."/level/hpboost.txt", "data")
file.Write("users/"..user:SteamID64().."/health/health.txt", reasons)
user:SetHealth( reasons * hpboost )
user:SetMaxHealth( reasons * hpboost )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL здоровье ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
end
end)

util.AddNetworkString("wlarmorhs")
net.Receive("wlarmorhs", function()
local reason = net.ReadString()
local banner = net.ReadString()
local user = net.ReadEntity()
local reasons = (reason + 0)
local bannername = "?"
for i, v in pairs(player.GetAll()) do
        if v:SteamID64() == banner then    
        bannername = v:Name()
        end
end
if file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "owner" and file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" then
local armorboost = file.Read("users/"..user:SteamID64().."/level/armorboost.txt", "data")
file.Write("users/"..user:SteamID64().."/armor/armor.txt", reasons)
user:SetArmor( reasons * armorboost )
user:SetMaxArmor( reasons * armorboost )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL броня ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "highadmin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
local armorboost = file.Read("users/"..user:SteamID64().."/level/armorboost.txt", "data")
file.Write("users/"..user:SteamID64().."/armor/armor.txt", reasons)
user:SetArmor( reasons * armorboost )
user:SetMaxArmor( reasons * armorboost )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL броня ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "admin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
local armorboost = file.Read("users/"..user:SteamID64().."/level/armorboost.txt", "data")
file.Write("users/"..user:SteamID64().."/armor/armor.txt", reasons)
user:SetArmor( reasons * armorboost )
user:SetMaxArmor( reasons * armorboost )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL броня ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "commander" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "commander") then
local armorboost = file.Read("users/"..user:SteamID64().."/level/armorboost.txt", "data")
file.Write("users/"..user:SteamID64().."/armor/armor.txt", reasons)
user:SetArmor( reasons * armorboost )
user:SetMaxArmor( reasons * armorboost )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL броня ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "user" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "commander") then
local armorboost = file.Read("users/"..user:SteamID64().."/level/armorboost.txt", "data")
file.Write("users/"..user:SteamID64().."/armor/armor.txt", reasons)
user:SetArmor( reasons * armorboost )
user:SetMaxArmor( reasons * armorboost )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL броня ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
end
end)

util.AddNetworkString("wlspeed")
net.Receive("wlspeed", function()
local reason = net.ReadString()
local banner = net.ReadString()
local user = net.ReadEntity()
local reasons = (reason + 0)
local bannername = "?"
for i, v in pairs(player.GetAll()) do
        if v:SteamID64() == banner then    
        bannername = v:Name()
        end
end
if file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "owner" and file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" then
local speedboost = file.Read("users/"..user:SteamID64().."/level/speedboost.txt", "data")
file.Write("users/"..user:SteamID64().."/speed/speed.txt", reasons)
user:SetWalkSpeed( reasons * 100 * speedboost )
user:SetRunSpeed( reasons * 240 * speedboost )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL скорость [x"..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "highadmin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
local speedboost = file.Read("users/"..user:SteamID64().."/level/speedboost.txt", "data")
file.Write("users/"..user:SteamID64().."/speed/speed.txt", reasons)
user:SetWalkSpeed( reasons * 100 * speedboost)
user:SetRunSpeed( reasons * 240 * speedboost)
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL скорость [x"..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "admin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
local speedboost = file.Read("users/"..user:SteamID64().."/level/speedboost.txt", "data")
file.Write("users/"..user:SteamID64().."/speed/speed.txt", reasons)
user:SetWalkSpeed( reasons * 100 * speedboost)
user:SetRunSpeed( reasons * 240 * speedboost)
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL скорость [x"..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "commander" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "commander") then
local speedboost = file.Read("users/"..user:SteamID64().."/level/speedboost.txt", "data")
file.Write("users/"..user:SteamID64().."/speed/speed.txt", reasons)
user:SetWalkSpeed( reasons * 100 * speedboost)
user:SetRunSpeed( reasons * 240 * speedboost)
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL скорость [x"..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "user" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "commander") then
local speedboost = file.Read("users/"..user:SteamID64().."/level/speedboost.txt", "data")
file.Write("users/"..user:SteamID64().."/speed/speed.txt", reasons)
user:SetWalkSpeed( reasons * 100 * speedboost)
user:SetRunSpeed( reasons * 240 * speedboost)
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL скорость [x"..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
end
end)

util.AddNetworkString("wlgrav")
net.Receive("wlgrav", function()
local reason = net.ReadString()
local banner = net.ReadString()
local user = net.ReadEntity()
local reasons = (reason + 0)
local bannername = "?"
for i, v in pairs(player.GetAll()) do
        if v:SteamID64() == banner then    
        bannername = v:Name()
        end
end
if file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "owner" and file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" then
file.Write("users/"..user:SteamID64().."/grav/grav.txt", reasons)
user:SetGravity( reasons )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL гравитация ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "highadmin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
file.Write("users/"..user:SteamID64().."/grav/grav.txt", reasons)
user:SetGravity( reasons )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL гравитация ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "admin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
file.Write("users/"..user:SteamID64().."/grav/grav.txt", reasons)
user:SetGravity( reasons )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL гравитация ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "commander" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "commander") then
file.Write("users/"..user:SteamID64().."/grav/grav.txt", reasons)
user:SetGravity( reasons )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL гравитация ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "user" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "commander") then
file.Write("users/"..user:SteamID64().."/grav/grav.txt", reasons)
user:SetGravity( reasons )
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL гравитация ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
end
end)

util.AddNetworkString("wlreloadchars")
net.Receive("wlreloadchars", function()
local reason = net.ReadString()
local banner = net.ReadString()
local user = net.ReadEntity()
local bannername = "?"
for i, v in pairs(player.GetAll()) do
        if v:SteamID64() == banner then    
        bannername = v:Name()
        end
end
if file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "owner" and file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" then
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сброс по причине: "..reason.."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
file.Write("users/"..user:SteamID64().."/model/model.txt", "models/aussiwozzi/phase1clones/sergeant.mdl")
file.Write("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "0000000000000")
file.Write("users/"..user:SteamID64().."/skin/skin.txt", "0")
file.Write("users/"..user:SteamID64().."/size/size.txt", "1")
file.Write("users/"..user:SteamID64().."/rank/rank.txt", "РКТ")
file.Write("users/"..user:SteamID64().."/spec/spec.txt", "НЕ СПЕЦИАЛИСТ")
file.Write("users/"..user:SteamID64().."/name/name.txt", "ГАММА")
file.Write("users/"..user:SteamID64().."/number/number.txt", math.random( 1000, 9999 ))
file.Write("users/"..user:SteamID64().."/legion/legion.txt", "СК")
file.Write("users/"..user:SteamID64().."/health/health.txt", "150")
file.Write("users/"..user:SteamID64().."/armor/armor.txt", "200")
file.Write("users/"..user:SteamID64().."/speed/speed.txt", "1")
file.Write("users/"..user:SteamID64().."/grav/grav.txt", "1")
file.Write("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "arms")
file.Write("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "arms")
file.Write("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "arms")
file.Write("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "arms")
file.Write("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles/utiles.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles2/utiles2.txt", "arms")
file.Write("users/"..user:SteamID64().."/entity/entity.txt", "null")
file.Write("users/"..user:SteamID64().."/radio/radio.txt", "null")
user:Kill()
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "highadmin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сброс по причине: "..reason.."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
file.Write("users/"..user:SteamID64().."/model/model.txt", "models/aussiwozzi/phase1clones/sergeant.mdl")
file.Write("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "0000000000000")
file.Write("users/"..user:SteamID64().."/skin/skin.txt", "0")
file.Write("users/"..user:SteamID64().."/size/size.txt", "1")
file.Write("users/"..user:SteamID64().."/rank/rank.txt", "РКТ")
file.Write("users/"..user:SteamID64().."/spec/spec.txt", "НЕ СПЕЦИАЛИСТ")
file.Write("users/"..user:SteamID64().."/name/name.txt", "ГАММА")
file.Write("users/"..user:SteamID64().."/number/number.txt", math.random( 1000, 9999 ))
file.Write("users/"..user:SteamID64().."/legion/legion.txt", "СК")
file.Write("users/"..user:SteamID64().."/health/health.txt", "150")
file.Write("users/"..user:SteamID64().."/armor/armor.txt", "200")
file.Write("users/"..user:SteamID64().."/speed/speed.txt", "1")
file.Write("users/"..user:SteamID64().."/grav/grav.txt", "1")
file.Write("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "arms")
file.Write("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "arms")
file.Write("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "arms")
file.Write("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "arms")
file.Write("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles/utiles.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles2/utiles2.txt", "arms")
file.Write("users/"..user:SteamID64().."/entity/entity.txt", "null")
file.Write("users/"..user:SteamID64().."/radio/radio.txt", "null")
user:Kill()
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "admin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сброс по причине: "..reason.."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
file.Write("users/"..user:SteamID64().."/model/model.txt", "models/aussiwozzi/phase1clones/sergeant.mdl")
file.Write("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "0000000000000")
file.Write("users/"..user:SteamID64().."/skin/skin.txt", "0")
file.Write("users/"..user:SteamID64().."/size/size.txt", "1")
file.Write("users/"..user:SteamID64().."/rank/rank.txt", "РКТ")
file.Write("users/"..user:SteamID64().."/spec/spec.txt", "НЕ СПЕЦИАЛИСТ")
file.Write("users/"..user:SteamID64().."/name/name.txt", "ГАММА")
file.Write("users/"..user:SteamID64().."/number/number.txt", math.random( 1000, 9999 ))
file.Write("users/"..user:SteamID64().."/legion/legion.txt", "СК")
file.Write("users/"..user:SteamID64().."/health/health.txt", "150")
file.Write("users/"..user:SteamID64().."/armor/armor.txt", "200")
file.Write("users/"..user:SteamID64().."/speed/speed.txt", "1")
file.Write("users/"..user:SteamID64().."/grav/grav.txt", "1")
file.Write("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "arms")
file.Write("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "arms")
file.Write("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "arms")
file.Write("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "arms")
file.Write("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles/utiles.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles2/utiles2.txt", "arms")
file.Write("users/"..user:SteamID64().."/entity/entity.txt", "null")
file.Write("users/"..user:SteamID64().."/radio/radio.txt", "null")
user:Kill()
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "commander" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "commander") then
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сброс по причине: "..reason.."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
file.Write("users/"..user:SteamID64().."/model/model.txt", "models/aussiwozzi/phase1clones/sergeant.mdl")
file.Write("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "0000000000000")
file.Write("users/"..user:SteamID64().."/skin/skin.txt", "0")
file.Write("users/"..user:SteamID64().."/size/size.txt", "1")
file.Write("users/"..user:SteamID64().."/rank/rank.txt", "РКТ")
file.Write("users/"..user:SteamID64().."/spec/spec.txt", "НЕ СПЕЦИАЛИСТ")
file.Write("users/"..user:SteamID64().."/name/name.txt", "ГАММА")
file.Write("users/"..user:SteamID64().."/number/number.txt", math.random( 1000, 9999 ))
file.Write("users/"..user:SteamID64().."/legion/legion.txt", "СК")
file.Write("users/"..user:SteamID64().."/health/health.txt", "150")
file.Write("users/"..user:SteamID64().."/armor/armor.txt", "200")
file.Write("users/"..user:SteamID64().."/speed/speed.txt", "1")
file.Write("users/"..user:SteamID64().."/grav/grav.txt", "1")
file.Write("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "arms")
file.Write("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "arms")
file.Write("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "arms")
file.Write("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "arms")
file.Write("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles/utiles.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles2/utiles2.txt", "arms")
file.Write("users/"..user:SteamID64().."/entity/entity.txt", "null")
file.Write("users/"..user:SteamID64().."/radio/radio.txt", "null")
user:Kill()
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "user" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "commander") then
file.Write("logs/witelist/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."WL сброс по причине: "..reason.."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
file.Write("users/"..user:SteamID64().."/model/model.txt", "models/aussiwozzi/phase1clones/sergeant.mdl")
file.Write("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "0000000000000")
file.Write("users/"..user:SteamID64().."/skin/skin.txt", "0")
file.Write("users/"..user:SteamID64().."/size/size.txt", "1")
file.Write("users/"..user:SteamID64().."/rank/rank.txt", "РКТ")
file.Write("users/"..user:SteamID64().."/spec/spec.txt", "НЕ СПЕЦИАЛИСТ")
file.Write("users/"..user:SteamID64().."/name/name.txt", "ГАММА")
file.Write("users/"..user:SteamID64().."/number/number.txt", math.random( 1000, 9999 ))
file.Write("users/"..user:SteamID64().."/legion/legion.txt", "СК")
file.Write("users/"..user:SteamID64().."/health/health.txt", "150")
file.Write("users/"..user:SteamID64().."/armor/armor.txt", "200")
file.Write("users/"..user:SteamID64().."/speed/speed.txt", "1")
file.Write("users/"..user:SteamID64().."/grav/grav.txt", "1")
file.Write("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "arms")
file.Write("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "arms")
file.Write("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "arms")
file.Write("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "arms")
file.Write("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles/utiles.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles2/utiles2.txt", "arms")
file.Write("users/"..user:SteamID64().."/entity/entity.txt", "null")
file.Write("users/"..user:SteamID64().."/radio/radio.txt", "null")
user:Kill()
end
end)

--- КЛОНЫ СОЛДАТЫ

util.AddNetworkString("Clone_CT_S")
net.Receive("Clone_CT_S", function()
local banner = net.ReadString()
local user = net.ReadEntity()
file.Write("users/"..user:SteamID64().."/model/model.txt", "models/aussiwozzi/phase1clones/trooper.mdl")
file.Write("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "0000000000000")
file.Write("users/"..user:SteamID64().."/skin/skin.txt", "0")
file.Write("users/"..user:SteamID64().."/size/size.txt", "1")
file.Write("users/"..user:SteamID64().."/legion/legion.txt", "СК")
file.Write("users/"..user:SteamID64().."/health/health.txt", "150")
file.Write("users/"..user:SteamID64().."/armor/armor.txt", "200")
file.Write("users/"..user:SteamID64().."/speed/speed.txt", "1")
file.Write("users/"..user:SteamID64().."/grav/grav.txt", "1")
file.Write("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "rw_sw_dc15a")
file.Write("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "arms")
file.Write("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "arms")
file.Write("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "arms")
file.Write("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles/utiles.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles2/utiles2.txt", "arms")
file.Write("users/"..user:SteamID64().."/entity/entity.txt", "null")
file.Write("users/"..user:SteamID64().."/radio/radio.txt", "null")
--- Респавн
local legiong = file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data")
if (legiong == oneleg) then
user:SetTeam(1)
elseif (legiong == twoleg) then
user:SetTeam(2)
elseif (legiong == trileg) then
user:SetTeam(3)
elseif (legiong == forleg) then
user:SetTeam(4)
elseif (legiong == fivleg) then
user:SetTeam(5)
elseif (legiong == sixleg) then
user:SetTeam(6)
elseif (legiong == sevleg) then
user:SetTeam(7)
elseif (legiong == eigleg) then
user:SetTeam(8)
else
user:SetTeam(9)
end
user:StripWeapons()
local modelka = file.Read("users/"..user:SteamID64().."/model/model.txt", "data")
local bodygrops = file.Read("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "data")
local skines = file.Read("users/"..user:SteamID64().."/skin/skin.txt", "data")
local mscale = file.Read("users/"..user:SteamID64().."/size/size.txt", "data")
local healsth = file.Read("users/"..user:SteamID64().."/health/health.txt", "data")
local armorks = file.Read("users/"..user:SteamID64().."/armor/armor.txt", "data")
local speedok = file.Read("users/"..user:SteamID64().."/speed/speed.txt", "data")
local gravok = file.Read("users/"..user:SteamID64().."/grav/grav.txt", "data")
local firweap = file.Read("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "data")
local secweap = file.Read("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "data")
local gern = file.Read("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "data")
local gern2 = file.Read("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "data")
local knifek = file.Read("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "data")
local utile = file.Read("users/"..user:SteamID64().."/utiles/utiles.txt", "data")
local utile2 = file.Read("users/"..user:SteamID64().."/utiles2/utiles2.txt", "data")
local entitis = file.Read("users/"..user:SteamID64().."/entity/entity.txt", "data")
timer.Create( "Unique2s", 1, 2, function()
user:SetHealth( healsth )
user:SetMaxHealth( healsth )
user:SetArmor( armorks )
user:SetMaxArmor( armorks )
user:SetWalkSpeed( speedok * 100 )
user:SetRunSpeed( speedok * 240 )
user:SetGravity( gravok )
user:SetModelScale( mscale, 1 )
end )
user:SetModel(modelka)
user:SetSkin( skines )
user:SetBodyGroups( bodygrops )
user:Give( "arms" )
user:Give( firweap, true )
user:Give( secweap, true )
user:Give( gern )
user:Give( gern2 )
user:Give( knifek )
user:Give( utile )
user:Give( utile2 )
if (entitis != "null") then
local ent = ents.Create(entitis)
ent:SetPos( user:GetPos() ) 
ent:Spawn()
ent:Use( user, NULL, 1, 0 )
end
end)

util.AddNetworkString("Clone_CT_O")
net.Receive("Clone_CT_O", function()
local banner = net.ReadString()
local user = net.ReadEntity()
file.Write("users/"..user:SteamID64().."/model/model.txt", "models/aussiwozzi/phase1clones/trooper.mdl")
file.Write("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "0000010000000")
file.Write("users/"..user:SteamID64().."/skin/skin.txt", "0")
file.Write("users/"..user:SteamID64().."/size/size.txt", "1")
file.Write("users/"..user:SteamID64().."/legion/legion.txt", "СК")
file.Write("users/"..user:SteamID64().."/health/health.txt", "150")
file.Write("users/"..user:SteamID64().."/armor/armor.txt", "200")
file.Write("users/"..user:SteamID64().."/speed/speed.txt", "1")
file.Write("users/"..user:SteamID64().."/grav/grav.txt", "1")
file.Write("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "rw_sw_dc15a")
file.Write("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "arms")
file.Write("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "arms")
file.Write("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "arms")
file.Write("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles/utiles.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles2/utiles2.txt", "arms")
file.Write("users/"..user:SteamID64().."/entity/entity.txt", "null")
file.Write("users/"..user:SteamID64().."/radio/radio.txt", "null")
--- Респавн
local legiong = file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data")
if (legiong == oneleg) then
user:SetTeam(1)
elseif (legiong == twoleg) then
user:SetTeam(2)
elseif (legiong == trileg) then
user:SetTeam(3)
elseif (legiong == forleg) then
user:SetTeam(4)
elseif (legiong == fivleg) then
user:SetTeam(5)
elseif (legiong == sixleg) then
user:SetTeam(6)
elseif (legiong == sevleg) then
user:SetTeam(7)
elseif (legiong == eigleg) then
user:SetTeam(8)
else
user:SetTeam(9)
end
user:StripWeapons()
local modelka = file.Read("users/"..user:SteamID64().."/model/model.txt", "data")
local bodygrops = file.Read("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "data")
local skines = file.Read("users/"..user:SteamID64().."/skin/skin.txt", "data")
local mscale = file.Read("users/"..user:SteamID64().."/size/size.txt", "data")
local healsth = file.Read("users/"..user:SteamID64().."/health/health.txt", "data")
local armorks = file.Read("users/"..user:SteamID64().."/armor/armor.txt", "data")
local speedok = file.Read("users/"..user:SteamID64().."/speed/speed.txt", "data")
local gravok = file.Read("users/"..user:SteamID64().."/grav/grav.txt", "data")
local firweap = file.Read("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "data")
local secweap = file.Read("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "data")
local gern = file.Read("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "data")
local gern2 = file.Read("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "data")
local knifek = file.Read("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "data")
local utile = file.Read("users/"..user:SteamID64().."/utiles/utiles.txt", "data")
local utile2 = file.Read("users/"..user:SteamID64().."/utiles2/utiles2.txt", "data")
local entitis = file.Read("users/"..user:SteamID64().."/entity/entity.txt", "data")
timer.Create( "Unique2s", 1, 2, function()
user:SetHealth( healsth )
user:SetMaxHealth( healsth )
user:SetArmor( armorks )
user:SetMaxArmor( armorks )
user:SetWalkSpeed( speedok * 100 )
user:SetRunSpeed( speedok * 240 )
user:SetGravity( gravok )
user:SetModelScale( mscale, 1 )
end )
user:SetModel(modelka)
user:SetSkin( skines )
user:SetBodyGroups( bodygrops )
user:Give( "arms" )
user:Give( firweap, true )
user:Give( secweap, true )
user:Give( gern )
user:Give( gern2 )
user:Give( knifek )
user:Give( utile )
user:Give( utile2 )
if (entitis != "null") then
local ent = ents.Create(entitis)
ent:SetPos( user:GetPos() ) 
ent:Spawn()
ent:Use( user, NULL, 1, 0 )
end
end)

util.AddNetworkString("Clone_CT_HO")
net.Receive("Clone_CT_HO", function()
local banner = net.ReadString()
local user = net.ReadEntity()
file.Write("users/"..user:SteamID64().."/model/model.txt", "models/aussiwozzi/phase1clones/trooper.mdl")
file.Write("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "0000012000000")
file.Write("users/"..user:SteamID64().."/skin/skin.txt", "0")
file.Write("users/"..user:SteamID64().."/size/size.txt", "1")
file.Write("users/"..user:SteamID64().."/legion/legion.txt", "СК")
file.Write("users/"..user:SteamID64().."/health/health.txt", "150")
file.Write("users/"..user:SteamID64().."/armor/armor.txt", "200")
file.Write("users/"..user:SteamID64().."/speed/speed.txt", "1")
file.Write("users/"..user:SteamID64().."/grav/grav.txt", "1")
file.Write("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "rw_sw_dc15a")
file.Write("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "rw_sw_dc17")
file.Write("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "rw_sw_nade_thermal")
file.Write("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "arms")
file.Write("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles/utiles.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles2/utiles2.txt", "arms")
file.Write("users/"..user:SteamID64().."/entity/entity.txt", "null")
file.Write("users/"..user:SteamID64().."/radio/radio.txt", "null")
--- Респавн
local legiong = file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data")
if (legiong == oneleg) then
user:SetTeam(1)
elseif (legiong == twoleg) then
user:SetTeam(2)
elseif (legiong == trileg) then
user:SetTeam(3)
elseif (legiong == forleg) then
user:SetTeam(4)
elseif (legiong == fivleg) then
user:SetTeam(5)
elseif (legiong == sixleg) then
user:SetTeam(6)
elseif (legiong == sevleg) then
user:SetTeam(7)
elseif (legiong == eigleg) then
user:SetTeam(8)
else
user:SetTeam(9)
end
user:StripWeapons()
local modelka = file.Read("users/"..user:SteamID64().."/model/model.txt", "data")
local bodygrops = file.Read("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "data")
local skines = file.Read("users/"..user:SteamID64().."/skin/skin.txt", "data")
local mscale = file.Read("users/"..user:SteamID64().."/size/size.txt", "data")
local healsth = file.Read("users/"..user:SteamID64().."/health/health.txt", "data")
local armorks = file.Read("users/"..user:SteamID64().."/armor/armor.txt", "data")
local speedok = file.Read("users/"..user:SteamID64().."/speed/speed.txt", "data")
local gravok = file.Read("users/"..user:SteamID64().."/grav/grav.txt", "data")
local firweap = file.Read("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "data")
local secweap = file.Read("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "data")
local gern = file.Read("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "data")
local gern2 = file.Read("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "data")
local knifek = file.Read("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "data")
local utile = file.Read("users/"..user:SteamID64().."/utiles/utiles.txt", "data")
local utile2 = file.Read("users/"..user:SteamID64().."/utiles2/utiles2.txt", "data")
local entitis = file.Read("users/"..user:SteamID64().."/entity/entity.txt", "data")
timer.Create( "Unique2s", 1, 2, function()
user:SetHealth( healsth )
user:SetMaxHealth( healsth )
user:SetArmor( armorks )
user:SetMaxArmor( armorks )
user:SetWalkSpeed( speedok * 100 )
user:SetRunSpeed( speedok * 240 )
user:SetGravity( gravok )
user:SetModelScale( mscale, 1 )
end )
user:SetModel(modelka)
user:SetSkin( skines )
user:SetBodyGroups( bodygrops )
user:Give( "arms" )
user:Give( firweap, true )
user:Give( secweap, true )
user:Give( gern )
user:Give( gern2 )
user:Give( knifek )
user:Give( utile )
user:Give( utile2 )
if (entitis != "null") then
local ent = ents.Create(entitis)
ent:SetPos( user:GetPos() ) 
ent:Spawn()
ent:Use( user, NULL, 1, 0 )
end
end)

util.AddNetworkString("Clone_CT_CC")
net.Receive("Clone_CT_CC", function()
local banner = net.ReadString()
local user = net.ReadEntity()
file.Write("users/"..user:SteamID64().."/model/model.txt", "models/aussiwozzi/phase1clones/trooper.mdl")
file.Write("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "0000012000300")
file.Write("users/"..user:SteamID64().."/skin/skin.txt", "0")
file.Write("users/"..user:SteamID64().."/size/size.txt", "1")
file.Write("users/"..user:SteamID64().."/legion/legion.txt", "СК")
file.Write("users/"..user:SteamID64().."/health/health.txt", "150")
file.Write("users/"..user:SteamID64().."/armor/armor.txt", "200")
file.Write("users/"..user:SteamID64().."/speed/speed.txt", "1")
file.Write("users/"..user:SteamID64().."/grav/grav.txt", "1")
file.Write("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "rw_sw_dc15a")
file.Write("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "rw_sw_dc17")
file.Write("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "rw_sw_nade_thermal")
file.Write("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "arms")
file.Write("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles/utiles.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles2/utiles2.txt", "arms")
file.Write("users/"..user:SteamID64().."/entity/entity.txt", "null")
file.Write("users/"..user:SteamID64().."/radio/radio.txt", "null")
--- Респавн
local legiong = file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data")
if (legiong == oneleg) then
user:SetTeam(1)
elseif (legiong == twoleg) then
user:SetTeam(2)
elseif (legiong == trileg) then
user:SetTeam(3)
elseif (legiong == forleg) then
user:SetTeam(4)
elseif (legiong == fivleg) then
user:SetTeam(5)
elseif (legiong == sixleg) then
user:SetTeam(6)
elseif (legiong == sevleg) then
user:SetTeam(7)
elseif (legiong == eigleg) then
user:SetTeam(8)
else
user:SetTeam(9)
end
user:StripWeapons()
local modelka = file.Read("users/"..user:SteamID64().."/model/model.txt", "data")
local bodygrops = file.Read("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "data")
local skines = file.Read("users/"..user:SteamID64().."/skin/skin.txt", "data")
local mscale = file.Read("users/"..user:SteamID64().."/size/size.txt", "data")
local healsth = file.Read("users/"..user:SteamID64().."/health/health.txt", "data")
local armorks = file.Read("users/"..user:SteamID64().."/armor/armor.txt", "data")
local speedok = file.Read("users/"..user:SteamID64().."/speed/speed.txt", "data")
local gravok = file.Read("users/"..user:SteamID64().."/grav/grav.txt", "data")
local firweap = file.Read("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "data")
local secweap = file.Read("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "data")
local gern = file.Read("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "data")
local gern2 = file.Read("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "data")
local knifek = file.Read("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "data")
local utile = file.Read("users/"..user:SteamID64().."/utiles/utiles.txt", "data")
local utile2 = file.Read("users/"..user:SteamID64().."/utiles2/utiles2.txt", "data")
local entitis = file.Read("users/"..user:SteamID64().."/entity/entity.txt", "data")
timer.Create( "Unique2s", 1, 2, function()
user:SetHealth( healsth )
user:SetMaxHealth( healsth )
user:SetArmor( armorks )
user:SetMaxArmor( armorks )
user:SetWalkSpeed( speedok * 100 )
user:SetRunSpeed( speedok * 240 )
user:SetGravity( gravok )
user:SetModelScale( mscale, 1 )
end )
user:SetModel(modelka)
user:SetSkin( skines )
user:SetBodyGroups( bodygrops )
user:Give( "arms" )
user:Give( firweap, true )
user:Give( secweap, true )
user:Give( gern )
user:Give( gern2 )
user:Give( knifek )
user:Give( utile )
user:Give( utile2 )
if (entitis != "null") then
local ent = ents.Create(entitis)
ent:SetPos( user:GetPos() ) 
ent:Spawn()
ent:Use( user, NULL, 1, 0 )
end
end)

--- КЛОНЫ 501-ого

util.AddNetworkString("Clone_501_S")
net.Receive("Clone_501_S", function()
local banner = net.ReadString()
local user = net.ReadEntity()
file.Write("users/"..user:SteamID64().."/model/model.txt", "models/aussiwozzi/phase1clones/501st/trooper.mdl")
file.Write("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "0000000000000")
file.Write("users/"..user:SteamID64().."/skin/skin.txt", "0")
file.Write("users/"..user:SteamID64().."/size/size.txt", "1")
file.Write("users/"..user:SteamID64().."/legion/legion.txt", "501-Л")
file.Write("users/"..user:SteamID64().."/health/health.txt", "150")
file.Write("users/"..user:SteamID64().."/armor/armor.txt", "200")
file.Write("users/"..user:SteamID64().."/speed/speed.txt", "1")
file.Write("users/"..user:SteamID64().."/grav/grav.txt", "1")
file.Write("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "rw_sw_dc15a")
file.Write("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "arms")
file.Write("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "rw_sw_nade_thermal")
file.Write("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "rw_sw_nade_smoke")
file.Write("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles/utiles.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles2/utiles2.txt", "arms")
file.Write("users/"..user:SteamID64().."/entity/entity.txt", "null")
file.Write("users/"..user:SteamID64().."/radio/radio.txt", "null")
--- Респавн
local legiong = file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data")
if (legiong == oneleg) then
user:SetTeam(1)
elseif (legiong == twoleg) then
user:SetTeam(2)
elseif (legiong == trileg) then
user:SetTeam(3)
elseif (legiong == forleg) then
user:SetTeam(4)
elseif (legiong == fivleg) then
user:SetTeam(5)
elseif (legiong == sixleg) then
user:SetTeam(6)
elseif (legiong == sevleg) then
user:SetTeam(7)
elseif (legiong == eigleg) then
user:SetTeam(8)
else
user:SetTeam(9)
end
user:StripWeapons()
local modelka = file.Read("users/"..user:SteamID64().."/model/model.txt", "data")
local bodygrops = file.Read("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "data")
local skines = file.Read("users/"..user:SteamID64().."/skin/skin.txt", "data")
local mscale = file.Read("users/"..user:SteamID64().."/size/size.txt", "data")
local healsth = file.Read("users/"..user:SteamID64().."/health/health.txt", "data")
local armorks = file.Read("users/"..user:SteamID64().."/armor/armor.txt", "data")
local speedok = file.Read("users/"..user:SteamID64().."/speed/speed.txt", "data")
local gravok = file.Read("users/"..user:SteamID64().."/grav/grav.txt", "data")
local firweap = file.Read("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "data")
local secweap = file.Read("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "data")
local gern = file.Read("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "data")
local gern2 = file.Read("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "data")
local knifek = file.Read("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "data")
local utile = file.Read("users/"..user:SteamID64().."/utiles/utiles.txt", "data")
local utile2 = file.Read("users/"..user:SteamID64().."/utiles2/utiles2.txt", "data")
local entitis = file.Read("users/"..user:SteamID64().."/entity/entity.txt", "data")
timer.Create( "Unique2s", 1, 2, function()
user:SetHealth( healsth )
user:SetMaxHealth( healsth )
user:SetArmor( armorks )
user:SetMaxArmor( armorks )
user:SetWalkSpeed( speedok * 100 )
user:SetRunSpeed( speedok * 240 )
user:SetGravity( gravok )
user:SetModelScale( mscale, 1 )
end )
user:SetModel(modelka)
user:SetSkin( skines )
user:SetBodyGroups( bodygrops )
user:Give( "arms" )
user:Give( firweap, true )
user:Give( secweap, true )
user:Give( gern )
user:Give( gern2 )
user:Give( knifek )
user:Give( utile )
user:Give( utile2 )
if (entitis != "null") then
local ent = ents.Create(entitis)
ent:SetPos( user:GetPos() ) 
ent:Spawn()
ent:Use( user, NULL, 1, 0 )
end
end)

util.AddNetworkString("Clone_501_O")
net.Receive("Clone_501_O", function()
local banner = net.ReadString()
local user = net.ReadEntity()
file.Write("users/"..user:SteamID64().."/model/model.txt", "models/aussiwozzi/phase1clones/501st/trooper.mdl")
file.Write("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "0000010000000")
file.Write("users/"..user:SteamID64().."/skin/skin.txt", "0")
file.Write("users/"..user:SteamID64().."/size/size.txt", "1")
file.Write("users/"..user:SteamID64().."/legion/legion.txt", "501-Л")
file.Write("users/"..user:SteamID64().."/health/health.txt", "150")
file.Write("users/"..user:SteamID64().."/armor/armor.txt", "200")
file.Write("users/"..user:SteamID64().."/speed/speed.txt", "1")
file.Write("users/"..user:SteamID64().."/grav/grav.txt", "1")
file.Write("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "rw_sw_dc15a")
file.Write("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "arms")
file.Write("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "rw_sw_nade_thermal")
file.Write("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "rw_sw_nade_smoke")
file.Write("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles/utiles.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles2/utiles2.txt", "arms")
file.Write("users/"..user:SteamID64().."/entity/entity.txt", "null")
file.Write("users/"..user:SteamID64().."/radio/radio.txt", "null")
--- Респавн
local legiong = file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data")
if (legiong == oneleg) then
user:SetTeam(1)
elseif (legiong == twoleg) then
user:SetTeam(2)
elseif (legiong == trileg) then
user:SetTeam(3)
elseif (legiong == forleg) then
user:SetTeam(4)
elseif (legiong == fivleg) then
user:SetTeam(5)
elseif (legiong == sixleg) then
user:SetTeam(6)
elseif (legiong == sevleg) then
user:SetTeam(7)
elseif (legiong == eigleg) then
user:SetTeam(8)
else
user:SetTeam(9)
end
user:StripWeapons()
local modelka = file.Read("users/"..user:SteamID64().."/model/model.txt", "data")
local bodygrops = file.Read("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "data")
local skines = file.Read("users/"..user:SteamID64().."/skin/skin.txt", "data")
local mscale = file.Read("users/"..user:SteamID64().."/size/size.txt", "data")
local healsth = file.Read("users/"..user:SteamID64().."/health/health.txt", "data")
local armorks = file.Read("users/"..user:SteamID64().."/armor/armor.txt", "data")
local speedok = file.Read("users/"..user:SteamID64().."/speed/speed.txt", "data")
local gravok = file.Read("users/"..user:SteamID64().."/grav/grav.txt", "data")
local firweap = file.Read("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "data")
local secweap = file.Read("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "data")
local gern = file.Read("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "data")
local gern2 = file.Read("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "data")
local knifek = file.Read("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "data")
local utile = file.Read("users/"..user:SteamID64().."/utiles/utiles.txt", "data")
local utile2 = file.Read("users/"..user:SteamID64().."/utiles2/utiles2.txt", "data")
local entitis = file.Read("users/"..user:SteamID64().."/entity/entity.txt", "data")
timer.Create( "Unique2s", 1, 2, function()
user:SetHealth( healsth )
user:SetMaxHealth( healsth )
user:SetArmor( armorks )
user:SetMaxArmor( armorks )
user:SetWalkSpeed( speedok * 100 )
user:SetRunSpeed( speedok * 240 )
user:SetGravity( gravok )
user:SetModelScale( mscale, 1 )
end )
user:SetModel(modelka)
user:SetSkin( skines )
user:SetBodyGroups( bodygrops )
user:Give( "arms" )
user:Give( firweap, true )
user:Give( secweap, true )
user:Give( gern )
user:Give( gern2 )
user:Give( knifek )
user:Give( utile )
user:Give( utile2 )
if (entitis != "null") then
local ent = ents.Create(entitis)
ent:SetPos( user:GetPos() ) 
ent:Spawn()
ent:Use( user, NULL, 1, 0 )
end
end)

util.AddNetworkString("Clone_501_HO")
net.Receive("Clone_501_HO", function()
local banner = net.ReadString()
local user = net.ReadEntity()
file.Write("users/"..user:SteamID64().."/model/model.txt", "models/aussiwozzi/phase1clones/501st/trooper.mdl")
file.Write("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "0000012000000")
file.Write("users/"..user:SteamID64().."/skin/skin.txt", "0")
file.Write("users/"..user:SteamID64().."/size/size.txt", "1")
file.Write("users/"..user:SteamID64().."/legion/legion.txt", "501-Л")
file.Write("users/"..user:SteamID64().."/health/health.txt", "150")
file.Write("users/"..user:SteamID64().."/armor/armor.txt", "200")
file.Write("users/"..user:SteamID64().."/speed/speed.txt", "1")
file.Write("users/"..user:SteamID64().."/grav/grav.txt", "1")
file.Write("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "rw_sw_dc15a")
file.Write("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "rw_sw_dc17")
file.Write("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "rw_sw_nade_thermal")
file.Write("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "rw_sw_nade_smoke")
file.Write("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles/utiles.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles2/utiles2.txt", "arms")
file.Write("users/"..user:SteamID64().."/entity/entity.txt", "null")
file.Write("users/"..user:SteamID64().."/radio/radio.txt", "null")
--- Респавн
local legiong = file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data")
if (legiong == oneleg) then
user:SetTeam(1)
elseif (legiong == twoleg) then
user:SetTeam(2)
elseif (legiong == trileg) then
user:SetTeam(3)
elseif (legiong == forleg) then
user:SetTeam(4)
elseif (legiong == fivleg) then
user:SetTeam(5)
elseif (legiong == sixleg) then
user:SetTeam(6)
elseif (legiong == sevleg) then
user:SetTeam(7)
elseif (legiong == eigleg) then
user:SetTeam(8)
else
user:SetTeam(9)
end
user:StripWeapons()
local modelka = file.Read("users/"..user:SteamID64().."/model/model.txt", "data")
local bodygrops = file.Read("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "data")
local skines = file.Read("users/"..user:SteamID64().."/skin/skin.txt", "data")
local mscale = file.Read("users/"..user:SteamID64().."/size/size.txt", "data")
local healsth = file.Read("users/"..user:SteamID64().."/health/health.txt", "data")
local armorks = file.Read("users/"..user:SteamID64().."/armor/armor.txt", "data")
local speedok = file.Read("users/"..user:SteamID64().."/speed/speed.txt", "data")
local gravok = file.Read("users/"..user:SteamID64().."/grav/grav.txt", "data")
local firweap = file.Read("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "data")
local secweap = file.Read("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "data")
local gern = file.Read("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "data")
local gern2 = file.Read("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "data")
local knifek = file.Read("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "data")
local utile = file.Read("users/"..user:SteamID64().."/utiles/utiles.txt", "data")
local utile2 = file.Read("users/"..user:SteamID64().."/utiles2/utiles2.txt", "data")
local entitis = file.Read("users/"..user:SteamID64().."/entity/entity.txt", "data")
timer.Create( "Unique2s", 1, 2, function()
user:SetHealth( healsth )
user:SetMaxHealth( healsth )
user:SetArmor( armorks )
user:SetMaxArmor( armorks )
user:SetWalkSpeed( speedok * 100 )
user:SetRunSpeed( speedok * 240 )
user:SetGravity( gravok )
user:SetModelScale( mscale, 1 )
end )
user:SetModel(modelka)
user:SetSkin( skines )
user:SetBodyGroups( bodygrops )
user:Give( "arms" )
user:Give( firweap, true )
user:Give( secweap, true )
user:Give( gern )
user:Give( gern2 )
user:Give( knifek )
user:Give( utile )
user:Give( utile2 )
if (entitis != "null") then
local ent = ents.Create(entitis)
ent:SetPos( user:GetPos() ) 
ent:Spawn()
ent:Use( user, NULL, 1, 0 )
end
end)

util.AddNetworkString("Clone_501_CC")
net.Receive("Clone_501_CC", function()
local banner = net.ReadString()
local user = net.ReadEntity()
file.Write("users/"..user:SteamID64().."/model/model.txt", "models/aussiwozzi/phase1clones/501st/trooper.mdl")
file.Write("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "0000012000300")
file.Write("users/"..user:SteamID64().."/skin/skin.txt", "0")
file.Write("users/"..user:SteamID64().."/size/size.txt", "1")
file.Write("users/"..user:SteamID64().."/legion/legion.txt", "501-Л")
file.Write("users/"..user:SteamID64().."/health/health.txt", "150")
file.Write("users/"..user:SteamID64().."/armor/armor.txt", "200")
file.Write("users/"..user:SteamID64().."/speed/speed.txt", "1")
file.Write("users/"..user:SteamID64().."/grav/grav.txt", "1")
file.Write("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "rw_sw_dc15a")
file.Write("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "rw_sw_dc17")
file.Write("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "rw_sw_nade_thermal")
file.Write("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "rw_sw_nade_smoke")
file.Write("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles/utiles.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles2/utiles2.txt", "arms")
file.Write("users/"..user:SteamID64().."/entity/entity.txt", "null")
file.Write("users/"..user:SteamID64().."/radio/radio.txt", "null")
--- Респавн
local legiong = file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data")
if (legiong == oneleg) then
user:SetTeam(1)
elseif (legiong == twoleg) then
user:SetTeam(2)
elseif (legiong == trileg) then
user:SetTeam(3)
elseif (legiong == forleg) then
user:SetTeam(4)
elseif (legiong == fivleg) then
user:SetTeam(5)
elseif (legiong == sixleg) then
user:SetTeam(6)
elseif (legiong == sevleg) then
user:SetTeam(7)
elseif (legiong == eigleg) then
user:SetTeam(8)
else
user:SetTeam(9)
end
user:StripWeapons()
local modelka = file.Read("users/"..user:SteamID64().."/model/model.txt", "data")
local bodygrops = file.Read("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "data")
local skines = file.Read("users/"..user:SteamID64().."/skin/skin.txt", "data")
local mscale = file.Read("users/"..user:SteamID64().."/size/size.txt", "data")
local healsth = file.Read("users/"..user:SteamID64().."/health/health.txt", "data")
local armorks = file.Read("users/"..user:SteamID64().."/armor/armor.txt", "data")
local speedok = file.Read("users/"..user:SteamID64().."/speed/speed.txt", "data")
local gravok = file.Read("users/"..user:SteamID64().."/grav/grav.txt", "data")
local firweap = file.Read("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "data")
local secweap = file.Read("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "data")
local gern = file.Read("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "data")
local gern2 = file.Read("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "data")
local knifek = file.Read("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "data")
local utile = file.Read("users/"..user:SteamID64().."/utiles/utiles.txt", "data")
local utile2 = file.Read("users/"..user:SteamID64().."/utiles2/utiles2.txt", "data")
local entitis = file.Read("users/"..user:SteamID64().."/entity/entity.txt", "data")
timer.Create( "Unique2s", 1, 2, function()
user:SetHealth( healsth )
user:SetMaxHealth( healsth )
user:SetArmor( armorks )
user:SetMaxArmor( armorks )
user:SetWalkSpeed( speedok * 100 )
user:SetRunSpeed( speedok * 240 )
user:SetGravity( gravok )
user:SetModelScale( mscale, 1 )
end )
user:SetModel(modelka)
user:SetSkin( skines )
user:SetBodyGroups( bodygrops )
user:Give( "arms" )
user:Give( firweap, true )
user:Give( secweap, true )
user:Give( gern )
user:Give( gern2 )
user:Give( knifek )
user:Give( utile )
user:Give( utile2 )
if (entitis != "null") then
local ent = ents.Create(entitis)
ent:SetPos( user:GetPos() ) 
ent:Spawn()
ent:Use( user, NULL, 1, 0 )
end
end)

--- КЛОНЫ 574-ого

util.AddNetworkString("Clone_104_S")
net.Receive("Clone_104_S", function()
local banner = net.ReadString()
local user = net.ReadEntity()
file.Write("users/"..user:SteamID64().."/model/model.txt", "models/cs574/clones/ait/ait_tactical.mdl")
file.Write("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "0000000000000")
file.Write("users/"..user:SteamID64().."/skin/skin.txt", "0")
file.Write("users/"..user:SteamID64().."/size/size.txt", "1")
file.Write("users/"..user:SteamID64().."/legion/legion.txt", "574-К")
file.Write("users/"..user:SteamID64().."/health/health.txt", "150")
file.Write("users/"..user:SteamID64().."/armor/armor.txt", "200")
file.Write("users/"..user:SteamID64().."/speed/speed.txt", "1")
file.Write("users/"..user:SteamID64().."/grav/grav.txt", "1")
file.Write("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "rw_sw_dc15a")
file.Write("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "arms")
file.Write("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "arms")
file.Write("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "arms")
file.Write("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles/utiles.txt", "alydus_fortificationbuildertablet")
file.Write("users/"..user:SteamID64().."/utiles2/utiles2.txt", "arms")
file.Write("users/"..user:SteamID64().."/entity/entity.txt", "null")
file.Write("users/"..user:SteamID64().."/radio/radio.txt", "null")
--- Респавн
local legiong = file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data")
if (legiong == oneleg) then
user:SetTeam(1)
elseif (legiong == twoleg) then
user:SetTeam(2)
elseif (legiong == trileg) then
user:SetTeam(3)
elseif (legiong == forleg) then
user:SetTeam(4)
elseif (legiong == fivleg) then
user:SetTeam(5)
elseif (legiong == sixleg) then
user:SetTeam(6)
elseif (legiong == sevleg) then
user:SetTeam(7)
elseif (legiong == eigleg) then
user:SetTeam(8)
else
user:SetTeam(9)
end
user:StripWeapons()
local modelka = file.Read("users/"..user:SteamID64().."/model/model.txt", "data")
local bodygrops = file.Read("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "data")
local skines = file.Read("users/"..user:SteamID64().."/skin/skin.txt", "data")
local mscale = file.Read("users/"..user:SteamID64().."/size/size.txt", "data")
local healsth = file.Read("users/"..user:SteamID64().."/health/health.txt", "data")
local armorks = file.Read("users/"..user:SteamID64().."/armor/armor.txt", "data")
local speedok = file.Read("users/"..user:SteamID64().."/speed/speed.txt", "data")
local gravok = file.Read("users/"..user:SteamID64().."/grav/grav.txt", "data")
local firweap = file.Read("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "data")
local secweap = file.Read("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "data")
local gern = file.Read("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "data")
local gern2 = file.Read("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "data")
local knifek = file.Read("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "data")
local utile = file.Read("users/"..user:SteamID64().."/utiles/utiles.txt", "data")
local utile2 = file.Read("users/"..user:SteamID64().."/utiles2/utiles2.txt", "data")
local entitis = file.Read("users/"..user:SteamID64().."/entity/entity.txt", "data")
timer.Create( "Unique2s", 1, 2, function()
user:SetHealth( healsth )
user:SetMaxHealth( healsth )
user:SetArmor( armorks )
user:SetMaxArmor( armorks )
user:SetWalkSpeed( speedok * 100 )
user:SetRunSpeed( speedok * 240 )
user:SetGravity( gravok )
user:SetModelScale( mscale, 1 )
end )
user:SetModel(modelka)
user:SetSkin( skines )
user:SetBodyGroups( bodygrops )
user:Give( "arms" )
user:Give( firweap, true )
user:Give( secweap, true )
user:Give( gern )
user:Give( gern2 )
user:Give( knifek )
user:Give( utile )
user:Give( utile2 )
if (entitis != "null") then
local ent = ents.Create(entitis)
ent:SetPos( user:GetPos() ) 
ent:Spawn()
ent:Use( user, NULL, 1, 0 )
end
end)

util.AddNetworkString("Clone_104_O")
net.Receive("Clone_104_O", function()
local banner = net.ReadString()
local user = net.ReadEntity()
file.Write("users/"..user:SteamID64().."/model/model.txt", "models/cs574/clones/ait/ait_tactical.mdl")
file.Write("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "0000000200000")
file.Write("users/"..user:SteamID64().."/skin/skin.txt", "0")
file.Write("users/"..user:SteamID64().."/size/size.txt", "1")
file.Write("users/"..user:SteamID64().."/legion/legion.txt", "574-К")
file.Write("users/"..user:SteamID64().."/health/health.txt", "150")
file.Write("users/"..user:SteamID64().."/armor/armor.txt", "200")
file.Write("users/"..user:SteamID64().."/speed/speed.txt", "1")
file.Write("users/"..user:SteamID64().."/grav/grav.txt", "1")
file.Write("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "rw_sw_dc15a")
file.Write("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "arms")
file.Write("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "arms")
file.Write("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "arms")
file.Write("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles/utiles.txt", "alydus_fortificationbuildertablet")
file.Write("users/"..user:SteamID64().."/utiles2/utiles2.txt", "arms")
file.Write("users/"..user:SteamID64().."/entity/entity.txt", "null")
file.Write("users/"..user:SteamID64().."/radio/radio.txt", "null")
--- Респавн
local legiong = file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data")
if (legiong == oneleg) then
user:SetTeam(1)
elseif (legiong == twoleg) then
user:SetTeam(2)
elseif (legiong == trileg) then
user:SetTeam(3)
elseif (legiong == forleg) then
user:SetTeam(4)
elseif (legiong == fivleg) then
user:SetTeam(5)
elseif (legiong == sixleg) then
user:SetTeam(6)
elseif (legiong == sevleg) then
user:SetTeam(7)
elseif (legiong == eigleg) then
user:SetTeam(8)
else
user:SetTeam(9)
end
user:StripWeapons()
local modelka = file.Read("users/"..user:SteamID64().."/model/model.txt", "data")
local bodygrops = file.Read("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "data")
local skines = file.Read("users/"..user:SteamID64().."/skin/skin.txt", "data")
local mscale = file.Read("users/"..user:SteamID64().."/size/size.txt", "data")
local healsth = file.Read("users/"..user:SteamID64().."/health/health.txt", "data")
local armorks = file.Read("users/"..user:SteamID64().."/armor/armor.txt", "data")
local speedok = file.Read("users/"..user:SteamID64().."/speed/speed.txt", "data")
local gravok = file.Read("users/"..user:SteamID64().."/grav/grav.txt", "data")
local firweap = file.Read("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "data")
local secweap = file.Read("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "data")
local gern = file.Read("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "data")
local gern2 = file.Read("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "data")
local knifek = file.Read("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "data")
local utile = file.Read("users/"..user:SteamID64().."/utiles/utiles.txt", "data")
local utile2 = file.Read("users/"..user:SteamID64().."/utiles2/utiles2.txt", "data")
local entitis = file.Read("users/"..user:SteamID64().."/entity/entity.txt", "data")
timer.Create( "Unique2s", 1, 2, function()
user:SetHealth( healsth )
user:SetMaxHealth( healsth )
user:SetArmor( armorks )
user:SetMaxArmor( armorks )
user:SetWalkSpeed( speedok * 100 )
user:SetRunSpeed( speedok * 240 )
user:SetGravity( gravok )
user:SetModelScale( mscale, 1 )
end )
user:SetModel(modelka)
user:SetSkin( skines )
user:SetBodyGroups( bodygrops )
user:Give( "arms" )
user:Give( firweap, true )
user:Give( secweap, true )
user:Give( gern )
user:Give( gern2 )
user:Give( knifek )
user:Give( utile )
user:Give( utile2 )
if (entitis != "null") then
local ent = ents.Create(entitis)
ent:SetPos( user:GetPos() ) 
ent:Spawn()
ent:Use( user, NULL, 1, 0 )
end
end)

util.AddNetworkString("Clone_104_HO")
net.Receive("Clone_104_HO", function()
local banner = net.ReadString()
local user = net.ReadEntity()
file.Write("users/"..user:SteamID64().."/model/model.txt", "models/cs574/clones/ait/ait_tactical.mdl")
file.Write("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "0000000220000")
file.Write("users/"..user:SteamID64().."/skin/skin.txt", "0")
file.Write("users/"..user:SteamID64().."/size/size.txt", "1")
file.Write("users/"..user:SteamID64().."/legion/legion.txt", "574-К")
file.Write("users/"..user:SteamID64().."/health/health.txt", "150")
file.Write("users/"..user:SteamID64().."/armor/armor.txt", "200")
file.Write("users/"..user:SteamID64().."/speed/speed.txt", "1")
file.Write("users/"..user:SteamID64().."/grav/grav.txt", "1")
file.Write("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "rw_sw_dc15a")
file.Write("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "rw_sw_dc17")
file.Write("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "rw_sw_nade_thermal")
file.Write("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "arms")
file.Write("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles/utiles.txt", "alydus_fortificationbuildertablet")
file.Write("users/"..user:SteamID64().."/utiles2/utiles2.txt", "arms")
file.Write("users/"..user:SteamID64().."/entity/entity.txt", "null")
file.Write("users/"..user:SteamID64().."/radio/radio.txt", "null")
--- Респавн
local legiong = file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data")
if (legiong == oneleg) then
user:SetTeam(1)
elseif (legiong == twoleg) then
user:SetTeam(2)
elseif (legiong == trileg) then
user:SetTeam(3)
elseif (legiong == forleg) then
user:SetTeam(4)
elseif (legiong == fivleg) then
user:SetTeam(5)
elseif (legiong == sixleg) then
user:SetTeam(6)
elseif (legiong == sevleg) then
user:SetTeam(7)
elseif (legiong == eigleg) then
user:SetTeam(8)
else
user:SetTeam(9)
end
user:StripWeapons()
local modelka = file.Read("users/"..user:SteamID64().."/model/model.txt", "data")
local bodygrops = file.Read("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "data")
local skines = file.Read("users/"..user:SteamID64().."/skin/skin.txt", "data")
local mscale = file.Read("users/"..user:SteamID64().."/size/size.txt", "data")
local healsth = file.Read("users/"..user:SteamID64().."/health/health.txt", "data")
local armorks = file.Read("users/"..user:SteamID64().."/armor/armor.txt", "data")
local speedok = file.Read("users/"..user:SteamID64().."/speed/speed.txt", "data")
local gravok = file.Read("users/"..user:SteamID64().."/grav/grav.txt", "data")
local firweap = file.Read("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "data")
local secweap = file.Read("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "data")
local gern = file.Read("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "data")
local gern2 = file.Read("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "data")
local knifek = file.Read("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "data")
local utile = file.Read("users/"..user:SteamID64().."/utiles/utiles.txt", "data")
local utile2 = file.Read("users/"..user:SteamID64().."/utiles2/utiles2.txt", "data")
local entitis = file.Read("users/"..user:SteamID64().."/entity/entity.txt", "data")
timer.Create( "Unique2s", 1, 2, function()
user:SetHealth( healsth )
user:SetMaxHealth( healsth )
user:SetArmor( armorks )
user:SetMaxArmor( armorks )
user:SetWalkSpeed( speedok * 100 )
user:SetRunSpeed( speedok * 240 )
user:SetGravity( gravok )
user:SetModelScale( mscale, 1 )
end )
user:SetModel(modelka)
user:SetSkin( skines )
user:SetBodyGroups( bodygrops )
user:Give( "arms" )
user:Give( firweap, true )
user:Give( secweap, true )
user:Give( gern )
user:Give( gern2 )
user:Give( knifek )
user:Give( utile )
user:Give( utile2 )
if (entitis != "null") then
local ent = ents.Create(entitis)
ent:SetPos( user:GetPos() ) 
ent:Spawn()
ent:Use( user, NULL, 1, 0 )
end
end)

util.AddNetworkString("Clone_104_CC")
net.Receive("Clone_104_CC", function()
local banner = net.ReadString()
local user = net.ReadEntity()
file.Write("users/"..user:SteamID64().."/model/model.txt", "models/cs574/clones/ait/ait_barc.mdl")
file.Write("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "0000001231110")
file.Write("users/"..user:SteamID64().."/skin/skin.txt", "0")
file.Write("users/"..user:SteamID64().."/size/size.txt", "1")
file.Write("users/"..user:SteamID64().."/legion/legion.txt", "574-К")
file.Write("users/"..user:SteamID64().."/health/health.txt", "150")
file.Write("users/"..user:SteamID64().."/armor/armor.txt", "200")
file.Write("users/"..user:SteamID64().."/speed/speed.txt", "1")
file.Write("users/"..user:SteamID64().."/grav/grav.txt", "1")
file.Write("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "rw_sw_dc15a")
file.Write("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "rw_sw_dc17")
file.Write("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "rw_sw_nade_thermal")
file.Write("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "arms")
file.Write("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles/utiles.txt", "alydus_fortificationbuildertablet")
file.Write("users/"..user:SteamID64().."/utiles2/utiles2.txt", "arms")
file.Write("users/"..user:SteamID64().."/entity/entity.txt", "null")
file.Write("users/"..user:SteamID64().."/radio/radio.txt", "null")
--- Респавн
local legiong = file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data")
if (legiong == oneleg) then
user:SetTeam(1)
elseif (legiong == twoleg) then
user:SetTeam(2)
elseif (legiong == trileg) then
user:SetTeam(3)
elseif (legiong == forleg) then
user:SetTeam(4)
elseif (legiong == fivleg) then
user:SetTeam(5)
elseif (legiong == sixleg) then
user:SetTeam(6)
elseif (legiong == sevleg) then
user:SetTeam(7)
elseif (legiong == eigleg) then
user:SetTeam(8)
else
user:SetTeam(9)
end
user:StripWeapons()
local modelka = file.Read("users/"..user:SteamID64().."/model/model.txt", "data")
local bodygrops = file.Read("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "data")
local skines = file.Read("users/"..user:SteamID64().."/skin/skin.txt", "data")
local mscale = file.Read("users/"..user:SteamID64().."/size/size.txt", "data")
local healsth = file.Read("users/"..user:SteamID64().."/health/health.txt", "data")
local armorks = file.Read("users/"..user:SteamID64().."/armor/armor.txt", "data")
local speedok = file.Read("users/"..user:SteamID64().."/speed/speed.txt", "data")
local gravok = file.Read("users/"..user:SteamID64().."/grav/grav.txt", "data")
local firweap = file.Read("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "data")
local secweap = file.Read("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "data")
local gern = file.Read("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "data")
local gern2 = file.Read("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "data")
local knifek = file.Read("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "data")
local utile = file.Read("users/"..user:SteamID64().."/utiles/utiles.txt", "data")
local utile2 = file.Read("users/"..user:SteamID64().."/utiles2/utiles2.txt", "data")
local entitis = file.Read("users/"..user:SteamID64().."/entity/entity.txt", "data")
timer.Create( "Unique2s", 1, 2, function()
user:SetHealth( healsth )
user:SetMaxHealth( healsth )
user:SetArmor( armorks )
user:SetMaxArmor( armorks )
user:SetWalkSpeed( speedok * 100 )
user:SetRunSpeed( speedok * 240 )
user:SetGravity( gravok )
user:SetModelScale( mscale, 1 )
end )
user:SetModel(modelka)
user:SetSkin( skines )
user:SetBodyGroups( bodygrops )
user:Give( "arms" )
user:Give( firweap, true )
user:Give( secweap, true )
user:Give( gern )
user:Give( gern2 )
user:Give( knifek )
user:Give( utile )
user:Give( utile2 )
if (entitis != "null") then
local ent = ents.Create(entitis)
ent:SetPos( user:GetPos() ) 
ent:Spawn()
ent:Use( user, NULL, 1, 0 )
end
end)

--- КЛОНЫ 91-ого

util.AddNetworkString("Clone_91_S")
net.Receive("Clone_91_S", function()
local banner = net.ReadString()
local user = net.ReadEntity()
file.Write("users/"..user:SteamID64().."/model/model.txt", "models/aussiwozzi/phase1clones/41st/ranger_trooper.mdl")
file.Write("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "0000000000000")
file.Write("users/"..user:SteamID64().."/skin/skin.txt", "0")
file.Write("users/"..user:SteamID64().."/size/size.txt", "1")
file.Write("users/"..user:SteamID64().."/legion/legion.txt", "41-К")
file.Write("users/"..user:SteamID64().."/health/health.txt", "150")
file.Write("users/"..user:SteamID64().."/armor/armor.txt", "200")
file.Write("users/"..user:SteamID64().."/speed/speed.txt", "1")
file.Write("users/"..user:SteamID64().."/grav/grav.txt", "1")
file.Write("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "rw_sw_valken38x")
file.Write("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "realistic_hook")
file.Write("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "rw_sw_bino_dark")
file.Write("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "arms")
file.Write("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles/utiles.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles2/utiles2.txt", "arms")
file.Write("users/"..user:SteamID64().."/entity/entity.txt", "null")
file.Write("users/"..user:SteamID64().."/radio/radio.txt", "null")
--- Респавн
local legiong = file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data")
if (legiong == oneleg) then
user:SetTeam(1)
elseif (legiong == twoleg) then
user:SetTeam(2)
elseif (legiong == trileg) then
user:SetTeam(3)
elseif (legiong == forleg) then
user:SetTeam(4)
elseif (legiong == fivleg) then
user:SetTeam(5)
elseif (legiong == sixleg) then
user:SetTeam(6)
elseif (legiong == sevleg) then
user:SetTeam(7)
elseif (legiong == eigleg) then
user:SetTeam(8)
else
user:SetTeam(9)
end
user:StripWeapons()
local modelka = file.Read("users/"..user:SteamID64().."/model/model.txt", "data")
local bodygrops = file.Read("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "data")
local skines = file.Read("users/"..user:SteamID64().."/skin/skin.txt", "data")
local mscale = file.Read("users/"..user:SteamID64().."/size/size.txt", "data")
local healsth = file.Read("users/"..user:SteamID64().."/health/health.txt", "data")
local armorks = file.Read("users/"..user:SteamID64().."/armor/armor.txt", "data")
local speedok = file.Read("users/"..user:SteamID64().."/speed/speed.txt", "data")
local gravok = file.Read("users/"..user:SteamID64().."/grav/grav.txt", "data")
local firweap = file.Read("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "data")
local secweap = file.Read("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "data")
local gern = file.Read("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "data")
local gern2 = file.Read("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "data")
local knifek = file.Read("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "data")
local utile = file.Read("users/"..user:SteamID64().."/utiles/utiles.txt", "data")
local utile2 = file.Read("users/"..user:SteamID64().."/utiles2/utiles2.txt", "data")
local entitis = file.Read("users/"..user:SteamID64().."/entity/entity.txt", "data")
timer.Create( "Unique2s", 1, 2, function()
user:SetHealth( healsth )
user:SetMaxHealth( healsth )
user:SetArmor( armorks )
user:SetMaxArmor( armorks )
user:SetWalkSpeed( speedok * 100 )
user:SetRunSpeed( speedok * 240 )
user:SetGravity( gravok )
user:SetModelScale( mscale, 1 )
end )
user:SetModel(modelka)
user:SetSkin( skines )
user:SetBodyGroups( bodygrops )
user:Give( "arms" )
user:Give( firweap, true )
user:Give( secweap, true )
user:Give( gern )
user:Give( gern2 )
user:Give( knifek )
user:Give( utile )
user:Give( utile2 )
if (entitis != "null") then
local ent = ents.Create(entitis)
ent:SetPos( user:GetPos() ) 
ent:Spawn()
ent:Use( user, NULL, 1, 0 )
end
end)

util.AddNetworkString("Clone_91_O")
net.Receive("Clone_91_O", function()
local banner = net.ReadString()
local user = net.ReadEntity()
file.Write("users/"..user:SteamID64().."/model/model.txt", "models/aussiwozzi/phase1clones/41st/ranger_trooper.mdl")
file.Write("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "0000010000000")
file.Write("users/"..user:SteamID64().."/skin/skin.txt", "0")
file.Write("users/"..user:SteamID64().."/size/size.txt", "1")
file.Write("users/"..user:SteamID64().."/legion/legion.txt", "41-К")
file.Write("users/"..user:SteamID64().."/health/health.txt", "150")
file.Write("users/"..user:SteamID64().."/armor/armor.txt", "200")
file.Write("users/"..user:SteamID64().."/speed/speed.txt", "1")
file.Write("users/"..user:SteamID64().."/grav/grav.txt", "1")
file.Write("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "rw_sw_valken38x")
file.Write("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "realistic_hook")
file.Write("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "rw_sw_bino_dark")
file.Write("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "arms")
file.Write("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles/utiles.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles2/utiles2.txt", "arms")
file.Write("users/"..user:SteamID64().."/entity/entity.txt", "null")
file.Write("users/"..user:SteamID64().."/radio/radio.txt", "null")
--- Респавн
local legiong = file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data")
if (legiong == oneleg) then
user:SetTeam(1)
elseif (legiong == twoleg) then
user:SetTeam(2)
elseif (legiong == trileg) then
user:SetTeam(3)
elseif (legiong == forleg) then
user:SetTeam(4)
elseif (legiong == fivleg) then
user:SetTeam(5)
elseif (legiong == sixleg) then
user:SetTeam(6)
elseif (legiong == sevleg) then
user:SetTeam(7)
elseif (legiong == eigleg) then
user:SetTeam(8)
else
user:SetTeam(9)
end
user:StripWeapons()
local modelka = file.Read("users/"..user:SteamID64().."/model/model.txt", "data")
local bodygrops = file.Read("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "data")
local skines = file.Read("users/"..user:SteamID64().."/skin/skin.txt", "data")
local mscale = file.Read("users/"..user:SteamID64().."/size/size.txt", "data")
local healsth = file.Read("users/"..user:SteamID64().."/health/health.txt", "data")
local armorks = file.Read("users/"..user:SteamID64().."/armor/armor.txt", "data")
local speedok = file.Read("users/"..user:SteamID64().."/speed/speed.txt", "data")
local gravok = file.Read("users/"..user:SteamID64().."/grav/grav.txt", "data")
local firweap = file.Read("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "data")
local secweap = file.Read("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "data")
local gern = file.Read("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "data")
local gern2 = file.Read("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "data")
local knifek = file.Read("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "data")
local utile = file.Read("users/"..user:SteamID64().."/utiles/utiles.txt", "data")
local utile2 = file.Read("users/"..user:SteamID64().."/utiles2/utiles2.txt", "data")
local entitis = file.Read("users/"..user:SteamID64().."/entity/entity.txt", "data")
timer.Create( "Unique2s", 1, 2, function()
user:SetHealth( healsth )
user:SetMaxHealth( healsth )
user:SetArmor( armorks )
user:SetMaxArmor( armorks )
user:SetWalkSpeed( speedok * 100 )
user:SetRunSpeed( speedok * 240 )
user:SetGravity( gravok )
user:SetModelScale( mscale, 1 )
end )
user:SetModel(modelka)
user:SetSkin( skines )
user:SetBodyGroups( bodygrops )
user:Give( "arms" )
user:Give( firweap, true )
user:Give( secweap, true )
user:Give( gern )
user:Give( gern2 )
user:Give( knifek )
user:Give( utile )
user:Give( utile2 )
if (entitis != "null") then
local ent = ents.Create(entitis)
ent:SetPos( user:GetPos() ) 
ent:Spawn()
ent:Use( user, NULL, 1, 0 )
end
end)

util.AddNetworkString("Clone_91_HO")
net.Receive("Clone_91_HO", function()
local banner = net.ReadString()
local user = net.ReadEntity()
file.Write("users/"..user:SteamID64().."/model/model.txt", "models/aussiwozzi/phase1clones/41st/ranger_trooper.mdl")
file.Write("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "0000012000000")
file.Write("users/"..user:SteamID64().."/skin/skin.txt", "0")
file.Write("users/"..user:SteamID64().."/size/size.txt", "1")
file.Write("users/"..user:SteamID64().."/legion/legion.txt", "41-К")
file.Write("users/"..user:SteamID64().."/health/health.txt", "150")
file.Write("users/"..user:SteamID64().."/armor/armor.txt", "200")
file.Write("users/"..user:SteamID64().."/speed/speed.txt", "1")
file.Write("users/"..user:SteamID64().."/grav/grav.txt", "1")
file.Write("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "rw_sw_valken38x")
file.Write("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "realistic_hook")
file.Write("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "rw_sw_nade_thermal")
file.Write("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "rw_sw_bino_dark")
file.Write("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles/utiles.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles2/utiles2.txt", "arms")
file.Write("users/"..user:SteamID64().."/entity/entity.txt", "null")
file.Write("users/"..user:SteamID64().."/radio/radio.txt", "null")
--- Респавн
local legiong = file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data")
if (legiong == oneleg) then
user:SetTeam(1)
elseif (legiong == twoleg) then
user:SetTeam(2)
elseif (legiong == trileg) then
user:SetTeam(3)
elseif (legiong == forleg) then
user:SetTeam(4)
elseif (legiong == fivleg) then
user:SetTeam(5)
elseif (legiong == sixleg) then
user:SetTeam(6)
elseif (legiong == sevleg) then
user:SetTeam(7)
elseif (legiong == eigleg) then
user:SetTeam(8)
else
user:SetTeam(9)
end
user:StripWeapons()
local modelka = file.Read("users/"..user:SteamID64().."/model/model.txt", "data")
local bodygrops = file.Read("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "data")
local skines = file.Read("users/"..user:SteamID64().."/skin/skin.txt", "data")
local mscale = file.Read("users/"..user:SteamID64().."/size/size.txt", "data")
local healsth = file.Read("users/"..user:SteamID64().."/health/health.txt", "data")
local armorks = file.Read("users/"..user:SteamID64().."/armor/armor.txt", "data")
local speedok = file.Read("users/"..user:SteamID64().."/speed/speed.txt", "data")
local gravok = file.Read("users/"..user:SteamID64().."/grav/grav.txt", "data")
local firweap = file.Read("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "data")
local secweap = file.Read("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "data")
local gern = file.Read("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "data")
local gern2 = file.Read("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "data")
local knifek = file.Read("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "data")
local utile = file.Read("users/"..user:SteamID64().."/utiles/utiles.txt", "data")
local utile2 = file.Read("users/"..user:SteamID64().."/utiles2/utiles2.txt", "data")
local entitis = file.Read("users/"..user:SteamID64().."/entity/entity.txt", "data")
timer.Create( "Unique2s", 1, 2, function()
user:SetHealth( healsth )
user:SetMaxHealth( healsth )
user:SetArmor( armorks )
user:SetMaxArmor( armorks )
user:SetWalkSpeed( speedok * 100 )
user:SetRunSpeed( speedok * 240 )
user:SetGravity( gravok )
user:SetModelScale( mscale, 1 )
end )
user:SetModel(modelka)
user:SetSkin( skines )
user:SetBodyGroups( bodygrops )
user:Give( "arms" )
user:Give( firweap, true )
user:Give( secweap, true )
user:Give( gern )
user:Give( gern2 )
user:Give( knifek )
user:Give( utile )
user:Give( utile2 )
if (entitis != "null") then
local ent = ents.Create(entitis)
ent:SetPos( user:GetPos() ) 
ent:Spawn()
ent:Use( user, NULL, 1, 0 )
end
end)

util.AddNetworkString("Clone_91_CC")
net.Receive("Clone_91_CC", function()
local banner = net.ReadString()
local user = net.ReadEntity()
file.Write("users/"..user:SteamID64().."/model/model.txt", "models/aussiwozzi/phase1clones/41st/ranger_trooper.mdl")
file.Write("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "0000012000300")
file.Write("users/"..user:SteamID64().."/skin/skin.txt", "0")
file.Write("users/"..user:SteamID64().."/size/size.txt", "1")
file.Write("users/"..user:SteamID64().."/legion/legion.txt", "41-К")
file.Write("users/"..user:SteamID64().."/health/health.txt", "150")
file.Write("users/"..user:SteamID64().."/armor/armor.txt", "200")
file.Write("users/"..user:SteamID64().."/speed/speed.txt", "1")
file.Write("users/"..user:SteamID64().."/grav/grav.txt", "1")
file.Write("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "rw_sw_valken38x")
file.Write("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "realistic_hook")
file.Write("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "rw_sw_nade_thermal")
file.Write("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "rw_sw_bino_dark")
file.Write("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles/utiles.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles2/utiles2.txt", "arms")
file.Write("users/"..user:SteamID64().."/entity/entity.txt", "null")
file.Write("users/"..user:SteamID64().."/radio/radio.txt", "null")
--- Респавн
local legiong = file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data")
if (legiong == oneleg) then
user:SetTeam(1)
elseif (legiong == twoleg) then
user:SetTeam(2)
elseif (legiong == trileg) then
user:SetTeam(3)
elseif (legiong == forleg) then
user:SetTeam(4)
elseif (legiong == fivleg) then
user:SetTeam(5)
elseif (legiong == sixleg) then
user:SetTeam(6)
elseif (legiong == sevleg) then
user:SetTeam(7)
elseif (legiong == eigleg) then
user:SetTeam(8)
else
user:SetTeam(9)
end
user:StripWeapons()
local modelka = file.Read("users/"..user:SteamID64().."/model/model.txt", "data")
local bodygrops = file.Read("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "data")
local skines = file.Read("users/"..user:SteamID64().."/skin/skin.txt", "data")
local mscale = file.Read("users/"..user:SteamID64().."/size/size.txt", "data")
local healsth = file.Read("users/"..user:SteamID64().."/health/health.txt", "data")
local armorks = file.Read("users/"..user:SteamID64().."/armor/armor.txt", "data")
local speedok = file.Read("users/"..user:SteamID64().."/speed/speed.txt", "data")
local gravok = file.Read("users/"..user:SteamID64().."/grav/grav.txt", "data")
local firweap = file.Read("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "data")
local secweap = file.Read("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "data")
local gern = file.Read("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "data")
local gern2 = file.Read("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "data")
local knifek = file.Read("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "data")
local utile = file.Read("users/"..user:SteamID64().."/utiles/utiles.txt", "data")
local utile2 = file.Read("users/"..user:SteamID64().."/utiles2/utiles2.txt", "data")
local entitis = file.Read("users/"..user:SteamID64().."/entity/entity.txt", "data")
timer.Create( "Unique2s", 1, 2, function()
user:SetHealth( healsth )
user:SetMaxHealth( healsth )
user:SetArmor( armorks )
user:SetMaxArmor( armorks )
user:SetWalkSpeed( speedok * 100 )
user:SetRunSpeed( speedok * 240 )
user:SetGravity( gravok )
user:SetModelScale( mscale, 1 )
end )
user:SetModel(modelka)
user:SetSkin( skines )
user:SetBodyGroups( bodygrops )
user:Give( "arms" )
user:Give( firweap, true )
user:Give( secweap, true )
user:Give( gern )
user:Give( gern2 )
user:Give( knifek )
user:Give( utile )
user:Give( utile2 )
if (entitis != "null") then
local ent = ents.Create(entitis)
ent:SetPos( user:GetPos() ) 
ent:Spawn()
ent:Use( user, NULL, 1, 0 )
end
end)

--- КЛОНЫ ГВАРДЫ

util.AddNetworkString("Clone_GUARD_S")
net.Receive("Clone_GUARD_S", function()
local banner = net.ReadString()
local user = net.ReadEntity()
file.Write("users/"..user:SteamID64().."/model/model.txt", "models/aussiwozzi/phase1clones/cg/trooper.mdl")
file.Write("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "0000000000000")
file.Write("users/"..user:SteamID64().."/skin/skin.txt", "0")
file.Write("users/"..user:SteamID64().."/size/size.txt", "1")
file.Write("users/"..user:SteamID64().."/legion/legion.txt", "ГК")
file.Write("users/"..user:SteamID64().."/health/health.txt", "150")
file.Write("users/"..user:SteamID64().."/armor/armor.txt", "200")
file.Write("users/"..user:SteamID64().."/speed/speed.txt", "1")
file.Write("users/"..user:SteamID64().."/grav/grav.txt", "1")
file.Write("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "rw_sw_dc15s_guard")
file.Write("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "rw_sw_dc17")
file.Write("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "rw_sw_nade_stun")
file.Write("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "arms")
file.Write("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles/utiles.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles2/utiles2.txt", "arms")
file.Write("users/"..user:SteamID64().."/entity/entity.txt", "null")
file.Write("users/"..user:SteamID64().."/radio/radio.txt", "null")
--- Респавн
local legiong = file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data")
if (legiong == oneleg) then
user:SetTeam(1)
elseif (legiong == twoleg) then
user:SetTeam(2)
elseif (legiong == trileg) then
user:SetTeam(3)
elseif (legiong == forleg) then
user:SetTeam(4)
elseif (legiong == fivleg) then
user:SetTeam(5)
elseif (legiong == sixleg) then
user:SetTeam(6)
elseif (legiong == sevleg) then
user:SetTeam(7)
elseif (legiong == eigleg) then
user:SetTeam(8)
else
user:SetTeam(9)
end
user:StripWeapons()
local modelka = file.Read("users/"..user:SteamID64().."/model/model.txt", "data")
local bodygrops = file.Read("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "data")
local skines = file.Read("users/"..user:SteamID64().."/skin/skin.txt", "data")
local mscale = file.Read("users/"..user:SteamID64().."/size/size.txt", "data")
local healsth = file.Read("users/"..user:SteamID64().."/health/health.txt", "data")
local armorks = file.Read("users/"..user:SteamID64().."/armor/armor.txt", "data")
local speedok = file.Read("users/"..user:SteamID64().."/speed/speed.txt", "data")
local gravok = file.Read("users/"..user:SteamID64().."/grav/grav.txt", "data")
local firweap = file.Read("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "data")
local secweap = file.Read("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "data")
local gern = file.Read("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "data")
local gern2 = file.Read("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "data")
local knifek = file.Read("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "data")
local utile = file.Read("users/"..user:SteamID64().."/utiles/utiles.txt", "data")
local utile2 = file.Read("users/"..user:SteamID64().."/utiles2/utiles2.txt", "data")
local entitis = file.Read("users/"..user:SteamID64().."/entity/entity.txt", "data")
timer.Create( "Unique2s", 1, 2, function()
user:SetHealth( healsth )
user:SetMaxHealth( healsth )
user:SetArmor( armorks )
user:SetMaxArmor( armorks )
user:SetWalkSpeed( speedok * 100 )
user:SetRunSpeed( speedok * 240 )
user:SetGravity( gravok )
user:SetModelScale( mscale, 1 )
end )
user:SetModel(modelka)
user:SetSkin( skines )
user:SetBodyGroups( bodygrops )
user:Give( "arms" )
user:Give( firweap, true )
user:Give( secweap, true )
user:Give( gern )
user:Give( gern2 )
user:Give( knifek )
user:Give( utile )
user:Give( utile2 )
if (entitis != "null") then
local ent = ents.Create(entitis)
ent:SetPos( user:GetPos() ) 
ent:Spawn()
ent:Use( user, NULL, 1, 0 )
end
end)

util.AddNetworkString("Clone_GUARD_O")
net.Receive("Clone_GUARD_O", function()
local banner = net.ReadString()
local user = net.ReadEntity()
file.Write("users/"..user:SteamID64().."/model/model.txt", "models/aussiwozzi/phase1clones/cg/trooper.mdl")
file.Write("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "0000010000000")
file.Write("users/"..user:SteamID64().."/skin/skin.txt", "0")
file.Write("users/"..user:SteamID64().."/size/size.txt", "1")
file.Write("users/"..user:SteamID64().."/legion/legion.txt", "ГК")
file.Write("users/"..user:SteamID64().."/health/health.txt", "150")
file.Write("users/"..user:SteamID64().."/armor/armor.txt", "200")
file.Write("users/"..user:SteamID64().."/speed/speed.txt", "1")
file.Write("users/"..user:SteamID64().."/grav/grav.txt", "1")
file.Write("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "rw_sw_dc15s_guard")
file.Write("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "rw_sw_dc17")
file.Write("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "rw_sw_nade_stun")
file.Write("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "arms")
file.Write("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles/utiles.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles2/utiles2.txt", "arms")
file.Write("users/"..user:SteamID64().."/entity/entity.txt", "null")
file.Write("users/"..user:SteamID64().."/radio/radio.txt", "null")
--- Респавн
local legiong = file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data")
if (legiong == oneleg) then
user:SetTeam(1)
elseif (legiong == twoleg) then
user:SetTeam(2)
elseif (legiong == trileg) then
user:SetTeam(3)
elseif (legiong == forleg) then
user:SetTeam(4)
elseif (legiong == fivleg) then
user:SetTeam(5)
elseif (legiong == sixleg) then
user:SetTeam(6)
elseif (legiong == sevleg) then
user:SetTeam(7)
elseif (legiong == eigleg) then
user:SetTeam(8)
else
user:SetTeam(9)
end
user:StripWeapons()
local modelka = file.Read("users/"..user:SteamID64().."/model/model.txt", "data")
local bodygrops = file.Read("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "data")
local skines = file.Read("users/"..user:SteamID64().."/skin/skin.txt", "data")
local mscale = file.Read("users/"..user:SteamID64().."/size/size.txt", "data")
local healsth = file.Read("users/"..user:SteamID64().."/health/health.txt", "data")
local armorks = file.Read("users/"..user:SteamID64().."/armor/armor.txt", "data")
local speedok = file.Read("users/"..user:SteamID64().."/speed/speed.txt", "data")
local gravok = file.Read("users/"..user:SteamID64().."/grav/grav.txt", "data")
local firweap = file.Read("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "data")
local secweap = file.Read("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "data")
local gern = file.Read("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "data")
local gern2 = file.Read("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "data")
local knifek = file.Read("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "data")
local utile = file.Read("users/"..user:SteamID64().."/utiles/utiles.txt", "data")
local utile2 = file.Read("users/"..user:SteamID64().."/utiles2/utiles2.txt", "data")
local entitis = file.Read("users/"..user:SteamID64().."/entity/entity.txt", "data")
timer.Create( "Unique2s", 1, 2, function()
user:SetHealth( healsth )
user:SetMaxHealth( healsth )
user:SetArmor( armorks )
user:SetMaxArmor( armorks )
user:SetWalkSpeed( speedok * 100 )
user:SetRunSpeed( speedok * 240 )
user:SetGravity( gravok )
user:SetModelScale( mscale, 1 )
end )
user:SetModel(modelka)
user:SetSkin( skines )
user:SetBodyGroups( bodygrops )
user:Give( "arms" )
user:Give( firweap, true )
user:Give( secweap, true )
user:Give( gern )
user:Give( gern2 )
user:Give( knifek )
user:Give( utile )
user:Give( utile2 )
if (entitis != "null") then
local ent = ents.Create(entitis)
ent:SetPos( user:GetPos() ) 
ent:Spawn()
ent:Use( user, NULL, 1, 0 )
end
end)

util.AddNetworkString("Clone_GUARD_HO")
net.Receive("Clone_GUARD_HO", function()
local banner = net.ReadString()
local user = net.ReadEntity()
file.Write("users/"..user:SteamID64().."/model/model.txt", "models/aussiwozzi/phase1clones/cg/trooper.mdl")
file.Write("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "0000012000000")
file.Write("users/"..user:SteamID64().."/skin/skin.txt", "0")
file.Write("users/"..user:SteamID64().."/size/size.txt", "1")
file.Write("users/"..user:SteamID64().."/legion/legion.txt", "ГК")
file.Write("users/"..user:SteamID64().."/health/health.txt", "150")
file.Write("users/"..user:SteamID64().."/armor/armor.txt", "200")
file.Write("users/"..user:SteamID64().."/speed/speed.txt", "1")
file.Write("users/"..user:SteamID64().."/grav/grav.txt", "1")
file.Write("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "rw_sw_dc15s_guard")
file.Write("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "rw_sw_dc17")
file.Write("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "rw_sw_nade_thermal")
file.Write("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "rw_sw_nade_stun")
file.Write("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles/utiles.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles2/utiles2.txt", "arms")
file.Write("users/"..user:SteamID64().."/entity/entity.txt", "null")
file.Write("users/"..user:SteamID64().."/radio/radio.txt", "null")
--- Респавн
local legiong = file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data")
if (legiong == oneleg) then
user:SetTeam(1)
elseif (legiong == twoleg) then
user:SetTeam(2)
elseif (legiong == trileg) then
user:SetTeam(3)
elseif (legiong == forleg) then
user:SetTeam(4)
elseif (legiong == fivleg) then
user:SetTeam(5)
elseif (legiong == sixleg) then
user:SetTeam(6)
elseif (legiong == sevleg) then
user:SetTeam(7)
elseif (legiong == eigleg) then
user:SetTeam(8)
else
user:SetTeam(9)
end
user:StripWeapons()
local modelka = file.Read("users/"..user:SteamID64().."/model/model.txt", "data")
local bodygrops = file.Read("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "data")
local skines = file.Read("users/"..user:SteamID64().."/skin/skin.txt", "data")
local mscale = file.Read("users/"..user:SteamID64().."/size/size.txt", "data")
local healsth = file.Read("users/"..user:SteamID64().."/health/health.txt", "data")
local armorks = file.Read("users/"..user:SteamID64().."/armor/armor.txt", "data")
local speedok = file.Read("users/"..user:SteamID64().."/speed/speed.txt", "data")
local gravok = file.Read("users/"..user:SteamID64().."/grav/grav.txt", "data")
local firweap = file.Read("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "data")
local secweap = file.Read("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "data")
local gern = file.Read("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "data")
local gern2 = file.Read("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "data")
local knifek = file.Read("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "data")
local utile = file.Read("users/"..user:SteamID64().."/utiles/utiles.txt", "data")
local utile2 = file.Read("users/"..user:SteamID64().."/utiles2/utiles2.txt", "data")
local entitis = file.Read("users/"..user:SteamID64().."/entity/entity.txt", "data")
timer.Create( "Unique2s", 1, 2, function()
user:SetHealth( healsth )
user:SetMaxHealth( healsth )
user:SetArmor( armorks )
user:SetMaxArmor( armorks )
user:SetWalkSpeed( speedok * 100 )
user:SetRunSpeed( speedok * 240 )
user:SetGravity( gravok )
user:SetModelScale( mscale, 1 )
end )
user:SetModel(modelka)
user:SetSkin( skines )
user:SetBodyGroups( bodygrops )
user:Give( "arms" )
user:Give( firweap, true )
user:Give( secweap, true )
user:Give( gern )
user:Give( gern2 )
user:Give( knifek )
user:Give( utile )
user:Give( utile2 )
if (entitis != "null") then
local ent = ents.Create(entitis)
ent:SetPos( user:GetPos() ) 
ent:Spawn()
ent:Use( user, NULL, 1, 0 )
end
end)

util.AddNetworkString("Clone_GUARD_CC")
net.Receive("Clone_GUARD_CC", function()
local banner = net.ReadString()
local user = net.ReadEntity()
file.Write("users/"..user:SteamID64().."/model/model.txt", "models/aussiwozzi/phase1clones/cg/trooper.mdl")
file.Write("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "0000012000300")
file.Write("users/"..user:SteamID64().."/skin/skin.txt", "0")
file.Write("users/"..user:SteamID64().."/size/size.txt", "1")
file.Write("users/"..user:SteamID64().."/legion/legion.txt", "ГК")
file.Write("users/"..user:SteamID64().."/health/health.txt", "150")
file.Write("users/"..user:SteamID64().."/armor/armor.txt", "200")
file.Write("users/"..user:SteamID64().."/speed/speed.txt", "1")
file.Write("users/"..user:SteamID64().."/grav/grav.txt", "1")
file.Write("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "rw_sw_dc15s_guard")
file.Write("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "rw_sw_dc17")
file.Write("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "rw_sw_nade_thermal")
file.Write("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "rw_sw_nade_stun")
file.Write("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles/utiles.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles2/utiles2.txt", "arms")
file.Write("users/"..user:SteamID64().."/entity/entity.txt", "null")
file.Write("users/"..user:SteamID64().."/radio/radio.txt", "null")
--- Респавн
local legiong = file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data")
if (legiong == oneleg) then
user:SetTeam(1)
elseif (legiong == twoleg) then
user:SetTeam(2)
elseif (legiong == trileg) then
user:SetTeam(3)
elseif (legiong == forleg) then
user:SetTeam(4)
elseif (legiong == fivleg) then
user:SetTeam(5)
elseif (legiong == sixleg) then
user:SetTeam(6)
elseif (legiong == sevleg) then
user:SetTeam(7)
elseif (legiong == eigleg) then
user:SetTeam(8)
else
user:SetTeam(9)
end
user:StripWeapons()
local modelka = file.Read("users/"..user:SteamID64().."/model/model.txt", "data")
local bodygrops = file.Read("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "data")
local skines = file.Read("users/"..user:SteamID64().."/skin/skin.txt", "data")
local mscale = file.Read("users/"..user:SteamID64().."/size/size.txt", "data")
local healsth = file.Read("users/"..user:SteamID64().."/health/health.txt", "data")
local armorks = file.Read("users/"..user:SteamID64().."/armor/armor.txt", "data")
local speedok = file.Read("users/"..user:SteamID64().."/speed/speed.txt", "data")
local gravok = file.Read("users/"..user:SteamID64().."/grav/grav.txt", "data")
local firweap = file.Read("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "data")
local secweap = file.Read("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "data")
local gern = file.Read("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "data")
local gern2 = file.Read("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "data")
local knifek = file.Read("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "data")
local utile = file.Read("users/"..user:SteamID64().."/utiles/utiles.txt", "data")
local utile2 = file.Read("users/"..user:SteamID64().."/utiles2/utiles2.txt", "data")
local entitis = file.Read("users/"..user:SteamID64().."/entity/entity.txt", "data")
timer.Create( "Unique2s", 1, 2, function()
user:SetHealth( healsth )
user:SetMaxHealth( healsth )
user:SetArmor( armorks )
user:SetMaxArmor( armorks )
user:SetWalkSpeed( speedok * 100 )
user:SetRunSpeed( speedok * 240 )
user:SetGravity( gravok )
user:SetModelScale( mscale, 1 )
end )
user:SetModel(modelka)
user:SetSkin( skines )
user:SetBodyGroups( bodygrops )
user:Give( "arms" )
user:Give( firweap, true )
user:Give( secweap, true )
user:Give( gern )
user:Give( gern2 )
user:Give( knifek )
user:Give( utile )
user:Give( utile2 )
if (entitis != "null") then
local ent = ents.Create(entitis)
ent:SetPos( user:GetPos() ) 
ent:Spawn()
ent:Use( user, NULL, 1, 0 )
end
end)

--- ПАЖИЛОЙ ФЛОТИЛЯНЕЦ

util.AddNetworkString("Clone_FLEET_S")
net.Receive("Clone_FLEET_S", function()
local banner = net.ReadString()
local user = net.ReadEntity()
file.Write("users/"..user:SteamID64().."/model/model.txt", "models/player/kurier/fleet/lightgrey.mdl")
file.Write("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "0100000000000")
file.Write("users/"..user:SteamID64().."/skin/skin.txt", "0")
file.Write("users/"..user:SteamID64().."/size/size.txt", "1")
file.Write("users/"..user:SteamID64().."/legion/legion.txt", "Флот")
file.Write("users/"..user:SteamID64().."/health/health.txt", "150")
file.Write("users/"..user:SteamID64().."/armor/armor.txt", "200")
file.Write("users/"..user:SteamID64().."/speed/speed.txt", "1")
file.Write("users/"..user:SteamID64().."/grav/grav.txt", "1")
file.Write("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "rw_sw_dc17")
file.Write("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "arms")
file.Write("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "arms")
file.Write("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "arms")
file.Write("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles/utiles.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles2/utiles2.txt", "arms")
file.Write("users/"..user:SteamID64().."/entity/entity.txt", "null")
file.Write("users/"..user:SteamID64().."/radio/radio.txt", "null")
--- Респавн
local legiong = file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data")
if (legiong == oneleg) then
user:SetTeam(1)
elseif (legiong == twoleg) then
user:SetTeam(2)
elseif (legiong == trileg) then
user:SetTeam(3)
elseif (legiong == forleg) then
user:SetTeam(4)
elseif (legiong == fivleg) then
user:SetTeam(5)
elseif (legiong == sixleg) then
user:SetTeam(6)
elseif (legiong == sevleg) then
user:SetTeam(7)
elseif (legiong == eigleg) then
user:SetTeam(8)
else
user:SetTeam(9)
end
user:StripWeapons()
local modelka = file.Read("users/"..user:SteamID64().."/model/model.txt", "data")
local bodygrops = file.Read("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "data")
local skines = file.Read("users/"..user:SteamID64().."/skin/skin.txt", "data")
local mscale = file.Read("users/"..user:SteamID64().."/size/size.txt", "data")
local healsth = file.Read("users/"..user:SteamID64().."/health/health.txt", "data")
local armorks = file.Read("users/"..user:SteamID64().."/armor/armor.txt", "data")
local speedok = file.Read("users/"..user:SteamID64().."/speed/speed.txt", "data")
local gravok = file.Read("users/"..user:SteamID64().."/grav/grav.txt", "data")
local firweap = file.Read("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "data")
local secweap = file.Read("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "data")
local gern = file.Read("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "data")
local gern2 = file.Read("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "data")
local knifek = file.Read("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "data")
local utile = file.Read("users/"..user:SteamID64().."/utiles/utiles.txt", "data")
local utile2 = file.Read("users/"..user:SteamID64().."/utiles2/utiles2.txt", "data")
local entitis = file.Read("users/"..user:SteamID64().."/entity/entity.txt", "data")
timer.Create( "Unique2s", 1, 2, function()
user:SetHealth( healsth )
user:SetMaxHealth( healsth )
user:SetArmor( armorks )
user:SetMaxArmor( armorks )
user:SetWalkSpeed( speedok * 100 )
user:SetRunSpeed( speedok * 240 )
user:SetGravity( gravok )
user:SetModelScale( mscale, 1 )
end )
user:SetModel(modelka)
user:SetSkin( skines )
user:SetBodyGroups( bodygrops )
user:Give( "arms" )
user:Give( firweap, true )
user:Give( secweap, true )
user:Give( gern )
user:Give( gern2 )
user:Give( knifek )
user:Give( utile )
user:Give( utile2 )
if (entitis != "null") then
local ent = ents.Create(entitis)
ent:SetPos( user:GetPos() ) 
ent:Spawn()
ent:Use( user, NULL, 1, 0 )
end
end)

util.AddNetworkString("Clone_FLEET_O")
net.Receive("Clone_FLEET_O", function()
local banner = net.ReadString()
local user = net.ReadEntity()
file.Write("users/"..user:SteamID64().."/model/model.txt", "models/player/kurier/fleet/grey.mdl")
file.Write("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "0101120000000")
file.Write("users/"..user:SteamID64().."/skin/skin.txt", "1")
file.Write("users/"..user:SteamID64().."/size/size.txt", "1")
file.Write("users/"..user:SteamID64().."/legion/legion.txt", "Флот")
file.Write("users/"..user:SteamID64().."/health/health.txt", "150")
file.Write("users/"..user:SteamID64().."/armor/armor.txt", "200")
file.Write("users/"..user:SteamID64().."/speed/speed.txt", "1")
file.Write("users/"..user:SteamID64().."/grav/grav.txt", "1")
file.Write("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "rw_sw_dc17")
file.Write("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "arms")
file.Write("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "arms")
file.Write("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "arms")
file.Write("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles/utiles.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles2/utiles2.txt", "arms")
file.Write("users/"..user:SteamID64().."/entity/entity.txt", "null")
file.Write("users/"..user:SteamID64().."/radio/radio.txt", "null")
--- Респавн
local legiong = file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data")
if (legiong == oneleg) then
user:SetTeam(1)
elseif (legiong == twoleg) then
user:SetTeam(2)
elseif (legiong == trileg) then
user:SetTeam(3)
elseif (legiong == forleg) then
user:SetTeam(4)
elseif (legiong == fivleg) then
user:SetTeam(5)
elseif (legiong == sixleg) then
user:SetTeam(6)
elseif (legiong == sevleg) then
user:SetTeam(7)
elseif (legiong == eigleg) then
user:SetTeam(8)
else
user:SetTeam(9)
end
user:StripWeapons()
local modelka = file.Read("users/"..user:SteamID64().."/model/model.txt", "data")
local bodygrops = file.Read("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "data")
local skines = file.Read("users/"..user:SteamID64().."/skin/skin.txt", "data")
local mscale = file.Read("users/"..user:SteamID64().."/size/size.txt", "data")
local healsth = file.Read("users/"..user:SteamID64().."/health/health.txt", "data")
local armorks = file.Read("users/"..user:SteamID64().."/armor/armor.txt", "data")
local speedok = file.Read("users/"..user:SteamID64().."/speed/speed.txt", "data")
local gravok = file.Read("users/"..user:SteamID64().."/grav/grav.txt", "data")
local firweap = file.Read("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "data")
local secweap = file.Read("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "data")
local gern = file.Read("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "data")
local gern2 = file.Read("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "data")
local knifek = file.Read("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "data")
local utile = file.Read("users/"..user:SteamID64().."/utiles/utiles.txt", "data")
local utile2 = file.Read("users/"..user:SteamID64().."/utiles2/utiles2.txt", "data")
local entitis = file.Read("users/"..user:SteamID64().."/entity/entity.txt", "data")
timer.Create( "Unique2s", 1, 2, function()
user:SetHealth( healsth )
user:SetMaxHealth( healsth )
user:SetArmor( armorks )
user:SetMaxArmor( armorks )
user:SetWalkSpeed( speedok * 100 )
user:SetRunSpeed( speedok * 240 )
user:SetGravity( gravok )
user:SetModelScale( mscale, 1 )
end )
user:SetModel(modelka)
user:SetSkin( skines )
user:SetBodyGroups( bodygrops )
user:Give( "arms" )
user:Give( firweap, true )
user:Give( secweap, true )
user:Give( gern )
user:Give( gern2 )
user:Give( knifek )
user:Give( utile )
user:Give( utile2 )
if (entitis != "null") then
local ent = ents.Create(entitis)
ent:SetPos( user:GetPos() ) 
ent:Spawn()
ent:Use( user, NULL, 1, 0 )
end
end)

util.AddNetworkString("Clone_FLEET_HO")
net.Receive("Clone_FLEET_HO", function()
local banner = net.ReadString()
local user = net.ReadEntity()
file.Write("users/"..user:SteamID64().."/model/model.txt", "models/player/kurier/fleet/black.mdl")
file.Write("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "0101260000000")
file.Write("users/"..user:SteamID64().."/skin/skin.txt", "3")
file.Write("users/"..user:SteamID64().."/size/size.txt", "1")
file.Write("users/"..user:SteamID64().."/legion/legion.txt", "Флот")
file.Write("users/"..user:SteamID64().."/health/health.txt", "150")
file.Write("users/"..user:SteamID64().."/armor/armor.txt", "200")
file.Write("users/"..user:SteamID64().."/speed/speed.txt", "1")
file.Write("users/"..user:SteamID64().."/grav/grav.txt", "1")
file.Write("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "rw_sw_dc17")
file.Write("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "arms")
file.Write("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "arms")
file.Write("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "arms")
file.Write("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles/utiles.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles2/utiles2.txt", "arms")
file.Write("users/"..user:SteamID64().."/entity/entity.txt", "null")
file.Write("users/"..user:SteamID64().."/radio/radio.txt", "null")
--- Респавн
local legiong = file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data")
if (legiong == oneleg) then
user:SetTeam(1)
elseif (legiong == twoleg) then
user:SetTeam(2)
elseif (legiong == trileg) then
user:SetTeam(3)
elseif (legiong == forleg) then
user:SetTeam(4)
elseif (legiong == fivleg) then
user:SetTeam(5)
elseif (legiong == sixleg) then
user:SetTeam(6)
elseif (legiong == sevleg) then
user:SetTeam(7)
elseif (legiong == eigleg) then
user:SetTeam(8)
else
user:SetTeam(9)
end
user:StripWeapons()
local modelka = file.Read("users/"..user:SteamID64().."/model/model.txt", "data")
local bodygrops = file.Read("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "data")
local skines = file.Read("users/"..user:SteamID64().."/skin/skin.txt", "data")
local mscale = file.Read("users/"..user:SteamID64().."/size/size.txt", "data")
local healsth = file.Read("users/"..user:SteamID64().."/health/health.txt", "data")
local armorks = file.Read("users/"..user:SteamID64().."/armor/armor.txt", "data")
local speedok = file.Read("users/"..user:SteamID64().."/speed/speed.txt", "data")
local gravok = file.Read("users/"..user:SteamID64().."/grav/grav.txt", "data")
local firweap = file.Read("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "data")
local secweap = file.Read("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "data")
local gern = file.Read("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "data")
local gern2 = file.Read("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "data")
local knifek = file.Read("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "data")
local utile = file.Read("users/"..user:SteamID64().."/utiles/utiles.txt", "data")
local utile2 = file.Read("users/"..user:SteamID64().."/utiles2/utiles2.txt", "data")
local entitis = file.Read("users/"..user:SteamID64().."/entity/entity.txt", "data")
timer.Create( "Unique2s", 1, 2, function()
user:SetHealth( healsth )
user:SetMaxHealth( healsth )
user:SetArmor( armorks )
user:SetMaxArmor( armorks )
user:SetWalkSpeed( speedok * 100 )
user:SetRunSpeed( speedok * 240 )
user:SetGravity( gravok )
user:SetModelScale( mscale, 1 )
end )
user:SetModel(modelka)
user:SetSkin( skines )
user:SetBodyGroups( bodygrops )
user:Give( "arms" )
user:Give( firweap, true )
user:Give( secweap, true )
user:Give( gern )
user:Give( gern2 )
user:Give( knifek )
user:Give( utile )
user:Give( utile2 )
if (entitis != "null") then
local ent = ents.Create(entitis)
ent:SetPos( user:GetPos() ) 
ent:Spawn()
ent:Use( user, NULL, 1, 0 )
end
end)

util.AddNetworkString("Clone_FLEET_XO")
net.Receive("Clone_FLEET_XO", function()
local banner = net.ReadString()
local user = net.ReadEntity()
file.Write("users/"..user:SteamID64().."/model/model.txt", "models/player/kurier/fleet/fleetadmiral.mdl")
file.Write("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "0151000000000")
file.Write("users/"..user:SteamID64().."/skin/skin.txt", "0")
file.Write("users/"..user:SteamID64().."/size/size.txt", "1")
file.Write("users/"..user:SteamID64().."/legion/legion.txt", "Флот")
file.Write("users/"..user:SteamID64().."/health/health.txt", "150")
file.Write("users/"..user:SteamID64().."/armor/armor.txt", "200")
file.Write("users/"..user:SteamID64().."/speed/speed.txt", "1")
file.Write("users/"..user:SteamID64().."/grav/grav.txt", "1")
file.Write("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "rw_sw_dc17")
file.Write("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "arms")
file.Write("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "arms")
file.Write("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "arms")
file.Write("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles/utiles.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles2/utiles2.txt", "arms")
file.Write("users/"..user:SteamID64().."/entity/entity.txt", "null")
file.Write("users/"..user:SteamID64().."/radio/radio.txt", "null")
--- Респавн
local legiong = file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data")
if (legiong == oneleg) then
user:SetTeam(1)
elseif (legiong == twoleg) then
user:SetTeam(2)
elseif (legiong == trileg) then
user:SetTeam(3)
elseif (legiong == forleg) then
user:SetTeam(4)
elseif (legiong == fivleg) then
user:SetTeam(5)
elseif (legiong == sixleg) then
user:SetTeam(6)
elseif (legiong == sevleg) then
user:SetTeam(7)
elseif (legiong == eigleg) then
user:SetTeam(8)
else
user:SetTeam(9)
end
user:StripWeapons()
local modelka = file.Read("users/"..user:SteamID64().."/model/model.txt", "data")
local bodygrops = file.Read("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "data")
local skines = file.Read("users/"..user:SteamID64().."/skin/skin.txt", "data")
local mscale = file.Read("users/"..user:SteamID64().."/size/size.txt", "data")
local healsth = file.Read("users/"..user:SteamID64().."/health/health.txt", "data")
local armorks = file.Read("users/"..user:SteamID64().."/armor/armor.txt", "data")
local speedok = file.Read("users/"..user:SteamID64().."/speed/speed.txt", "data")
local gravok = file.Read("users/"..user:SteamID64().."/grav/grav.txt", "data")
local firweap = file.Read("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "data")
local secweap = file.Read("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "data")
local gern = file.Read("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "data")
local gern2 = file.Read("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "data")
local knifek = file.Read("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "data")
local utile = file.Read("users/"..user:SteamID64().."/utiles/utiles.txt", "data")
local utile2 = file.Read("users/"..user:SteamID64().."/utiles2/utiles2.txt", "data")
local entitis = file.Read("users/"..user:SteamID64().."/entity/entity.txt", "data")
timer.Create( "Unique2s", 1, 2, function()
user:SetHealth( healsth )
user:SetMaxHealth( healsth )
user:SetArmor( armorks )
user:SetMaxArmor( armorks )
user:SetWalkSpeed( speedok * 100 )
user:SetRunSpeed( speedok * 240 )
user:SetGravity( gravok )
user:SetModelScale( mscale, 1 )
end )
user:SetModel(modelka)
user:SetSkin( skines )
user:SetBodyGroups( bodygrops )
user:Give( "arms" )
user:Give( firweap, true )
user:Give( secweap, true )
user:Give( gern )
user:Give( gern2 )
user:Give( knifek )
user:Give( utile )
user:Give( utile2 )
if (entitis != "null") then
local ent = ents.Create(entitis)
ent:SetPos( user:GetPos() ) 
ent:Spawn()
ent:Use( user, NULL, 1, 0 )
end
end)

util.AddNetworkString("Clone_FLEET_CC")
net.Receive("Clone_FLEET_CC", function()
local banner = net.ReadString()
local user = net.ReadEntity()
file.Write("users/"..user:SteamID64().."/model/model.txt", "models/player/kurier/fleet/admiral.mdl")
file.Write("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "0100100000000")
file.Write("users/"..user:SteamID64().."/skin/skin.txt", "0")
file.Write("users/"..user:SteamID64().."/size/size.txt", "1")
file.Write("users/"..user:SteamID64().."/legion/legion.txt", "Флот")
file.Write("users/"..user:SteamID64().."/health/health.txt", "150")
file.Write("users/"..user:SteamID64().."/armor/armor.txt", "200")
file.Write("users/"..user:SteamID64().."/speed/speed.txt", "1")
file.Write("users/"..user:SteamID64().."/grav/grav.txt", "1")
file.Write("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "rw_sw_dc17")
file.Write("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "arms")
file.Write("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "arms")
file.Write("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "arms")
file.Write("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles/utiles.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles2/utiles2.txt", "arms")
file.Write("users/"..user:SteamID64().."/entity/entity.txt", "null")
file.Write("users/"..user:SteamID64().."/radio/radio.txt", "null")
--- Респавн
local legiong = file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data")
if (legiong == oneleg) then
user:SetTeam(1)
elseif (legiong == twoleg) then
user:SetTeam(2)
elseif (legiong == trileg) then
user:SetTeam(3)
elseif (legiong == forleg) then
user:SetTeam(4)
elseif (legiong == fivleg) then
user:SetTeam(5)
elseif (legiong == sixleg) then
user:SetTeam(6)
elseif (legiong == sevleg) then
user:SetTeam(7)
elseif (legiong == eigleg) then
user:SetTeam(8)
else
user:SetTeam(9)
end
user:StripWeapons()
local modelka = file.Read("users/"..user:SteamID64().."/model/model.txt", "data")
local bodygrops = file.Read("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "data")
local skines = file.Read("users/"..user:SteamID64().."/skin/skin.txt", "data")
local mscale = file.Read("users/"..user:SteamID64().."/size/size.txt", "data")
local healsth = file.Read("users/"..user:SteamID64().."/health/health.txt", "data")
local armorks = file.Read("users/"..user:SteamID64().."/armor/armor.txt", "data")
local speedok = file.Read("users/"..user:SteamID64().."/speed/speed.txt", "data")
local gravok = file.Read("users/"..user:SteamID64().."/grav/grav.txt", "data")
local firweap = file.Read("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "data")
local secweap = file.Read("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "data")
local gern = file.Read("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "data")
local gern2 = file.Read("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "data")
local knifek = file.Read("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "data")
local utile = file.Read("users/"..user:SteamID64().."/utiles/utiles.txt", "data")
local utile2 = file.Read("users/"..user:SteamID64().."/utiles2/utiles2.txt", "data")
local entitis = file.Read("users/"..user:SteamID64().."/entity/entity.txt", "data")
timer.Create( "Unique2s", 1, 2, function()
user:SetHealth( healsth )
user:SetMaxHealth( healsth )
user:SetArmor( armorks )
user:SetMaxArmor( armorks )
user:SetWalkSpeed( speedok * 100 )
user:SetRunSpeed( speedok * 240 )
user:SetGravity( gravok )
user:SetModelScale( mscale, 1 )
end )
user:SetModel(modelka)
user:SetSkin( skines )
user:SetBodyGroups( bodygrops )
user:Give( "arms" )
user:Give( firweap, true )
user:Give( secweap, true )
user:Give( gern )
user:Give( gern2 )
user:Give( knifek )
user:Give( utile )
user:Give( utile2 )
if (entitis != "null") then
local ent = ents.Create(entitis)
ent:SetPos( user:GetPos() ) 
ent:Spawn()
ent:Use( user, NULL, 1, 0 )
end
end)



-- ЧИСТО ARC



util.AddNetworkString("Clone_ARC_S")
net.Receive("Clone_ARC_S", function()
local banner = net.ReadString()
local user = net.ReadEntity()
file.Write("users/"..user:SteamID64().."/model/model.txt", "models/player/trooper/trooper.mdl")
file.Write("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "0000000000000")
file.Write("users/"..user:SteamID64().."/skin/skin.txt", "0")
file.Write("users/"..user:SteamID64().."/size/size.txt", "1")
file.Write("users/"..user:SteamID64().."/legion/legion.txt", "ЭРК")
file.Write("users/"..user:SteamID64().."/health/health.txt", "150")
file.Write("users/"..user:SteamID64().."/armor/armor.txt", "200")
file.Write("users/"..user:SteamID64().."/speed/speed.txt", "1")
file.Write("users/"..user:SteamID64().."/grav/grav.txt", "1")
file.Write("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "rw_sw_westarm5")
file.Write("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "rw_sw_dc17")
file.Write("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "rw_sw_nade_thermal")
file.Write("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "rw_sw_nade_smoke")
file.Write("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "rw_sw_nade_stun")
file.Write("users/"..user:SteamID64().."/utiles/utiles.txt", "realistic_hook")
file.Write("users/"..user:SteamID64().."/utiles2/utiles2.txt", "arms")
file.Write("users/"..user:SteamID64().."/entity/entity.txt", "null")
file.Write("users/"..user:SteamID64().."/radio/radio.txt", "null")
--- Респавн
local legiong = file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data")
if (legiong == oneleg) then
user:SetTeam(1)
elseif (legiong == twoleg) then
user:SetTeam(2)
elseif (legiong == trileg) then
user:SetTeam(3)
elseif (legiong == forleg) then
user:SetTeam(4)
elseif (legiong == fivleg) then
user:SetTeam(5)
elseif (legiong == sixleg) then
user:SetTeam(6)
elseif (legiong == sevleg) then
user:SetTeam(7)
elseif (legiong == eigleg) then
user:SetTeam(8)
else
user:SetTeam(9)
end
user:StripWeapons()
local modelka = file.Read("users/"..user:SteamID64().."/model/model.txt", "data")
local bodygrops = file.Read("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "data")
local skines = file.Read("users/"..user:SteamID64().."/skin/skin.txt", "data")
local mscale = file.Read("users/"..user:SteamID64().."/size/size.txt", "data")
local healsth = file.Read("users/"..user:SteamID64().."/health/health.txt", "data")
local armorks = file.Read("users/"..user:SteamID64().."/armor/armor.txt", "data")
local speedok = file.Read("users/"..user:SteamID64().."/speed/speed.txt", "data")
local gravok = file.Read("users/"..user:SteamID64().."/grav/grav.txt", "data")
local firweap = file.Read("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "data")
local secweap = file.Read("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "data")
local gern = file.Read("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "data")
local gern2 = file.Read("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "data")
local knifek = file.Read("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "data")
local utile = file.Read("users/"..user:SteamID64().."/utiles/utiles.txt", "data")
local utile2 = file.Read("users/"..user:SteamID64().."/utiles2/utiles2.txt", "data")
local entitis = file.Read("users/"..user:SteamID64().."/entity/entity.txt", "data")
timer.Create( "Unique2s", 1, 2, function()
user:SetHealth( healsth )
user:SetMaxHealth( healsth )
user:SetArmor( armorks )
user:SetMaxArmor( armorks )
user:SetWalkSpeed( speedok * 100 )
user:SetRunSpeed( speedok * 240 )
user:SetGravity( gravok )
user:SetModelScale( mscale, 1 )
end )
user:SetModel(modelka)
user:SetSkin( skines )
user:SetBodyGroups( bodygrops )
user:Give( "arms" )
user:Give( firweap, true )
user:Give( secweap, true )
user:Give( gern )
user:Give( gern2 )
user:Give( knifek )
user:Give( utile )
user:Give( utile2 )
if (entitis != "null") then
local ent = ents.Create(entitis)
ent:SetPos( user:GetPos() ) 
ent:Spawn()
ent:Use( user, NULL, 1, 0 )
end
end)

util.AddNetworkString("Clone_ARC_CC")
net.Receive("Clone_ARC_CC", function()
local banner = net.ReadString()
local user = net.ReadEntity()
file.Write("users/"..user:SteamID64().."/model/model.txt", "models/player/rancor/blitz/blitz.mdl")
file.Write("users/"..user:SteamID64().."/name/name.txt", "Blitz")
file.Write("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "0000000000000")
file.Write("users/"..user:SteamID64().."/skin/skin.txt", "0")
file.Write("users/"..user:SteamID64().."/size/size.txt", "1")
file.Write("users/"..user:SteamID64().."/legion/legion.txt", "ЭРК")
file.Write("users/"..user:SteamID64().."/health/health.txt", "150")
file.Write("users/"..user:SteamID64().."/armor/armor.txt", "200")
file.Write("users/"..user:SteamID64().."/speed/speed.txt", "1")
file.Write("users/"..user:SteamID64().."/grav/grav.txt", "1")
file.Write("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "rw_sw_westarm5")
file.Write("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "rw_sw_dual_dc17")
file.Write("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "rw_sw_nade_thermal")
file.Write("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "rw_sw_nade_smoke")
file.Write("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "rw_sw_nade_stun")
file.Write("users/"..user:SteamID64().."/utiles/utiles.txt", "realistic_hook")
file.Write("users/"..user:SteamID64().."/utiles2/utiles2.txt", "arms")
file.Write("users/"..user:SteamID64().."/entity/entity.txt", "null")
file.Write("users/"..user:SteamID64().."/radio/radio.txt", "null")
--- Респавн
local legiong = file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data")
if (legiong == oneleg) then
user:SetTeam(1)
elseif (legiong == twoleg) then
user:SetTeam(2)
elseif (legiong == trileg) then
user:SetTeam(3)
elseif (legiong == forleg) then
user:SetTeam(4)
elseif (legiong == fivleg) then
user:SetTeam(5)
elseif (legiong == sixleg) then
user:SetTeam(6)
elseif (legiong == sevleg) then
user:SetTeam(7)
elseif (legiong == eigleg) then
user:SetTeam(8)
else
user:SetTeam(9)
end
user:StripWeapons()
local modelka = file.Read("users/"..user:SteamID64().."/model/model.txt", "data")
local bodygrops = file.Read("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "data")
local skines = file.Read("users/"..user:SteamID64().."/skin/skin.txt", "data")
local mscale = file.Read("users/"..user:SteamID64().."/size/size.txt", "data")
local healsth = file.Read("users/"..user:SteamID64().."/health/health.txt", "data")
local armorks = file.Read("users/"..user:SteamID64().."/armor/armor.txt", "data")
local speedok = file.Read("users/"..user:SteamID64().."/speed/speed.txt", "data")
local gravok = file.Read("users/"..user:SteamID64().."/grav/grav.txt", "data")
local firweap = file.Read("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "data")
local secweap = file.Read("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "data")
local gern = file.Read("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "data")
local gern2 = file.Read("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "data")
local knifek = file.Read("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "data")
local utile = file.Read("users/"..user:SteamID64().."/utiles/utiles.txt", "data")
local utile2 = file.Read("users/"..user:SteamID64().."/utiles2/utiles2.txt", "data")
local entitis = file.Read("users/"..user:SteamID64().."/entity/entity.txt", "data")
timer.Create( "Unique2s", 1, 2, function()
user:SetHealth( healsth )
user:SetMaxHealth( healsth )
user:SetArmor( armorks )
user:SetMaxArmor( armorks )
user:SetWalkSpeed( speedok * 100 )
user:SetRunSpeed( speedok * 240 )
user:SetGravity( gravok )
user:SetModelScale( mscale, 1 )
end )
user:SetModel(modelka)
user:SetSkin( skines )
user:SetBodyGroups( bodygrops )
user:Give( "arms" )
user:Give( firweap, true )
user:Give( secweap, true )
user:Give( gern )
user:Give( gern2 )
user:Give( knifek )
user:Give( utile )
user:Give( utile2 )
if (entitis != "null") then
local ent = ents.Create(entitis)
ent:SetPos( user:GetPos() ) 
ent:Spawn()
ent:Use( user, NULL, 1, 0 )
end
end)

util.AddNetworkString("Clone_ARC_A77")
net.Receive("Clone_ARC_A77", function()
local banner = net.ReadString()
local user = net.ReadEntity()
file.Write("users/"..user:SteamID64().."/model/model.txt", "models/player/captain/captain.mdl")
file.Write("users/"..user:SteamID64().."/name/name.txt", "Fordo")
file.Write("users/"..user:SteamID64().."/number/number.txt", "0077")
file.Write("users/"..user:SteamID64().."/rank/rank.txt", "КМДР")
file.Write("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "0000000000000")
file.Write("users/"..user:SteamID64().."/skin/skin.txt", "0")
file.Write("users/"..user:SteamID64().."/size/size.txt", "1")
file.Write("users/"..user:SteamID64().."/legion/legion.txt", "ЭРК")
file.Write("users/"..user:SteamID64().."/health/health.txt", "150")
file.Write("users/"..user:SteamID64().."/armor/armor.txt", "200")
file.Write("users/"..user:SteamID64().."/speed/speed.txt", "1")
file.Write("users/"..user:SteamID64().."/grav/grav.txt", "1")
file.Write("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "rw_sw_dual_dc17s")
file.Write("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "realistic_hook")
file.Write("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "rw_sw_nade_thermal")
file.Write("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "rw_sw_nade_smoke")
file.Write("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles/utiles.txt", "arms")
file.Write("users/"..user:SteamID64().."/utiles2/utiles2.txt", "arms")
file.Write("users/"..user:SteamID64().."/entity/entity.txt", "null")
file.Write("users/"..user:SteamID64().."/radio/radio.txt", "null")
--- Респавн
local legiong = file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data")
if (legiong == oneleg) then
user:SetTeam(1)
elseif (legiong == twoleg) then
user:SetTeam(2)
elseif (legiong == trileg) then
user:SetTeam(3)
elseif (legiong == forleg) then
user:SetTeam(4)
elseif (legiong == fivleg) then
user:SetTeam(5)
elseif (legiong == sixleg) then
user:SetTeam(6)
elseif (legiong == sevleg) then
user:SetTeam(7)
elseif (legiong == eigleg) then
user:SetTeam(8)
else
user:SetTeam(9)
end
user:StripWeapons()
local modelka = file.Read("users/"..user:SteamID64().."/model/model.txt", "data")
local bodygrops = file.Read("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "data")
local skines = file.Read("users/"..user:SteamID64().."/skin/skin.txt", "data")
local mscale = file.Read("users/"..user:SteamID64().."/size/size.txt", "data")
local healsth = file.Read("users/"..user:SteamID64().."/health/health.txt", "data")
local armorks = file.Read("users/"..user:SteamID64().."/armor/armor.txt", "data")
local speedok = file.Read("users/"..user:SteamID64().."/speed/speed.txt", "data")
local gravok = file.Read("users/"..user:SteamID64().."/grav/grav.txt", "data")
local firweap = file.Read("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "data")
local secweap = file.Read("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "data")
local gern = file.Read("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "data")
local gern2 = file.Read("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "data")
local knifek = file.Read("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "data")
local utile = file.Read("users/"..user:SteamID64().."/utiles/utiles.txt", "data")
local utile2 = file.Read("users/"..user:SteamID64().."/utiles2/utiles2.txt", "data")
local entitis = file.Read("users/"..user:SteamID64().."/entity/entity.txt", "data")
timer.Create( "Unique2s", 1, 2, function()
user:SetHealth( healsth )
user:SetMaxHealth( healsth )
user:SetArmor( armorks )
user:SetMaxArmor( armorks )
user:SetWalkSpeed( speedok * 100 )
user:SetRunSpeed( speedok * 240 )
user:SetGravity( gravok )
user:SetModelScale( mscale, 1 )
end )
user:SetModel(modelka)
user:SetSkin( skines )
user:SetBodyGroups( bodygrops )
user:Give( "arms" )
user:Give( firweap, true )
user:Give( secweap, true )
user:Give( gern )
user:Give( gern2 )
user:Give( knifek )
user:Give( utile )
user:Give( utile2 )
if (entitis != "null") then
local ent = ents.Create(entitis)
ent:SetPos( user:GetPos() ) 
ent:Spawn()
ent:Use( user, NULL, 1, 0 )
end
end)

util.AddNetworkString("Clone_ARC_A77L")
net.Receive("Clone_ARC_A77L", function()
local banner = net.ReadString()
local user = net.ReadEntity()
file.Write("users/"..user:SteamID64().."/model/model.txt", "models/player/lieutenant/lieutenant.mdl")
file.Write("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "0000000000000")
file.Write("users/"..user:SteamID64().."/rank/rank.txt", "СЛТ")
file.Write("users/"..user:SteamID64().."/skin/skin.txt", "0")
file.Write("users/"..user:SteamID64().."/size/size.txt", "1")
file.Write("users/"..user:SteamID64().."/legion/legion.txt", "ЭРК")
file.Write("users/"..user:SteamID64().."/health/health.txt", "150")
file.Write("users/"..user:SteamID64().."/armor/armor.txt", "200")
file.Write("users/"..user:SteamID64().."/speed/speed.txt", "1")
file.Write("users/"..user:SteamID64().."/grav/grav.txt", "1")
file.Write("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "rw_sw_westarm5")
file.Write("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "realistic_hook")
file.Write("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "rw_sw_nade_thermal")
file.Write("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "rw_sw_nade_dioxis")
file.Write("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "rw_sw_nade_smoke")
file.Write("users/"..user:SteamID64().."/utiles/utiles.txt", "rw_sw_nade_impact")
file.Write("users/"..user:SteamID64().."/utiles2/utiles2.txt", "alydus_fortificationbuildertablet")
file.Write("users/"..user:SteamID64().."/entity/entity.txt", "null")
file.Write("users/"..user:SteamID64().."/radio/radio.txt", "null")
--- Респавн
local legiong = file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data")
if (legiong == oneleg) then
user:SetTeam(1)
elseif (legiong == twoleg) then
user:SetTeam(2)
elseif (legiong == trileg) then
user:SetTeam(3)
elseif (legiong == forleg) then
user:SetTeam(4)
elseif (legiong == fivleg) then
user:SetTeam(5)
elseif (legiong == sixleg) then
user:SetTeam(6)
elseif (legiong == sevleg) then
user:SetTeam(7)
elseif (legiong == eigleg) then
user:SetTeam(8)
else
user:SetTeam(9)
end
user:StripWeapons()
local modelka = file.Read("users/"..user:SteamID64().."/model/model.txt", "data")
local bodygrops = file.Read("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "data")
local skines = file.Read("users/"..user:SteamID64().."/skin/skin.txt", "data")
local mscale = file.Read("users/"..user:SteamID64().."/size/size.txt", "data")
local healsth = file.Read("users/"..user:SteamID64().."/health/health.txt", "data")
local armorks = file.Read("users/"..user:SteamID64().."/armor/armor.txt", "data")
local speedok = file.Read("users/"..user:SteamID64().."/speed/speed.txt", "data")
local gravok = file.Read("users/"..user:SteamID64().."/grav/grav.txt", "data")
local firweap = file.Read("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "data")
local secweap = file.Read("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "data")
local gern = file.Read("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "data")
local gern2 = file.Read("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "data")
local knifek = file.Read("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "data")
local utile = file.Read("users/"..user:SteamID64().."/utiles/utiles.txt", "data")
local utile2 = file.Read("users/"..user:SteamID64().."/utiles2/utiles2.txt", "data")
local entitis = file.Read("users/"..user:SteamID64().."/entity/entity.txt", "data")
timer.Create( "Unique2s", 1, 2, function()
user:SetHealth( healsth )
user:SetMaxHealth( healsth )
user:SetArmor( armorks )
user:SetMaxArmor( armorks )
user:SetWalkSpeed( speedok * 100 )
user:SetRunSpeed( speedok * 240 )
user:SetGravity( gravok )
user:SetModelScale( mscale, 1 )
end )
user:SetModel(modelka)
user:SetSkin( skines )
user:SetBodyGroups( bodygrops )
user:Give( "arms" )
user:Give( firweap, true )
user:Give( secweap, true )
user:Give( gern )
user:Give( gern2 )
user:Give( knifek )
user:Give( utile )
user:Give( utile2 )
if (entitis != "null") then
local ent = ents.Create(entitis)
ent:SetPos( user:GetPos() ) 
ent:Spawn()
ent:Use( user, NULL, 1, 0 )
end
end)

util.AddNetworkString("Clone_RC_STANDART")
net.Receive("Clone_RC_STANDART", function()
local banner = net.ReadString()
local user = net.ReadEntity()
local randomselectmodel = math.random(0,100)
local randommodelrc = "?"
if randomselectmodel < 25 and randomselectmodel >= 0 then
randommodelrc = "models/player/republiccommandos/rc_omega_niner.mdl"
elseif randomselectmodel < 50 and randomselectmodel >= 25 then
randommodelrc = "models/player/republiccommandos/rc_omega_niner.mdl"
elseif randomselectmodel < 75 and randomselectmodel >= 50 then
randommodelrc = "models/player/republiccommandos/rc_omega_niner.mdl"
elseif randomselectmodel <= 100 and randomselectmodel >= 75 then
randommodelrc = "models/player/republiccommandos/rc_omega_niner.mdl"
end
file.Write("users/"..user:SteamID64().."/model/model.txt", randommodelrc)
file.Write("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "0000000")
file.Write("users/"..user:SteamID64().."/rank/rank.txt", "КПЛ")
file.Write("users/"..user:SteamID64().."/skin/skin.txt", "0")
file.Write("users/"..user:SteamID64().."/size/size.txt", "1")
file.Write("users/"..user:SteamID64().."/legion/legion.txt", "НЕТ")
file.Write("users/"..user:SteamID64().."/health/health.txt", "350")
file.Write("users/"..user:SteamID64().."/armor/armor.txt", "500")
file.Write("users/"..user:SteamID64().."/speed/speed.txt", "1")
file.Write("users/"..user:SteamID64().."/grav/grav.txt", "1")
file.Write("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "rw_sw_dc17m")
file.Write("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "rw_sw_dc17m_launcher")
file.Write("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "realistic_hook")
file.Write("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "rw_sw_dc17m_sniper")
file.Write("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "rw_sw_nade_thermal")
file.Write("users/"..user:SteamID64().."/utiles/utiles.txt", "rw_sw_nade_smoke")
file.Write("users/"..user:SteamID64().."/utiles2/utiles2.txt", "rw_sw_bino_dark")
file.Write("users/"..user:SteamID64().."/entity/entity.txt", "null")
file.Write("users/"..user:SteamID64().."/radio/radio.txt", "null")
--- Респавн
local legiong = file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data")
if (legiong == oneleg) then
user:SetTeam(1)
elseif (legiong == twoleg) then
user:SetTeam(2)
elseif (legiong == trileg) then
user:SetTeam(3)
elseif (legiong == forleg) then
user:SetTeam(4)
elseif (legiong == fivleg) then
user:SetTeam(5)
elseif (legiong == sixleg) then
user:SetTeam(6)
elseif (legiong == sevleg) then
user:SetTeam(7)
elseif (legiong == eigleg) then
user:SetTeam(8)
else
user:SetTeam(9)
end
user:StripWeapons()
local modelka = file.Read("users/"..user:SteamID64().."/model/model.txt", "data")
local bodygrops = file.Read("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "data")
local skines = file.Read("users/"..user:SteamID64().."/skin/skin.txt", "data")
local mscale = file.Read("users/"..user:SteamID64().."/size/size.txt", "data")
local healsth = file.Read("users/"..user:SteamID64().."/health/health.txt", "data")
local armorks = file.Read("users/"..user:SteamID64().."/armor/armor.txt", "data")
local speedok = file.Read("users/"..user:SteamID64().."/speed/speed.txt", "data")
local gravok = file.Read("users/"..user:SteamID64().."/grav/grav.txt", "data")
local firweap = file.Read("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "data")
local secweap = file.Read("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "data")
local gern = file.Read("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "data")
local gern2 = file.Read("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "data")
local knifek = file.Read("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "data")
local utile = file.Read("users/"..user:SteamID64().."/utiles/utiles.txt", "data")
local utile2 = file.Read("users/"..user:SteamID64().."/utiles2/utiles2.txt", "data")
local entitis = file.Read("users/"..user:SteamID64().."/entity/entity.txt", "data")
timer.Create( "Unique2s", 1, 2, function()
user:SetHealth( healsth )
user:SetMaxHealth( healsth )
user:SetArmor( armorks )
user:SetMaxArmor( armorks )
user:SetWalkSpeed( speedok * 100 )
user:SetRunSpeed( speedok * 240 )
user:SetGravity( gravok )
user:SetModelScale( mscale, 1 )
end )
user:SetModel(modelka)
user:SetSkin( skines )
user:SetBodyGroups( bodygrops )
user:Give( "arms" )
user:Give( firweap, true )
user:Give( secweap, true )
user:Give( gern )
user:Give( gern2 )
user:Give( knifek )
user:Give( utile )
user:Give( utile2 )
if (entitis != "null") then
local ent = ents.Create(entitis)
ent:SetPos( user:GetPos() ) 
ent:Spawn()
ent:Use( user, NULL, 1, 0 )
end
end)