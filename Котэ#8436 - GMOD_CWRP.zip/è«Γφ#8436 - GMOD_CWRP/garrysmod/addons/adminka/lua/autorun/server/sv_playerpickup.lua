if CLIENT then return end
local function PlayerPickup(ply, ent)
	if (ent:GetClass():lower() == "player") then
if (file.Read("users/"..ply:SteamID64().."/admin/admin.txt", "data") == "owner" or file.Read("users/"..ply:SteamID64().."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..ply:SteamID64().."/admin/admin.txt", "data") == "admin") then
		ent:Freeze(true)
		ent:SetMoveType(MOVETYPE_NOCLIP)
		return true
	end
	end
end

hook.Add("PhysgunDrop", "PhysgunFreeze.PhysgunDrop", function(ply, ent)
if ply:KeyPressed(IN_ATTACK2) then return end
if (ent:GetClass():lower() == "player") then
		ent:DropToFloor()
		ent:Freeze(false)
		ent:SetMoveType(MOVETYPE_WALK)
end
end)

hook.Add("PhysgunPickup", "playergetphis", PlayerPickup)
