if CLIENT then return end
hook.Add( "PlayerSwitchWeapon", "delmodel", function( ply, oldWeapon, newWeapon )
if (file.Read("users/"..ply:SteamID64().."/admin/cloak.txt", "data") == "true") then
timer.Create( "timerdelmodel", 1, 1, function()
ply:DrawWorldModel( false )
end)
end
end)

util.AddNetworkString("sendtoserveramenu")
net.Receive("sendtoserveramenu", function()
local reason = net.ReadString()
local user = net.ReadString()
local banner = net.ReadString()
local user2 = net.ReadString()
local players = player.GetAll()
local bannername = "?"
local user2name = "?"
for i, v in pairs(players) do
        if v:SteamID64() == banner then    
        bannername = v:Name()
        end
end
for i, v in pairs(players) do
        if v:SteamID64() == user2 then    
        user2name = v:Name()
        end
end
if file.Read("users/"..user2.."/admin/admin.txt", "data") == "owner" and file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" then
game.KickID( user, reason )
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."кикнул по причине: "..reason.."\n"..user2.." - ["..user2name.."] - ["..file.Read("users/"..user2.."/legion/legion.txt", "data").." | "..file.Read("users/"..user2.."/name/name.txt", "data").." | "..file.Read("users/"..user2.."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user2.."/admin/admin.txt", "data") == "highadmin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
game.KickID( user, reason )
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."кикнул по причине: "..reason.."\n"..user2.." - ["..user2name.."] - ["..file.Read("users/"..user2.."/legion/legion.txt", "data").." | "..file.Read("users/"..user2.."/name/name.txt", "data").." | "..file.Read("users/"..user2.."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user2.."/admin/admin.txt", "data") == "admin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
game.KickID( user, reason )	
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."кикнул по причине: "..reason.."\n"..user2.." - ["..user2name.."] - ["..file.Read("users/"..user2.."/legion/legion.txt", "data").." | "..file.Read("users/"..user2.."/name/name.txt", "data").." | "..file.Read("users/"..user2.."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user2.."/admin/admin.txt", "data") == "commander" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "commander") then
game.KickID( user, reason )
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."кикнул по причине: "..reason.."\n"..user2.." - ["..user2name.."] - ["..file.Read("users/"..user2.."/legion/legion.txt", "data").." | "..file.Read("users/"..user2.."/name/name.txt", "data").." | "..file.Read("users/"..user2.."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user2.."/admin/admin.txt", "data") == "user" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "commander") then
game.KickID( user, reason )
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."кикнул по причине: "..reason.."\n"..user2.." - ["..user2name.."] - ["..file.Read("users/"..user2.."/legion/legion.txt", "data").." | "..file.Read("users/"..user2.."/name/name.txt", "data").." | "..file.Read("users/"..user2.."/number/number.txt", "data").."]".."\n".."------------")
end
end)

util.AddNetworkString("sendtoserveramenuunban")
net.Receive("sendtoserveramenuunban", function()
local userid = net.ReadString()
local unbanner = net.ReadString()
local unbannername = net.ReadString()
local steamiduser32 = util.SteamIDFrom64( userid )
file.Write("users/"..userid.."/banned/banned.txt", "false")
file.Write("users/"..userid.."/banned/timerbanned.txt", "0")
RunConsoleCommand( "removeid", steamiduser32 )
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..unbanner.." - ["..unbannername.."] - ["..file.Read("users/"..unbanner.."/legion/legion.txt", "data").." | "..file.Read("users/"..unbanner.."/name/name.txt", "data").." | "..file.Read("users/"..unbanner.."/number/number.txt", "data").."]".."\n".."разбанил ID64".."\n"..userid.." - ["..userid.."] - ["..file.Read("users/"..userid.."/legion/legion.txt", "data").." | "..file.Read("users/"..userid.."/name/name.txt", "data").." | "..file.Read("users/"..userid.."/number/number.txt", "data").."]".."\n".."------------")
end)

util.AddNetworkString("sendtoserveramenubanid")
net.Receive("sendtoserveramenubanid", function()
local userid = net.ReadString()
local banner = net.ReadString()
local bannername = net.ReadString()
local reason = net.ReadString()
local steamiduser32 = util.SteamIDFrom64( userid )
if file.Read("users/"..userid.."/admin/admin.txt", "data") == "owner" and file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" then
file.Write("users/"..userid.."/banned/banned.txt", "true")
file.Write("users/"..userid.."/banned/reason.txt", reason..", ай-яй-яй")
file.Write("users/"..userid.."/banned/whobanned.txt", bannername.." - "..banner)
RunConsoleCommand( "banid", "0", steamiduser32 )
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."забанил ID64 по причине: "..reason.."\n"..userid.." - ["..userid.."] - ["..file.Read("users/"..userid.."/legion/legion.txt", "data").." | "..file.Read("users/"..userid.."/name/name.txt", "data").." | "..file.Read("users/"..userid.."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..userid.."/admin/admin.txt", "data") == "highadmin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner") then
file.Write("users/"..userid.."/banned/banned.txt", "true")
file.Write("users/"..userid.."/banned/reason.txt", reason..", ай-яй-яй")
file.Write("users/"..userid.."/banned/whobanned.txt", bannername.." - "..banner)
RunConsoleCommand( "banid", "0", steamiduser32 )
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."забанил ID64 по причине: "..reason.."\n"..userid.." - ["..userid.."] - ["..file.Read("users/"..userid.."/legion/legion.txt", "data").." | "..file.Read("users/"..userid.."/name/name.txt", "data").." | "..file.Read("users/"..userid.."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..userid.."/admin/admin.txt", "data") == "admin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
file.Write("users/"..userid.."/banned/banned.txt", "true")
file.Write("users/"..userid.."/banned/reason.txt", reason..", ай-яй-яй")
file.Write("users/"..userid.."/banned/whobanned.txt", bannername.." - "..banner)
RunConsoleCommand( "banid", "0", steamiduser32 )
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."забанил ID64 по причине: "..reason.."\n"..userid.." - ["..userid.."] - ["..file.Read("users/"..userid.."/legion/legion.txt", "data").." | "..file.Read("users/"..userid.."/name/name.txt", "data").." | "..file.Read("users/"..userid.."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..userid.."/admin/admin.txt", "data") == "commander" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
file.Write("users/"..userid.."/banned/banned.txt", "true")
file.Write("users/"..userid.."/banned/reason.txt", reason..", ай-яй-яй")
file.Write("users/"..userid.."/banned/whobanned.txt", bannername.." - "..banner)
RunConsoleCommand( "banid", "0", steamiduser32 )
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."забанил ID64 по причине: "..reason.."\n"..userid.." - ["..userid.."] - ["..file.Read("users/"..userid.."/legion/legion.txt", "data").." | "..file.Read("users/"..userid.."/name/name.txt", "data").." | "..file.Read("users/"..userid.."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..userid.."/admin/admin.txt", "data") == "user" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
file.Write("users/"..userid.."/banned/banned.txt", "true")
file.Write("users/"..userid.."/banned/reason.txt", reason..", ай-яй-яй")
file.Write("users/"..userid.."/banned/whobanned.txt", bannername.." - "..banner)
RunConsoleCommand( "banid", "0", steamiduser32 )
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."забанил ID64 по причине: "..reason.."\n"..userid.." - ["..userid.."] - ["..file.Read("users/"..userid.."/legion/legion.txt", "data").." | "..file.Read("users/"..userid.."/name/name.txt", "data").." | "..file.Read("users/"..userid.."/number/number.txt", "data").."]".."\n".."------------")
end
end)

util.AddNetworkString("sendtoserveramenuban")
net.Receive("sendtoserveramenuban", function()
local reason = net.ReadString()
local banner = net.ReadString()
local bannername = net.ReadString()
local user = net.ReadEntity()
local userid = user:SteamID64()
if file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "owner" and file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" then
file.Write("users/"..userid.."/banned/banned.txt", "true")
file.Write("users/"..userid.."/banned/reason.txt", reason..", ай-яй-яй")
file.Write("users/"..userid.."/banned/whobanned.txt", bannername.." - "..banner)
game.KickID( user:SteamID(), "Вы забанены на нашем сервере, вот причина: /"..reason.."/, как же так получилось? А если интересно, то вас заблокировал "..bannername.." - "..banner)
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."забанил по причине: "..reason.."\n"..userid.." - ["..user:Name().."] - ["..file.Read("users/"..userid.."/legion/legion.txt", "data").." | "..file.Read("users/"..userid.."/name/name.txt", "data").." | "..file.Read("users/"..userid.."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "highadmin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner") then
file.Write("users/"..userid.."/banned/banned.txt", "true")
file.Write("users/"..userid.."/banned/reason.txt", reason..", ай-яй-яй")
file.Write("users/"..userid.."/banned/whobanned.txt", bannername.." - "..banner)
game.KickID( user:SteamID(), "Вы забанены на нашем сервере, вот причина: /"..reason.."/, как же так получилось? А если интересно, то вас заблокировал "..bannername.." - "..banner)
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."забанил по причине: "..reason.."\n"..userid.." - ["..user:Name().."] - ["..file.Read("users/"..userid.."/legion/legion.txt", "data").." | "..file.Read("users/"..userid.."/name/name.txt", "data").." | "..file.Read("users/"..userid.."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "admin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
file.Write("users/"..userid.."/banned/banned.txt", "true")
file.Write("users/"..userid.."/banned/reason.txt", reason..", ай-яй-яй")
file.Write("users/"..userid.."/banned/whobanned.txt", bannername.." - "..banner)
game.KickID( user:SteamID(), "Вы забанены на нашем сервере, вот причина: /"..reason.."/, как же так получилось? А если интересно, то вас заблокировал "..bannername.." - "..banner)
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."забанил по причине: "..reason.."\n"..userid.." - ["..user:Name().."] - ["..file.Read("users/"..userid.."/legion/legion.txt", "data").." | "..file.Read("users/"..userid.."/name/name.txt", "data").." | "..file.Read("users/"..userid.."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "commander" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
file.Write("users/"..userid.."/banned/banned.txt", "true")
file.Write("users/"..userid.."/banned/reason.txt", reason..", ай-яй-яй")
file.Write("users/"..userid.."/banned/whobanned.txt", bannername.." - "..banner)
game.KickID( user:SteamID(), "Вы забанены на нашем сервере, вот причина: /"..reason.."/, как же так получилось? А если интересно, то вас заблокировал "..bannername.." - "..banner)
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."забанил по причине: "..reason.."\n"..userid.." - ["..user:Name().."] - ["..file.Read("users/"..userid.."/legion/legion.txt", "data").." | "..file.Read("users/"..userid.."/name/name.txt", "data").." | "..file.Read("users/"..userid.."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "user" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
file.Write("users/"..userid.."/banned/banned.txt", "true")
file.Write("users/"..userid.."/banned/reason.txt", reason..", ай-яй-яй")
file.Write("users/"..userid.."/banned/whobanned.txt", bannername.." - "..banner)
game.KickID( user:SteamID(), "Вы забанены на нашем сервере, вот причина: /"..reason.."/, как же так получилось? А если интересно, то вас заблокировал "..bannername.." - "..banner)
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."забанил по причине: "..reason.."\n"..userid.." - ["..user:Name().."] - ["..file.Read("users/"..userid.."/legion/legion.txt", "data").." | "..file.Read("users/"..userid.."/name/name.txt", "data").." | "..file.Read("users/"..userid.."/number/number.txt", "data").."]".."\n".."------------")
end
end)

util.AddNetworkString("sendtoserveramenmodel")
net.Receive("sendtoserveramenmodel", function()
local reason = net.ReadString()
local banner = net.ReadString()
local user = net.ReadEntity()
local bannername = "?"
for i, v in pairs(player.GetAll()) do
        if v:SteamID64() == banner then    
        bannername = v:Name()
        end
end
if file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "owner" and file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" then
user:SetModelScale( reason, 1 )
user:SetViewOffset( Vector( 0, 0, 64 ) * Vector( 0, 0, reason ) )
user:SetViewOffsetDucked(Vector( 0, 0, 28 ) * Vector( 0, 0, reason ))
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."сменил размер модели на: ["..reason.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "highadmin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
user:SetModelScale( reason, 1 )
user:SetViewOffset( Vector( 0, 0, 64 ) * Vector( 0, 0, reason ) )
user:SetViewOffsetDucked(Vector( 0, 0, 28 ) * Vector( 0, 0, reason ))
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."сменил размер модели на: ["..reason.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "admin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
user:SetModelScale( reason, 1 )
user:SetViewOffset( Vector( 0, 0, 64 ) * Vector( 0, 0, reason ) )
user:SetViewOffsetDucked(Vector( 0, 0, 28 ) * Vector( 0, 0, reason ))
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."сменил размер модели на: ["..reason.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "commander" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
user:SetModelScale( reason, 1 )
user:SetViewOffset( Vector( 0, 0, 64 ) * Vector( 0, 0, reason ) )
user:SetViewOffsetDucked(Vector( 0, 0, 28 ) * Vector( 0, 0, reason ))
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."сменил размер модели на: ["..reason.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "user" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
user:SetModelScale( reason, 1 )
user:SetViewOffset( Vector( 0, 0, 64 ) * Vector( 0, 0, reason ) )
user:SetViewOffsetDucked(Vector( 0, 0, 28 ) * Vector( 0, 0, reason ))
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."сменил размер модели на: ["..reason.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
end
end)

util.AddNetworkString("sendtoserveramenarmoer")
net.Receive("sendtoserveramenarmoer", function()
local reasons = net.ReadString()
local reason = (reasons + 0)
local banner = net.ReadString()
local user = net.ReadEntity()
local bannername = "?"
for i, v in pairs(player.GetAll()) do
        if v:SteamID64() == banner then    
        bannername = v:Name()
        end
end
if file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "owner" and file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" then
user:SetArmor( reason )
user:SetMaxArmor( reason )
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."установил броню: ["..reason.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "highadmin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
user:SetArmor( reason )
user:SetMaxArmor( reason )
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."установил броню: ["..reason.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "admin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
user:SetArmor( reason )	
user:SetMaxArmor( reason )
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."установил броню: ["..reason.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "commander" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
user:SetArmor( reason )
user:SetMaxArmor( reason )
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."установил броню: ["..reason.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "user" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
user:SetArmor( reason )
user:SetMaxArmor( reason )
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."установил броню: ["..reason.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
end
end)

util.AddNetworkString("sendtoserveramenheels")
net.Receive("sendtoserveramenheels", function()
local reasons = net.ReadString()
local reason = (reasons + 0)
local banner = net.ReadString()
local user = net.ReadEntity()
local bannername = "?"
for i, v in pairs(player.GetAll()) do
        if v:SteamID64() == banner then    
        bannername = v:Name()
        end
end
if file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "owner" and file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" then
user:SetHealth( reason )
user:SetMaxHealth( reason )
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."установил здоровье: ["..reason.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "highadmin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
user:SetHealth( reason )
user:SetMaxHealth( reason )
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."установил здоровье: ["..reason.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "admin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
user:SetHealth( reason )	
user:SetMaxHealth( reason )
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."установил здоровье: ["..reason.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "commander" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
user:SetHealth( reason )
user:SetMaxHealth( reason )
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."установил здоровье: ["..reason.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "user" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
user:SetHealth( reason )
user:SetMaxHealth( reason )
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."установил здоровье: ["..reason.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
end
end)

util.AddNetworkString("sendtoserveramenspeed")
net.Receive("sendtoserveramenspeed", function()
local reasons = net.ReadString()
local reason = (reasons + 0)
local banner = net.ReadString()
local user = net.ReadEntity()
local bannername = "?"
for i, v in pairs(player.GetAll()) do
        if v:SteamID64() == banner then    
        bannername = v:Name()
        end
end
if file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "owner" and file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" then
user:SetRunSpeed( 240 * reason )
user:SetWalkSpeed( 100 * reason )
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."установил скорость: [x"..reason.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "highadmin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
user:SetRunSpeed( 240 * reason )
user:SetWalkSpeed( 100 * reason )
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."установил скорость: [x"..reason.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "admin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
user:SetRunSpeed( 240 * reason )
user:SetWalkSpeed( 100 * reason )
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."установил скорость: [x"..reason.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "commander" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
user:SetRunSpeed( 240 * reason )
user:SetWalkSpeed( 100 * reason )
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."установил скорость: [x"..reason.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "user" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
user:SetRunSpeed( 240 * reason )
user:SetWalkSpeed( 100 * reason )
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."установил скорость: [x"..reason.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
end
end)

util.AddNetworkString("sendtoserveramengrav")
net.Receive("sendtoserveramengrav", function()
local reasons = net.ReadString()
local reason = (reasons + 0)
local banner = net.ReadString()
local user = net.ReadEntity()
local bannername = "?"
for i, v in pairs(player.GetAll()) do
        if v:SteamID64() == banner then    
        bannername = v:Name()
        end
end
if file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "owner" and file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" then
user:SetGravity( reason )
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."установил гравитацию: ["..reason.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "highadmin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
user:SetGravity( reason )
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."установил гравитацию: ["..reason.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "admin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
user:SetGravity( reason )
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."установил гравитацию: ["..reason.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "commander" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
user:SetGravity( reason )
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."установил гравитацию: ["..reason.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "user" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
user:SetGravity( reason )
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."установил гравитацию: ["..reason.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
end
end)

util.AddNetworkString("sendtoserveramenmodl")
net.Receive("sendtoserveramenmodl", function()
local reasons = net.ReadString()
local banner = net.ReadString()
local user = net.ReadEntity()
local bannername = "?"
for i, v in pairs(player.GetAll()) do
        if v:SteamID64() == banner then    
        bannername = v:Name()
        end
end
if file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "owner" and file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" then
user:SetModel( reasons )
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."установил модель: ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "highadmin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
user:SetModel( reasons )
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."установил модель: ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "admin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
user:SetModel( reasons )
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."установил модель: ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "commander" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
user:SetModel( reasons )
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."установил модель: ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "user" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
user:SetModel( reasons )
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."установил модель: ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
end
end)

util.AddNetworkString("sendtoserveramenfreez")
net.Receive("sendtoserveramenfreez", function()
local banner = net.ReadString()
local user = net.ReadEntity()
local bannername = "?"
for i, v in pairs(player.GetAll()) do
        if v:SteamID64() == banner then    
        bannername = v:Name()
        end
end
if file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "owner" and file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" then
if file.Read("users/"..user:SteamID64().."/admin/frozen.txt", "data") == "true" then
file.Write("users/"..user:SteamID64().."/admin/frozen.txt", "false")
user:Freeze( false )
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."разморозил".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/frozen.txt", "data") == "false" then
file.Write("users/"..user:SteamID64().."/admin/frozen.txt", "true")
user:Freeze( true )
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."заморозил".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
end
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "highadmin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
if file.Read("users/"..user:SteamID64().."/admin/frozen.txt", "data") == "true" then
file.Write("users/"..user:SteamID64().."/admin/frozen.txt", "false")
user:Freeze( false )
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."разморозил".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/frozen.txt", "data") == "false" then
file.Write("users/"..user:SteamID64().."/admin/frozen.txt", "true")
user:Freeze( true )
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."заморозил".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
end
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "admin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
if file.Read("users/"..user:SteamID64().."/admin/frozen.txt", "data") == "true" then
file.Write("users/"..user:SteamID64().."/admin/frozen.txt", "false")
user:Freeze( false )
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."разморозил".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/frozen.txt", "data") == "false" then
file.Write("users/"..user:SteamID64().."/admin/frozen.txt", "true")
user:Freeze( true )
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."заморозил".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
end
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "commander" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
if file.Read("users/"..user:SteamID64().."/admin/frozen.txt", "data") == "true" then
file.Write("users/"..user:SteamID64().."/admin/frozen.txt", "false")
user:Freeze( false )
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."разморозил".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/frozen.txt", "data") == "false" then
file.Write("users/"..user:SteamID64().."/admin/frozen.txt", "true")
user:Freeze( true )
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."заморозил".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
end
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "user" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
if file.Read("users/"..user:SteamID64().."/admin/frozen.txt", "data") == "true" then
file.Write("users/"..user:SteamID64().."/admin/frozen.txt", "false")
user:Freeze( false )
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."разморозил".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/frozen.txt", "data") == "false" then
file.Write("users/"..user:SteamID64().."/admin/frozen.txt", "true")
user:Freeze( true )
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."заморозил".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
end
end
end)

util.AddNetworkString("warncipka")
net.Receive("warncipka", function()
local user = net.ReadString()
local reason = net.ReadString()
local banner = net.ReadString()
local bannername = net.ReadString()
local userban = net.ReadEntity()
if file.Read("users/"..user.."/admin/admin.txt", "data") == "owner" and file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" then
local warenkas = file.Read("users/"..user.."/warns/warns.txt", "data")
file.Write("users/"..user.."/warns/warns.txt", warenkas + 1)
file.Write("users/"..user.."/warns/warns.txt", warenkas + 1)
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."выдал выговор "..file.Read("users/"..user.."/warns/warns.txt", "data").."/6 по причине: "..reason.."\n"..user.." - ["..userban:Name().."] - ["..file.Read("users/"..user.."/legion/legion.txt", "data").." | "..file.Read("users/"..user.."/name/name.txt", "data").." | "..file.Read("users/"..user.."/number/number.txt", "data").."]".."\n".."------------")
if warenkas == "1" then userban:Kick("Вы получили выговор, всего: "..(warenkas + 1).."/6. Выдал его"..bannername.." - "..banner)
elseif warenkas == "2" then userban:Kick("Вы получили выговор, всего: "..(warenkas + 1).."/6. Выдал его "..bannername.." - "..banner)
elseif warenkas == "3" then userban:Kick("Вы получили выговор, всего: "..(warenkas + 1).."/6. Выдал его "..bannername.." - "..banner)
elseif warenkas == "4" then userban:Kick("Вы получили выговор, всего: "..(warenkas + 1).."/6. Выдал его "..bannername.." - "..banner)
elseif warenkas == "5" then 
game.KickID( userban:SteamID(), "Вы забанены на нашем сервере, вы заработали: "..(warenkas + 1).."/6 выговоров. А если интересно, то вас заблокировал "..bannername.." - "..banner)
file.Write("users/"..user.."/banned/whobanned.txt", bannername.." - "..banner)
file.Write("users/"..user.."/banned/reason.txt", "6/6 выговоров, ай-яй-яй")
warenkas = 0
file.Write("users/"..user.."/warns/warns.txt", warenkas)
file.Write("users/"..user.."/banned/banned.txt", "true")
end
elseif file.Read("users/"..user.."/admin/admin.txt", "data") == "highadmin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
local warenkas = file.Read("users/"..user.."/warns/warns.txt", "data")
file.Write("users/"..user.."/warns/warns.txt", warenkas + 1)
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."выдал выговор "..file.Read("users/"..user.."/warns/warns.txt", "data").."/6 по причине: "..reason.."\n"..user.." - ["..userban:Name().."] - ["..file.Read("users/"..user.."/legion/legion.txt", "data").." | "..file.Read("users/"..user.."/name/name.txt", "data").." | "..file.Read("users/"..user.."/number/number.txt", "data").."]".."\n".."------------")
if warenkas == "1" then userban:Kick("Вы получили выговор, всего: "..(warenkas + 1).."/6. Выдал его"..bannername.." - "..banner)
elseif warenkas == "2" then userban:Kick("Вы получили выговор, всего: "..(warenkas + 1).."/6. Выдал его "..bannername.." - "..banner)
elseif warenkas == "3" then userban:Kick("Вы получили выговор, всего: "..(warenkas + 1).."/6. Выдал его "..bannername.." - "..banner)
elseif warenkas == "4" then userban:Kick("Вы получили выговор, всего: "..(warenkas + 1).."/6. Выдал его "..bannername.." - "..banner)
elseif warenkas == "5" then 
game.KickID( userban:SteamID(), "Вы забанены на нашем сервере, вы заработали: "..(warenkas + 1).."/6 выговоров. А если интересно, то вас заблокировал "..bannername.." - "..banner)
file.Write("users/"..user.."/banned/whobanned.txt", bannername.." - "..banner)
file.Write("users/"..user.."/banned/reason.txt", "6/6 выговоров, ай-яй-яй")
warenkas = 0
file.Write("users/"..user.."/warns/warns.txt", warenkas)
file.Write("users/"..user.."/banned/banned.txt", "true")
end
elseif file.Read("users/"..user.."/admin/admin.txt", "data") == "admin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
local warenkas = file.Read("users/"..user.."/warns/warns.txt", "data")
file.Write("users/"..user.."/warns/warns.txt", warenkas + 1)
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."выдал выговор "..file.Read("users/"..user.."/warns/warns.txt", "data").."/6 по причине: "..reason.."\n"..user.." - ["..userban:Name().."] - ["..file.Read("users/"..user.."/legion/legion.txt", "data").." | "..file.Read("users/"..user.."/name/name.txt", "data").." | "..file.Read("users/"..user.."/number/number.txt", "data").."]".."\n".."------------")
if warenkas == "1" then userban:Kick("Вы получили выговор, всего: "..(warenkas + 1).."/6. Выдал его"..bannername.." - "..banner)
elseif warenkas == "2" then userban:Kick("Вы получили выговор, всего: "..(warenkas + 1).."/6. Выдал его "..bannername.." - "..banner)
elseif warenkas == "3" then userban:Kick("Вы получили выговор, всего: "..(warenkas + 1).."/6. Выдал его "..bannername.." - "..banner)
elseif warenkas == "4" then userban:Kick("Вы получили выговор, всего: "..(warenkas + 1).."/6. Выдал его "..bannername.." - "..banner)
elseif warenkas == "5" then 
game.KickID( userban:SteamID(), "Вы забанены на нашем сервере, вы заработали: "..(warenkas + 1).."/6 выговоров. А если интересно, то вас заблокировал "..bannername.." - "..banner)
file.Write("users/"..user.."/banned/whobanned.txt", bannername.." - "..banner)
file.Write("users/"..user.."/banned/reason.txt", "6/6 выговоров, ай-яй-яй")
warenkas = 0
file.Write("users/"..user.."/warns/warns.txt", warenkas)
file.Write("users/"..user.."/banned/banned.txt", "true")
end 
elseif file.Read("users/"..user.."/admin/admin.txt", "data") == "commander" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
local warenkas = file.Read("users/"..user.."/warns/warns.txt", "data")
file.Write("users/"..user.."/warns/warns.txt", warenkas + 1)
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."выдал выговор "..file.Read("users/"..user.."/warns/warns.txt", "data").."/6 по причине: "..reason.."\n"..user.." - ["..userban:Name().."] - ["..file.Read("users/"..user.."/legion/legion.txt", "data").." | "..file.Read("users/"..user.."/name/name.txt", "data").." | "..file.Read("users/"..user.."/number/number.txt", "data").."]".."\n".."------------")
if warenkas == "1" then userban:Kick("Вы получили выговор, всего: "..(warenkas + 1).."/6. Выдал его"..bannername.." - "..banner)
elseif warenkas == "2" then userban:Kick("Вы получили выговор, всего: "..(warenkas + 1).."/6. Выдал его "..bannername.." - "..banner)
elseif warenkas == "3" then userban:Kick("Вы получили выговор, всего: "..(warenkas + 1).."/6. Выдал его "..bannername.." - "..banner)
elseif warenkas == "4" then userban:Kick("Вы получили выговор, всего: "..(warenkas + 1).."/6. Выдал его "..bannername.." - "..banner)
elseif warenkas == "5" then 
game.KickID( userban:SteamID(), "Вы забанены на нашем сервере, вы заработали: "..(warenkas + 1).."/6 выговоров. А если интересно, то вас заблокировал "..bannername.." - "..banner)
file.Write("users/"..user.."/banned/whobanned.txt", bannername.." - "..banner)
file.Write("users/"..user.."/banned/reason.txt", "6/6 выговоров, ай-яй-яй")
warenkas = 0
file.Write("users/"..user.."/warns/warns.txt", warenkas)
file.Write("users/"..user.."/banned/banned.txt", "true")
end 
elseif file.Read("users/"..user.."/admin/admin.txt", "data") == "user" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
local warenkas = file.Read("users/"..user.."/warns/warns.txt", "data")
file.Write("users/"..user.."/warns/warns.txt", warenkas + 1)
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."выдал выговор "..file.Read("users/"..user.."/warns/warns.txt", "data").."/6 по причине: "..reason.."\n"..user.." - ["..userban:Name().."] - ["..file.Read("users/"..user.."/legion/legion.txt", "data").." | "..file.Read("users/"..user.."/name/name.txt", "data").." | "..file.Read("users/"..user.."/number/number.txt", "data").."]".."\n".."------------")
if warenkas == "1" then userban:Kick("Вы получили выговор, всего: "..(warenkas + 1).."/6. Выдал его"..bannername.." - "..banner)
elseif warenkas == "2" then userban:Kick("Вы получили выговор, всего: "..(warenkas + 1).."/6. Выдал его "..bannername.." - "..banner)
elseif warenkas == "3" then userban:Kick("Вы получили выговор, всего: "..(warenkas + 1).."/6. Выдал его "..bannername.." - "..banner)
elseif warenkas == "4" then userban:Kick("Вы получили выговор, всего: "..(warenkas + 1).."/6. Выдал его "..bannername.." - "..banner)
elseif warenkas == "5" then 
game.KickID( userban:SteamID(), "Вы забанены на нашем сервере, вы заработали: "..(warenkas + 1).."/6 выговоров. А если интересно, то вас заблокировал "..bannername.." - "..banner)
file.Write("users/"..user.."/banned/whobanned.txt", bannername.." - "..banner)
file.Write("users/"..user.."/banned/reason.txt", "6/6 выговоров, ай-яй-яй")
warenkas = 0
file.Write("users/"..user.."/warns/warns.txt", warenkas)
file.Write("users/"..user.."/banned/banned.txt", "true")
end 
end
end)

util.AddNetworkString("warncipkar")
net.Receive("warncipkar", function()
local user = net.ReadString()
local reason = net.ReadString()
local banner = net.ReadString()
local bannername = "?"
for i, v in pairs(player.GetAll()) do
        if v:SteamID64() == banner then    
        bannername = v:Name()
        end
end
local username = "?"
for i, v in pairs(player.GetAll()) do
        if v:SteamID64() == user then    
        username = v:Name()
        end
end
if file.Read("users/"..user.."/admin/admin.txt", "data") == "owner" and file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" then
local warenkas = file.Read("users/"..user.."/warns/warns.txt", "data")
if warenkas == "0" then warenkas = 1 end
file.Write("users/"..user.."/warns/warns.txt", warenkas - 1)
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."снял выговор "..file.Read("users/"..user.."/warns/warns.txt", "data").."/6 по причине: "..reason.."\n"..user.." - ["..username.."] - ["..file.Read("users/"..user.."/legion/legion.txt", "data").." | "..file.Read("users/"..user.."/name/name.txt", "data").." | "..file.Read("users/"..user.."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user.."/admin/admin.txt", "data") == "highadmin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
local warenkas = file.Read("users/"..user.."/warns/warns.txt", "data")
if warenkas == "0" then warenkas = 1 end
file.Write("users/"..user.."/warns/warns.txt", warenkas - 1)
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."снял выговор "..file.Read("users/"..user.."/warns/warns.txt", "data").."/6 по причине: "..reason.."\n"..user.." - ["..username.."] - ["..file.Read("users/"..user.."/legion/legion.txt", "data").." | "..file.Read("users/"..user.."/name/name.txt", "data").." | "..file.Read("users/"..user.."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user.."/admin/admin.txt", "data") == "admin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
local warenkas = file.Read("users/"..user.."/warns/warns.txt", "data")
if warenkas == "0" then warenkas = 1 end
file.Write("users/"..user.."/warns/warns.txt", warenkas - 1)
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."снял выговор "..file.Read("users/"..user.."/warns/warns.txt", "data").."/6 по причине: "..reason.."\n"..user.." - ["..username.."] - ["..file.Read("users/"..user.."/legion/legion.txt", "data").." | "..file.Read("users/"..user.."/name/name.txt", "data").." | "..file.Read("users/"..user.."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user.."/admin/admin.txt", "data") == "commander" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
local warenkas = file.Read("users/"..user.."/warns/warns.txt", "data")
if warenkas == "0" then warenkas = 1 end
file.Write("users/"..user.."/warns/warns.txt", warenkas - 1)
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."снял выговор "..file.Read("users/"..user.."/warns/warns.txt", "data").."/6 по причине: "..reason.."\n"..user.." - ["..username.."] - ["..file.Read("users/"..user.."/legion/legion.txt", "data").." | "..file.Read("users/"..user.."/name/name.txt", "data").." | "..file.Read("users/"..user.."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user.."/admin/admin.txt", "data") == "user" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
local warenkas = file.Read("users/"..user.."/warns/warns.txt", "data")
if warenkas == "0" then warenkas = 1 end
file.Write("users/"..user.."/warns/warns.txt", warenkas - 1)
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."снял выговор "..file.Read("users/"..user.."/warns/warns.txt", "data").."/6 по причине: "..reason.."\n"..user.." - ["..username.."] - ["..file.Read("users/"..user.."/legion/legion.txt", "data").." | "..file.Read("users/"..user.."/name/name.txt", "data").." | "..file.Read("users/"..user.."/number/number.txt", "data").."]".."\n".."------------")
end
end)

util.AddNetworkString("sendtoserveramentimerban")
net.Receive("sendtoserveramentimerban", function()
local user = net.ReadString()
local reason = net.ReadString()
local time = (net.ReadString() * 60)
local time2 = (os.time() + time)
local banner = net.ReadString()
local bannername = net.ReadString()
local userban = net.ReadEntity()
local username = "?"
for i, v in pairs(player.GetAll()) do
        if v:SteamID64() == user then    
        username = v:Name()
        end
end
if file.Read("users/"..user.."/admin/admin.txt", "data") == "owner" and file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" then
file.Write("users/"..user.."/banned/timerbanned.txt", time2)
local timerbanned = file.Read("users/"..user.."/banned/timerbanned.txt", "data")
file.Write("users/"..user.."/banned/whobanned.txt", bannername.." - "..banner)
file.Write("users/"..user.."/banned/reason.txt", reason)
game.KickID( userban:SteamID(), "Вы временно забанены на нашем сервере, вам осталось подождать: "..time.." секунд. А если интересно, то вас заблокировал "..bannername.." - "..banner..". Причина: "..reason)
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."забанил на время: "..time.." секунд".."\n".."по причине: "..reason.."\n"..user.." - ["..username.."] - ["..file.Read("users/"..user.."/legion/legion.txt", "data").." | "..file.Read("users/"..user.."/name/name.txt", "data").." | "..file.Read("users/"..user.."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user.."/admin/admin.txt", "data") == "highadmin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
file.Write("users/"..user.."/banned/timerbanned.txt", time2)
local timerbanned = file.Read("users/"..user.."/banned/timerbanned.txt", "data")
file.Write("users/"..user.."/banned/whobanned.txt", bannername.." - "..banner)
file.Write("users/"..user.."/banned/reason.txt", reason)
game.KickID( userban:SteamID(), "Вы временно забанены на нашем сервере, вам осталось подождать: "..time.." секунд. А если интересно, то вас заблокировал "..bannername.." - "..banner..". Причина: "..reason)
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."забанил на время: "..time.." секунд".."\n".."по причине: "..reason.."\n"..user.." - ["..username.."] - ["..file.Read("users/"..user.."/legion/legion.txt", "data").." | "..file.Read("users/"..user.."/name/name.txt", "data").." | "..file.Read("users/"..user.."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user.."/admin/admin.txt", "data") == "admin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
file.Write("users/"..user.."/banned/timerbanned.txt", time2)
local timerbanned = file.Read("users/"..user.."/banned/timerbanned.txt", "data")
file.Write("users/"..user.."/banned/whobanned.txt", bannername.." - "..banner)
file.Write("users/"..user.."/banned/reason.txt", reason)
game.KickID( userban:SteamID(), "Вы временно забанены на нашем сервере, вам осталось подождать: "..time.." секунд. А если интересно, то вас заблокировал "..bannername.." - "..banner..". Причина: "..reason)
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."забанил на время: "..time.." секунд".."\n".."по причине: "..reason.."\n"..user.." - ["..username.."] - ["..file.Read("users/"..user.."/legion/legion.txt", "data").." | "..file.Read("users/"..user.."/name/name.txt", "data").." | "..file.Read("users/"..user.."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user.."/admin/admin.txt", "data") == "commander" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
file.Write("users/"..user.."/banned/timerbanned.txt", time2)
local timerbanned = file.Read("users/"..user.."/banned/timerbanned.txt", "data")
file.Write("users/"..user.."/banned/whobanned.txt", bannername.." - "..banner)
file.Write("users/"..user.."/banned/reason.txt", reason)
game.KickID( userban:SteamID(), "Вы временно забанены на нашем сервере, вам осталось подождать: "..time.." секунд. А если интересно, то вас заблокировал "..bannername.." - "..banner..". Причина: "..reason)
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."забанил на время: "..time.." секунд".."\n".."по причине: "..reason.."\n"..user.." - ["..username.."] - ["..file.Read("users/"..user.."/legion/legion.txt", "data").." | "..file.Read("users/"..user.."/name/name.txt", "data").." | "..file.Read("users/"..user.."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user.."/admin/admin.txt", "data") == "user" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
file.Write("users/"..user.."/banned/timerbanned.txt", time2)
local timerbanned = file.Read("users/"..user.."/banned/timerbanned.txt", "data")
file.Write("users/"..user.."/banned/whobanned.txt", bannername.." - "..banner)
file.Write("users/"..user.."/banned/reason.txt", reason)
game.KickID( userban:SteamID(), "Вы временно забанены на нашем сервере, вам осталось подождать: "..time.." секунд. А если интересно, то вас заблокировал "..bannername.." - "..banner..". Причина: "..reason)
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."забанил на время: "..time.." секунд".."\n".."по причине: "..reason.."\n"..user.." - ["..username.."] - ["..file.Read("users/"..user.."/legion/legion.txt", "data").." | "..file.Read("users/"..user.."/name/name.txt", "data").." | "..file.Read("users/"..user.."/number/number.txt", "data").."]".."\n".."------------")
end
end)

util.AddNetworkString("sendtoclientamenus")
util.AddNetworkString("sendtoserveramenus")
net.Receive("sendtoserveramenus", function()
local playeadm = net.ReadEntity()
local function Sentoclientcs()
net.Start('sendtoclientamenus')
net.WriteString(file.Read("users/"..playeadm:SteamID64().."/admin/admin.txt", "data"))
net.Send(playeadm)
end
Sentoclientcs()
end)


util.AddNetworkString("teleporttoplay")
net.Receive("teleporttoplay", function()
local banner = net.ReadString()
local user = net.ReadEntity()
local adminply = net.ReadEntity()
if file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "owner" and file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" then
local targpos = user:GetPos()
adminply:SetPos(targpos)
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..adminply:SteamID64().." - ["..adminply:Name().."] - ["..file.Read("users/"..adminply:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/number/number.txt", "data").."]".."\n".."телепортировался к".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "highadmin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
local targpos = user:GetPos()
adminply:SetPos(targpos)
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..adminply:SteamID64().." - ["..adminply:Name().."] - ["..file.Read("users/"..adminply:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/number/number.txt", "data").."]".."\n".."телепортировался к".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "admin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
local targpos = user:GetPos()
adminply:SetPos(targpos)
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..adminply:SteamID64().." - ["..adminply:Name().."] - ["..file.Read("users/"..adminply:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/number/number.txt", "data").."]".."\n".."телепортировался к".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "commander" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
local targpos = user:GetPos()
adminply:SetPos(targpos)
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..adminply:SteamID64().." - ["..adminply:Name().."] - ["..file.Read("users/"..adminply:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/number/number.txt", "data").."]".."\n".."телепортировался к".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "user" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
local targpos = user:GetPos()
adminply:SetPos(targpos)
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..adminply:SteamID64().." - ["..adminply:Name().."] - ["..file.Read("users/"..adminply:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/number/number.txt", "data").."]".."\n".."телепортировался к".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
end
end)

util.AddNetworkString("bringplay")
net.Receive("bringplay", function()
local banner = net.ReadString()
local user = net.ReadEntity()
local adminply = net.ReadEntity()
if file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "owner" and file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" then
local targpos = adminply:GetPos()
user:SetPos(targpos)
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..adminply:SteamID64().." - ["..adminply:Name().."] - ["..file.Read("users/"..adminply:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/number/number.txt", "data").."]".."\n".."телепортировал к себе".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "highadmin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
local targpos = adminply:GetPos()
user:SetPos(targpos)
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..adminply:SteamID64().." - ["..adminply:Name().."] - ["..file.Read("users/"..adminply:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/number/number.txt", "data").."]".."\n".."телепортировал к себе".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "admin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
local targpos = adminply:GetPos()
user:SetPos(targpos)
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..adminply:SteamID64().." - ["..adminply:Name().."] - ["..file.Read("users/"..adminply:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/number/number.txt", "data").."]".."\n".."телепортировал к себе".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "commander" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
local targpos = adminply:GetPos()
user:SetPos(targpos)
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..adminply:SteamID64().." - ["..adminply:Name().."] - ["..file.Read("users/"..adminply:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/number/number.txt", "data").."]".."\n".."телепортировал к себе".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "user" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
local targpos = adminply:GetPos()
user:SetPos(targpos)
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..adminply:SteamID64().." - ["..adminply:Name().."] - ["..file.Read("users/"..adminply:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/number/number.txt", "data").."]".."\n".."телепортировал к себе".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
end
end)

util.AddNetworkString("strippiaponsgog")
net.Receive("strippiaponsgog", function()
local banner = net.ReadString()
local user = net.ReadEntity()
local adminply = net.ReadEntity()
if file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "owner" and file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" then
user:StripWeapons()
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..adminply:SteamID64().." - ["..adminply:Name().."] - ["..file.Read("users/"..adminply:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/number/number.txt", "data").."]".."\n".."удалил оружия".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "highadmin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
user:StripWeapons()
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..adminply:SteamID64().." - ["..adminply:Name().."] - ["..file.Read("users/"..adminply:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/number/number.txt", "data").."]".."\n".."удалил оружия".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "admin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
user:StripWeapons()
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..adminply:SteamID64().." - ["..adminply:Name().."] - ["..file.Read("users/"..adminply:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/number/number.txt", "data").."]".."\n".."удалил оружия".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "commander" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
user:StripWeapons()
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..adminply:SteamID64().." - ["..adminply:Name().."] - ["..file.Read("users/"..adminply:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/number/number.txt", "data").."]".."\n".."удалил оружия".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "user" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
user:StripWeapons()
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..adminply:SteamID64().." - ["..adminply:Name().."] - ["..file.Read("users/"..adminply:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/number/number.txt", "data").."]".."\n".."удалил оружия".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
end
end)

util.AddNetworkString("spectateplyersd")
net.Receive("spectateplyersd", function()
local banner = net.ReadString()
local user = net.ReadEntity()
local adminply = net.ReadEntity()
if file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "owner" and file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" then
if (file.Read("users/"..user:SteamID64().."/admin/cloak.txt", "data") == "false") then
user:DrawWorldModel( false )
user:SetModel("models/vortigaunt_anims.mdl")
file.Write("users/"..user:SteamID64().."/admin/cloak.txt", "true")
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..adminply:SteamID64().." - ["..adminply:Name().."] - ["..file.Read("users/"..adminply:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/number/number.txt", "data").."]".."\n".."включил слежку".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
else
user:SetModel(file.Read("users/"..user:SteamID64().."/model/model.txt", "data"))
file.Write("users/"..user:SteamID64().."/admin/cloak.txt", "false")
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..adminply:SteamID64().." - ["..adminply:Name().."] - ["..file.Read("users/"..adminply:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/number/number.txt", "data").."]".."\n".."выключил слежку".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
end
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "highadmin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
if (file.Read("users/"..user:SteamID64().."/admin/cloak.txt", "data") == "false") then
user:DrawWorldModel( false )
user:SetModel("models/vortigaunt_anims.mdl")
file.Write("users/"..user:SteamID64().."/admin/cloak.txt", "true")
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..adminply:SteamID64().." - ["..adminply:Name().."] - ["..file.Read("users/"..adminply:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/number/number.txt", "data").."]".."\n".."включил слежку".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
else
user:SetModel(file.Read("users/"..user:SteamID64().."/model/model.txt", "data"))
file.Write("users/"..user:SteamID64().."/admin/cloak.txt", "false")
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..adminply:SteamID64().." - ["..adminply:Name().."] - ["..file.Read("users/"..adminply:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/number/number.txt", "data").."]".."\n".."выключил слежку".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
end
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "admin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
if (file.Read("users/"..user:SteamID64().."/admin/cloak.txt", "data") == "false") then
user:DrawWorldModel( false )
user:SetModel("models/vortigaunt_anims.mdl")
file.Write("users/"..user:SteamID64().."/admin/cloak.txt", "true")
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..adminply:SteamID64().." - ["..adminply:Name().."] - ["..file.Read("users/"..adminply:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/number/number.txt", "data").."]".."\n".."включил слежку".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
else
user:SetModel(file.Read("users/"..user:SteamID64().."/model/model.txt", "data"))
file.Write("users/"..user:SteamID64().."/admin/cloak.txt", "false")
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..adminply:SteamID64().." - ["..adminply:Name().."] - ["..file.Read("users/"..adminply:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/number/number.txt", "data").."]".."\n".."выключил слежку".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
end
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "commander" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
if (file.Read("users/"..user:SteamID64().."/admin/cloak.txt", "data") == "false") then
user:DrawWorldModel( false )
user:SetModel("models/vortigaunt_anims.mdl")
file.Write("users/"..user:SteamID64().."/admin/cloak.txt", "true")
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..adminply:SteamID64().." - ["..adminply:Name().."] - ["..file.Read("users/"..adminply:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/number/number.txt", "data").."]".."\n".."включил слежку".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
else
user:SetModel(file.Read("users/"..user:SteamID64().."/model/model.txt", "data"))
file.Write("users/"..user:SteamID64().."/admin/cloak.txt", "false")
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..adminply:SteamID64().." - ["..adminply:Name().."] - ["..file.Read("users/"..adminply:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/number/number.txt", "data").."]".."\n".."выключил слежку".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
end
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "user" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "admin") then
if (file.Read("users/"..user:SteamID64().."/admin/cloak.txt", "data") == "false") then
user:DrawWorldModel( false )
user:SetModel("models/vortigaunt_anims.mdl")
file.Write("users/"..user:SteamID64().."/admin/cloak.txt", "true")
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..adminply:SteamID64().." - ["..adminply:Name().."] - ["..file.Read("users/"..adminply:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/number/number.txt", "data").."]".."\n".."включил слежку".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
else
user:SetModel(file.Read("users/"..user:SteamID64().."/model/model.txt", "data"))
file.Write("users/"..user:SteamID64().."/admin/cloak.txt", "false")
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..adminply:SteamID64().." - ["..adminply:Name().."] - ["..file.Read("users/"..adminply:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..adminply:SteamID64().."/number/number.txt", "data").."]".."\n".."выключил слежку".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
end
end
end)

util.AddNetworkString("sendtoserveramenuser")
net.Receive("sendtoserveramenuser", function()
local reasons = net.ReadString()
local banner = net.ReadString()
local user = net.ReadEntity()
local bannername = "?"
for i, v in pairs(player.GetAll()) do
        if v:SteamID64() == banner then    
        bannername = v:Name()
        end
end
if file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "owner" and file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" then
file.Write("users/"..user:SteamID64().."/admin/admin.txt", "user")
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."Выдал (ИГРОК) по причине: ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "highadmin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner") then
file.Write("users/"..user:SteamID64().."/admin/admin.txt", "user")
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."Выдал (ИГРОК) по причине: ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "admin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
file.Write("users/"..user:SteamID64().."/admin/admin.txt", "user")
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."Выдал (ИГРОК) по причине: ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "commander" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
file.Write("users/"..user:SteamID64().."/admin/admin.txt", "user")
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."Выдал (ИГРОК) по причине: ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "user" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
file.Write("users/"..user:SteamID64().."/admin/admin.txt", "user")
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."Выдал (ИГРОК) по причине: ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
end
end)

util.AddNetworkString("sendtoserveramencmd")
net.Receive("sendtoserveramencmd", function()
local reasons = net.ReadString()
local banner = net.ReadString()
local user = net.ReadEntity()
local bannername = "?"
for i, v in pairs(player.GetAll()) do
        if v:SteamID64() == banner then    
        bannername = v:Name()
        end
end
if file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "owner" and file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" then
file.Write("users/"..user:SteamID64().."/admin/admin.txt", "commander")
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."Выдал (КОМАНДИР) по причине: ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "highadmin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner") then
file.Write("users/"..user:SteamID64().."/admin/admin.txt", "commander")
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."Выдал (КОМАНДИР) по причине: ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "admin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
file.Write("users/"..user:SteamID64().."/admin/admin.txt", "commander")
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."Выдал (КОМАНДИР) по причине: ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "commander" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
file.Write("users/"..user:SteamID64().."/admin/admin.txt", "commander")
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."Выдал (КОМАНДИР) по причине: ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "user" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
file.Write("users/"..user:SteamID64().."/admin/admin.txt", "commander")
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."Выдал (КОМАНДИР) по причине: ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
end
end)

util.AddNetworkString("sendtoserveramenadmin")
net.Receive("sendtoserveramenadmin", function()
local reasons = net.ReadString()
local banner = net.ReadString()
local user = net.ReadEntity()
local bannername = "?"
for i, v in pairs(player.GetAll()) do
        if v:SteamID64() == banner then    
        bannername = v:Name()
        end
end
if file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "owner" and file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" then
file.Write("users/"..user:SteamID64().."/admin/admin.txt", "admin")
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."Выдал (АДМИН) по причине: ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "highadmin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner") then
file.Write("users/"..user:SteamID64().."/admin/admin.txt", "admin")
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."Выдал (АДМИН) по причине: ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "admin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
file.Write("users/"..user:SteamID64().."/admin/admin.txt", "admin")
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."Выдал (АДМИН) по причине: ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "commander" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
file.Write("users/"..user:SteamID64().."/admin/admin.txt", "admin")
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."Выдал (АДМИН) по причине: ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "user" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" or file.Read("users/"..banner.."/admin/admin.txt", "data") == "highadmin") then
file.Write("users/"..user:SteamID64().."/admin/admin.txt", "admin")
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."Выдал (АДМИН) по причине: ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
end
end)

util.AddNetworkString("sendtoserveramenhighadmin")
net.Receive("sendtoserveramenhighadmin", function()
local reasons = net.ReadString()
local banner = net.ReadString()
local user = net.ReadEntity()
local bannername = "?"
for i, v in pairs(player.GetAll()) do
        if v:SteamID64() == banner then    
        bannername = v:Name()
        end
end
if file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "owner" and file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner" then
file.Write("users/"..user:SteamID64().."/admin/admin.txt", "highadmin")
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."Выдал (СТАРШИЙ АДМИН) по причине: ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "highadmin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner") then
file.Write("users/"..user:SteamID64().."/admin/admin.txt", "highadmin")
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."Выдал (СТАРШИЙ АДМИН) по причине: ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "admin" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner") then
file.Write("users/"..user:SteamID64().."/admin/admin.txt", "highadmin")
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."Выдал (СТАРШИЙ АДМИН) по причине: ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "commander" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner") then
file.Write("users/"..user:SteamID64().."/admin/admin.txt", "highadmin")
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."Выдал (СТАРШИЙ АДМИН) по причине: ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
elseif file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "user" and (file.Read("users/"..banner.."/admin/admin.txt", "data") == "owner") then
file.Write("users/"..user:SteamID64().."/admin/admin.txt", "highadmin")
file.Write("logs/admin/log.txt", "------------".."\n".."["..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").."]".."\n"..banner.." - ["..bannername.."] - ["..file.Read("users/"..banner.."/legion/legion.txt", "data").." | "..file.Read("users/"..banner.."/name/name.txt", "data").." | "..file.Read("users/"..banner.."/number/number.txt", "data").."]".."\n".."Выдал (СТАРШИЙ АДМИН) по причине: ["..reasons.."]".."\n"..user:SteamID64().." - ["..user:Name().."] - ["..file.Read("users/"..user:SteamID64().."/legion/legion.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/name/name.txt", "data").." | "..file.Read("users/"..user:SteamID64().."/number/number.txt", "data").."]".."\n".."------------")
end
end)
