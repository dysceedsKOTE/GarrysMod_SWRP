if CLIENT then return end
hook.Add( "PlayerAuthed", "Abobadolabebasosixuy", function( ply, steamid, uniqueid )
ply:SetNWInt( ply:SteamID64().."headhp", "100" )
ply:SetNWInt( ply:SteamID64().."armlefthp", "100" )
ply:SetNWInt( ply:SteamID64().."armrighthp", "100" )
ply:SetNWInt( ply:SteamID64().."leglefthp", "100" )
ply:SetNWInt( ply:SteamID64().."legrighthp", "100" )
ply:ConCommand("rate 300000")
local banned = file.Read("users/"..ply:SteamID64().."/banned/banned.txt", "data")
local banner = file.Read("users/"..ply:SteamID64().."/banned/whobanned.txt", "data")
local reasons = file.Read("users/"..ply:SteamID64().."/banned/reason.txt", "data")
local timerbanned = (file.Read("users/"..ply:SteamID64().."/banned/timerbanned.txt", "data") + 0)
local timerbanned2 = (timerbanned - os.time())
if banned == "true" then game.KickID( ply:SteamID(), "Поздравляю вы заблокированы на нашем сервере. А если интересно то, вас заблокировал "..banner..". Причина сея бана: "..reasons) end
if (timerbanned > os.time()) then game.KickID( ply:SteamID(), "Вы временно забанены на нашем сервере, вам осталось подождать: "..timerbanned2.." секунд. А если интересно, то вас заблокировал "..banner..". Причина: "..reasons) end
end)

concommand.Add("unban", function( ply, cmd, args )
if ply:IsValid() == false then
file.Write("users/"..args[1].."/banned/banned.txt", "false")
print(args[1].." разбанен!")
end
end)
concommand.Add("ban", function( ply, cmd, args )
if ply:IsValid() == false then
file.Write("users/"..args[1].."/banned/banned.txt", "true")
file.Write("users/"..args[1].."/banned/reason.txt", args[2]..", ай-яй-яй")
file.Write("users/"..args[1].."/banned/whobanned.txt", "CONSOLE")
print(args[1].." забанен! По причине: "..args[2])
end
end)

concommand.Add("admin", function( ply, cmd, args )
if not file.Exists("users/"..args[1], "data") then return PrintMessage(HUD_PRINTTALK, 'Пользователь '..args[1]..' не найден!') end;
if file.Read("users/"..ply:SteamID64().."/admin/admin.txt", "data") == "owner" then
file.Write("users/"..args[1].."/admin/admin.txt", "admin")
PrintMessage(HUD_PRINTTALK, 'Вы успешно дали права АДМИНИСТРАТОРА пользователю '..args[1].." .")
PrintMessage(HUD_PRINTTALK, ply:Name().." ["..ply:SteamID64().."] успешно выдал права АДМИНИСТРАТОРА пользователю "..args[1].." .")
PrintMessage(HUD_PRINTCENTER, ply:Name().." ["..ply:SteamID64().."] успешно выдал права АДМИНИСТРАТОРА пользователю "..args[1].." .")
elseif file.Read("users/"..ply:SteamID64().."/admin/admin.txt", "data") == "highadmin" then
file.Write("users/"..args[1].."/admin/admin.txt", "admin")
PrintMessage(HUD_PRINTTALK, 'Вы успешно дали права АДМИНИСТРАТОРА пользователю '..args[1].." .")
PrintMessage(HUD_PRINTTALK, ply:Name().." ["..ply:SteamID64().."] успешно выдал права АДМИНИСТРАТОРА пользователю "..args[1].." .")
PrintMessage(HUD_PRINTCENTER, ply:Name().." ["..ply:SteamID64().."] успешно выдал права АДМИНИСТРАТОРА пользователю "..args[1].." .")
else ply:ChatPrint("НЕ ДОСТАТОЧНО ПРАВ!") end
end)

concommand.Add("owner", function( ply, cmd, args )
if not file.Exists("users/"..args[1], "data") then return PrintMessage(HUD_PRINTTALK, 'Пользователь '..args[1]..' не найден!') end;
if file.Read("users/"..ply:SteamID64().."/admin/admin.txt", "data") == "owner" then
file.Write("users/"..args[1].."/admin/admin.txt", "owner")
PrintMessage(HUD_PRINTTALK, 'Вы успешно дали права ВЛАДЕЛЬЦА пользователю '..args[1].." .")
PrintMessage(HUD_PRINTTALK, ply:Name().." ["..ply:SteamID64().."] успешно выдал права ВЛАДЕЛЬЦА пользователю "..args[1].." .")
PrintMessage(HUD_PRINTCENTER, ply:Name().." ["..ply:SteamID64().."] успешно выдал права ВЛАДЕЛЬЦА пользователю "..args[1].." .")
else ply:ChatPrint("НЕ ДОСТАТОЧНО ПРАВ!") end
end)

concommand.Add("commander", function( ply, cmd, args )
if not file.Exists("users/"..args[1], "data") then return PrintMessage(HUD_PRINTTALK, 'Пользователь '..args[1]..' не найден!') end;
if file.Read("users/"..ply:SteamID64().."/admin/admin.txt", "data") == "owner" then
file.Write("users/"..args[1].."/admin/admin.txt", "commander")
PrintMessage(HUD_PRINTTALK, 'Вы успешно дали права КОМАНДУЮЩЕГО пользователю '..args[1].." .")
PrintMessage(HUD_PRINTTALK, ply:Name().." ["..ply:SteamID64().."] успешно выдал права КОМАНДУЮЩЕГО пользователю "..args[1].." .")
PrintMessage(HUD_PRINTCENTER, ply:Name().." ["..ply:SteamID64().."] успешно выдал права КОМАНДУЮЩЕГО пользователю "..args[1].." .")
elseif file.Read("users/"..ply:SteamID64().."/admin/admin.txt", "data") == "highadmin" then
file.Write("users/"..args[1].."/admin/admin.txt", "commander")
PrintMessage(HUD_PRINTTALK, 'Вы успешно дали права КОМАНДУЮЩЕГО пользователю '..args[1].." .")
PrintMessage(HUD_PRINTTALK, ply:Name().." ["..ply:SteamID64().."] успешно выдал права КОМАНДУЮЩЕГО пользователю "..args[1].." .")
PrintMessage(HUD_PRINTCENTER, ply:Name().." ["..ply:SteamID64().."] успешно выдал права КОМАНДУЮЩЕГО пользователю "..args[1].." .")
else ply:ChatPrint("НЕ ДОСТАТОЧНО ПРАВ!") end
end)

concommand.Add("highadmin", function( ply, cmd, args )
if not file.Exists("users/"..args[1], "data") then return PrintMessage(HUD_PRINTTALK, 'Пользователь '..args[1]..' не найден!') end;
if file.Read("users/"..ply:SteamID64().."/admin/admin.txt", "data") == "owner" then
file.Write("users/"..args[1].."/admin/admin.txt", "highadmin")
PrintMessage(HUD_PRINTTALK, 'Вы успешно дали права СТРАШЕГО АДМИНИСТРАТОРА пользователю '..args[1].." .")
PrintMessage(HUD_PRINTTALK, ply:Name().." ["..ply:SteamID64().."] успешно выдал права СТРАШЕГО АДМИНИСТРАТОРА пользователю "..args[1].." .")
PrintMessage(HUD_PRINTCENTER, ply:Name().." ["..ply:SteamID64().."] успешно выдал права СТРАШЕГО АДМИНИСТРАТОРА пользователю "..args[1].." .")
else ply:ChatPrint("НЕ ДОСТАТОЧНО ПРАВ!") end
end)

util.AddNetworkString("sendtoclient")
util.AddNetworkString("sendtoserver")

net.Receive("sendtoserver", function()

local playeadm = net.ReadEntity()
local caller = net.ReadEntity()
local function Sentoclient()
net.Start('sendtoclient')
net.WriteString(file.Read("users/"..playeadm:SteamID64().."/admin/admin.txt", "data"))
net.WriteString(file.Read("users/"..playeadm:SteamID64().."/warns/warns.txt", "data"))
net.WriteEntity(playeadm)
net.Send(caller)
end

Sentoclient()
end)

util.AddNetworkString("pladminka2")
util.AddNetworkString("pladminkaserv2")
net.Receive("pladminkaserv2", function()
local playeadm = net.ReadString()
local keksik = net.ReadEntity()
local function SCRList2()
net.Start('pladminka2')
net.WriteString(file.Read("users/"..playeadm.."/admin/admin.txt", "data"))
net.Send(keksik)
end
SCRList2()
end)

util.AddNetworkString("MDLserversend")
net.Receive("MDLserversend", function()
local user = net.ReadEntity()
	if not file.Exists("users/"..user:SteamID64(), "data") then
	file.CreateDir("users/"..user:SteamID64().."/model")
	file.Write("users/"..user:SteamID64().."/model/model.txt", "models/aussiwozzi/phase1clones/sergeant.mdl")

	file.CreateDir("users/"..user:SteamID64().."/bodygroups")
	file.Write("users/"..user:SteamID64().."/bodygroups/bodygroups.txt", "000000")

	file.CreateDir("users/"..user:SteamID64().."/skin")
	file.Write("users/"..user:SteamID64().."/skin/skin.txt", "0")

	file.CreateDir("users/"..user:SteamID64().."/size")
	file.Write("users/"..user:SteamID64().."/size/size.txt", "1")

	file.CreateDir("users/"..user:SteamID64().."/rank")
	file.Write("users/"..user:SteamID64().."/rank/rank.txt", "РКТ")

	file.CreateDir("users/"..user:SteamID64().."/spec")
	file.Write("users/"..user:SteamID64().."/spec/spec.txt", "НЕ СПЕЦИАЛИСТ")

	file.CreateDir("users/"..user:SteamID64().."/name")
    file.Write("users/"..user:SteamID64().."/name/name.txt", "ГАММА")

	file.CreateDir("users/"..user:SteamID64().."/number")
	file.Write("users/"..user:SteamID64().."/number/number.txt", math.random( 1000, 9999 ))

	file.CreateDir("users/"..user:SteamID64().."/legion")
	file.Write("users/"..user:SteamID64().."/legion/legion.txt", "СК")

	file.CreateDir("users/"..user:SteamID64().."/health")
	file.Write("users/"..user:SteamID64().."/health/health.txt", "150")

	file.CreateDir("users/"..user:SteamID64().."/armor")
	file.Write("users/"..user:SteamID64().."/armor/armor.txt", "200")

	file.CreateDir("users/"..user:SteamID64().."/speed")
	file.Write("users/"..user:SteamID64().."/speed/speed.txt", "1")

	file.CreateDir("users/"..user:SteamID64().."/grav")
	file.Write("users/"..user:SteamID64().."/grav/grav.txt", "1")

	file.CreateDir("users/"..user:SteamID64().."/admin")
	file.Write("users/"..user:SteamID64().."/admin/admin.txt", "user")
	file.Write("users/"..user:SteamID64().."/admin/frozen.txt", "false")
	file.Write("users/"..user:SteamID64().."/admin/cloak.txt", "false")

	file.CreateDir("users/"..user:SteamID64().."/warns")
	file.Write("users/"..user:SteamID64().."/warns/warns.txt", "0")

	file.CreateDir("users/"..user:SteamID64().."/weaponfirst")
	file.Write("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "arms")

	file.CreateDir("users/"..user:SteamID64().."/weaponsecond")
	file.Write("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "arms")

	file.CreateDir("users/"..user:SteamID64().."/weapongrenade")
	file.Write("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "arms")

	file.CreateDir("users/"..user:SteamID64().."/weapongrenade2")
	file.Write("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "arms")

	file.CreateDir("users/"..user:SteamID64().."/weaponknife")
	file.Write("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "arms")

	file.CreateDir("users/"..user:SteamID64().."/utiles")
    file.Write("users/"..user:SteamID64().."/utiles/utiles.txt", "arms")

	file.CreateDir("users/"..user:SteamID64().."/utiles2")
    file.Write("users/"..user:SteamID64().."/utiles2/utiles2.txt", "arms")

    file.CreateDir("users/"..user:SteamID64().."/entity")
    file.Write("users/"..user:SteamID64().."/entity/entity.txt", "null")
    
	file.CreateDir("users/"..user:SteamID64().."/money")
    file.Write("users/"..user:SteamID64().."/money/money.txt", "0")
    file.Write("users/"..user:SteamID64().."/money/moneyboost.txt", "1")
    file.Write("users/"..user:SteamID64().."/money/points.txt", "0")

	file.CreateDir("users/"..user:SteamID64().."/level")
    file.Write("users/"..user:SteamID64().."/level/level.txt", "0")
    file.Write("users/"..user:SteamID64().."/level/xp.txt", "0")
    file.Write("users/"..user:SteamID64().."/level/booster.txt", "1")
    file.Write("users/"..user:SteamID64().."/level/hpboost.txt", "1")
    file.Write("users/"..user:SteamID64().."/level/armorboost.txt", "1")
    file.Write("users/"..user:SteamID64().."/level/statminaboost.txt", "1")
    file.Write("users/"..user:SteamID64().."/level/ammoboost.txt", "1")
    file.Write("users/"..user:SteamID64().."/level/granboost.txt", "0")
    file.Write("users/"..user:SteamID64().."/level/speedboost.txt", "1")

	file.CreateDir("users/"..user:SteamID64().."/radio")
    file.Write("users/"..user:SteamID64().."/radio/radio.txt", "null")
    file.Write("users/"..user:SteamID64().."/radio/intercom.txt", "false")
    file.Write("users/"..user:SteamID64().."/radio/interdist.txt", "0")
    file.Write("users/"..user:SteamID64().."/radio/radioon.txt", "null")

	file.CreateDir("users/"..user:SteamID64().."/banned")
    file.Write("users/"..user:SteamID64().."/banned/banned.txt", "false")
    file.Write("users/"..user:SteamID64().."/banned/timerbanned.txt", "null")
    file.Write("users/"..user:SteamID64().."/banned/whobanned.txt", "none")
    file.Write("users/"..user:SteamID64().."/banned/reason.txt", "none")
end
user:SetModel(file.Read("users/"..user:SteamID64().."/model/model.txt", "data"))
timer.Create( user:SteamID64().."firstscalehaha", 1, 2, function()
user:SetModelScale( file.Read("users/"..user:SteamID64().."/size/size.txt", "data"), 1 )
user:SetViewOffset( Vector( 0, 0, 64 ) * Vector( 0, 0, file.Read("users/"..user:SteamID64().."/size/size.txt", "data") ) )
user:SetViewOffsetDucked(Vector( 0, 0, 28 ) * Vector( 0, 0, file.Read("users/"..user:SteamID64().."/size/size.txt", "data") ))
end)
end)

hook.Add("PlayerDisconnected", "discordcount", function( ply, steamid, uniqueid )
if string.Split( game.GetIPAddress(), ":" )[1]..":27015" == game.GetIPAddress() then
file.Write("logs/playercount/count.txt", player.GetCount() - 1)
end
end)

hook.Add("PlayerConnect", "discordcount2", function( ply, steamid, uniqueid )
if string.Split( game.GetIPAddress(), ":" )[1]..":27015" == game.GetIPAddress() then
file.Write("logs/playercount/count.txt", player.GetCount() + 1)
end
end)

util.AddNetworkString("rankcontextserver")
util.AddNetworkString("rankcontextclient")
net.Receive("rankcontextserver", function()
local playerd = net.ReadEntity()
local pladmin = file.Read("users/"..playerd:SteamID64().."/admin/admin.txt", "data")
local function ranksendserv()
net.Start('rankcontextclient')   
net.WriteString(pladmin)
net.Send(playerd)
end
ranksendserv()
end)

util.AddNetworkString("rankcontextserver2")
util.AddNetworkString("rankcontextclient2")
net.Receive("rankcontextserver2", function()
local playerd = net.ReadEntity()
local pladmin = file.Read("users/"..playerd:SteamID64().."/admin/admin.txt", "data")
local function ranksendserv()
net.Start('rankcontextclient2')   
net.WriteString(pladmin)
net.Send(playerd)
end
ranksendserv()
end)

util.AddNetworkString("rankcontextserver3")
util.AddNetworkString("rankcontextclient3")
net.Receive("rankcontextserver3", function()
local playerd = net.ReadEntity()
local pladmin = file.Read("users/"..playerd:SteamID64().."/admin/admin.txt", "data")
local function ranksendserv()
net.Start('rankcontextclient3')   
net.WriteString(pladmin)
net.Send(playerd)
end
ranksendserv()
end)

util.AddNetworkString("rankcontextserver4")
util.AddNetworkString("rankcontextclient4")
net.Receive("rankcontextserver4", function()
local playerd = net.ReadEntity()
local pladmin = file.Read("users/"..playerd:SteamID64().."/admin/admin.txt", "data")
local function ranksendserv()
net.Start('rankcontextclient4')   
net.WriteString(pladmin)
net.Send(playerd)
end
ranksendserv()
end)