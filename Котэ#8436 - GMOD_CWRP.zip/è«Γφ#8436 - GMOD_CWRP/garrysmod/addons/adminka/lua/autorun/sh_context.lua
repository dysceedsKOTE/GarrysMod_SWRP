if SERVER then return end
properties.Add( "whitelist", {
	MenuLabel = "Вайтлист",
	Order = 597,
	MenuIcon = "icon16/link_edit.png",

	Filter = function( self, ent, ply )

		if ( !IsValid( ent ) ) then return false end
		if ( !ent:IsPlayer() ) then return false end
		if ( IsValid( ent.AttachedEntity ) ) then ent = ent.AttachedEntity end  -- If our ent has an attached entity, we want to use and modify its bodygroups instead

		--
		-- Get a list of bodygroups
		--

		--
		-- If a bodygroup has more than one state - then we can configure it
		--
		return true

	end,

	MenuOpen = function( self, option, pl, tr )
local function ranksendserv()
net.Start('rankcontextserver')   
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
ranksendserv()
net.Receive("rankcontextclient", function()
local pladmin = net.ReadString()
if pladmin == "user" then return end
		--
local sub_commands2 = option:AddSubMenu()
local sub_commands21 = sub_commands2:AddSubMenu("Солдатский корпус")

		sub_commands21:AddOption("Клон солдат", function()
local function tpplysssssdddd()
    net.Start('Clone_CT_S')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

sub_commands21:AddOption("Клон офицер", function()
local function tpplysssssdddd()
    net.Start('Clone_CT_O')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

sub_commands21:AddOption("Клон старший офицер", function()
local function tpplysssssdddd()
    net.Start('Clone_CT_HO')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

sub_commands21:AddOption("Клон командир", function()
local function tpplysssssdddd()
    net.Start('Clone_CT_CC')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

                local sub_commands22 = sub_commands2:AddSubMenu("501-ый легион")

sub_commands22:AddOption("Клон солдат", function()
local function tpplysssssdddd()
    net.Start('Clone_501_S')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

sub_commands22:AddOption("Клон офицер", function()
local function tpplysssssdddd()
    net.Start('Clone_501_O')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

sub_commands22:AddOption("Клон старший офицер", function()
local function tpplysssssdddd()
    net.Start('Clone_501_HO')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

sub_commands22:AddOption("Клон командир", function()
local function tpplysssssdddd()
    net.Start('Clone_501_CC')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

                local sub_commands23 = sub_commands2:AddSubMenu("574-ый корпус")

sub_commands23:AddOption("Клон солдат", function()
local function tpplysssssdddd()
    net.Start('Clone_104_S')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

sub_commands23:AddOption("Клон офицер", function()
local function tpplysssssdddd()
    net.Start('Clone_104_O')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

sub_commands23:AddOption("Клон старший офицер", function()
local function tpplysssssdddd()
    net.Start('Clone_104_HO')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

sub_commands23:AddOption("Клон командир", function()
local function tpplysssssdddd()
    net.Start('Clone_104_CC')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

                local sub_commands24 = sub_commands2:AddSubMenu("41-ый корпус")

sub_commands24:AddOption("Клон солдат", function()
local function tpplysssssdddd()
    net.Start('Clone_91_S')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

sub_commands24:AddOption("Клон офицер", function()
local function tpplysssssdddd()
    net.Start('Clone_91_O')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

sub_commands24:AddOption("Клон старший офицер", function()
local function tpplysssssdddd()
    net.Start('Clone_91_HO')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

sub_commands24:AddOption("Клон командир", function()
local function tpplysssssdddd()
    net.Start('Clone_91_CC')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)                

                local sub_commands25 = sub_commands2:AddSubMenu("Гвардейский корпус")

sub_commands25:AddOption("Клон солдат", function()
local function tpplysssssdddd()
    net.Start('Clone_GUARD_S')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

sub_commands25:AddOption("Клон офицер", function()
local function tpplysssssdddd()
    net.Start('Clone_GUARD_O')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

sub_commands25:AddOption("Клон старший офицер", function()
local function tpplysssssdddd()
    net.Start('Clone_GUARD_HO')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

sub_commands25:AddOption("Клон командир", function()
local function tpplysssssdddd()
    net.Start('Clone_GUARD_CC')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

                local sub_commands26 = sub_commands2:AddSubMenu("Флот")

sub_commands26:AddOption("Матрос", function()
local function tpplysssssdddd()
    net.Start('Clone_FLEET_S')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

sub_commands26:AddOption("Офицер", function()
local function tpplysssssdddd()
    net.Start('Clone_FLEET_O')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

sub_commands26:AddOption("Старший офицер", function()
local function tpplysssssdddd()
    net.Start('Clone_FLEET_HO')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

sub_commands26:AddOption("Командир", function()
local function tpplysssssdddd()
    net.Start('Clone_FLEET_XO')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

sub_commands26:AddOption("Адмирал", function()
local function tpplysssssdddd()
    net.Start('Clone_FLEET_CC')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

                local sub_commands27 = sub_commands2:AddSubMenu("ЭРК")

sub_commands27:AddOption("Клон ARC", function()
local function tpplysssssdddd()
    net.Start('Clone_ARC_S')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

sub_commands27:AddOption("Клон комадир ARC", function()
local function tpplysssssdddd()
    net.Start('Clone_ARC_CC')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

sub_commands27:AddOption("ARC Alpha 77", function()
local function tpplysssssdddd()
    net.Start('Clone_ARC_A77')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

sub_commands27:AddOption("ARC Муунилинст-10", function()
local function tpplysssssdddd()
    net.Start('Clone_ARC_A77L')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

                local sub_commands28 = sub_commands2:AddSubMenu("Донат")

sub_commands28:AddOption("Республиканский коммандос", function()
local function tpplysssssdddd()
    net.Start('Clone_RC_STANDART')
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
end
tpplysssssdddd()
end)

sub_commands2:AddOption("Сбросить всё", function()
local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Сброс персонажа "..pl:Name().." ("..pl:SteamID64()..")")
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите причину и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function wlreloadallc()
    net.Start('wlreloadchars')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    wlreloadallc()
end
end)

end)
	end,

	Action = function( self, ent )

		-- Nothing - we use SetBodyGroup below

	end,

} )

properties.Add( "tonkwhitelist", {
	MenuLabel = "Тонкий вайтлист",
	Order = 598,
	MenuIcon = "icon16/link_edit.png",

    Filter = function( self, ent, ply )

        if ( !IsValid( ent ) ) then return false end
        if ( !ent:IsPlayer() ) then return false end
        if ( IsValid( ent.AttachedEntity ) ) then ent = ent.AttachedEntity end  -- If our ent has an attached entity, we want to use and modify its bodygroups instead

        --
        -- Get a list of bodygroups
        --

        --
        -- If a bodygroup has more than one state - then we can configure it
        --
        return true

    end,

	MenuOpen = function( self, option, pl, tr )
local function ranksendserv()
net.Start('rankcontextserver2')   
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
ranksendserv()
net.Receive("rankcontextclient2", function()
local pladmin = net.ReadString()
if pladmin == "user" then return end
		--
local sub_commands3 = option:AddSubMenu()
local sub_commands31 = sub_commands3:AddSubMenu("Ранги и положения")

sub_commands31:AddOption("Установить позывной WL", function()
local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Позывной "..pl:Name().." ("..pl:SteamID64()..")")
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите позывной и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function tonkiywl()
    net.Start('wlistpoziv')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    tonkiywl()
end
end)

sub_commands31:AddOption("Установить IDN WL", function()
local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("IDN "..pl:Name().." ("..pl:SteamID64()..")")
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите IDN и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function tonkiywl()
    net.Start('wlistnum')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    tonkiywl()
end
end)

sub_commands31:AddOption("Установить легион WL", function()
local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Легион "..pl:Name().." ("..pl:SteamID64()..")")
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите легион и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function tonkiywl()
    net.Start('wlistlegion')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    tonkiywl()
end
end)

sub_commands31:AddOption("Установить звание WL", function()
local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Звание "..pl:Name().." ("..pl:SteamID64()..")")
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите звание и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function tonkiywl()
    net.Start('wlrank')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    tonkiywl()
end
end)

sub_commands31:AddOption("Установить специализацию WL", function()
local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Специализация "..pl:Name().." ("..pl:SteamID64()..")")
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите специализацию и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function tonkiywl()
    net.Start('wlspec')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    tonkiywl()
end
end)


local sub_commands32 = sub_commands3:AddSubMenu("Внешний вид") 

sub_commands32:AddOption("Установить модель WL", function()
local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Модель "..pl:Name().." ("..pl:SteamID64()..")")
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите путь к модели и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function tonkiywl()
    net.Start('wlistmodel')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    tonkiywl()
end
end)

sub_commands32:AddOption("Установить БГ WL", function()
local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Бодигруппы "..pl:Name().." ("..pl:SteamID64()..")")
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите (000000) и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function tonkiywl()
    net.Start('wlistbodygroups')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    tonkiywl()
end
end)

sub_commands32:AddOption("Установить скин WL", function()
local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Скин "..pl:Name().." ("..pl:SteamID64()..")")
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите (0) и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function tonkiywl()
    net.Start('wlistskinsesd')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    tonkiywl()
end
end)

sub_commands32:AddOption("Установить размер WL", function()
local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Размер "..pl:Name().." ("..pl:SteamID64()..")")
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите множитель и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function tonkiywl()
    net.Start('wlistsize')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    tonkiywl()
end
end)


local sub_commands33 = sub_commands3:AddSubMenu("Вооружение")

sub_commands33:AddOption("Основное оружие WL", function()
local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Основное оружие "..pl:Name().." ("..pl:SteamID64()..")")
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите класс оружия и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function tonkiywl()
    net.Start('wlfirweap')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    tonkiywl()
end
end)

sub_commands33:AddOption("Вторичное оружие WL", function()
local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Вторичное оружие "..pl:Name().." ("..pl:SteamID64()..")")
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите класс оружия и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function tonkiywl()
    net.Start('wlsecweap')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    tonkiywl()
end
end)

sub_commands33:AddOption("Основная граната WL", function()
local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Основная граната "..pl:Name().." ("..pl:SteamID64()..")")
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите класс гранаты и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function tonkiywl()
    net.Start('wlfirgren')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    tonkiywl()
end
end)

sub_commands33:AddOption("Вторичная граната WL", function()
local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Вторичная граната "..pl:Name().." ("..pl:SteamID64()..")")
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите класс гранаты и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function tonkiywl()
    net.Start('wlsecgren')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    tonkiywl()
end
end)

sub_commands33:AddOption("Холодное оружие WL", function()
local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Холодное оружие "..pl:Name().." ("..pl:SteamID64()..")")
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите класс оружия и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function tonkiywl()
    net.Start('wlknife')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    tonkiywl()
end
end)

sub_commands33:AddOption("Запасной слот WL", function()
local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Запасной слот "..pl:Name().." ("..pl:SteamID64()..")")
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите класс оружия и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function tonkiywl()
    net.Start('wlutil')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    tonkiywl()
end
end)

sub_commands33:AddOption("Запасной слот №2 WL", function()
local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Запасной слот №2 "..pl:Name().." ("..pl:SteamID64()..")")
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите класс оружия и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function tonkiywl()
    net.Start('wlutil2')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    tonkiywl()
end
end)

sub_commands33:AddOption("Энтити WL", function()
local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Энтити "..pl:Name().." ("..pl:SteamID64()..")")
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите класс энтити и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function tonkiywl()
    net.Start('wlent')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    tonkiywl()
end
end)


local sub_commands34 = sub_commands3:AddSubMenu("Другие параметры")

sub_commands34:AddOption("Здоровье WL", function()
local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Здоровье "..pl:Name().." ("..pl:SteamID64()..")")
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите кол-во и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function tonkiywl()
    net.Start('wlhealths')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    tonkiywl()
end
end)

sub_commands34:AddOption("Броня WL", function()
local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Броня "..pl:Name().." ("..pl:SteamID64()..")")
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите кол-во и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function tonkiywl()
    net.Start('wlarmorhs')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    tonkiywl()
end
end)

sub_commands34:AddOption("Скорость WL", function()
local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Скорость "..pl:Name().." ("..pl:SteamID64()..")")
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите множитель и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function tonkiywl()
    net.Start('wlspeed')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    tonkiywl()
end
end)

sub_commands34:AddOption("Гравитация WL", function()
local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Гравитация "..pl:Name().." ("..pl:SteamID64()..")")
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите множитель и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function tonkiywl()
    net.Start('wlgrav')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    tonkiywl()
end
end)

end)
	end,

	Action = function( self, ent )

		-- Nothing - we use SetBodyGroup below

	end,

} )

properties.Add( "admincontmenu", {
	MenuLabel = "Администрирование",
	Order = 599,
	MenuIcon = "icon16/link_edit.png",

    Filter = function( self, ent, ply )

        if ( !IsValid( ent ) ) then return false end
        if ( !ent:IsPlayer() ) then return false end
        if ( IsValid( ent.AttachedEntity ) ) then ent = ent.AttachedEntity end  -- If our ent has an attached entity, we want to use and modify its bodygroups instead

        --
        -- Get a list of bodygroups
        --

        --
        -- If a bodygroup has more than one state - then we can configure it
        --
        return true

    end,

	MenuOpen = function( self, option, pl, tr )
local function ranksendserv()
net.Start('rankcontextserver3')   
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
ranksendserv()
net.Receive("rankcontextclient3", function()
local pladmin = net.ReadString()
if pladmin == "user" or pladmin == "commander" then return end
		--
local sub_commands = option:AddSubMenu()
                ---
sub_commands:AddOption("К игроку", function()
local function tpplysssssdddd()
net.Start('teleporttoplay')  
net.WriteString(LocalPlayer():SteamID64())
net.WriteEntity(pl)
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
tpplysssssdddd()
end)

sub_commands:AddOption("К себе", function()
   local function bringusply()
    net.Start('bringplay')  
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.WriteEntity(LocalPlayer())
    net.SendToServer()
    end
    bringusply()
end)

sub_commands:AddOption("Убрать оружия", function()
   local function strippiaponsgog()
    net.Start('strippiaponsgog')  
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.WriteEntity(LocalPlayer())
    net.SendToServer()
    end
    strippiaponsgog()
end)

sub_commands:AddOption("Кикнуть", function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Кикнуть игрока "..pl:Name())
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Ввидите причину и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function sendservamen()
    net.Start('sendtoserveramenu')  
    net.WriteString(self:GetValue())
    net.WriteString(pl:SteamID())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteString(pl:SteamID64())
    net.SendToServer()
    end
    sendservamen()
    end
end)

if (pladmin == "owner" or pladmin == "highadmin") then
sub_commands:AddOption("Пермабан", function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Забанить игрока "..pl:Name())
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Ввидите причину и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function sendservamenban()
    net.Start('sendtoserveramenuban')   
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteString(LocalPlayer():Name())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    sendservamenban()
    end
end)
end

sub_commands:AddOption("Выговоры", function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Выговоры "..pl:Name())
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Выдать выговор по причине (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function warncipkasend()
    net.Start('warncipka')
    net.WriteString(pl:SteamID64()) 
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteString(LocalPlayer():Name())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    warncipkasend()
end
    local TextEntryPH2 = vgui.Create( "DTextEntry", Krame )
    TextEntryPH2:Dock( TOP )
    TextEntryPH2:DockMargin( 0, 5, 0, 0 )
    TextEntryPH2:SetPlaceholderText( "Снять выговор по причине (ENTER)" )
    TextEntryPH2.OnEnter = function( self )
    local function warncipkaremove()
    net.Start('warncipkar')
    net.WriteString(pl:SteamID64()) 
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.SendToServer()
    end
    warncipkaremove()
    end
end)

sub_commands:AddOption("Размер модели", function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Размер модели "..pl:Name())
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите размер и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function sendservamenmodel()
    net.Start('sendtoserveramenmodel')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    sendservamenmodel()
    end
end)

sub_commands:AddOption("Выдать армора", function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Броник для "..pl:Name())
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите кол-во и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function sendservamenarmor()
    net.Start('sendtoserveramenarmoer')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    sendservamenarmor()
    end
end)

sub_commands:AddOption("Выдать хэлсов", function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Броник для "..pl:Name())
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите кол-во и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function sendservamenheals()
    net.Start('sendtoserveramenheels')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    sendservamenheals()
    end
end)

sub_commands:AddOption("Выдать скорость", function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Скорость "..pl:Name())
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "(1-стандарт) Введите и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function sendservamenspee()
    net.Start('sendtoserveramenspeed')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    sendservamenspee()
    end
end)

sub_commands:AddOption("Установить гравитацию", function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Гравитация "..pl:Name())
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "(1-стандарт) Введите и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function sendservamengra()
    net.Start('sendtoserveramengrav')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    sendservamengra()
    end
end)

sub_commands:AddOption("Установить модель", function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Модель "..pl:Name())
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите путь к модели и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function sendservamenmodel()
    net.Start('sendtoserveramenmodl')  
    net.WriteString(self:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    sendservamenmodel()
    end
end)

sub_commands:AddOption("Заморозить/Разморозить", function()
   local function sendservamenfre()
    net.Start('sendtoserveramenfreez')  
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
    sendservamenfre()
end)

sub_commands:AddOption("Слежка", function()
   local function sendservamenspec()
    net.Start('spectateplyersd')  
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.WriteEntity(LocalPlayer())
    net.SendToServer()
    end
    sendservamenspec()
end)

sub_commands:AddOption("Бан на время", function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Бан на время "..pl:Name())
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите причину" )
    local TextEntryPH2 = vgui.Create( "DTextEntry", Krame )
    TextEntryPH2:Dock( TOP )
    TextEntryPH2:DockMargin( 0, 5, 0, 0 )
    TextEntryPH2:SetPlaceholderText( "Введите время в минутах" )
    local DermaButton = vgui.Create( "DButton", Krame ) 
    DermaButton:SetText( "Выдать наказание" )                   
    DermaButton:SetPos( 67, 100 )                   
    DermaButton:SetSize( 250, 30 )  
    DermaButton.DoClick = function()    
    local function sendservamentimerba()
    net.Start('sendtoserveramentimerban')
    net.WriteString(pl:SteamID64()) 
    net.WriteString(TextEntryPH:GetValue())
    net.WriteString(TextEntryPH2:GetInt())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteString(LocalPlayer():Name())
    net.WriteEntity(pl)
    net.SendToServer()
    end
   sendservamentimerba()
end
end)

end)
	end,

	Action = function( self, ent )

		-- Nothing - we use SetBodyGroup below

	end,

} )

properties.Add( "admincontmenurank", {
	MenuLabel = "Выдача рангов",
	Order = 600,
	MenuIcon = "icon16/link_edit.png",

    Filter = function( self, ent, ply )

        if ( !IsValid( ent ) ) then return false end
        if ( !ent:IsPlayer() ) then return false end
        if ( IsValid( ent.AttachedEntity ) ) then ent = ent.AttachedEntity end  -- If our ent has an attached entity, we want to use and modify its bodygroups instead

        --
        -- Get a list of bodygroups
        --

        --
        -- If a bodygroup has more than one state - then we can configure it
        --
        return true

    end,

	MenuOpen = function( self, option, pl, tr )

local function ranksendserv()
net.Start('rankcontextserver4')   
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
ranksendserv()
net.Receive("rankcontextclient4", function()
local pladmin = net.ReadString()
if pladmin == "user" or pladmin == "commander" or pladmin == "admin" then return end

local sub_commandsik234 = option:AddSubMenu()

sub_commandsik234:AddOption("Ранг (игрок)", function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Ранг (игрок) "..pl:Name())
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите причину" )
    local DermaButton = vgui.Create( "DButton", Krame ) 
    DermaButton:SetText( "Выдать ранг" )                   
    DermaButton:SetPos( 67, 100 )                   
    DermaButton:SetSize( 250, 30 )  
    DermaButton.DoClick = function()    
    local function sendservamentimerba()
    net.Start('sendtoserveramenuser')
    net.WriteString(TextEntryPH:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
   sendservamentimerba()
end
end)

sub_commandsik234:AddOption("Ранг (командир)", function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Ранг (командир) "..pl:Name())
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите причину" )
    local DermaButton = vgui.Create( "DButton", Krame ) 
    DermaButton:SetText( "Выдать ранг" )                   
    DermaButton:SetPos( 67, 100 )                   
    DermaButton:SetSize( 250, 30 )  
    DermaButton.DoClick = function()    
    local function sendservamentimerba()
    net.Start('sendtoserveramencmd')
    net.WriteString(TextEntryPH:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
   sendservamentimerba()
end
end)

sub_commandsik234:AddOption("Ранг (админ)", function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Ранг (админ) "..pl:Name())
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите причину" )
    local DermaButton = vgui.Create( "DButton", Krame ) 
    DermaButton:SetText( "Выдать ранг" )                   
    DermaButton:SetPos( 67, 100 )                   
    DermaButton:SetSize( 250, 30 )  
    DermaButton.DoClick = function()    
    local function sendservamentimerba()
    net.Start('sendtoserveramenadmin')
    net.WriteString(TextEntryPH:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
   sendservamentimerba()
end
end)

sub_commandsik234:AddOption("Ранг (старший админ)", function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Ранг (старший админ) "..pl:Name())
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите причину" )
    local DermaButton = vgui.Create( "DButton", Krame ) 
    DermaButton:SetText( "Выдать ранг" )                   
    DermaButton:SetPos( 67, 100 )                   
    DermaButton:SetSize( 250, 30 )  
    DermaButton.DoClick = function()    
    local function sendservamentimerba()
    net.Start('sendtoserveramenhighadmin')
    net.WriteString(TextEntryPH:GetValue())
    net.WriteString(LocalPlayer():SteamID64())
    net.WriteEntity(pl)
    net.SendToServer()
    end
   sendservamentimerba()
end
end)

end)
	end,

	Action = function( self, ent )

		-- Nothing - we use SetBodyGroup below

	end,

} )