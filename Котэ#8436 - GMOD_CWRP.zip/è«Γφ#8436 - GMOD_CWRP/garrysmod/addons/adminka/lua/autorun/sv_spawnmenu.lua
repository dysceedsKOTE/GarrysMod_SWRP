hook.Add( "SpawnMenuOpen", "SpawnMenuWhitelist", function()
local function pladminsendserv()
local playadm = LocalPlayer():SteamID64()
net.Start('pladminkaserv2')   
net.WriteString(playadm)
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
pladminsendserv()
return false
end )

net.Receive("pladminka2", function()
local pladmin = net.ReadString()
hook.Add( "SpawnMenuOpen", "SpawnMenuWhitelist", function()
if ( pladmin == "owner" or pladmin == "highadmin" or pladmin == "admin" or pladmin == "commander" ) then
return true
else return false
end
end)
end)

hook.Add( "PlayerNoClip", "FeelFreeToTurnItOff", function( ply, desiredState )
pladmin = file.Read("users/"..ply:SteamID64().."/admin/admin.txt", "data")
if ( pladmin == "owner" or pladmin == "highadmin" or pladmin == "admin" or pladmin == "commander" ) then
	if ( desiredState == false ) then -- the player wants to turn noclip off
		return true
	else
		return true
	end
else return false, false
end
end)