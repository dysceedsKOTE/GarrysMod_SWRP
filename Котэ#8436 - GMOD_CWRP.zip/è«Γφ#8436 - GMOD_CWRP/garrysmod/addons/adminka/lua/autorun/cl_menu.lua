hook.Add( "PlayerButtonDown", "Admin_F4menu", function( ply, button )
if ( IsFirstTimePredicted() ) then
if button == 95 then

	local function sendservamens()
    local playeadm = ply
    net.Start('sendtoserveramenus')	
    net.WriteEntity(playeadm)
    net.SendToServer()
    end
    sendservamens()
    net.Receive("sendtoclientamenus", function()
    local adminhavg = net.ReadString()
if (adminhavg == "owner" or adminhavg == "admin" or adminhavg == "highadmin" or adminhavg == "commander") then
local ADFrame = vgui.Create( "DFrame" )
ADFrame:SetPos( ScrW() * 600/1920, ScrH() * 400/1080 )
ADFrame:SetSize( ScrW() * 600/1920, ScrH() * 400/1080 )
ADFrame:SetTitle( "Админ панель" ) 
ADFrame:SetVisible( true ) 
ADFrame:SetDraggable( true ) 
ADFrame:ShowCloseButton( true ) 
ADFrame:MakePopup()

local sheet = vgui.Create( "DPropertySheet", ADFrame )
sheet:Dock( FILL )

local panel1 = vgui.Create( "DPanel", sheet )
panel1.Paint = function( self, w, h ) draw.RoundedBox( 4, 0, 0, w, h, Color( 0, 128, 255, self:GetAlpha() ) ) end 
sheet:AddSheet( "Вайтлист", panel1, "icon16/tick.png" )

local panel4 = vgui.Create( "DPanel", sheet )
panel4.Paint = function( self, w, h ) draw.RoundedBox( 4, 0, 0, w, h, Color( 255, 128, 0, self:GetAlpha() ) ) end 
sheet:AddSheet( "Тонкий Вайтлист", panel4, "icon16/tick.png" )

local AppList41 = vgui.Create( "DListView", panel1 )
AppList41:Dock( FILL )
AppList41:SetMultiSelect( false )
AppList41:AddColumn( "Позывной" )
AppList41:AddColumn( "IDN" )
AppList41:AddColumn( "Подразделение" )
AppList41:AddColumn( "Звание" )
AppList41:AddColumn( "STEAMID64" )
for i, v in ipairs( player.GetAll() ) do
local function whitelists2()
local playadm = v:SteamID64()
net.Start('whitelist2')   
net.WriteString(playadm)
net.WriteEntity(ply)
net.SendToServer()
end
whitelists2()
net.Receive("whitelistclient2", function()
local pozivnoy = net.ReadString()
local IDNdruga = net.ReadString()
local ROTA = net.ReadString()
local zvanie = net.ReadString()
local igrokaID64 = net.ReadString()
AppList41:AddLine(pozivnoy, IDNdruga, ROTA, zvanie, igrokaID64)  
end)
end 

AppList41.OnRowSelected = function( lst, index, pnl )
local MFFrame = vgui.Create( "DFrame" )
MFFrame:SetPos( ScrW() * 600/1920, ScrH() * 400/1080 )
MFFrame:SetSize( ScrW() * 400/1920, ScrH() * 600/1080 )
MFFrame:SetTitle( "Взаимодействие с "..pnl:GetColumnText( 1 ).." ("..pnl:GetColumnText( 2 )..")") 
MFFrame:Center()
MFFrame:SetDraggable( true ) 
MFFrame:ShowCloseButton( true ) 
MFFrame:MakePopup()
local CatList41 = vgui.Create( "DCategoryList", MFFrame )
CatList41:Dock( FILL )

local Cate = CatList41:Add( "Солдатский корпус" )
local Cati = CatList41:Add( "501-ый легион" )
local Cats = CatList41:Add( "574-ый корпус" )
local Catd = CatList41:Add( "41-ый корпус" )
local Catq = CatList41:Add( "Гвардейский корпус" )
local Catfleetos = CatList41:Add( "Флот" )
local CatARCs = CatList41:Add( "ЭРК" )
local Catdonats = CatList41:Add( "Донат" )

-- Солдатский корпус

local button = Cate:Add( "Клон солдат" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Выдать форму клона солдата "..pnl:GetColumnText( 1 ))
    local DermaButton = vgui.Create( "DButton", Krame )
    DermaButton:SetText( "Подтвердить" )                  
    DermaButton:SetPos( 67, 100 )                   
    DermaButton:SetSize( 250, 30 )                  
    DermaButton.DoClick = function() 
    local function CTcloneprof()
    net.Start('Clone_CT_S')
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    CTcloneprof()
end
end

local button = Cate:Add( "Клон офицер" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Выдать форму клона офицера "..pnl:GetColumnText( 1 ))
    local DermaButton = vgui.Create( "DButton", Krame )
    DermaButton:SetText( "Подтвердить" )                  
    DermaButton:SetPos( 67, 100 )                   
    DermaButton:SetSize( 250, 30 )                  
    DermaButton.DoClick = function() 
    local function CTcloneprofo()
    net.Start('Clone_CT_O')
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    CTcloneprofo()
end
end

local button = Cate:Add( "Клон старший офицер" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Выдать форму клона старшего офицера "..pnl:GetColumnText( 1 ))
    local DermaButton = vgui.Create( "DButton", Krame )
    DermaButton:SetText( "Подтвердить" )                  
    DermaButton:SetPos( 67, 100 )                   
    DermaButton:SetSize( 250, 30 )                  
    DermaButton.DoClick = function() 
    local function CTcloneprofHo()
    net.Start('Clone_CT_HO')
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    CTcloneprofHo()
end
end

local button = Cate:Add( "Клон командир" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Выдать форму клона командира "..pnl:GetColumnText( 1 ))
    local DermaButton = vgui.Create( "DButton", Krame )
    DermaButton:SetText( "Подтвердить" )                  
    DermaButton:SetPos( 67, 100 )                   
    DermaButton:SetSize( 250, 30 )                  
    DermaButton.DoClick = function() 
    local function CTcloneprofCC()
    net.Start('Clone_CT_CC')
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    CTcloneprofCC()
end
end

-- 501ый корпус

local button = Cati:Add( "Клон солдат" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Выдать форму клона солдата "..pnl:GetColumnText( 1 ))
    local DermaButton = vgui.Create( "DButton", Krame )
    DermaButton:SetText( "Подтвердить" )                  
    DermaButton:SetPos( 67, 100 )                   
    DermaButton:SetSize( 250, 30 )                  
    DermaButton.DoClick = function() 
    local function ppccloneprof()
    net.Start('Clone_501_S')
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    ppccloneprof()
end
end

local button = Cati:Add( "Клон офицер" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Выдать форму клона офицера "..pnl:GetColumnText( 1 ))
    local DermaButton = vgui.Create( "DButton", Krame )
    DermaButton:SetText( "Подтвердить" )                  
    DermaButton:SetPos( 67, 100 )                   
    DermaButton:SetSize( 250, 30 )                  
    DermaButton.DoClick = function() 
    local function ppccloneprofo()
    net.Start('Clone_501_O')
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    ppccloneprofo()
end
end

local button = Cati:Add( "Клон старший офицер" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Выдать форму клона старшего офицера "..pnl:GetColumnText( 1 ))
    local DermaButton = vgui.Create( "DButton", Krame )
    DermaButton:SetText( "Подтвердить" )                  
    DermaButton:SetPos( 67, 100 )                   
    DermaButton:SetSize( 250, 30 )                  
    DermaButton.DoClick = function() 
    local function ppccloneprofHo()
    net.Start('Clone_501_HO')
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    ppccloneprofHo()
end
end

local button = Cati:Add( "Клон командир" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Выдать форму клона командира "..pnl:GetColumnText( 1 ))
    local DermaButton = vgui.Create( "DButton", Krame )
    DermaButton:SetText( "Подтвердить" )                  
    DermaButton:SetPos( 67, 100 )                   
    DermaButton:SetSize( 250, 30 )                  
    DermaButton.DoClick = function() 
    local function ppccloneprofCC()
    net.Start('Clone_501_CC')
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    ppccloneprofCC()
end
end

-- 574ый корпус

local button = Cats:Add( "Клон солдат" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Выдать форму клона солдата "..pnl:GetColumnText( 1 ))
    local DermaButton = vgui.Create( "DButton", Krame )
    DermaButton:SetText( "Подтвердить" )                  
    DermaButton:SetPos( 67, 100 )                   
    DermaButton:SetSize( 250, 30 )                  
    DermaButton.DoClick = function() 
    local function schcloneprof()
    net.Start('Clone_104_S')
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    schcloneprof()
end
end

local button = Cats:Add( "Клон офицер" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Выдать форму клона офицера "..pnl:GetColumnText( 1 ))
    local DermaButton = vgui.Create( "DButton", Krame )
    DermaButton:SetText( "Подтвердить" )                  
    DermaButton:SetPos( 67, 100 )                   
    DermaButton:SetSize( 250, 30 )                  
    DermaButton.DoClick = function() 
    local function schcloneprofo()
    net.Start('Clone_104_O')
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    schcloneprofo()
end
end

local button = Cats:Add( "Клон старший офицер" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Выдать форму клона старшего офицера "..pnl:GetColumnText( 1 ))
    local DermaButton = vgui.Create( "DButton", Krame )
    DermaButton:SetText( "Подтвердить" )                  
    DermaButton:SetPos( 67, 100 )                   
    DermaButton:SetSize( 250, 30 )                  
    DermaButton.DoClick = function() 
    local function schcloneprofHo()
    net.Start('Clone_104_HO')
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    schcloneprofHo()
end
end

local button = Cats:Add( "Клон командир" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Выдать форму клона командира "..pnl:GetColumnText( 1 ))
    local DermaButton = vgui.Create( "DButton", Krame )
    DermaButton:SetText( "Подтвердить" )                  
    DermaButton:SetPos( 67, 100 )                   
    DermaButton:SetSize( 250, 30 )                  
    DermaButton.DoClick = function() 
    local function schcloneprofCC()
    net.Start('Clone_104_CC')
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    schcloneprofCC()
end
end

-- 91ый корпус

local button = Catd:Add( "Клон солдат" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Выдать форму клона солдата "..pnl:GetColumnText( 1 ))
    local DermaButton = vgui.Create( "DButton", Krame )
    DermaButton:SetText( "Подтвердить" )                  
    DermaButton:SetPos( 67, 100 )                   
    DermaButton:SetSize( 250, 30 )                  
    DermaButton.DoClick = function() 
    local function dvcloneprof()
    net.Start('Clone_91_S')
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    dvcloneprof()
end
end

local button = Catd:Add( "Клон офицер" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Выдать форму клона офицера "..pnl:GetColumnText( 1 ))
    local DermaButton = vgui.Create( "DButton", Krame )
    DermaButton:SetText( "Подтвердить" )                  
    DermaButton:SetPos( 67, 100 )                   
    DermaButton:SetSize( 250, 30 )                  
    DermaButton.DoClick = function() 
    local function dvcloneprofo()
    net.Start('Clone_91_O')
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    dvcloneprofo()
end
end

local button = Catd:Add( "Клон старший офицер" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Выдать форму клона старшего офицера "..pnl:GetColumnText( 1 ))
    local DermaButton = vgui.Create( "DButton", Krame )
    DermaButton:SetText( "Подтвердить" )                  
    DermaButton:SetPos( 67, 100 )                   
    DermaButton:SetSize( 250, 30 )                  
    DermaButton.DoClick = function() 
    local function dvcloneprofHo()
    net.Start('Clone_91_HO')
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    dvcloneprofHo()
end
end

local button = Catd:Add( "Клон командир" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Выдать форму клона командира "..pnl:GetColumnText( 1 ))
    local DermaButton = vgui.Create( "DButton", Krame )
    DermaButton:SetText( "Подтвердить" )                  
    DermaButton:SetPos( 67, 100 )                   
    DermaButton:SetSize( 250, 30 )                  
    DermaButton.DoClick = function() 
    local function dvcloneprofCC()
    net.Start('Clone_91_CC')
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    dvcloneprofCC()
end
end

-- гвардейский корпус

local button = Catq:Add( "Клон солдат" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Выдать форму клона солдата "..pnl:GetColumnText( 1 ))
    local DermaButton = vgui.Create( "DButton", Krame )
    DermaButton:SetText( "Подтвердить" )                  
    DermaButton:SetPos( 67, 100 )                   
    DermaButton:SetSize( 250, 30 )                  
    DermaButton.DoClick = function() 
    local function GUARDprof()
    net.Start('Clone_GUARD_S')
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    GUARDprof()
end
end

local button = Catq:Add( "Клон офицер" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Выдать форму клона офицера "..pnl:GetColumnText( 1 ))
    local DermaButton = vgui.Create( "DButton", Krame )
    DermaButton:SetText( "Подтвердить" )                  
    DermaButton:SetPos( 67, 100 )                   
    DermaButton:SetSize( 250, 30 )                  
    DermaButton.DoClick = function() 
    local function GUARDprofo()
    net.Start('Clone_GUARD_O')
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    GUARDprofo()
end
end

local button = Catq:Add( "Клон старший офицер" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Выдать форму клона старшего офицера "..pnl:GetColumnText( 1 ))
    local DermaButton = vgui.Create( "DButton", Krame )
    DermaButton:SetText( "Подтвердить" )                  
    DermaButton:SetPos( 67, 100 )                   
    DermaButton:SetSize( 250, 30 )                  
    DermaButton.DoClick = function() 
    local function GUARDprofHo()
    net.Start('Clone_GUARD_HO')
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    GUARDprofHo()
end
end

local button = Catq:Add( "Клон командир" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Выдать форму клона командира "..pnl:GetColumnText( 1 ))
    local DermaButton = vgui.Create( "DButton", Krame )
    DermaButton:SetText( "Подтвердить" )                  
    DermaButton:SetPos( 67, 100 )                   
    DermaButton:SetSize( 250, 30 )                  
    DermaButton.DoClick = function() 
    local function GUARDprofCC()
    net.Start('Clone_GUARD_CC')
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    GUARDprofCC()
end
end

-- ПАЖИЛОЙ ФЛОТ

local button = Catfleetos:Add( "Матрос" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Выдать форму матроса "..pnl:GetColumnText( 1 ))
    local DermaButton = vgui.Create( "DButton", Krame )
    DermaButton:SetText( "Подтвердить" )                  
    DermaButton:SetPos( 67, 100 )                   
    DermaButton:SetSize( 250, 30 )                  
    DermaButton.DoClick = function() 
    local function FLEETprof()
    net.Start('Clone_FLEET_S')
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    FLEETprof()
end
end

local button = Catfleetos:Add( "Офицер" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Выдать форму офицера "..pnl:GetColumnText( 1 ))
    local DermaButton = vgui.Create( "DButton", Krame )
    DermaButton:SetText( "Подтвердить" )                  
    DermaButton:SetPos( 67, 100 )                   
    DermaButton:SetSize( 250, 30 )                  
    DermaButton.DoClick = function() 
    local function FLEETprofo()
    net.Start('Clone_FLEET_O')
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    FLEETprofo()
end
end

local button = Catfleetos:Add( "Старший Офицер" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Выдать форму старшего офицера "..pnl:GetColumnText( 1 ))
    local DermaButton = vgui.Create( "DButton", Krame )
    DermaButton:SetText( "Подтвердить" )                  
    DermaButton:SetPos( 67, 100 )                   
    DermaButton:SetSize( 250, 30 )                  
    DermaButton.DoClick = function() 
    local function FLEETprofHo()
    net.Start('Clone_FLEET_HO')
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    FLEETprofHo()
end
end

local button = Catfleetos:Add( "Командир" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Выдать форму командира "..pnl:GetColumnText( 1 ))
    local DermaButton = vgui.Create( "DButton", Krame )
    DermaButton:SetText( "Подтвердить" )                  
    DermaButton:SetPos( 67, 100 )                   
    DermaButton:SetSize( 250, 30 )                  
    DermaButton.DoClick = function() 
    local function FLEETprofXO()
    net.Start('Clone_FLEET_XO')
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    FLEETprofXO()
end
end

local button = Catfleetos:Add( "Адмирал" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Выдать форму адмирала "..pnl:GetColumnText( 1 ))
    local DermaButton = vgui.Create( "DButton", Krame )
    DermaButton:SetText( "Подтвердить" )                  
    DermaButton:SetPos( 67, 100 )                   
    DermaButton:SetSize( 250, 30 )                  
    DermaButton.DoClick = function() 
    local function FLEETprofCC()
    net.Start('Clone_FLEET_CC')
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    FLEETprofCC()
end
end

-- ARC

local button = CatARCs:Add( "Клон ARC" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Выдать форму клона солдата "..pnl:GetColumnText( 1 ))
    local DermaButton = vgui.Create( "DButton", Krame )
    DermaButton:SetText( "Подтвердить" )                  
    DermaButton:SetPos( 67, 100 )                   
    DermaButton:SetSize( 250, 30 )                  
    DermaButton.DoClick = function() 
    local function GUARDprof()
    net.Start('Clone_ARC_S')
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    GUARDprof()
end
end

local button = CatARCs:Add( "Клон командир ARC" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Выдать форму клона командира "..pnl:GetColumnText( 1 ))
    local DermaButton = vgui.Create( "DButton", Krame )
    DermaButton:SetText( "Подтвердить" )                  
    DermaButton:SetPos( 67, 100 )                   
    DermaButton:SetSize( 250, 30 )                  
    DermaButton.DoClick = function() 
    local function GUARDprofCC()
    net.Start('Clone_ARC_CC')
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    GUARDprofCC()
end
end

local button = CatARCs:Add( "ARC Alpha 77" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Выдать форму ALPHA 77 "..pnl:GetColumnText( 1 ))
    local DermaButton = vgui.Create( "DButton", Krame )
    DermaButton:SetText( "Подтвердить" )                  
    DermaButton:SetPos( 67, 100 )                   
    DermaButton:SetSize( 250, 30 )                  
    DermaButton.DoClick = function() 
    local function GUARDprofCC()
    net.Start('Clone_ARC_A77')
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    GUARDprofCC()
end
end

local button = CatARCs:Add( "ARC Муунилинст-10" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Выдать форму ARC Муунилинст-10 "..pnl:GetColumnText( 1 ))
    local DermaButton = vgui.Create( "DButton", Krame )
    DermaButton:SetText( "Подтвердить" )                  
    DermaButton:SetPos( 67, 100 )                   
    DermaButton:SetSize( 250, 30 )                  
    DermaButton.DoClick = function() 
    local function GUARDprofCC()
    net.Start('Clone_ARC_A77L')
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    GUARDprofCC()
end
end

local button = Catdonats:Add( "Республиканский коммандос" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Выдать форму РК "..pnl:GetColumnText( 1 ))
    local DermaButton = vgui.Create( "DButton", Krame )
    DermaButton:SetText( "Подтвердить" )                  
    DermaButton:SetPos( 67, 100 )                   
    DermaButton:SetSize( 250, 30 )                  
    DermaButton.DoClick = function() 
    local function GUARDprofCC()
    net.Start('Clone_RC_STANDART')
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    GUARDprofCC()
end
end

end
--ВАЙТЛИСТ ТОНКИЙ НИЖЕ

local AppList2 = vgui.Create( "DListView", panel4 )
AppList2:Dock( FILL )
AppList2:SetMultiSelect( false )
AppList2:AddColumn( "Позывной" )
AppList2:AddColumn( "IDN" )
AppList2:AddColumn( "Подразделение" )
AppList2:AddColumn( "Звание" )
AppList2:AddColumn( "STEAMID64" )
for i, v in ipairs( player.GetAll() ) do
local function whitelists()
local playadm = v:SteamID64()
net.Start('whitelist')   
net.WriteString(playadm)
net.WriteEntity(ply)
net.SendToServer()
end
whitelists()
net.Receive("whitelistclient", function()
local pozivnoy = net.ReadString()
local IDNdruga = net.ReadString()
local ROTA = net.ReadString()
local zvanie = net.ReadString()
local igrokaID64 = net.ReadString()
AppList2:AddLine(pozivnoy, IDNdruga, ROTA, zvanie, igrokaID64)  
end)
end 

if (adminhavg == "owner" or adminhavg == "highadmin") then
local panel3 = vgui.Create( "DPanel", sheet )
panel3.Paint = function( self, w, h ) draw.RoundedBox( 4, 0, 0, w, h, Color( 255, 128, 0, self:GetAlpha() ) ) end 
sheet:AddSheet( "STEAMID64", panel3, "icon16/tick.png" )

local CatList2 = vgui.Create( "DCategoryList", panel3 )
CatList2:Dock( FILL )

local Cat2 = CatList2:Add( "Действия со STEAMID64" )
local button = Cat2:Add( "Пермаразбан" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Разбанить игрока")
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Ввидите STEAMID64 и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function sendservamenunban()
    net.Start('sendtoserveramenuunban') 
    net.WriteString(self:GetValue())
    net.WriteString(ply:SteamID64())
    net.WriteString(ply:Name())
    net.SendToServer()
    end
    sendservamenunban()
    end
end
local button = Cat2:Add( "Пермабан" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Забанить игрока")
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Ввидите STEAMID64 и нажмите (ENTER)" )
    local TextEntryPH2 = vgui.Create( "DTextEntry", Krame )
    TextEntryPH2:Dock( TOP )
    TextEntryPH2:DockMargin( 0, 5, 0, 0 )
    TextEntryPH2:SetPlaceholderText( "Ввидите причину и нажмите (ENTER)" )
    local DermaButton = vgui.Create( "DButton", Krame )
    DermaButton:SetText( "ENTER" )                  
    DermaButton:SetPos( 67, 100 )                   
    DermaButton:SetSize( 250, 30 )                  
    DermaButton.DoClick = function()    
    local function sendservamenunban()
    net.Start('sendtoserveramenubanid') 
    net.WriteString(TextEntryPH:GetValue())
    net.WriteString(ply:SteamID64())
    net.WriteString(ply:Name())
    net.WriteString(TextEntryPH2:GetValue())
    net.SendToServer()
    end
    sendservamenunban()
    end
end
end

AppList2.OnRowSelected = function( lst, index, pnl )
local MFFrame = vgui.Create( "DFrame" )
MFFrame:SetPos( ScrW() * 600/1920, ScrH() * 400/1080 )
MFFrame:SetSize( ScrW() * 400/1920, ScrH() * 600/1080 )
MFFrame:SetTitle( "Взаимодействие с "..pnl:GetColumnText( 1 ).." ("..pnl:GetColumnText( 2 )..")") 
MFFrame:Center()
MFFrame:SetDraggable( true ) 
MFFrame:ShowCloseButton( true ) 
MFFrame:MakePopup()
local CatList3 = vgui.Create( "DCategoryList", MFFrame )
CatList3:Dock( FILL )

local Cat3 = CatList3:Add( "Ранги и положения" )
local Cat31 = CatList3:Add( "Внешний вид" )
local Cat32 = CatList3:Add( "Вооружение" )
local Cat33 = CatList3:Add( "Другие параметры" )
local Cat34 = CatList3:Add( "Дополнительно" )

local button = Cat3:Add( "Установить позывной WL" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Позывной "..pnl:GetColumnText( 1 ))
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите позывной и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function wlpozivn()
    net.Start('wlistpoziv')  
    net.WriteString(self:GetValue())
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    wlpozivn()
end
end

local button = Cat3:Add( "Установить IDN WL" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("IDN "..pnl:GetColumnText( 1 ))
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите IDN и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function wlnumber()
    net.Start('wlistnum')  
    net.WriteString(self:GetValue())
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    wlnumber()
end
end

local button = Cat3:Add( "Установить легион WL" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Легион "..pnl:GetColumnText( 1 ))
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите легион и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function wllegion()
    net.Start('wlistlegion')  
    net.WriteString(self:GetValue())
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    wllegion()
end
end

local button = Cat3:Add( "Установить звание WL" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Звание "..pnl:GetColumnText( 1 ))
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите звание и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function wlrankk()
    net.Start('wlrank')  
    net.WriteString(self:GetValue())
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    wlrankk()
end
end

local button = Cat3:Add( "Установить специализацию WL" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Специализация "..pnl:GetColumnText( 1 ))
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите специализацию и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function wlspecc()
    net.Start('wlspec')  
    net.WriteString(self:GetValue())
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    wlspecc()
end
end

local button = Cat31:Add( "Установить модель WL" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Модель "..pnl:GetColumnText( 1 ))
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите путь к модели и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function wlmodelka()
    net.Start('wlistmodel')  
    net.WriteString(self:GetValue())
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    wlmodelka()
end
end

local button = Cat31:Add( "Установить БГ WL" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Бодигруппы "..pnl:GetColumnText( 1 ))
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите (000000) и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function wlbodygroups()
    net.Start('wlistbodygroups')  
    net.WriteString(self:GetValue())
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    wlbodygroups()
end
end

local button = Cat31:Add( "Установить скин WL" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Скин "..pnl:GetColumnText( 1 ))
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите (0) и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function wlskinseds()
    net.Start('wlistskinsesd')  
    net.WriteString(self:GetValue())
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    wlskinseds()
end
end

local button = Cat31:Add( "Установить размер WL" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Размер "..pnl:GetColumnText( 1 ))
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите множитель и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function wlsize()
    net.Start('wlistsize')  
    net.WriteString(self:GetValue())
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    wlsize()
end
end

local button = Cat32:Add( "Основное оружие WL" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Основное оружие "..pnl:GetColumnText( 1 ))
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите класс оружия и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function wlfirwep()
    net.Start('wlfirweap')  
    net.WriteString(self:GetValue())
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    wlfirwep()
end
end

local button = Cat32:Add( "Вторичное оружие WL" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Вторичное оружие "..pnl:GetColumnText( 1 ))
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите класс оружия и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function wlsecwep()
    net.Start('wlsecweap')  
    net.WriteString(self:GetValue())
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    wlsecwep()
end
end

local button = Cat32:Add( "Основная граната WL" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Основная граната "..pnl:GetColumnText( 1 ))
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите класс гранаты и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function wlfirgrenk()
    net.Start('wlfirgren')  
    net.WriteString(self:GetValue())
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    wlfirgrenk()
end
end

local button = Cat32:Add( "Вторичная граната WL" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Вторичная граната "..pnl:GetColumnText( 1 ))
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите класс гранаты и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function wlsecgrenk()
    net.Start('wlsecgren')  
    net.WriteString(self:GetValue())
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    wlsecgrenk()
end
end

local button = Cat32:Add( "Холодное оружие WL" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Холодное оружие "..pnl:GetColumnText( 1 ))
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите класс оружия и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function wlknifek()
    net.Start('wlknife')  
    net.WriteString(self:GetValue())
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    wlknifek()
end
end

local button = Cat32:Add( "Запасной слот WL" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Запасной слот "..pnl:GetColumnText( 1 ))
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите класс оружия и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function wlkniwlutil()
    net.Start('wlutil')  
    net.WriteString(self:GetValue())
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    wlkniwlutil()
end
end

local button = Cat32:Add( "Запасной слот №2 WL" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Запасной слот №2 "..pnl:GetColumnText( 1 ))
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите класс оружия и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function wlkniwlutil2()
    net.Start('wlutil2')  
    net.WriteString(self:GetValue())
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    wlkniwlutil2()
end
end

local button = Cat32:Add( "Энтити WL" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Энтити "..pnl:GetColumnText( 1 ))
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите класс энтити и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function wlentsd2()
    net.Start('wlent')  
    net.WriteString(self:GetValue())
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    wlentsd2()
end
end

local button = Cat33:Add( "Здоровье WL" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Здоровье "..pnl:GetColumnText( 1 ))
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите кол-во и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function wlhealthss()
    net.Start('wlhealths')  
    net.WriteString(self:GetValue())
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    wlhealthss()
end
end

local button = Cat33:Add( "Броня WL" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Броня "..pnl:GetColumnText( 1 ))
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите кол-во и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function wlarmorsss()
    net.Start('wlarmorhs')  
    net.WriteString(self:GetValue())
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    wlarmorsss()
end
end

local button = Cat33:Add( "Скорость WL" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Скорость "..pnl:GetColumnText( 1 ))
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите множитель и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function wlspeedok()
    net.Start('wlspeed')  
    net.WriteString(self:GetValue())
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    wlspeedok()
end
end

local button = Cat33:Add( "Гравитация WL" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Гравитация "..pnl:GetColumnText( 1 ))
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите множитель и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function wlgravok()
    net.Start('wlgrav')  
    net.WriteString(self:GetValue())
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    wlgravok()
end
end

local button = Cat34:Add( "Сброс WL" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Сброс персонажа "..pnl:GetColumnText( 1 ))
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите причину и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function wlreloadallc()
    net.Start('wlreloadchars')  
    net.WriteString(self:GetValue())
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 5 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    wlreloadallc()
end
end
---
end

if (adminhavg == "owner" or adminhavg == "admin" or adminhavg == "highadmin") then
local panel2 = vgui.Create( "DPanel", sheet )
panel2.Paint = function( self, w, h ) draw.RoundedBox( 4, 0, 0, w, h, Color( 255, 128, 0, self:GetAlpha() ) ) end 
sheet:AddSheet( "Игроки и действия", panel2, "icon16/tick.png" )

local AppList = vgui.Create( "DListView", panel2 )
AppList:Dock( FILL )
AppList:SetMultiSelect( false )
AppList:AddColumn( "Ник" )
AppList:AddColumn( "SteamID" )
AppList:AddColumn( "SteamID64" )
AppList:AddColumn( "Статус" )
AppList:AddColumn( "Выговоры" )

for i, v in ipairs( player.GetAll() ) do
local function sendserv()
local playadm = v
net.Start('sendtoserver')	
net.WriteEntity(playadm)
net.WriteEntity(ply)
net.SendToServer()
end
sendserv()
net.Receive("sendtoclient", function()
local adminkas = net.ReadString()
local warens = net.ReadString()
local keksik = net.ReadEntity()
AppList:AddLine(keksik:Nick(), keksik:SteamID(), keksik:SteamID64(), adminkas, warens)  
end)
end 
AppList.OnRowSelected = function( lst, index, pnl )
	local MFFrame = vgui.Create( "DFrame" )
MFFrame:SetPos( ScrW() * 600/1920, ScrH() * 400/1080 )
MFFrame:SetSize( ScrW() * 400/1920, ScrH() * 600/1080 )
MFFrame:SetTitle( "Взаимодействие с "..pnl:GetColumnText( 1 ).." ("..pnl:GetColumnText( 3 )..")") 
MFFrame:Center()
MFFrame:SetDraggable( true ) 
MFFrame:ShowCloseButton( true ) 
MFFrame:MakePopup()
local CatList = vgui.Create( "DCategoryList", MFFrame )
CatList:Dock( FILL )
local Cat = CatList:Add( "Действия" )
local button = Cat:Add( "Кикнуть с сервера" )
button.DoClick = function()
	local Krame = vgui.Create( "DFrame" )
	Krame:SetSize( 400, 200 )
	Krame:Center()
	Krame:MakePopup()
    Krame:SetTitle("Кикнуть игрока "..pnl:GetColumnText( 1 ))
	local TextEntryPH = vgui.Create( "DTextEntry", Krame )
	TextEntryPH:Dock( TOP )
	TextEntryPH:DockMargin( 0, 5, 0, 0 )
	TextEntryPH:SetPlaceholderText( "Ввидите причину и нажмите (ENTER)" )
	TextEntryPH.OnEnter = function( self )
	local function sendservamen()
    net.Start('sendtoserveramenu')	
    net.WriteString(self:GetValue())
    net.WriteString(pnl:GetColumnText( 2 ))
    net.WriteString(ply:SteamID64())
    net.WriteString(pnl:GetColumnText( 3 ))
    net.SendToServer()
    end
    sendservamen()
	end
end

if (adminhavg == "owner" or adminhavg == "highadmin") then
local button = Cat:Add( "Пермабан" )
button.DoClick = function()
	local Krame = vgui.Create( "DFrame" )
	Krame:SetSize( 400, 200 )
	Krame:Center()
	Krame:MakePopup()
    Krame:SetTitle("Забанить игрока "..pnl:GetColumnText( 1 ))
	local TextEntryPH = vgui.Create( "DTextEntry", Krame )
	TextEntryPH:Dock( TOP )
	TextEntryPH:DockMargin( 0, 5, 0, 0 )
	TextEntryPH:SetPlaceholderText( "Ввидите причину и нажмите (ENTER)" )
	TextEntryPH.OnEnter = function( self )
	local function sendservamenban()
    net.Start('sendtoserveramenuban')	
    net.WriteString(self:GetValue())
    net.WriteString(ply:SteamID64())
    net.WriteString(ply:Name())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 3 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    sendservamenban()
	end
end
end

local button = Cat:Add( "Выговоры" )
button.DoClick = function()
	local Krame = vgui.Create( "DFrame" )
	Krame:SetSize( 400, 200 )
	Krame:Center()
	Krame:MakePopup()
    Krame:SetTitle("Выговоры "..pnl:GetColumnText( 1 ))
	local TextEntryPH = vgui.Create( "DTextEntry", Krame )
	TextEntryPH:Dock( TOP )
	TextEntryPH:DockMargin( 0, 5, 0, 0 )
	TextEntryPH:SetPlaceholderText( "Выдать выговор по причине (ENTER)" )
	TextEntryPH.OnEnter = function( self )
	local function warncipkasend()
    net.Start('warncipka')
    net.WriteString(pnl:GetColumnText( 3 ))	
    net.WriteString(self:GetValue())
    net.WriteString(ply:SteamID64())
    net.WriteString(ply:Name())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 3 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    warncipkasend()
end
	local TextEntryPH2 = vgui.Create( "DTextEntry", Krame )
	TextEntryPH2:Dock( TOP )
	TextEntryPH2:DockMargin( 0, 5, 0, 0 )
	TextEntryPH2:SetPlaceholderText( "Снять выговор по причине (ENTER)" )
	TextEntryPH2.OnEnter = function( self )
	local function warncipkaremove()
    net.Start('warncipkar')
    net.WriteString(pnl:GetColumnText( 3 ))	
    net.WriteString(self:GetValue())
    net.WriteString(ply:SteamID64())
    net.SendToServer()
    end
    warncipkaremove()
	end
end

local button = Cat:Add( "Размер модельки" )
button.DoClick = function()
	local Krame = vgui.Create( "DFrame" )
	Krame:SetSize( 400, 200 )
	Krame:Center()
	Krame:MakePopup()
    Krame:SetTitle("Размер модели "..pnl:GetColumnText( 1 ))
	local TextEntryPH = vgui.Create( "DTextEntry", Krame )
	TextEntryPH:Dock( TOP )
	TextEntryPH:DockMargin( 0, 5, 0, 0 )
	TextEntryPH:SetPlaceholderText( "Введите размер и нажмите (ENTER)" )
	TextEntryPH.OnEnter = function( self )
	local function sendservamenmodel()
    net.Start('sendtoserveramenmodel')	
    net.WriteString(self:GetValue())
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 3 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    sendservamenmodel()
end
end

local button = Cat:Add( "Выдать армора" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Броник для "..pnl:GetColumnText( 1 ))
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите кол-во и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function sendservamenarmor()
    net.Start('sendtoserveramenarmoer')  
    net.WriteString(self:GetValue())
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 3 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    sendservamenarmor()
end
end

local button = Cat:Add( "Выдать хэлсов" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Броник для "..pnl:GetColumnText( 1 ))
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите кол-во и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function sendservamenheals()
    net.Start('sendtoserveramenheels')  
    net.WriteString(self:GetValue())
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 3 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    sendservamenheals()
end
end

local button = Cat:Add( "Выдать скорость" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Скорость "..pnl:GetColumnText( 1 ))
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "(1-стандарт) Введите и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function sendservamenspee()
    net.Start('sendtoserveramenspeed')  
    net.WriteString(self:GetValue())
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 3 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    sendservamenspee()
end
end

local button = Cat:Add( "Установить гравитацию" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Гравитация "..pnl:GetColumnText( 1 ))
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "(1-стандарт) Введите и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function sendservamengra()
    net.Start('sendtoserveramengrav')  
    net.WriteString(self:GetValue())
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 3 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    sendservamengra()
end
end

local button = Cat:Add( "Установить модель" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Модель "..pnl:GetColumnText( 1 ))
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите путь к модели и нажмите (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function sendservamenmodel()
    net.Start('sendtoserveramenmodl')  
    net.WriteString(self:GetValue())
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 3 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    sendservamenmodel()
end
end

local button = Cat:Add( "Заморозить/Разморозить" )
button.DoClick = function()
   local function sendservamenfre()
    net.Start('sendtoserveramenfreez')  
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 3 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    sendservamenfre()
end

local button = Cat:Add( "Телепорт к человеку" )
button.DoClick = function()
   local function tpplysssssdddd()
    net.Start('teleporttoplay')  
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 3 ) then
    net.WriteEntity(v)
end
end
    net.WriteEntity(ply)
    net.SendToServer()
    end
    tpplysssssdddd()
end

local button = Cat:Add( "Телепорт к себе" )
button.DoClick = function()
   local function bringusply()
    net.Start('bringplay')  
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 3 ) then
    net.WriteEntity(v)
end
end
    net.WriteEntity(ply)
    net.SendToServer()
    end
    bringusply()
end

local button = Cat:Add( "Убрать оружия" )
button.DoClick = function()
   local function strippiaponsgog()
    net.Start('strippiaponsgog')  
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 3 ) then
    net.WriteEntity(v)
end
end
    net.WriteEntity(ply)
    net.SendToServer()
    end
    strippiaponsgog()
end

local button = Cat:Add( "Слежка" )
button.DoClick = function()
   local function bringusply()
    net.Start('spectateplyersd')  
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 3 ) then
    net.WriteEntity(v)
end
end
    net.WriteEntity(ply)
    net.SendToServer()
    end
    bringusply()
end

local button = Cat:Add( "Бан на время" )
button.DoClick = function()
	local Krame = vgui.Create( "DFrame" )
	Krame:SetSize( 400, 200 )
	Krame:Center()
	Krame:MakePopup()
    Krame:SetTitle("Бан на время "..pnl:GetColumnText( 1 ))
	local TextEntryPH = vgui.Create( "DTextEntry", Krame )
	TextEntryPH:Dock( TOP )
	TextEntryPH:DockMargin( 0, 5, 0, 0 )
	TextEntryPH:SetPlaceholderText( "Введите причину" )
	local TextEntryPH2 = vgui.Create( "DTextEntry", Krame )
	TextEntryPH2:Dock( TOP )
	TextEntryPH2:DockMargin( 0, 5, 0, 0 )
	TextEntryPH2:SetPlaceholderText( "Введите время в минутах" )
	local DermaButton = vgui.Create( "DButton", Krame ) 
    DermaButton:SetText( "Выдать наказание" )					
    DermaButton:SetPos( 67, 100 )					
    DermaButton:SetSize( 250, 30 )	
    DermaButton.DoClick = function()	
	local function sendservamentimerba()
    net.Start('sendtoserveramentimerban')
    net.WriteString(pnl:GetColumnText( 3 ))	
    net.WriteString(TextEntryPH:GetValue())
    net.WriteString(TextEntryPH2:GetInt())
    net.WriteString(ply:SteamID64())
    net.WriteString(ply:Name())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 3 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
   sendservamentimerba()
end
end

if (adminhavg == "owner" or adminhavg == "highadmin") then
local button = Cat:Add( "Ранг (игрок)" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Ранг (игрок) "..pnl:GetColumnText( 1 ))
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите причину (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function sendservamengra()
    net.Start('sendtoserveramenuser')  
    net.WriteString(self:GetValue())
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 3 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    sendservamengra()
end
end

local button = Cat:Add( "Ранг (командир)" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Ранг (командир) "..pnl:GetColumnText( 1 ))
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите причину (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function sendservamengra()
    net.Start('sendtoserveramencmd')  
    net.WriteString(self:GetValue())
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 3 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    sendservamengra()
end
end

local button = Cat:Add( "Ранг (админ)" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Ранг (админ) "..pnl:GetColumnText( 1 ))
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите причину (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function sendservamengra()
    net.Start('sendtoserveramenadmin')  
    net.WriteString(self:GetValue())
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 3 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    sendservamengra()
end
end

if (adminhavg == "owner") then
local button = Cat:Add( "Ранг (старший админ)" )
button.DoClick = function()
    local Krame = vgui.Create( "DFrame" )
    Krame:SetSize( 400, 200 )
    Krame:Center()
    Krame:MakePopup()
    Krame:SetTitle("Ранг (старший админ) "..pnl:GetColumnText( 1 ))
    local TextEntryPH = vgui.Create( "DTextEntry", Krame )
    TextEntryPH:Dock( TOP )
    TextEntryPH:DockMargin( 0, 5, 0, 0 )
    TextEntryPH:SetPlaceholderText( "Введите причину (ENTER)" )
    TextEntryPH.OnEnter = function( self )
    local function sendservamengra()
    net.Start('sendtoserveramenhighadmin')  
    net.WriteString(self:GetValue())
    net.WriteString(ply:SteamID64())
    for i, v in ipairs( player.GetAll() ) do
    if v:SteamID64() == pnl:GetColumnText( 3 ) then
    net.WriteEntity(v)
end
end
    net.SendToServer()
    end
    sendservamengra()
end
end
end
end

local Cat2 = CatList:Add( "Дополнительно" )
Cat2:SetTall( 100 )
local button = Cat2:Add( "Скопировать STEAMID64" )
button.DoClick = function()
SetClipboardText(pnl:GetColumnText( 3 ))
end
local button = Cat2:Add( "Скопировать STEAMID" )
button.DoClick = function()
SetClipboardText(pnl:GetColumnText( 2 ))
end
local button = Cat2:Add( "Скопировать никнейм" )
button.DoClick = function()
SetClipboardText(pnl:GetColumnText( 1 ))
end
end
end
end
end)
end
end
end)