if SERVER then return end
net.Receive( "Advert_XCWRP", function( len, pl )
	local text = net.ReadString()
	local names = net.ReadString()
	local number = net.ReadString()
	local legion = net.ReadString()
	local ply = net.ReadEntity()
	if ( IsValid( ply ) and ply:IsPlayer() ) then
		chat.PlaySound()
		chat.AddText( Color( 225,255,0 ), "(", Color( 225,255,255 ), legion.." | "..names.." | "..number, Color( 225,255,0 ), ") [О-связь] ", Color( 255, 255, 255 ), " - ", Color( 225,255,0 ), text )
	end
end )

net.Receive( "Sys_XCWRP", function( len, pl )
	local text = net.ReadString()
	local names = net.ReadString()
	local number = net.ReadString()
	local legion = net.ReadString()
	local ply = net.ReadEntity()
	if ( IsValid( ply ) and ply:IsPlayer() ) then
		chat.PlaySound()
		chat.AddText( Color(46,192,255), "(", Color(255,255,255), legion.." | "..names.." | "..number, Color(46,192,255), ") [Система] ", Color( 255, 255, 255 ), " - ", Color(46,192,255), text )
	end
end )