if CLIENT then return end
util.AddNetworkString( "Advert_XCWRP" )
timer.Simple( 5, function()
	hook.Add( "PlayerSay", "Advert_XCWRP_start", function( ply, text, team )
		local test = string.lower( text )
		if ( string.sub( test, 1, 3 ) == "/ad" ) or ( string.sub( test, 1, 3 ) == "!ad" ) then
			local String = string.sub( text, 4 )
			if String != "" then
				net.Start( "Advert_XCWRP" )
					net.WriteString( String )
                    net.WriteString( file.Read("users/"..ply:SteamID64().."/name/name.txt", "data") )
                    net.WriteString( file.Read("users/"..ply:SteamID64().."/number/number.txt", "data") )
                    net.WriteString( file.Read("users/"..ply:SteamID64().."/legion/legion.txt", "data") )
					net.WriteEntity( ply )
				net.Broadcast()
			end
			return ""
		end
	end )
end )

util.AddNetworkString( "Sys_XCWRP" )
timer.Simple( 5, function()
	hook.Add( "PlayerSay", "Sys_XCWRP_start", function( ply, text, team )
		local test = string.lower( text )
		if ( string.sub( test, 1, 4 ) == "/sys" ) or ( string.sub( test, 1, 4 ) == "!sys" ) then
			local String = string.sub( text, 5 )
			if String != "" then
				net.Start( "Sys_XCWRP" )
					net.WriteString( String )
                    net.WriteString( file.Read("users/"..ply:SteamID64().."/name/name.txt", "data") )
                    net.WriteString( file.Read("users/"..ply:SteamID64().."/number/number.txt", "data") )
                    net.WriteString( file.Read("users/"..ply:SteamID64().."/legion/legion.txt", "data") )
					net.WriteEntity( ply )
				net.Broadcast()
			end
			return ""
		end
	end )
end )