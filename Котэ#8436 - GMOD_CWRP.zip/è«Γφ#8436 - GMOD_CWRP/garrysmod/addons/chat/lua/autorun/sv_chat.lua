if CLIENT then return end
util.AddNetworkString("chatstclient")
util.AddNetworkString("chatlwork")
net.Receive("chatlwork", function()
local playeadm = net.ReadString()
local gamerdrug = net.ReadEntity()
local caller = net.ReadEntity()
local function WLCList()
net.Start('chatstclient')
net.WriteEntity(gamerdrug)
net.WriteString(file.Read("users/"..playeadm.."/name/name.txt", "data"))
net.WriteString(file.Read("users/"..playeadm.."/number/number.txt", "data"))
net.WriteString(file.Read("users/"..playeadm.."/legion/legion.txt", "data"))
net.Send(caller)
end
WLCList()
end)

hook.Add( "PlayerCanSeePlayersChat", "Maximum Range2", function( text, teamOnly, listener, talker )
if listener:GetPos():Distance( talker:GetPos() ) > 600 then 
return false
end
end )