// Make sure the clients get these files in order
AddCSLuaFile("cl_theme.lua");
AddCSLuaFile("cl_quotes.lua");
AddCSLuaFile("cl_chat.lua");