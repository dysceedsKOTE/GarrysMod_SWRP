if CLIENT then return end
local limittakeammo = 300

if not file.Exists("storage/baseammo", "data") then
file.CreateDir("storage/baseammo")
file.Write("storage/baseammo/baseammo.txt", "0")
file.CreateDir("storage/rpgammo")
file.Write("storage/rpgammo/rpgammo.txt", "0")
end

-----
util.AddNetworkString("ammowhitelistsendclient")
-----
util.AddNetworkString("ammoserversendinfotakeammo")
util.AddNetworkString("ammoserversendinfo")
util.AddNetworkString("ammoserversendinfo2")
util.AddNetworkString("ammoserversendinfo3")
util.AddNetworkString("ammoserversendinfo4")
util.AddNetworkString("ammoserversendinfoadm")

util.AddNetworkString("ammoserverwlgrensend2")
net.Receive("ammoserverwlgrensend2", function()
local user = net.ReadEntity()
if file.Read("storage/baseammo/baseammo.txt", "data") + 0 >= 500 then
file.Write("storage/baseammo/baseammo.txt", file.Read("storage/baseammo/baseammo.txt", "data") - 500)
user:Give("ammocrate_sweep", false)
end
end)

net.Receive("ammoserversendinfotakeammo", function()
local user = net.ReadEntity()
local ammo = net.ReadString()
local ammonum = (ammo + 0)
limittakeammo = ammonum
end)

net.Receive("ammoserversendinfo", function()
local user = net.ReadEntity()
local ammo = net.ReadString()
local ammonum = (ammo + 0)
ammonum = math.ceil( ammonum )
if (ammonum <= 0) then return end
if (ammonum > 0) then
if ((user:GetAmmoCount(1) > 0) and (user:GetAmmoCount(1) >= (ammonum + 0))) then
user:RemoveAmmo( ammonum, 1 )
local ammoin = file.Read("storage/baseammo/baseammo.txt", "data")
local readyammo = (ammoin + ammonum)
file.Write("storage/baseammo/baseammo.txt", readyammo)
end
end
end)

net.Receive("ammoserversendinfo2", function()
local user = net.ReadEntity()
local ammoboost = file.Read("users/"..user:SteamID64().."/level/ammoboost.txt")
local ammo = net.ReadString()
local ammonum = (ammo + 0)
ammonum = math.ceil( ammonum )
if (ammonum <= 0) then return end
if (ammonum > 0) then
if ((user:GetAmmoCount(1) < math.ceil(limittakeammo * ammoboost)) and ((user:GetAmmoCount(1) + ammonum) <= math.ceil(limittakeammo * ammoboost)) and (ammonum <= (file.Read("storage/baseammo/baseammo.txt", "data") + 0))) then
user:GiveAmmo( ammonum, 1, false )
local ammoin = file.Read("storage/baseammo/baseammo.txt", "data")
local readyammo = (ammoin - ammonum)
file.Write("storage/baseammo/baseammo.txt", readyammo)
end
end
end)

net.Receive("ammoserversendinfo3", function()
local user = net.ReadEntity()
local ammoboost = file.Read("users/"..user:SteamID64().."/level/ammoboost.txt")
if (user:GetAmmoCount(1) < math.ceil(limittakeammo * ammoboost)) then
local keksik = (math.ceil(limittakeammo * ammoboost) - user:GetAmmoCount(1))
if (keksik <= (file.Read("storage/baseammo/baseammo.txt", "data") + 0)) then
user:GiveAmmo( keksik, 1, false )
local ammoin = file.Read("storage/baseammo/baseammo.txt", "data")
local readyammo = (ammoin - keksik)
file.Write("storage/baseammo/baseammo.txt", readyammo)
else
local ammoin = file.Read("storage/baseammo/baseammo.txt", "data")
user:GiveAmmo( ammoin, 1, false )
local readyammo = (ammoin - ammoin)
file.Write("storage/baseammo/baseammo.txt", readyammo)
end
end
end)

net.Receive("ammoserversendinfo4", function()
local user = net.ReadEntity()
local ammoboost = file.Read("users/"..user:SteamID64().."/level/ammoboost.txt")
if (user:GetAmmoCount(1) < math.ceil(limittakeammo * ammoboost)) then
local keksik = user:GetAmmoCount(1)
user:RemoveAmmo( keksik, 1 )
local ammoin = file.Read("storage/baseammo/baseammo.txt", "data")
local readyammo = (ammoin + keksik)
file.Write("storage/baseammo/baseammo.txt", readyammo)
end
if (user:GetAmmoCount(1) >= math.ceil(limittakeammo * ammoboost)) then
local seksik = user:GetAmmoCount(1)
user:RemoveAmmo( seksik, 1 )
local ammoin = file.Read("storage/baseammo/baseammo.txt", "data")
local readyammo = (ammoin + seksik)
file.Write("storage/baseammo/baseammo.txt", readyammo)
end
end)

net.Receive("ammoserversendinfoadm", function()
local user = net.ReadEntity()
local ammo = net.ReadString()
local ammonum = (ammo + 0)
ammonum = math.ceil( ammonum )
if (file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "owner" or file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "highadmin") then
file.Write("storage/baseammo/baseammo.txt", ammonum)
end
end)

----ВВЕРХУ ПАТРОНЫ БАЗЫ