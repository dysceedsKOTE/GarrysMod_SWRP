if CLIENT then return end
local limittakeammorpg = 3

if not file.Exists("storage/baseammo", "data") then
file.CreateDir("storage/baseammo")
file.Write("storage/baseammo/baseammo.txt", "0")
file.CreateDir("storage/rpgammo")
file.Write("storage/rpgammo/rpgammo.txt", "0")
end
----ВНИЗУ ГРАНАТЫ

-----
util.AddNetworkString("ammowhitelistsendclient2")
-----
util.AddNetworkString("ammoserversendinfotakeammo2")
util.AddNetworkString("ammoserversendinfo1")
util.AddNetworkString("ammoserversendinfo22")
util.AddNetworkString("ammoserversendinfo32")
util.AddNetworkString("ammoserversendinfo42")
util.AddNetworkString("ammoserversendinfoadm2")

util.AddNetworkString("ammoserverwlgrensend")
net.Receive("ammoserverwlgrensend", function()
local user = net.ReadEntity()
local granboost = file.Read("users/"..user:SteamID64().."/level/granboost.txt")
local weap1 = file.Read("users/"..user:SteamID64().."/weaponfirst/weaponfirst.txt", "data")
local weap2 = file.Read("users/"..user:SteamID64().."/weaponsecond/weaponsecond.txt", "data")
local gren = file.Read("users/"..user:SteamID64().."/weapongrenade/weapongrenade.txt", "data")
local gren2 = file.Read("users/"..user:SteamID64().."/weapongrenade2/weapongrenade2.txt", "data")
local knife = file.Read("users/"..user:SteamID64().."/weaponknife/weaponknife.txt", "data")
local wlutil = file.Read("users/"..user:SteamID64().."/utiles/utiles.txt", "data")
local wlutil2 = file.Read("users/"..user:SteamID64().."/utiles2/utiles2.txt", "data")
if not user:HasWeapon( weap1 ) then
user:Give( weap1 )
user:GiveAmmo( granboost, "grenade", false )
end
if not user:HasWeapon( weap2 ) then
user:Give( weap2 )
user:GiveAmmo( granboost, "grenade", false )
end
if not user:HasWeapon( gren ) then
user:Give( gren )
user:GiveAmmo( granboost, "grenade", false )
end
if not user:HasWeapon( gren2 ) then
user:Give( gren2 )
user:GiveAmmo( granboost, "grenade", false )
end
if not user:HasWeapon( knife ) then
user:Give( knife )
user:GiveAmmo( granboost, "grenade", false )
end
if not user:HasWeapon( wlutil ) then
user:Give( wlutil )
user:GiveAmmo( granboost, "grenade", false )
end
if not user:HasWeapon( wlutil2 ) then
user:Give( wlutil2 )
user:GiveAmmo( granboost, "grenade", false )
end
end)

net.Receive("ammoserversendinfotakeammo2", function()
local user = net.ReadEntity()
local ammo = net.ReadString()
local ammonum = (ammo + 0)
limittakeammorpg = ammonum
end)

net.Receive("ammoserversendinfo1", function()
local user = net.ReadEntity()
local ammo = net.ReadString()
local ammonum = (ammo + 0)
ammonum = math.ceil( ammonum )
if (ammonum <= 0) then return end
if (ammonum > 0) then
if ((user:GetAmmoCount(8) > 0) and (user:GetAmmoCount(8) >= (ammonum + 0))) then
user:RemoveAmmo( ammonum, 8 )
local ammoin = file.Read("storage/rpgammo/rpgammo.txt", "data")
local readyammo = (ammoin + ammonum)
file.Write("storage/rpgammo/rpgammo.txt", readyammo)
end
end
end)

net.Receive("ammoserversendinfo22", function()
local user = net.ReadEntity()
local granboost = file.Read("users/"..user:SteamID64().."/level/granboost.txt")
local ammo = net.ReadString()
local ammonum = (ammo + 0)
ammonum = math.ceil( ammonum )
if (ammonum <= 0) then return end
if (ammonum > 0) then
if ((user:GetAmmoCount(8) < limittakeammorpg + granboost) and ((user:GetAmmoCount(8) + ammonum) <= limittakeammorpg + granboost) and (ammonum <= (file.Read("storage/rpgammo/rpgammo.txt", "data") + 0))) then
user:GiveAmmo( ammonum, 8, false )
local ammoin = file.Read("storage/rpgammo/rpgammo.txt", "data")
local readyammo = (ammoin - ammonum)
file.Write("storage/rpgammo/rpgammo.txt", readyammo)
end
end
end)

net.Receive("ammoserversendinfo32", function()
local user = net.ReadEntity()
local granboost = file.Read("users/"..user:SteamID64().."/level/granboost.txt")
if (user:GetAmmoCount(8) < limittakeammorpg + granboost) then
local keksik = ((limittakeammorpg + granboost) - user:GetAmmoCount(8))
if (keksik <= (file.Read("storage/rpgammo/rpgammo.txt", "data") + 0)) then
user:GiveAmmo( keksik, 8, false )
local ammoin = file.Read("storage/rpgammo/rpgammo.txt", "data")
local readyammo = (ammoin - keksik)
file.Write("storage/rpgammo/rpgammo.txt", readyammo)
else
local ammoin = file.Read("storage/rpgammo/rpgammo.txt", "data")
user:GiveAmmo( ammoin, 8, false )
local readyammo = (ammoin - ammoin)
file.Write("storage/rpgammo/rpgammo.txt", readyammo)
end
end
end)

net.Receive("ammoserversendinfo42", function()
local user = net.ReadEntity()
local granboost = file.Read("users/"..user:SteamID64().."/level/granboost.txt")
if (user:GetAmmoCount(8) < limittakeammorpg + granboost) then
local keksik = user:GetAmmoCount(8)
user:RemoveAmmo( keksik, 8 )
local ammoin = file.Read("storage/rpgammo/rpgammo.txt", "data")
local readyammo = (ammoin + keksik)
file.Write("storage/rpgammo/rpgammo.txt", readyammo)
end
if (user:GetAmmoCount(8) >= limittakeammorpg + granboost) then
local seksik = user:GetAmmoCount(8)
user:RemoveAmmo( seksik, 8 )
local ammoin = file.Read("storage/rpgammo/rpgammo.txt", "data")
local readyammo = (ammoin + seksik)
file.Write("storage/rpgammo/rpgammo.txt", readyammo)
end
end)

net.Receive("ammoserversendinfoadm2", function()
local user = net.ReadEntity()
local ammo = net.ReadString()
local ammonum = (ammo + 0)
ammonum = math.ceil( ammonum )
if (file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "owner" or file.Read("users/"..user:SteamID64().."/admin/admin.txt", "data") == "highadmin") then
file.Write("storage/rpgammo/rpgammo.txt", ammonum)
end
end)