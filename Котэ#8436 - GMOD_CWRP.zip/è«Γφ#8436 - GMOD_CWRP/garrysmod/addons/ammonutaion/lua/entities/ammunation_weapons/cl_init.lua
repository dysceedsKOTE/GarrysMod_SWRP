include('shared.lua')

function ENT:Draw()
	self:DrawModel()
	
end

surface.CreateFont( 'buttonammo', {
	font = 'Exo 2 Semi Bold',
	extended = true,
	size = 30,
	weight = 500,
	antialias = true,
	underline = false,
	shadow = true,
} )

local function Draw3DText( pos, ang, scale, text, flipView )
	if ( flipView ) then
		-- Flip the angle 180 degrees around the UP axis
		ang:RotateAroundAxis( Vector( 0, 0, 1 ), 180 )
	end

	cam.Start3D2D( pos, ang, scale )
		-- Actually draw the text. Customize this to your liking.
		draw.DrawText( text, "InfoHP", 0, 0, Color( 218, 218, 218, 255 ), TEXT_ALIGN_CENTER )
	cam.End3D2D()
end

function ENT:Draw()
	-- Draw the model
	self:DrawModel()

	-- The text to display
	local text = "Арсенал"

	-- The position. We use model bounds to make the text appear just above the model. Customize this to your liking.
	local mins, maxs = self:GetModelBounds()
	local pos = self:GetPos() + Vector( 0, 0, maxs.z + 10 )

	-- The angle
	local ang = Angle( 0, SysTime() * 100 % 360, 90 )

	-- Draw front
	Draw3DText( pos, ang, 0.3, text, true )
	-- DrawDraw3DTextback
	Draw3DText( pos, ang, 0.3, text, true )
end

---- NET
net.Receive("ammowhitelistsendclient3", function()
local plymdls = net.ReadString()
local plyskin = net.ReadString()
local plybodyg = net.ReadString()
local plyadmin = net.ReadString()
local legion = net.ReadString()
local firweap = net.ReadString()
local secweap = net.ReadString()
local firgren = net.ReadString()
local secgren = net.ReadString()
local knife = net.ReadString()
local utilka = net.ReadString()
local utilka2 = net.ReadString()
local skind = (plyskin + 0)
local DFrameammo = vgui.Create( "DFrame" )
DFrameammo:SetSize( ScrW()*0.4,ScrH()*0.6 )
DFrameammo:Center()
DFrameammo:SetTitle( "Арсенал" )
DFrameammo:SetDraggable( true )
DFrameammo:ShowCloseButton( true )
DFrameammo:MakePopup()
DFrameammo.Paint = function( self, w, h ) -- 'function Frame:Paint( w, h )' works too
	draw.RoundedBox( 0, 0, 0, w, h, Color( 100, 100, 200, 150 ) ) -- Draw a red box instead of the frame
	surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
    surface.DrawOutlinedRect( 0, 0, w, h )
end
if util.IsValidModel( plymdls ) == false then
plymdls = "models/breen.mdl"
end
local icon = vgui.Create( "DModelPanel", DFrameammo )
icon:SetSize(ScrW()*0.5, ScrH()*0.67)
icon:SetPos(ScrW()*0.05, ScrH()*0.125)
icon:SetModel(plymdls)
icon:GetEntity():SetSkin(skind)
icon:GetEntity():SetBodyGroups(plybodyg)
function icon:LayoutEntity( Entity ) return end -- disables default rotation
function icon.Entity:GetPlayerColor() return Vector (1, 0, 0) end 


local DScrollPanel = vgui.Create( "DScrollPanel", DFrameammo )
DScrollPanel:SetSize(ScrW()*0.16, ScrH()*0.32)
DScrollPanel:SetPos(ScrW()*0.04, ScrH()*0.1)
local sbar = DScrollPanel:GetVBar()
function sbar:Paint(w, h)
	draw.RoundedBox(0, 0, 0, w, h, Color(255, 255, 255, 255))
end
function sbar.btnUp:Paint(w, h)
	draw.RoundedBox(0, 0, 0, w, h, Color(100, 100, 100))
end
function sbar.btnDown:Paint(w, h)
	draw.RoundedBox(0, 0, 0, w, h, Color(100, 100, 100))
end
function sbar.btnGrip:Paint(w, h)
	draw.RoundedBox(0, 0, 0, w, h, Color(100, 100, 100))
end

if firweap != "arms" then
local firtext = "ВЗЯТЬ ОСНОВНОЕ"
if LocalPlayer():HasWeapon(firweap) then
firtext = "ОСТАВИТЬ ОСНОВНОЕ"
end
local buttoncolfir = Color( 100, 100, 200, 255 )
local DermaButton = DScrollPanel:Add( "DButton" )
DermaButton:SetText( "" )					
DermaButton:SetSize(ScrW()*0.16, ScrH()*0.04)
DermaButton:Dock( TOP )
DermaButton:DockMargin( 0, 0, 0, 5 )
function DermaButton:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, buttoncolfir )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText(firtext,'buttonammo',w*0.5,h*0.1,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end
DermaButton.OnCursorEntered = function()
buttoncolfir = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
DermaButton.OnCursorExited = function()
buttoncolfir = Color( 100, 100, 200, 255 )
end
DermaButton.DoClick = function()
-------------
if LocalPlayer():HasWeapon(firweap) then
firtext = "ВЗЯТЬ ОСНОВНОЕ"
local function sendclimyammo()
net.Start('weaponsneedgetmain2')
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
sendclimyammo()
else
firtext = "ОСТАВИТЬ ОСНОВНОЕ"
local function sendclimyammo()
net.Start('weaponsneedgetmain')
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
sendclimyammo()
end
-------------				
end
end

if secweap != "arms" then
local sectext = 'ВЗЯТЬ ВТОРИЧНОЕ'
if LocalPlayer():HasWeapon(secweap) then
sectext = "ОСТАВИТЬ ВТОРИЧНОЕ"
end
local buttoncolfir = Color( 100, 100, 200, 255 )
local DermaButton = DScrollPanel:Add( "DButton" )
DermaButton:SetText( "" )					
DermaButton:SetSize(ScrW()*0.16, ScrH()*0.04)
DermaButton:Dock( TOP )
DermaButton:DockMargin( 0, 0, 0, 5 )
function DermaButton:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, buttoncolfir )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText(sectext,'buttonammo',w*0.5,h*0.1,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end
DermaButton.OnCursorEntered = function()
buttoncolfir = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
DermaButton.OnCursorExited = function()
buttoncolfir = Color( 100, 100, 200, 255 )
end
DermaButton.DoClick = function()
-------------
if LocalPlayer():HasWeapon(secweap) then
sectext = "ВЗЯТЬ ВТОРИЧНОЕ"
local function sendclimyammo()
net.Start('weaponsneedgetsec2')
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
sendclimyammo()
else
sectext = "ОСТАВИТЬ ВТОРИЧНОЕ"
local function sendclimyammo()
net.Start('weaponsneedgetsec')
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
sendclimyammo()
end
-------------				
end
end

if firgren != "arms" then
local grentext = 'ВЗЯТЬ ГРАНАТУ'
if LocalPlayer():HasWeapon(firgren) then
grentext = "ОСТАВИТЬ ГРАНАТУ"
end
local buttoncolfir = Color( 100, 100, 200, 255 )
local DermaButton = DScrollPanel:Add( "DButton" )
DermaButton:SetText( "" )					
DermaButton:SetSize(ScrW()*0.16, ScrH()*0.04)
DermaButton:Dock( TOP )
DermaButton:DockMargin( 0, 0, 0, 5 )
function DermaButton:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, buttoncolfir )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText(grentext,'buttonammo',w*0.5,h*0.1,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end
DermaButton.OnCursorEntered = function()
buttoncolfir = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
DermaButton.OnCursorExited = function()
buttoncolfir = Color( 100, 100, 200, 255 )
end
DermaButton.DoClick = function()
-------------
if LocalPlayer():HasWeapon(firgren) then
grentext = "ВЗЯТЬ ГРАНАТУ"
local function sendclimyammo()
net.Start('weaponsneedgetgren2')
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
sendclimyammo()
else
grentext = "ОСТАВИТЬ ГРАНАТУ"
local function sendclimyammo()
net.Start('weaponsneedgetgren')
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
sendclimyammo()
end
-------------				
end
end

if secgren != "arms" then
local secgrentext = 'ВЗЯТЬ ГРАНАТУ 2'
if LocalPlayer():HasWeapon(secgren) then
secgrentext = "ОСТАВИТЬ ГРАНАТУ 2"
end
local buttoncolfir = Color( 100, 100, 200, 255 )
local DermaButton = DScrollPanel:Add( "DButton" )
DermaButton:SetText( "" )					
DermaButton:SetSize(ScrW()*0.16, ScrH()*0.04)
DermaButton:Dock( TOP )
DermaButton:DockMargin( 0, 0, 0, 5 )
function DermaButton:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, buttoncolfir )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText(secgrentext,'buttonammo',w*0.5,h*0.1,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end
DermaButton.OnCursorEntered = function()
buttoncolfir = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
DermaButton.OnCursorExited = function()
buttoncolfir = Color( 100, 100, 200, 255 )
end
DermaButton.DoClick = function()
-------------
if LocalPlayer():HasWeapon(secgren) then
secgrentext = "ВЗЯТЬ ГРАНАТУ 2"
local function sendclimyammo()
net.Start('weaponsneedgetsecgren2')
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
sendclimyammo()
else
secgrentext = "ОСТАВИТЬ ГРАНАТУ 2"
local function sendclimyammo()
net.Start('weaponsneedgetsecgren')
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
sendclimyammo()
end
-------------				
end
end

if knife != "arms" then
local knifetext = 'ВЗЯТЬ ХОЛОДНОЕ'
if LocalPlayer():HasWeapon(knife) then
knifetext = "ОСТАВИТЬ ХОЛОДНОЕ"
end
local buttoncolfir = Color( 100, 100, 200, 255 )
local DermaButton = DScrollPanel:Add( "DButton" )
DermaButton:SetText( "" )					
DermaButton:SetSize(ScrW()*0.16, ScrH()*0.04)
DermaButton:Dock( TOP )
DermaButton:DockMargin( 0, 0, 0, 5 )
function DermaButton:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, buttoncolfir )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText(knifetext,'buttonammo',w*0.5,h*0.1,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end
DermaButton.OnCursorEntered = function()
buttoncolfir = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
DermaButton.OnCursorExited = function()
buttoncolfir = Color( 100, 100, 200, 255 )
end
DermaButton.DoClick = function()
-------------
if LocalPlayer():HasWeapon(knife) then
knifetext = "ВЗЯТЬ ХОЛОДНОЕ"
local function sendclimyammo()
net.Start('weaponsneedgetsecknife2')
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
sendclimyammo()
else
knifetext = "ОСТАВИТЬ ХОЛОДНОЕ"
local function sendclimyammo()
net.Start('weaponsneedgetsecknife')
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
sendclimyammo()
end
-------------				
end
end

if utilka != "arms" then
local utiltext = 'ВЗЯТЬ ОСОБОЕ'
if LocalPlayer():HasWeapon(utilka) then
utiltext = "ОСТАВИТЬ ОСОБОЕ"
end
local buttoncolfir = Color( 100, 100, 200, 255 )
local DermaButton = DScrollPanel:Add( "DButton" )
DermaButton:SetText( "" )					
DermaButton:SetSize(ScrW()*0.16, ScrH()*0.04)
DermaButton:Dock( TOP )
DermaButton:DockMargin( 0, 0, 0, 5 )
function DermaButton:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, buttoncolfir )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText(utiltext,'buttonammo',w*0.5,h*0.1,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end
DermaButton.OnCursorEntered = function()
buttoncolfir = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
DermaButton.OnCursorExited = function()
buttoncolfir = Color( 100, 100, 200, 255 )
end
DermaButton.DoClick = function()
-------------
if LocalPlayer():HasWeapon(utilka) then
utiltext = "ВЗЯТЬ ОСОБОЕ"
local function sendclimyammo()
net.Start('weaponsneedgetutil2')
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
sendclimyammo()
else
utiltext = "ОСТАВИТЬ ОСОБОЕ"
local function sendclimyammo()
net.Start('weaponsneedgetutil')
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
sendclimyammo()
end
-------------
end
end

if utilka2 != "arms" then
local util2text = 'ВЗЯТЬ ОСОБОЕ 2'
if LocalPlayer():HasWeapon(utilka2) then
util2text = "ОСТАВИТЬ ОСОБОЕ 2"
end
local buttoncolfir = Color( 100, 100, 200, 255 )
local DermaButton = DScrollPanel:Add( "DButton" )
DermaButton:SetText( "" )					
DermaButton:SetSize(ScrW()*0.16, ScrH()*0.04)
DermaButton:Dock( TOP )
DermaButton:DockMargin( 0, 0, 0, 5 )
function DermaButton:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, buttoncolfir )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText(util2text,'buttonammo',w*0.5,h*0.1,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end
DermaButton.OnCursorEntered = function()
buttoncolfir = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
DermaButton.OnCursorExited = function()
buttoncolfir = Color( 100, 100, 200, 255 )
end
DermaButton.DoClick = function()
-------------
if LocalPlayer():HasWeapon(utilka2) then
util2text = "ВЗЯТЬ ОСОБОЕ 2"
local function sendclimyammo()
net.Start('weaponsneedgetsecutil2')
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
sendclimyammo()
else
util2text = "ОСТАВИТЬ ОСОБОЕ 2"
local function sendclimyammo()
net.Start('weaponsneedgetsecutil')
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
sendclimyammo()
end
-------------
end
end

if legion == "574-К" then
local buttoncolfour = Color( 100, 100, 200, 255 )
local DermaButton = vgui.Create( "DButton", DFrameammo ) 
DermaButton:SetText( "" )					
DermaButton:SetSize(ScrW()*0.16, ScrH()*0.04)
DermaButton:SetPos(ScrW()*0.04, ScrH()*0.5)
function DermaButton:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, buttoncolfour )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText('ВЗЯТЬ ЯЩИК БРОНИ','buttonammo',w*0.5,h*0.1,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end
DermaButton.OnCursorEntered = function()
buttoncolfour = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
DermaButton.OnCursorExited = function()
if IsValid( TextEntryKEK23 ) then return end;
if IsValid( richtextusjaloba ) then return end;
buttoncolfour = Color( 100, 100, 200, 255 )
end						
DermaButton.DoClick = function()				
local function senserv4ammonut()
net.Start('weaponsendgetammocrate')   
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
senserv4ammonut()			
end
end

local buttoncolfour = Color( 100, 100, 200, 255 )
local DermaButton = vgui.Create( "DButton", DFrameammo ) 
DermaButton:SetText( "" )					
DermaButton:SetSize(ScrW()*0.16, ScrH()*0.04)
DermaButton:SetPos(ScrW()*0.04, ScrH()*0.4565)
function DermaButton:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, buttoncolfour )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText('ВОСПОЛНИТЬ БРОНЮ','buttonammo',w*0.5,h*0.1,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end
DermaButton.OnCursorEntered = function()
buttoncolfour = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
DermaButton.OnCursorExited = function()
if IsValid( TextEntryKEK23 ) then return end;
if IsValid( richtextusjaloba ) then return end;
buttoncolfour = Color( 100, 100, 200, 255 )
end						
DermaButton.DoClick = function()				
local function senserv4ammonut()
net.Start('weaponsendgetammocrate2')   
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
senserv4ammonut()			
end

end)
