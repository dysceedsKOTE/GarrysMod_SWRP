AddCSLuaFile("shared.lua")
AddCSLuaFile("cl_init.lua")
include("shared.lua")

function ENT:Initialize()
	self:SetModel('models/starwars/syphadias/props/hoth_barrack/small_box.mdl')

	self:PhysicsInit( SOLID_VPHYSICS )
	self:SetMoveType( MOVETYPE_VPHYSICS )
	self:SetSolid( SOLID_VPHYSICS )
	self:SetSkin( 1 )
	self:SetUseType( SIMPLE_USE )
    self.ProtalVector = false
    self:SetNWInt("ammo_has_on_crate", 500)
    self:SetHealth( 500 )

	-- Wake the physics object up
	local phys = self.Entity:GetPhysicsObject()
	if (phys:IsValid()) then
		phys:EnableMotion( false )
		phys:Wake()
	end
end


function ENT:Use( activator, caller )
if IsValid( activator ) and activator:IsPlayer() then
if self:GetNWInt("ammo_has_on_crate") > 0 then
self:SetNWInt("ammo_has_on_crate", self:GetNWInt("ammo_has_on_crate") - 50)
activator:GiveAmmo(50, "AR2", false)
if self:GetNWInt("ammo_has_on_crate") == 0 then
self:Remove()
end
else
self:Remove()
end
end
end

function ENT:OnTakeDamage(dmg)
self:SetHealth( self:Health() - 50 )
if self:Health() <= 0 then
local explosion = ents.Create( "env_explosion" ) -- The explosion entity
	explosion:SetPos( self:GetPos() ) -- Put the position of the explosion at the position of the entity
	explosion:Spawn() -- Spawn the explosion
	explosion:SetKeyValue( "iMagnitude", "50" ) -- the magnitude of the explosion
	explosion:Fire( "Explode", 0, 0 ) -- explode
self:Remove()
end
end