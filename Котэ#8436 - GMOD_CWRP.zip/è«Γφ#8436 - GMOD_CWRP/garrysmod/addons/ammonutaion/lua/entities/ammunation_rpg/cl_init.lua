include('shared.lua')

function ENT:Draw()
	self:DrawModel()
	
end

surface.CreateFont( 'buttonammo', {
	font = 'Exo 2 Semi Bold',
	extended = true,
	size = 30,
	weight = 500,
	antialias = true,
	underline = false,
	shadow = true,
} )

local function Draw3DText( pos, ang, scale, text, flipView )
	if ( flipView ) then
		-- Flip the angle 180 degrees around the UP axis
		ang:RotateAroundAxis( Vector( 0, 0, 1 ), 180 )
	end

	cam.Start3D2D( pos, ang, scale )
		-- Actually draw the text. Customize this to your liking.
		draw.DrawText( text, "InfoHP", 0, 0, Color( 218, 218, 218, 255 ), TEXT_ALIGN_CENTER )
	cam.End3D2D()
end

function ENT:Draw()
	-- Draw the model
	self:DrawModel()

	-- The text to display
	local text = "Взрывчатка"

	-- The position. We use model bounds to make the text appear just above the model. Customize this to your liking.
	local mins, maxs = self:GetModelBounds()
	local pos = self:GetPos() + Vector( 0, 0, maxs.z + 10 )

	-- The angle
	local ang = Angle( 0, SysTime() * 100 % 360, 90 )

	-- Draw front
	Draw3DText( pos, ang, 0.3, text, true )
	-- DrawDraw3DTextback
	Draw3DText( pos, ang, 0.3, text, true )
end

---- NET
net.Receive("ammowhitelistsendclient2", function()
local ammoleft = net.ReadString()
local plymdls = net.ReadString()
local plyskin = net.ReadString()
local plybodyg = net.ReadString()
local plyadmin = net.ReadString()
local skind = (plyskin + 0)
local DFrameammo = vgui.Create( "DFrame" )
DFrameammo:SetSize( ScrW()*0.4,ScrH()*0.6 )
DFrameammo:Center()
DFrameammo:SetTitle( "Запас".." | "..ammoleft.." ракет" )
DFrameammo:SetDraggable( true )
DFrameammo:ShowCloseButton( true )
DFrameammo:MakePopup()
DFrameammo.Paint = function( self, w, h ) -- 'function Frame:Paint( w, h )' works too
	draw.RoundedBox( 0, 0, 0, w, h, Color( 100, 100, 200, 150 ) ) -- Draw a red box instead of the frame
	surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
    surface.DrawOutlinedRect( 0, 0, w, h )
    draw.SimpleText( "Ваш боезапас | "..LocalPlayer():GetAmmoCount(8), "littleInfoHP", w*0.1, h*0.125, Color(255,255,255) )
end

if util.IsValidModel( plymdls ) == false then
plymdls = "models/breen.mdl"
end
local icon = vgui.Create( "DModelPanel", DFrameammo )
icon:SetSize(ScrW()*0.5, ScrH()*0.67)
icon:SetPos(ScrW()*0.05, ScrH()*0.125)
icon:SetModel(plymdls)
icon:GetEntity():SetSkin(skind)
icon:GetEntity():SetBodyGroups(plybodyg)
function icon:LayoutEntity( Entity ) return end -- disables default rotation
function icon.Entity:GetPlayerColor() return Vector (1, 0, 0) end 

TextEntryPHyesd = vgui.Create( "DTextEntry", DFrameammo )
TextEntryPHyesd:SetSize(ScrW()*0.16, ScrH()*0.02)
TextEntryPHyesd:SetPos(ScrW()*0.04, ScrH()*0.195)
TextEntryPHyesd:DockMargin( 0, 5, 0, 0 )
TextEntryPHyesd:SetPlaceholderText( "Введите кол-во" )

local buttoncolfir = Color( 100, 100, 200, 255 )
local DermaButton = vgui.Create( "DButton", DFrameammo )
DermaButton:SetText( "" )					
DermaButton:SetSize(ScrW()*0.16, ScrH()*0.04)
DermaButton:SetPos(ScrW()*0.04, ScrH()*0.15)
function DermaButton:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, buttoncolfir )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText('ВЫЛОЖИТЬ','buttonammo',w*0.5,h*0.1,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end
DermaButton.OnCursorEntered = function()
buttoncolfir = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
DermaButton.OnCursorExited = function()
if IsValid( TextEntryKEK23 ) then return end;
if IsValid( richtextusjaloba ) then return end;
buttoncolfir = Color( 100, 100, 200, 255 )
end
DermaButton.DoClick = function()				
local function senservammonut()
net.Start('ammoserversendinfo1')   
net.WriteEntity(LocalPlayer())
net.WriteString(TextEntryPHyesd:GetValue())
net.SendToServer()
end
senservammonut()
end

local buttoncoltwo = Color( 100, 100, 200, 255 )
local DermaButton = vgui.Create( "DButton", DFrameammo ) 
DermaButton:SetText( "" )					
DermaButton:SetSize(ScrW()*0.16, ScrH()*0.04)
DermaButton:SetPos(ScrW()*0.04, ScrH()*0.220)
function DermaButton:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, buttoncoltwo )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText('ЗАБРАТЬ','buttonammo',w*0.5,h*0.1,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end
DermaButton.OnCursorEntered = function()
buttoncoltwo = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
DermaButton.OnCursorExited = function()
if IsValid( TextEntryKEK23 ) then return end;
if IsValid( richtextusjaloba ) then return end;
buttoncoltwo = Color( 100, 100, 200, 255 )
end				
DermaButton.DoClick = function()				
local function senserv2ammonut()
net.Start('ammoserversendinfo22')   
net.WriteEntity(LocalPlayer())
net.WriteString(TextEntryPHyesd:GetValue())
net.SendToServer()
end
senserv2ammonut()			
end

local buttoncoltri = Color( 100, 100, 200, 255 )
local DermaButton = vgui.Create( "DButton", DFrameammo ) 
DermaButton:SetText( "" )					
DermaButton:SetSize(ScrW()*0.16, ScrH()*0.04)
DermaButton:SetPos(ScrW()*0.04, ScrH()*0.27)
function DermaButton:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, buttoncoltri )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText('ДО МАКСИМУМА','buttonammo',w*0.5,h*0.1,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end
DermaButton.OnCursorEntered = function()
buttoncoltri = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
DermaButton.OnCursorExited = function()
if IsValid( TextEntryKEK23 ) then return end;
if IsValid( richtextusjaloba ) then return end;
buttoncoltri = Color( 100, 100, 200, 255 )
end				
DermaButton.DoClick = function()				
local function senserv3ammonut()
net.Start('ammoserversendinfo32')   
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
senserv3ammonut()			
end

local buttoncolfour = Color( 100, 100, 200, 255 )
local DermaButton = vgui.Create( "DButton", DFrameammo ) 
DermaButton:SetText( "" )					
DermaButton:SetSize(ScrW()*0.16, ScrH()*0.04)
DermaButton:SetPos(ScrW()*0.04, ScrH()*0.1)
function DermaButton:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, buttoncolfour )
surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.SimpleText('ДО МАКСИМУМА','buttonammo',w*0.5,h*0.1,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end
DermaButton.OnCursorEntered = function()
buttoncolfour = Color(155,155,255, 255)
surface.PlaySound('garrysmod/ui_hover.wav')
end 
DermaButton.OnCursorExited = function()
if IsValid( TextEntryKEK23 ) then return end;
if IsValid( richtextusjaloba ) then return end;
buttoncolfour = Color( 100, 100, 200, 255 )
end						
DermaButton.DoClick = function()				
local function senserv4ammonut()
net.Start('ammoserversendinfo42')   
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
senserv4ammonut()			
end

---local buttoncolfour = Color( 100, 100, 200, 255 )
---local DermaButton = vgui.Create( "DButton", DFrameammo ) 
---DermaButton:SetText( "" )					
---DermaButton:SetSize(ScrW()*0.16, ScrH()*0.04)
---DermaButton:SetPos(ScrW()*0.04, ScrH()*0.5)
---function DermaButton:Paint( w, h )
---draw.RoundedBox( 0, 0, 0, w, h, buttoncolfour )
---surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
---surface.DrawOutlinedRect( 0, 0, w, h )
---draw.SimpleText('Личная взрывчатка','buttonammo',w*0.5,h*0.1,Color(230,230,230), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
---end
---DermaButton.OnCursorEntered = function()
---buttoncolfour = Color(155,155,255, 255)
---surface.PlaySound('garrysmod/ui_hover.wav')
---end 
---DermaButton.OnCursorExited = function()
---if IsValid( TextEntryKEK23 ) then return end;
---if IsValid( richtextusjaloba ) then return end;
---buttoncolfour = Color( 100, 100, 200, 255 )
---end						
---DermaButton.DoClick = function()				
---local function senserv4ammonut()
---net.Start('ammoserverwlgrensend')   
---net.WriteEntity(LocalPlayer())
---net.SendToServer()
---end
---senserv4ammonut()			
---end

if (plyadmin == "owner" or plyadmin == "highadmin" or plyadmin == "admin") then
TextEntryPHyesd34 = vgui.Create( "DTextEntry", DFrameammo )
TextEntryPHyesd34:SetSize(ScrW()*0.16, ScrH()*0.02)
TextEntryPHyesd34:SetPos(ScrW()*0.04, ScrH()*0.33)
TextEntryPHyesd34:DockMargin( 0, 5, 0, 0 )
TextEntryPHyesd34:SetPlaceholderText( "Адм Патроны базы" )

local DermaButton = vgui.Create( "DButton", DFrameammo )
DermaButton:SetText( "Установить" )					
DermaButton:SetSize(ScrW()*0.16, ScrH()*0.02)
DermaButton:SetPos(ScrW()*0.04, ScrH()*0.35)				
DermaButton.DoClick = function()				
local function senservammonut234()
net.Start('ammoserversendinfoadm2')   
net.WriteEntity(LocalPlayer())
net.WriteString(TextEntryPHyesd34:GetValue())
net.SendToServer()
end
senservammonut234()
end

TextEntryPHyesd22 = vgui.Create( "DTextEntry", DFrameammo )
TextEntryPHyesd22:SetSize(ScrW()*0.16, ScrH()*0.02)
TextEntryPHyesd22:SetPos(ScrW()*0.04, ScrH()*0.38)
TextEntryPHyesd22:DockMargin( 0, 5, 0, 0 )
TextEntryPHyesd22:SetPlaceholderText( "Адм Лимит взять" )

local DermaButton = vgui.Create( "DButton", DFrameammo )
DermaButton:SetText( "Установить" )					
DermaButton:SetSize(ScrW()*0.16, ScrH()*0.02)
DermaButton:SetPos(ScrW()*0.04, ScrH()*0.4)			
DermaButton.DoClick = function()				
local function senservammonuted()
net.Start('ammoserversendinfotakeammo2')   
net.WriteEntity(LocalPlayer())
net.WriteString(TextEntryPHyesd22:GetValue())
net.SendToServer()
end
senservammonuted()
end
end

end)
