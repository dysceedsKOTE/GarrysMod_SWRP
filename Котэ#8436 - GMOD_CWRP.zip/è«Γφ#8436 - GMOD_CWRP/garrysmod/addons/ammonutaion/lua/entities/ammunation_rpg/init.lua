AddCSLuaFile("shared.lua")
AddCSLuaFile("cl_init.lua")
include("shared.lua")

function ENT:Initialize()
	self:SetModel('models/lordtrilobite/starwars/props/crate_yavin01_phys.mdl')

	self:PhysicsInit( SOLID_VPHYSICS )
	self:SetMoveType( MOVETYPE_VPHYSICS )
	self:SetSolid( SOLID_VPHYSICS )
	self:SetSkin( 1 )
	self:SetUseType( SIMPLE_USE )
    self.ProtalVector = false

	-- Wake the physics object up
	local phys = self.Entity:GetPhysicsObject()
	if (phys:IsValid()) then
		phys:EnableMotion( false )
		phys:Wake()
	end
end


function ENT:Use( activator, caller )
if CLIENT then return end;
if IsValid( activator ) and activator:IsPlayer() then
		
local function sendclimyammo()
net.Start('ammowhitelistsendclient2')
net.WriteString(file.Read("storage/rpgammo/rpgammo.txt", "data"))
net.WriteString(file.Read("users/"..activator:SteamID64().."/model/model.txt", "data"))
net.WriteString(file.Read("users/"..activator:SteamID64().."/skin/skin.txt", "data"))
net.WriteString(file.Read("users/"..activator:SteamID64().."/bodygroups/bodygroups.txt", "data"))
net.WriteString(file.Read("users/"..activator:SteamID64().."/admin/admin.txt", "data"))
net.Send(activator)
end
sendclimyammo()

	end

end