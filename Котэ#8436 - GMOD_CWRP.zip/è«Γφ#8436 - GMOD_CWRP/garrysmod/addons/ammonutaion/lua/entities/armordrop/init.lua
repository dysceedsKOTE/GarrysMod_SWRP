AddCSLuaFile("shared.lua")
AddCSLuaFile("cl_init.lua")
include("shared.lua")

function ENT:Initialize()
	self:SetModel('models/starwars/syphadias/props/hoth_barrack/medium_box.mdl')

	self:PhysicsInit( SOLID_VPHYSICS )
	self:SetMoveType( MOVETYPE_VPHYSICS )
	self:SetSolid( SOLID_VPHYSICS )
	self:SetSkin( 1 )
	self:SetUseType( SIMPLE_USE )
    self.ProtalVector = false
    self:SetNWInt("ammo_has_on_crate", 300)
    self:SetHealth( 500 )

	-- Wake the physics object up
	local phys = self.Entity:GetPhysicsObject()
	if (phys:IsValid()) then
		phys:EnableMotion( false )
		phys:Wake()
	end
end


function ENT:Use( activator, caller )
local kote = 0
---------------------
if IsValid( activator ) and activator:IsPlayer() then
--------
if self:GetNWInt("ammo_has_on_crate") > 0 then
----
if self:GetNWInt("ammo_has_on_crate") < 50 then
kote = activator:GetMaxArmor() - activator:Armor()
if kote < self:GetNWInt("ammo_has_on_crate") then
activator:SetArmor(activator:Armor() + kote)
self:SetNWInt("ammo_has_on_crate", self:GetNWInt("ammo_has_on_crate") - kote)
else
activator:SetArmor(activator:Armor() + self:GetNWInt("ammo_has_on_crate"))
self:SetNWInt("ammo_has_on_crate", self:GetNWInt("ammo_has_on_crate") - self:GetNWInt("ammo_has_on_crate"))
self:Remove()
end
else
kote = activator:GetMaxArmor() - activator:Armor()
if kote > 50 then
kote = 50
end
activator:SetArmor(activator:Armor() + kote)
self:SetNWInt("ammo_has_on_crate", self:GetNWInt("ammo_has_on_crate") - kote)
if self:GetNWInt("ammo_has_on_crate") == 0 then
self:Remove()
end
end
----
end
--------
end
--------------------
end

function ENT:OnTakeDamage(dmg)
self:SetHealth( self:Health() - 50 )
if self:Health() <= 0 then
self:Remove()
end
end