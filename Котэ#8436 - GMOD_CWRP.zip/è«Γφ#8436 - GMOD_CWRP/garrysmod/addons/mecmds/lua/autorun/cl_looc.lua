if SERVER then return end
net.Receive("loocclinit", function()
local text = net.ReadString()
local name = net.ReadString()
local number = net.ReadString()
local legion = net.ReadString()
chat.PlaySound()
chat.AddText( Color( 28, 144, 202 ), "[LOOC] ", Color( 225,255,255 ), "[ "..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").." | "..legion.." | "..name.." | "..number.." ]", Color( 255, 255, 255 ), " - ", Color( 225,255,255 ), text )
end)