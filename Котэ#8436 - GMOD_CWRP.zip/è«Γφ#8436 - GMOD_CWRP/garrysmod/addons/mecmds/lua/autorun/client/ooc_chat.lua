net.Receive( "DarkRP_Ooc", function( len, pl )
	local text = net.ReadString()
	local names = net.ReadString()
	local number = net.ReadString()
	local legion = net.ReadString()
	local ply = net.ReadEntity()
	if ( IsValid( ply ) and ply:IsPlayer() ) then
		chat.PlaySound()
		chat.AddText( Color( 28, 144, 202 ), "[OOC] ", Color( 225,255,255 ), "[ "..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").." | "..legion.." | "..names.." | "..number.." ]", Color( 255, 255, 255 ), " - ", Color( 225,255,255 ), text )
	end
end )