if SERVER then return end

net.Receive("trylinit", function()
local text = net.ReadString()
local name = net.ReadString()
local number = net.ReadString()
local legion = net.ReadString()
if (math.random(1,100) < 50) then
chislo = "[Не получилось]"
else
chislo = "[Получилось]"
end
chat.PlaySound()
chat.AddText( Color( 28, 144, 202 ), "[ "..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").." | "..legion.." | "..name.." | "..number.." ]".." "..text.." "..chislo )
end)

net.Receive("rolllinit", function()
local text = net.ReadString()
local name = net.ReadString()
local number = net.ReadString()
local legion = net.ReadString()
chat.PlaySound()
chat.AddText( Color( 28, 144, 202 ), "[ "..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").." | "..legion.." | "..name.." | "..number.." ]".." выбросил число "..math.random(1,100))
end)

net.Receive("dolinit", function()
local text = net.ReadString()
local name = net.ReadString()
local number = net.ReadString()
local legion = net.ReadString()
chat.PlaySound()
chat.AddText( Color( 28, 144, 202 ), "[ "..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").." | ".."Действие] "..text)
end)

net.Receive("itlinit", function()
local text = net.ReadString()
local name = net.ReadString()
local number = net.ReadString()
local legion = net.ReadString()
chat.PlaySound()
chat.AddText( Color( 28, 144, 202 ), "[ "..os.date("%H")..":"..os.date("%M")..":"..os.date("%S").." | ".."Описание] "..text)
end)