if CLIENT then return end

util.AddNetworkString( "trylinit" )
timer.Simple( 5, function()
	hook.Add( "PlayerSay", "DarkRP_tryclinit", function( ply, text, team )
		local test = string.lower( text )
		if ( string.sub( test, 1, 4 ) == "/try" ) or ( string.sub( test, 1, 4 ) == "!try" ) then
		local String = string.sub( text, 5 )
		    for i, v in ipairs( player.GetAll() ) do
            if ply:GetPos():DistToSqr(v:GetPos()) < 300000 then
			if String != "" then
				net.Start( "trylinit" )
				    net.WriteString( String )
                    net.WriteString( file.Read("users/"..ply:SteamID64().."/name/name.txt", "data") )
                    net.WriteString( file.Read("users/"..ply:SteamID64().."/number/number.txt", "data") )
                    net.WriteString( file.Read("users/"..ply:SteamID64().."/legion/legion.txt", "data") )
				net.Send(v)
			end 
			end
            end
			return ""
		end
	end )
end )

util.AddNetworkString( "rolllinit" )
timer.Simple( 5, function()
	hook.Add( "PlayerSay", "DarkRP_rollclinit", function( ply, text, team )
		local test = string.lower( text )
		if ( string.sub( test, 1, 5 ) == "/roll" ) or ( string.sub( test, 1, 5 ) == "!roll" ) then
		local String = string.sub( text, 5 )
		    for i, v in ipairs( player.GetAll() ) do
            if ply:GetPos():DistToSqr(v:GetPos()) < 300000 then
			if String != "" then
				net.Start( "rolllinit" )
				    net.WriteString( String )
                    net.WriteString( file.Read("users/"..ply:SteamID64().."/name/name.txt", "data") )
                    net.WriteString( file.Read("users/"..ply:SteamID64().."/number/number.txt", "data") )
                    net.WriteString( file.Read("users/"..ply:SteamID64().."/legion/legion.txt", "data") )
				net.Send(v)
			end 
			end
            end
			return ""
		end
	end )
end )

util.AddNetworkString( "dolinit" )
timer.Simple( 5, function()
	hook.Add( "PlayerSay", "DarkRP_doclinit", function( ply, text, team )
		local test = string.lower( text )
		if ( string.sub( test, 1, 3 ) == "/do" ) or ( string.sub( test, 1, 3 ) == "!do" ) then
		local String = string.sub( text, 4 )
		    for i, v in ipairs( player.GetAll() ) do
            if ply:GetPos():DistToSqr(v:GetPos()) < 300000 then
			if String != "" then
				net.Start( "dolinit" )
				    net.WriteString( String )
                    net.WriteString( file.Read("users/"..ply:SteamID64().."/name/name.txt", "data") )
                    net.WriteString( file.Read("users/"..ply:SteamID64().."/number/number.txt", "data") )
                    net.WriteString( file.Read("users/"..ply:SteamID64().."/legion/legion.txt", "data") )
				net.Send(v)
			end 
			end
            end
			return ""
		end
	end )
end )

util.AddNetworkString( "itlinit" )
timer.Simple( 5, function()
	hook.Add( "PlayerSay", "DarkRP_itclinit", function( ply, text, team )
		local test = string.lower( text )
		if ( string.sub( test, 1, 3 ) == "/it" ) or ( string.sub( test, 1, 3 ) == "!it" ) then
		local String = string.sub( text, 4 )
		    for i, v in ipairs( player.GetAll() ) do
            if ply:GetPos():DistToSqr(v:GetPos()) < 300000 then
			if String != "" then
				net.Start( "itlinit" )
				    net.WriteString( String )
                    net.WriteString( file.Read("users/"..ply:SteamID64().."/name/name.txt", "data") )
                    net.WriteString( file.Read("users/"..ply:SteamID64().."/number/number.txt", "data") )
                    net.WriteString( file.Read("users/"..ply:SteamID64().."/legion/legion.txt", "data") )
				net.Send(v)
			end 
			end
            end
			return ""
		end
	end )
end )