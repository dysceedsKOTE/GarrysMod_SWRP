if CLIENT then return end

util.AddNetworkString( "meelinit" )
timer.Simple( 5, function()
	hook.Add( "PlayerSay", "DarkRP_meeclinit", function( ply, text, team )
		local test = string.lower( text )
		if ( string.sub( test, 1, 3 ) == "/me" ) or ( string.sub( test, 1, 3 ) == "!me" ) then
		local String = string.sub( text, 4 )
		    for i, v in ipairs( player.GetAll() ) do
            if ply:GetPos():DistToSqr(v:GetPos()) < 300000 then
			if String != "" then
				net.Start( "meelinit" )
				    net.WriteString( String )
                    net.WriteString( file.Read("users/"..ply:SteamID64().."/name/name.txt", "data") )
                    net.WriteString( file.Read("users/"..ply:SteamID64().."/number/number.txt", "data") )
                    net.WriteString( file.Read("users/"..ply:SteamID64().."/legion/legion.txt", "data") )
				net.Send(v)
			end 
			end
            end
			return ""
		end
	end )
end )

util.AddNetworkString( "helmetcmdopen" )
util.AddNetworkString( "helmetcmdopen2" )
timer.Simple( 5, function()
	hook.Add( "PlayerSay", "DarkRP_helmetcmdopen", function( ply, text, team )
		local test = string.lower( text )
		if ( string.sub( test, 1, 7 ) == "/helmet" ) or ( string.sub( test, 1, 7 ) == "!helmet" ) then
			if ply:GetBodygroup( ply:FindBodygroupByName( "helmet" ) ) == 0 then
			ply:SetBodygroup( ply:FindBodygroupByName( "helmet" ), 3 )
			if ply:GetBodygroup( ply:FindBodygroupByName( "helmet" ) ) == 0 then
			ply:SetBodygroup( ply:FindBodygroupByName( "helmet" ), 1 )
			end	
			ply:SetBodygroup( ply:FindBodygroupByName( "helmet attachments" ), 0 )
			ply:SetBodygroup( ply:FindBodygroupByName( "Fleshlight" ), 0 )
			ply:SetBodygroup( ply:FindBodygroupByName( "Sunvisor" ), 0 )
			ply:SetBodygroup( ply:FindBodygroupByName( "Antenna" ), 0 )
			ply:SetBodygroup( ply:FindBodygroupByName( "Macrobinoculars" ), 0 )
			ply:SetBodygroup( ply:FindBodygroupByName( "Flesh lights" ), 0 )
			for i, v in ipairs( player.GetAll() ) do
            if ply:GetPos():DistToSqr(v:GetPos()) < 300000 then
				net.Start( "helmetcmdopen" )
                    net.WriteString( file.Read("users/"..ply:SteamID64().."/name/name.txt", "data") )
                    net.WriteString( file.Read("users/"..ply:SteamID64().."/number/number.txt", "data") )
                    net.WriteString( file.Read("users/"..ply:SteamID64().."/legion/legion.txt", "data") )
				net.Send(v)
			end
            end
		    else
		    ply:SetBodyGroups( file.Read("users/"..ply:SteamID64().."/bodygroups/bodygroups.txt", "data") )
		    for i, v in ipairs( player.GetAll() ) do
            if ply:GetPos():DistToSqr(v:GetPos()) < 300000 then
				net.Start( "helmetcmdopen2" )
                    net.WriteString( file.Read("users/"..ply:SteamID64().."/name/name.txt", "data") )
                    net.WriteString( file.Read("users/"..ply:SteamID64().."/number/number.txt", "data") )
                    net.WriteString( file.Read("users/"..ply:SteamID64().."/legion/legion.txt", "data") )
				net.Send(v)
			end
            end
		    end
			return ""
		end
	end )
end )