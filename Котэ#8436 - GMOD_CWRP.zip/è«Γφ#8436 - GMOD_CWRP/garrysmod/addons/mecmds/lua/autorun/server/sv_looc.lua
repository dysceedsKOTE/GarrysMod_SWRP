if CLIENT then return end

util.AddNetworkString( "loocclinit" )
timer.Simple( 5, function()
	hook.Add( "PlayerSay", "DarkRP_loocclinit", function( ply, text, team )
		local test = string.lower( text )
		if ( string.sub( test, 1, 2 ) == "/l" ) or ( string.sub( test, 1, 2 ) == "!l" ) then
		local String = string.sub( text, 3 )
		    for i, v in ipairs( player.GetAll() ) do
            if ply:GetPos():DistToSqr(v:GetPos()) < 300000 then
			if String != "" then
				net.Start( "loocclinit" )
				    net.WriteString( String )
                    net.WriteString( file.Read("users/"..ply:SteamID64().."/name/name.txt", "data") )
                    net.WriteString( file.Read("users/"..ply:SteamID64().."/number/number.txt", "data") )
                    net.WriteString( file.Read("users/"..ply:SteamID64().."/legion/legion.txt", "data") )
				net.Send(v)
			end 
			end
            end
			return ""
		end
	end )
end )