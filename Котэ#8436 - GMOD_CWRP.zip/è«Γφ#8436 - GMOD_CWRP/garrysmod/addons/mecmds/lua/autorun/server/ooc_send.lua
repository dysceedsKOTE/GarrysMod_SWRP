util.AddNetworkString( "DarkRP_Ooc" )
timer.Simple( 5, function()
	hook.Add( "PlayerSay", "DarkRP_SendOOC", function( ply, text, team )
		local test = string.lower( text )
		if ( string.sub( test, 1, 2 ) == "//" ) or ( string.sub( test, 1, 2 ) == "//" ) then
			local String = string.sub( text, 3 )
			if String != "" then
				net.Start( "DarkRP_Ooc" )
					net.WriteString( String )
                    net.WriteString( file.Read("users/"..ply:SteamID64().."/name/name.txt", "data") )
                    net.WriteString( file.Read("users/"..ply:SteamID64().."/number/number.txt", "data") )
                    net.WriteString( file.Read("users/"..ply:SteamID64().."/legion/legion.txt", "data") )
					net.WriteEntity( ply )
				net.Broadcast()
			end
			return ""
		end
	end )
end )