const discord = require('discord.js');
const client = new discord.Client();
const fs = require('fs');
const buttonPressesLogFile = './garrysmod/data/logs/admin/log.txt';
const buttonPressesLogFile2 = './garrysmod/data/logs/witelist/log.txt';
const prlog = [];
const prlog2 = [];
const counc = [0];

setInterval(() => {
counc.unshift(fs.readFileSync("./garrysmod/data/logs/playercount/count.txt", "utf8"));
}, 15000);

setInterval(() => {
client.user.setActivity(counc[0] + "/128", { type: 'PLAYING' });
}, 15000);

fs.watch(buttonPressesLogFile, (event, filename) => {
 if (filename && event ==='change') {
 var lastlog = fs.readFileSync(buttonPressesLogFile, "utf8");
 if (prlog[0] == lastlog) return prlog.shift();
 prlog.unshift(lastlog);
  const exampleEmbed2 = new discord.MessageEmbed()
 	.setColor('#0099ff')
	.setDescription(lastlog)
	.setTimestamp();
 client.channels.cache.get('849789496514183208').send(exampleEmbed2);
}
});
console.log(`Слежу за изменениями ${buttonPressesLogFile}`);

fs.watch(buttonPressesLogFile2, (event, filename) => {
 if (filename && event ==='change') {
 var lastlog2 = fs.readFileSync(buttonPressesLogFile2, "utf8");
 if (prlog2[0] == lastlog2) return prlog2.shift();
 prlog2.unshift(lastlog2);
 const exampleEmbed = new discord.MessageEmbed()
 	.setColor('#0099ff')
	.setDescription(lastlog2)
	.setTimestamp();
 client.channels.cache.get('850088925270769727').send(exampleEmbed);
}
});
console.log(`Слежу за изменениями ${buttonPressesLogFile2}`);

client.login("")

// БОТ ДЛЯ ЛОГОВ В ДС, ОСТАВЬТЕ ПО ПУТИ КАК В АРХИВЕ.
// Котэ#8436